"""Start EXPORT DOCS MANAGEMENT.

Run:  .venv\\Scripts\\python.exe app.py   then open http://127.0.0.1:7860

Google Colab (ExportDocs_Colab.ipynb) calls the same steps one cell at a time:
    app.prepare_data(force_unlock=False)   # cell 4: lock, Drive → local copy, create / upgrade tables
    app.load_demo()                        # cell 5 (optional): the SAMPLE / DEMO shipment
    demo = app.build()                     # cell 6
    demo.launch(share=True, **app.launch_options())
    app.shutdown()                         # when the app is stopped: copy to Drive, remove the lock
"""

import os

from export_docs import __version__, database, drive_sync, reference, settings
from export_docs.ui import CSS, FORCE_LIGHT_JS, THEME, build_app


def prepare_data(force_unlock: bool = False) -> None:
    """Data folder, (Colab) lock + local working copy, tables, reference lists. Never adds demo data."""
    print(f"Phiên bản ứng dụng: {__version__}")
    settings.ensure_data_folders()
    for note in drive_sync.start(force_unlock=force_unlock):    # Colab only; raises DataLockedError if in use
        print(note)
    database.init_database()
    reference.ensure_seed()            # public UN/LOCODE port names for the pick lists (once)
    added = reference.import_from_shipments()   # carriers / ports / terminals / depots already used → lists
    if added:
        print(f"Added {added} carrier / port / terminal / depot names used in shipments to the Settings lists")
    drive_sync.flush()
    print(f"Data folder: {settings.DATA_DIR}")


def load_demo() -> None:
    """The one SAMPLE / DEMO shipment SHP-2026-0001 (created once; never changed afterwards)."""
    from export_docs.demo_data import (
        ensure_sample_bl, ensure_sample_booking, ensure_sample_eirs, ensure_sample_export_registration,
        ensure_sample_gatein, ensure_sample_routing_fix, ensure_sample_shipment, ensure_sample_si, ensure_sample_vgms,
    )
    sample_id = ensure_sample_shipment()
    sample_booking = ensure_sample_booking()
    sample_eirs = ensure_sample_eirs()
    sample_vgms = ensure_sample_vgms()
    sample_si = ensure_sample_si()
    if ensure_sample_routing_fix():
        print("Fixed SAMPLE routing (port to port: receipt = POL, delivery = POD, no pre-carriage)")
    if ensure_sample_gatein():
        print("Set up SAMPLE gate-in records (Step 5)")
    if ensure_sample_bl():
        print("Set up SAMPLE draft Bill of Lading (Step 6)")
    if ensure_sample_export_registration():
        print("SAMPLE gate-in: export registration recorded in the status timeline (Step 5)")
    if sample_eirs:
        print(f"Set up SAMPLE EIRs (Step 2) for {sample_eirs}")
    if sample_vgms:
        print(f"Set up SAMPLE VGMs (Step 3) for {sample_vgms}")
    if sample_si:
        print(f"Set up SAMPLE Shipping Instruction (Step 4) for {sample_si}")
    if sample_id:
        print(f"Created SAMPLE/DEMO shipment {sample_id}")
    if sample_booking:
        print(f"Added SAMPLE booking data (Step 1) to {sample_booking}")
    reference.import_from_shipments()
    drive_sync.flush()


def build():
    return build_app()


def launch_options() -> dict:
    """Everything demo.launch() needs besides share=… (theme, CSS, downloads from the data folder)."""
    options = dict(
        server_name=settings.SERVER_HOST,
        theme=THEME,
        css=CSS,
        js=FORCE_LIGHT_JS,
        # Let the browser download PDFs from the data folder (also on Google Drive)
        allowed_paths=[str(settings.DATA_DIR)],
    )
    if not settings.IS_COLAB or "EXPORT_DOCS_PORT" in os.environ:
        options["server_port"] = settings.SERVER_PORT    # Colab: Gradio picks a free port itself
    return options


def shutdown() -> None:
    """Copy the database to Drive one last time and remove the lock (Colab); nothing to do locally."""
    drive_sync.stop()


def main() -> None:
    prepare_data()
    if os.environ.get("EXPORT_DOCS_LOAD_DEMO", "1") != "0":
        load_demo()
    demo = build()
    try:
        demo.launch(share=settings.SHARE_LINK, **launch_options())
    finally:
        shutdown()


if __name__ == "__main__":
    main()
