"""Business logic.

Phase 1 holds the fixed business definitions shared by the whole app:
the six document steps and the main modules. Shipment logic (create, sync,
validate) is added here from Phase 2.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class DocumentStep:
    number: int
    key: str
    name_en: str          # document names stay in English
    name_vi: str          # Vietnamese explanation
    build_phase: int      # build phase from REQUIREMENTS.md §16


DOCUMENT_STEPS: tuple[DocumentStep, ...] = (
    DocumentStep(1, "booking", "Booking Confirmation", "Xác nhận đặt chỗ", 3),
    DocumentStep(2, "eir", "Empty Container EIR", "Phiếu EIR cấp container rỗng", 4),
    DocumentStep(3, "vgm", "VGM Declaration", "Phiếu xác nhận khối lượng toàn bộ container", 4),
    DocumentStep(4, "si", "Shipping Instruction (SI)", "Phiếu hướng dẫn lập vận đơn", 4),
    DocumentStep(5, "gatein", "Export Gate-in & Loading Registration",
                 "Xác nhận hạ bãi và đăng ký xuất tàu", 4),
    DocumentStep(6, "bl", "Bill of Lading (B/L)", "Vận đơn đường biển", 4),
)


@dataclass(frozen=True)
class Module:
    key: str
    label_vi: str
    label_en: str
    icon: str
    build_phase: int


# Main modules (REQUIREMENTS.md §3). The six document steps are listed separately.
MODULES: tuple[Module, ...] = (
    Module("dashboard", "Tổng quan", "Dashboard", "📊", 1),
    Module("shipments", "Quản lý lô hàng", "Shipment Management", "🚢", 2),
    Module("library", "Thư viện chứng từ", "Document Library", "📁", 6),
    Module("validation", "Trung tâm kiểm tra", "Validation Center", "✅", 5),
    Module("export", "Xuất chứng từ PDF", "Export Documents", "📄", 6),
    Module("history", "Lịch sử chứng từ", "Document History", "🕘", 5),
    Module("settings", "Cài đặt", "Settings", "⚙️", 6),
)

# Step status names (REQUIREMENTS.md §7), Vietnamese label + English term
STEP_STATUSES = (
    ("Not Started", "Chưa bắt đầu"),
    ("In Progress", "Đang thực hiện"),
    ("Completed", "Hoàn thành"),
    ("Needs Correction", "Cần chỉnh sửa"),
    ("Waiting for External Confirmation", "Chờ xác nhận bên ngoài"),
)

# Columns of the "recent shipments" table on the dashboard (REQUIREMENTS.md §3)
RECENT_SHIPMENT_COLUMNS = [
    "Shipment ID", "Booking No.", "Shipper", "Consignee", "POL", "POD",
    "Vessel/Voyage", "ETD", "Trạng thái", "Tiến độ (6 bước)",
]
