"""Google Colab: a local working copy of the database, kept in step with Google Drive, one session at a time.

Why: SQLite must not be written directly on Google Drive (Drive is a network folder — locking and the
WAL journal are not reliable there, the file can be corrupted). So, when settings.USE_LOCAL_COPY is on:

  start()   1. lock file in the Drive data folder → a second Colab session cannot open the same data
            2. copy the database Drive → Colab's local disk (the app works only on that copy)
  after every save (database.transaction commit) → the local copy is copied back to Drive
            (≈1 second later, so one save that writes several tables is copied once)
  flush()   copy now (used by backup, restore and stop)
  stop()    copy one last time and remove the lock

Copying back: a consistent snapshot is taken with SQLite's backup API on the LOCAL disk, copied to
"<name>.uploading" on Drive and then renamed over the old file — Drive never holds a half-written database.

The lock file holds who opened the data and a heartbeat (updated every minute). A lock whose heartbeat is
older than STALE_AFTER (the other session was disconnected) or that was left by an earlier run on this same
Colab computer is taken over automatically; otherwise the start is refused with a Vietnamese message.
Locally (Windows) none of this runs: the app uses the database in the data folder directly.
"""

import atexit
import json
import os
import shutil
import socket
import sqlite3
import threading
import time
import uuid
from contextlib import closing
from datetime import datetime, timedelta
from pathlib import Path

from . import settings

LOCK_NAME = "ExportDocs_DANG_MO.lock"
STALE_AFTER = timedelta(minutes=15)     # no heartbeat for this long → the other session has stopped
HEARTBEAT_SECONDS = 60
DEBOUNCE_SECONDS = 1.0                  # wait for the rest of one save before copying

SESSION_ID = uuid.uuid4().hex[:12]
HOST = socket.gethostname()

_cond = threading.Condition()
_push_lock = threading.Lock()
_state = {"started": False, "generation": 0, "pushed_generation": 0, "last_push": None, "last_error": None,
          "lost_lock": False, "thread": None, "stop": False}


class DataLockedError(RuntimeError):
    """The data folder is open in another Colab session."""


def enabled() -> bool:
    return settings.USE_LOCAL_COPY


def lock_path() -> Path:
    return settings.DATA_DIR / LOCK_NAME


def _unsynced_marker() -> Path:
    return settings.DATABASE_PATH.with_name(settings.DATABASE_PATH.name + ".unsynced")


def _now() -> datetime:
    return datetime.now().replace(microsecond=0)


def _fmt(dt: datetime | None) -> str:
    return dt.strftime("%Y-%m-%d %H:%M") if dt else "—"


# ---- lock -------------------------------------------------------------------------------------------------

def read_lock() -> dict | None:
    try:
        info = json.loads(lock_path().read_text(encoding="utf-8"))
        return info if isinstance(info, dict) else {}
    except FileNotFoundError:
        return None
    except (OSError, ValueError):
        return {}                                     # unreadable lock: still a lock


def _write_lock(started_at: str | None = None) -> None:
    info = {"session": SESSION_ID, "host": HOST, "pid": os.getpid(),
            "started_at": started_at or _now().isoformat(), "heartbeat_at": _now().isoformat(),
            "note": "EXPORT DOCS MANAGEMENT đang mở dữ liệu này. Đừng xóa file khi ứng dụng đang chạy."}
    tmp = lock_path().with_name(LOCK_NAME + ".tmp")
    tmp.write_text(json.dumps(info, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, lock_path())


def _parse(value) -> datetime | None:
    try:
        return datetime.fromisoformat(str(value))
    except (TypeError, ValueError):
        return None


def locked_message(info: dict) -> str:
    beat = _parse(info.get("heartbeat_at"))
    minutes = int((_now() - beat).total_seconds() // 60) if beat else None
    ago = f" ({minutes} phút trước)" if minutes is not None else ""
    return (
        "\n" + "=" * 72 + "\n"
        "⛔  DỮ LIỆU ĐANG ĐƯỢC MỞ Ở MỘT PHIÊN COLAB KHÁC\n"
        + "=" * 72 + "\n"
        f"Thư mục dữ liệu : {settings.DATA_DIR}\n"
        f"Mở lúc          : {_fmt(_parse(info.get('started_at')))}\n"
        f"Hoạt động cuối  : {_fmt(beat)}{ago}\n\n"
        "Để không bị mất hoặc ghi đè dữ liệu, ứng dụng KHÔNG mở ở phiên này.\n\n"
        "Cách xử lý:\n"
        "  1. Ở phiên Colab kia: bấm nút ■ (Dừng) ở ô 6, hoặc menu Runtime → Disconnect and delete runtime.\n"
        "     Sau đó quay lại đây và chạy lại ô 4.\n"
        f"  2. Nếu phiên kia đã bị ngắt, khóa tự hết hạn sau {int(STALE_AFTER.total_seconds() // 60)} phút "
        "không hoạt động — chờ rồi chạy lại ô 4.\n"
        "  3. Chỉ khi CHẮC CHẮN không còn phiên nào khác đang mở: ở ô 4 đặt MO_KHOA_CU = True rồi chạy lại.\n"
        + "=" * 72
    )


def acquire_lock(force: bool = False) -> str:
    """Take the lock. Returns a short note; raises DataLockedError when another session holds it."""
    info = read_lock()
    note = "Đã khóa dữ liệu cho phiên này."
    if info is not None:
        beat = _parse(info.get("heartbeat_at"))
        same_computer = info.get("host") == HOST
        stale = beat is None or _now() - beat > STALE_AFTER
        if force:
            note = "Đã mở khóa cũ theo yêu cầu (MO_KHOA_CU = True) và khóa lại cho phiên này."
        elif same_computer:
            note = "Khóa cũ là của lần chạy trước trên chính máy Colab này — đã nhận lại."
        elif stale:
            note = (f"Khóa cũ không hoạt động từ {_fmt(beat)} (phiên đó đã dừng) — đã nhận lại.")
        else:
            raise DataLockedError(locked_message(info))
    _write_lock()
    time.sleep(0.5)                                  # another session writing at the same moment?
    mine = read_lock() or {}
    if mine.get("session") != SESSION_ID:
        raise DataLockedError(locked_message(mine))
    return note


def holds_lock() -> bool:
    info = read_lock()
    return bool(info) and info.get("session") == SESSION_ID


def release_lock() -> None:
    if holds_lock():
        try:
            lock_path().unlink()
        except OSError:
            pass


# ---- copying ----------------------------------------------------------------------------------------------

def _snapshot(source: Path, target: Path) -> None:
    with closing(sqlite3.connect(source)) as src, closing(sqlite3.connect(target)) as dst:
        src.backup(dst)


def _check(path: Path) -> None:
    with closing(sqlite3.connect(path)) as conn:
        result = conn.execute("PRAGMA integrity_check").fetchone()[0]
    if result != "ok":
        raise RuntimeError(f"Cơ sở dữ liệu {path} bị lỗi: {result}")


def pull() -> str:
    """Drive → local. Returns what happened (Vietnamese)."""
    local, stored = settings.DATABASE_PATH, settings.STORED_DATABASE_PATH
    local.parent.mkdir(parents=True, exist_ok=True)
    if local.exists() and _unsynced_marker().exists():
        # an earlier run on THIS computer saved something that never reached Drive: the local copy is newer
        _check(local)
        push(force=True)
        return "Bản trên máy Colab có thay đổi chưa kịp chép lên Drive — đã chép lên Drive trước khi mở."
    for f in (local, local.with_name(local.name + "-wal"), local.with_name(local.name + "-shm")):
        if f.exists():
            f.unlink()
    if not stored.exists():
        return "Chưa có cơ sở dữ liệu trên Drive — sẽ tạo mới."
    tmp = local.with_name(local.name + ".download")
    shutil.copyfile(stored, tmp)
    _check(tmp)
    os.replace(tmp, local)
    size = local.stat().st_size / 1024
    return f"Đã chép cơ sở dữ liệu từ Drive về máy Colab ({size:,.0f} KB)."


def push(force: bool = False) -> bool:
    """Local → Drive (consistent snapshot, then rename). Returns True when copied."""
    with _push_lock:
        generation = _state["generation"]
        if not force and generation == _state["pushed_generation"]:
            return False
        if _state["started"] and not holds_lock():
            _state["lost_lock"] = True
            _state["last_error"] = ("Khóa dữ liệu trên Drive không còn là của phiên này (một phiên khác đã mở "
                                    "dữ liệu). Thay đổi mới KHÔNG được chép lên Drive.")
            print("⚠️ " + _state["last_error"])
            return False
        local, stored = settings.DATABASE_PATH, settings.STORED_DATABASE_PATH
        if not local.exists():
            return False
        snap = local.with_name(local.name + ".snapshot")
        _snapshot(local, snap)
        stored.parent.mkdir(parents=True, exist_ok=True)
        uploading = stored.with_name(stored.name + ".uploading")
        shutil.copyfile(snap, uploading)
        os.replace(uploading, stored)
        snap.unlink(missing_ok=True)
        _state["pushed_generation"] = generation
        _state["last_push"] = _now()
        _state["last_error"] = None
        if generation == _state["generation"]:
            _unsynced_marker().unlink(missing_ok=True)
        if _state["started"]:
            _write_lock(started_at=(read_lock() or {}).get("started_at"))
        return True


def after_commit() -> None:
    """Called by database.transaction() after every successful save."""
    if not enabled():
        return
    with _cond:
        _state["generation"] += 1
        try:
            _unsynced_marker().touch()
        except OSError:
            pass
        _cond.notify_all()


def flush() -> bool:
    """Copy to Drive now if anything changed (backup, restore, stop)."""
    if not enabled():
        return False
    try:
        return push()
    except Exception as exc:                          # noqa: BLE001 — shown to the user, retried later
        _state["last_error"] = f"Chưa chép được lên Drive: {exc}"
        print("⚠️ " + _state["last_error"])
        return False


def _worker() -> None:
    last_beat = time.monotonic()
    while not _state["stop"]:
        with _cond:
            _cond.wait(timeout=5)
        if _state["stop"]:
            break
        if _state["generation"] != _state["pushed_generation"]:
            time.sleep(DEBOUNCE_SECONDS)
            flush()
            last_beat = time.monotonic()
        elif time.monotonic() - last_beat >= HEARTBEAT_SECONDS:
            try:
                if holds_lock():
                    _write_lock(started_at=(read_lock() or {}).get("started_at"))
                elif not _state["lost_lock"]:
                    _state["lost_lock"] = True
                    print("⚠️ Khóa dữ liệu trên Drive đã bị một phiên khác nhận. Hãy dừng ứng dụng ở phiên này.")
            except OSError as exc:
                print(f"⚠️ Không cập nhật được khóa trên Drive: {exc}")
            last_beat = time.monotonic()


def start(force_unlock: bool = False) -> list[str]:
    """Lock + copy Drive → local + start copying back after every save. Returns notes to print."""
    if not enabled():
        return []
    if _state["started"]:
        return ["Đồng bộ Drive đã chạy trong phiên này."]
    settings.ensure_data_folders()
    notes = [acquire_lock(force=force_unlock)]
    try:
        notes.append(pull())
    except Exception:
        release_lock()
        raise
    _state.update(started=True, stop=False, lost_lock=False)
    thread = threading.Thread(target=_worker, name="drive-sync", daemon=True)
    _state["thread"] = thread
    thread.start()
    atexit.register(stop)
    return notes


def stop() -> None:
    """Copy one last time and remove the lock."""
    if not enabled() or not _state["started"]:
        return
    _state["stop"] = True
    with _cond:
        _cond.notify_all()
    flush()
    release_lock()
    _state["started"] = False


def status() -> dict:
    return {"enabled": enabled(), "started": _state["started"], "last_push": _fmt(_state["last_push"]),
            "unsynced": _state["generation"] != _state["pushed_generation"], "last_error": _state["last_error"],
            "lost_lock": _state["lost_lock"], "stored": str(settings.STORED_DATABASE_PATH),
            "working_copy": str(settings.DATABASE_PATH)}
