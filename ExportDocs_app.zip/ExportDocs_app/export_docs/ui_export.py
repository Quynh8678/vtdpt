"""Export page ("Xuất chứng từ PDF") — combined PDF, ZIP of separate PDFs, JSON (REQUIREMENTS.md §12)."""

import gradio as gr

from . import exporter as X
from . import shipments as S
from .services import STEP_STATUSES
from .ui_common import STEP_STATUS_COLOURS, e, message_html, notice_html, page_title_html, section_title_html

DOC_CHOICES = [(X.display_name(d[1]), d[0]) for d in X.DOCUMENTS]


def documents_html(result: dict) -> str:
    vi = dict(STEP_STATUSES)
    rows = []
    for d in result["documents"]:
        colour = STEP_STATUS_COLOURS.get(d["step_status"], "#CBD3DF")
        will = d["doc_type"] in result["export"]
        rows.append(
            f"<tr><td><b>{e(d['set_name'][:2])}</b></td><td><b>{e(X.display_name(d['set_name'])[3:])}</b>"
            f"<div class='hint'>{e(d['name_vi'])}</div></td><td>{e(d['version'])}</td><td>{e(d['status'])}</td>"
            f"<td><span class='pill' style='border-color:{colour}'><i class='dot' style='background:{colour}'></i>"
            f"{e(vi.get(d['step_status'], d['step_status']))}</span></td>"
            f"<td>{'✅ có trong bộ xuất' if will else ('— chưa có chứng từ' if not d['exists'] else '— không chọn / bỏ qua')}"
            "</td></tr>")
    return ('<div class="table-wrap"><table class="grid"><tr><th>#</th><th>Chứng từ</th><th>Phiên bản</th>'
            '<th>Trạng thái chứng từ</th><th>Bước (6-step)</th><th>Xuất</th></tr>' + "".join(rows) + "</table></div>")


def warnings_html(result: dict) -> str:
    parts = []
    if result["incomplete"]:
        parts.append(message_html("warning", "Bộ chứng từ chưa đầy đủ — các bước chưa hoàn thành (vẫn xuất được, "
                                             "chứng từ chưa xong được ghi rõ DRAFT / INTERNAL):", result["incomplete"]))
    else:
        parts.append(message_html("success", "Cả 6 bước đã hoàn thành."))
    extra = [w for w in result["warnings"] if "PDF vẫn xuất" not in w]     # incomplete steps are listed above
    if extra:
        parts.append(message_html("info", "Bộ xuất lần này:", extra))
    return "".join(parts)


def build_export_page():
    gr.HTML(page_title_html("Xuất chứng từ PDF", "Export Documents — PDF gộp, ZIP từng PDF, JSON dữ liệu lô hàng"))
    gr.HTML(notice_html(
        "Chọn lô hàng và các chứng từ cần xuất. <b>PDF gộp</b>: trang bìa + chứng từ theo thứ tự cố định "
        "01 Booking → 06 B/L, mỗi chứng từ giữ số trang và footer riêng. <b>ZIP</b>: từng PDF, đánh số theo thứ tự 01_ … 06_, tên "
        "<code>ShipmentID_BookingNumber_DocumentName_Version.pdf</code>. <b>JSON</b>: toàn bộ dữ liệu lô hàng. "
        "Mọi bản xuất được lưu trong thư mục dữ liệu (<code>exports/</code>), có trong <b>Thư viện chứng từ</b> và "
        "được ghi vào <b>Lịch sử</b>. Xuất không thay đổi chứng từ nào."))
    with gr.Row():
        ship_dd = gr.Dropdown(label="Chọn lô hàng (Shipment)", choices=[], scale=3)
        check_btn = gr.Button("🔍 Kiểm tra bộ chứng từ", scale=1)
    docs_cb = gr.CheckboxGroup(label="Chứng từ đưa vào bộ xuất", choices=DOC_CHOICES, value=[d[0] for d in X.DOCUMENTS])
    only_done = gr.Checkbox(label="Chỉ xuất chứng từ ở bước đã hoàn thành (Completed)", value=False)
    gr.HTML(section_title_html("Kiểm tra trước khi xuất", "Documents, version, status — and incomplete steps"))
    warn = gr.HTML()
    table = gr.HTML()
    with gr.Row():
        pdf_btn = gr.Button("📕 Xuất PDF gộp (combined)", variant="primary")
        zip_btn = gr.Button("🗜 Xuất ZIP các PDF")
        json_btn = gr.Button("🧾 Xuất JSON dữ liệu lô hàng")
    msg = gr.HTML()
    out_file = gr.File(label="File vừa xuất (bấm để tải)", interactive=False)
    preview = gr.Gallery(label="Xem trước PDF gộp (trang bìa + vài trang đầu)", columns=3, height=420, visible=False)

    def inspect(shipment_id, selected, only):
        if not shipment_id:
            return notice_html("Chọn một lô hàng."), ""
        try:
            result = X.check(shipment_id, selected or [], bool(only))
        except S.ShipmentError as ex:
            return message_html("error", "Không kiểm tra được.", ex.errors), ""
        return warnings_html(result), documents_html(result)

    def run(kind, shipment_id, selected, only):
        if not shipment_id:
            return message_html("warning", "Chọn một lô hàng trước."), None, gr.update(visible=False), *inspect(None, [], False)
        try:
            if kind == "pdf":
                path, result = X.export_combined_pdf(shipment_id, selected or [], bool(only))
                from .pdf_generator import render_pdf_pages
                images = render_pdf_pages(path.read_bytes(), 1.0)[:6]
                text = (f"Đã xuất PDF gộp: {path.name} — trang bìa + {len(result['export'])} chứng từ "
                        f"({sum(b - a + 1 for a, b in result['pages'].values()) + result['cover_pages']} trang).")
                gallery = gr.update(value=images, visible=True)
            elif kind == "zip":
                path, result = X.export_zip(shipment_id, selected or [], bool(only))
                text = f"Đã xuất ZIP: {path.name} — " + ", ".join(result["files"])
                gallery = gr.update(visible=False)
            else:
                path, _ = X.export_json(shipment_id)
                text = f"Đã xuất JSON: {path.name}"
                gallery = gr.update(visible=False)
        except S.ShipmentError as ex:
            return message_html("error", "Chưa xuất được.", ex.errors), None, gr.update(visible=False), \
                *inspect(shipment_id, selected, only)
        return (message_html("success", text + " Đã lưu trong Thư viện chứng từ và ghi vào Lịch sử."), str(path),
                gallery, *inspect(shipment_id, selected, only))

    inputs = [ship_dd, docs_cb, only_done]
    for comp in (ship_dd, docs_cb, only_done):
        comp.input(inspect, inputs, [warn, table])
    ship_dd.input(S.remember_opened, ship_dd, None)
    check_btn.click(inspect, inputs, [warn, table])
    outputs = [msg, out_file, preview, warn, table]
    pdf_btn.click(lambda *a: run("pdf", *a), inputs, outputs)
    zip_btn.click(lambda *a: run("zip", *a), inputs, outputs)
    json_btn.click(lambda *a: run("json", *a), inputs, outputs)

    def refresh(chosen=None):
        ships = [(f"{r['shipment_id']} · {r.get('customer_name') or r.get('shipper_name') or ''}", r["shipment_id"])
                 for r in S.list_shipments()]
        ids = [s[1] for s in ships]
        value = S.default_shipment(ids)             # the shipment opened last, else SHP-2026-0001
        return [gr.update(choices=ships, value=value), *inspect(value, [d[0] for d in X.DOCUMENTS], False)]

    return [ship_dd], [ship_dd, warn, table], refresh
