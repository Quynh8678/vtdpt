"""Step 2 — Empty Container EIR business logic (REQUIREMENTS.md §5 Step 2, §6, §7).

One EIR record per container.

Data sync rule (§6):
- Booking number, carrier, planned pick-up depot and date come from `shipments`
  (read-only in Step 2; edited at the source).
- Container number, size, ISO type, container type, truck, chassis and the depot's
  EIR number are saved to the central `containers` table, so Steps 3–6 see them.
- Only EIR facts (date/time, actual depot, status at handover, driver, checklist,
  remarks) are stored in `eir_records`.

Honesty rules:
- The app never creates a depot EIR number. Without one, the record uses an internal
  reference EIR-INT-<ShipmentID>-<n> and is labelled INTERNAL EIR RECORD.
- With the depot's EIR number entered by the user, it is labelled REFERENCE COPY
  (a copy of data from the depot's EIR — not the depot's original document).
- Saving a draft is always allowed; problems are warnings.
"""

import re
from dataclasses import dataclass, field

from . import shipments as S
from .database import reading, transaction
from .tracking import tracked

CONDITION_AREAS = (
    ("floor", "Floor", "Sàn"),
    ("roof", "Roof", "Nóc"),
    ("left_side", "Left side", "Vách trái"),
    ("right_side", "Right side", "Vách phải"),
    ("front_wall", "Front wall", "Vách trước"),
    ("door", "Door", "Cửa"),
    ("door_seals", "Door seals / gaskets", "Gioăng cửa"),
)
CONDITION_VALUES = {"OK": "OK", "DAMAGED": "Hư hỏng (Damaged)", "NOT_CHECKED": "Chưa kiểm tra (Not checked)"}

EIR_STATUSES = {"Not Started": "Chưa bắt đầu", "Draft": "Nháp", "Completed": "Hoàn thành"}
HANDOVER_STATUSES = ("Empty", "Full")

# Saved to the central `containers` table
CONTAINER_FIELDS = ("container_number", "container_size", "iso_type_code", "container_type",
                    "truck_number", "chassis_number", "eir_number")
# Saved to `eir_records`
EIR_FIELDS = ("eir_datetime", "depot_yard", "handover_load_status", "driver_info", "handover_info",
              "damage_remarks",
              *(f"cond_{k}" for k, _, _ in CONDITION_AREAS), *(f"note_{k}" for k, _, _ in CONDITION_AREAS))


class EIRError(S.ShipmentError):
    pass


@dataclass
class EIRSaveResult:
    container_id: int
    internal_reference: str
    status: str
    created: bool
    warnings: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------
def _empty_eir() -> dict:
    data = {k: None for k in EIR_FIELDS}
    data.update({f"cond_{k}": "NOT_CHECKED" for k, _, _ in CONDITION_AREAS})
    data.update(handover_load_status="Empty", internal_reference=None, doc_version=1,
                last_pdf_path=None, last_pdf_at=None, created_at=None, updated_at=None)
    return data


def get_shipment_eirs(shipment_id: str) -> dict | None:
    """Central shipment data + every container with its EIR record (or None) and status."""
    ship = S.get_shipment(shipment_id)
    if not ship:
        return None
    with reading() as conn:
        records = {r["container_fk"]: dict(r) for r in conn.execute(
            "SELECT * FROM eir_records WHERE shipment_fk = ?", (ship["id"],))}
    items = []
    for n, c in enumerate(ship["containers"], start=1):
        record = records.get(c["id"])
        items.append({"no": n, "container": c, "eir": record, "status": eir_status(ship, c, record)})
    return {"shipment": ship, "items": items}


def find_item(overview: dict, container_id: int) -> dict | None:
    return next((i for i in overview["items"] if i["container"]["id"] == container_id), None)


def effective_depot(ship: dict, record: dict | None) -> str | None:
    """Actual depot of the EIR, or the planned pick-up depot from Step 1 when not overridden."""
    return (record or {}).get("depot_yard") or ship.get("empty_pickup_depot")


def missing_for_completion(ship: dict, container: dict, record: dict | None) -> list[str]:
    if not record:
        return ["Chưa có EIR"]
    missing = []
    if not container.get("container_number"):
        missing.append("Container number")
    if not record.get("eir_datetime"):
        missing.append("EIR date/time")
    if not effective_depot(ship, record):
        missing.append("Depot/Yard")
    unchecked = [en for k, en, _ in CONDITION_AREAS if (record.get(f"cond_{k}") or "NOT_CHECKED") == "NOT_CHECKED"]
    if unchecked:
        missing.append("Chưa kiểm tra: " + ", ".join(unchecked))
    if damaged_areas(record) and not (record.get("damage_remarks") or "").strip():
        missing.append("Damage / Condition Remarks (bắt buộc khi có hạng mục hư hỏng)")
    return missing


DAMAGE_ADVICE = "Container damaged — consider requesting a replacement from the depot."


def damaged_areas(record: dict | None) -> list[dict]:
    """Checklist areas marked DAMAGED, in checklist order, with their notes."""
    if not record:
        return []
    return [{"key": k, "en": en, "vi": vi, "note": (record.get(f"note_{k}") or "").strip() or None}
            for k, en, vi in CONDITION_AREAS if record.get(f"cond_{k}") == "DAMAGED"]


def damage_warning(record: dict | None) -> str | None:
    """The replacement advice + the damaged areas, or None when nothing is damaged."""
    areas = damaged_areas(record)
    if not areas:
        return None
    return f"{DAMAGE_ADVICE} Damaged: " + ", ".join(a["en"] for a in areas) + "."


def eir_status(ship: dict, container: dict, record: dict | None) -> str:
    if not record:
        return "Not Started"
    return "Completed" if not missing_for_completion(ship, container, record) else "Draft"


def document_label(ship: dict, container: dict, record: dict) -> dict:
    """INTERNAL EIR RECORD unless the depot's own EIR number was entered (→ REFERENCE COPY)."""
    depot_no = container.get("eir_number")
    if depot_no:
        label = dict(kind="reference", title="EIR — REFERENCE COPY", badge="REFERENCE COPY",
                     reference=depot_no, reference_label="Depot EIR No.",
                     note=(f"Reference copy of data from the depot's EIR No. {depot_no}, entered by the user. "
                           "Not the depot's original document — the depot's original EIR prevails."))
    else:
        label = dict(kind="internal", title="INTERNAL EIR RECORD", badge="INTERNAL EIR RECORD",
                     reference=record["internal_reference"], reference_label="Internal Reference",
                     note=("Internal record prepared by the shipper/forwarder. No depot EIR number has been "
                           "recorded; this is NOT the depot's equipment interchange receipt."))
    label["sample"] = bool(ship["is_sample"])
    label["sample_text"] = S.sample_text(ship)
    return label


def step_status(shipment_id: str) -> str:
    """Step 2 in the 6-step progress: Completed only when EVERY container has a completed EIR."""
    overview = get_shipment_eirs(shipment_id)
    if not overview or not overview["items"]:
        return "Not Started"
    statuses = [i["status"] for i in overview["items"]]
    if all(s == "Completed" for s in statuses):
        return "Completed"
    if all(s == "Not Started" for s in statuses):
        return "Not Started"
    return "In Progress"


def count_eirs() -> int:
    with reading() as conn:
        return conn.execute("SELECT COUNT(*) FROM eir_records").fetchone()[0]


# ---------------------------------------------------------------------------
# Save
# ---------------------------------------------------------------------------
def _next_internal_reference(conn, fk: int, shipment_id: str) -> str:
    prefix = f"EIR-INT-{shipment_id}-"
    rows = conn.execute("SELECT internal_reference FROM eir_records WHERE shipment_fk = ?", (fk,)).fetchall()
    used = [int(r[0].rsplit("-", 1)[1]) for r in rows if r[0].startswith(prefix) and r[0].rsplit("-", 1)[1].isdigit()]
    return f"{prefix}{max(used, default=0) + 1}"


@tracked("EIR")
def save_eir(shipment_id: str, container_id: int | None, container_values: dict, eir_values: dict) -> EIRSaveResult:
    """Save one EIR. container_id=None adds a new container to the central containers table.

    Raises EIRError only for real data errors; everything else is a warning.
    """
    errors, warnings = [], []

    # --- container (central) ---
    cont = {k: S.clean_text(container_values.get(k)) for k in CONTAINER_FIELDS}
    cont["container_number"] = S.normalize_container_number(cont["container_number"])
    if cont["container_number"]:
        problem = S.container_number_problem(cont["container_number"])
        if problem:
            warnings.append(f"Container {cont['container_number']}: {problem}.")
    if cont["container_size"]:
        size = re.sub(r"(?i)\s*(ft|feet|'|’)$", "", cont["container_size"])
        if size not in S.CONTAINER_SIZES:
            errors.append("Size phải là 20, 40 hoặc 45.")
        cont["container_size"] = size
    if cont["iso_type_code"]:
        cont["iso_type_code"] = cont["iso_type_code"].upper()
    if cont["eir_number"]:
        cont["eir_number"] = cont["eir_number"].upper()

    # --- EIR record ---
    rec = {k: S.clean_text(eir_values.get(k)) for k in EIR_FIELDS}
    rec["eir_datetime"] = S.parse_when(eir_values.get("eir_datetime"), True, "EIR date/time", errors)
    rec["handover_load_status"] = rec["handover_load_status"] or "Empty"
    if rec["handover_load_status"] not in HANDOVER_STATUSES:
        errors.append("Full/Empty phải là “Empty” hoặc “Full”.")
    for key, en, _ in CONDITION_AREAS:
        value = rec[f"cond_{key}"] or "NOT_CHECKED"
        if value not in CONDITION_VALUES:
            errors.append(f"{en}: tình trạng không hợp lệ.")
        rec[f"cond_{key}"] = value
    if errors:
        raise EIRError(errors)

    stamp = S.now_text()
    with transaction() as conn:
        ship_row = conn.execute("SELECT id, empty_pickup_depot FROM shipments WHERE shipment_id = ?",
                                (shipment_id,)).fetchone()
        if not ship_row:
            raise EIRError([f"Không tìm thấy lô hàng {shipment_id}."])
        fk = ship_row["id"]
        # actual depot equal to the planned depot → keep one copy (NULL = same as planned)
        if rec["depot_yard"] and rec["depot_yard"] == (ship_row["empty_pickup_depot"] or ""):
            rec["depot_yard"] = None

        # duplicate container number within this shipment = data error
        if cont["container_number"]:
            dup = conn.execute(
                "SELECT id FROM containers WHERE shipment_fk = ? AND container_number = ? AND id != ?",
                (fk, cont["container_number"], container_id or -1)).fetchone()
            if dup:
                raise EIRError([f"Container {cont['container_number']} đã có trong lô hàng này."])
            others = conn.execute(
                "SELECT DISTINCT s.shipment_id FROM containers c JOIN shipments s ON s.id = c.shipment_fk "
                "WHERE c.container_number = ? AND s.id != ? AND s.status IN (" + ",".join("?" * len(S.ACTIVE_STATUSES)) + ")",
                (cont["container_number"], fk, *S.ACTIVE_STATUSES)).fetchall()
            if others:
                warnings.append(f"Container {cont['container_number']} cũng có trong lô hàng đang xử lý: "
                                + ", ".join(r[0] for r in others) + ".")

        if container_id is None:
            cur = conn.execute(
                f"INSERT INTO containers (shipment_fk, load_status, {', '.join(CONTAINER_FIELDS)}) "
                f"VALUES (?, 'Full', {', '.join('?' * len(CONTAINER_FIELDS))})",
                [fk, *(cont[k] for k in CONTAINER_FIELDS)])
            container_id = cur.lastrowid
        else:
            owner = conn.execute("SELECT shipment_fk FROM containers WHERE id = ?", (container_id,)).fetchone()
            if not owner or owner[0] != fk:
                raise EIRError(["Container không thuộc lô hàng này."])
            conn.execute(f"UPDATE containers SET {', '.join(f'{k} = ?' for k in CONTAINER_FIELDS)} WHERE id = ?",
                         [*(cont[k] for k in CONTAINER_FIELDS), container_id])
        conn.execute("UPDATE shipments SET updated_at = ? WHERE id = ?", (stamp, fk))

        existing = conn.execute("SELECT internal_reference FROM eir_records WHERE container_fk = ?",
                                (container_id,)).fetchone()
        if existing:
            reference = existing[0]
            conn.execute(f"UPDATE eir_records SET {', '.join(f'{k} = ?' for k in EIR_FIELDS)}, updated_at = ? "
                         f"WHERE container_fk = ?", [*(rec[k] for k in EIR_FIELDS), stamp, container_id])
        else:
            reference = _next_internal_reference(conn, fk, shipment_id)
            cols = ["shipment_fk", "container_fk", "internal_reference", *EIR_FIELDS, "created_at", "updated_at"]
            conn.execute(f"INSERT INTO eir_records ({', '.join(cols)}) VALUES ({', '.join('?' * len(cols))})",
                         [fk, container_id, reference, *(rec[k] for k in EIR_FIELDS), stamp, stamp])

    overview = get_shipment_eirs(shipment_id)
    item = find_item(overview, container_id)
    missing = missing_for_completion(overview["shipment"], item["container"], item["eir"])
    if missing:
        warnings.insert(0, "Chưa đủ để Hoàn thành: " + "; ".join(missing) + ".")
    advice = damage_warning(rec)
    if advice:
        warnings.append(advice)
    if not cont["eir_number"]:
        warnings.append(f"Chưa có số EIR của depot — chứng từ sẽ là INTERNAL EIR RECORD ({reference}).")
    return EIRSaveResult(container_id=container_id, internal_reference=reference, status=item["status"],
                         created=existing is None, warnings=warnings)


@tracked("EIR")
def delete_eir(shipment_id: str, container_id: int) -> str:
    """Delete one EIR record (the container itself stays). Returns its internal reference."""
    with transaction() as conn:
        fk = S.get_shipment_fk(conn, shipment_id)
        row = conn.execute("SELECT internal_reference FROM eir_records WHERE container_fk = ? AND shipment_fk = ?",
                           (container_id, fk)).fetchone()
        if not row:
            raise EIRError(["Container này chưa có EIR."])
        conn.execute("DELETE FROM eir_records WHERE container_fk = ?", (container_id,))
        conn.execute("UPDATE shipments SET updated_at = ? WHERE id = ?", (S.now_text(), fk))
    return row[0]


def record_pdf_export(container_ids: list[int], path: str) -> None:
    stamp = S.now_text()[:16]
    with transaction() as conn:
        for cid in container_ids:
            conn.execute("UPDATE eir_records SET last_pdf_path = ?, last_pdf_at = ? WHERE container_fk = ?",
                         (path, stamp, cid))
