"""Step 6 — Bill of Lading (draft) business logic (REQUIREMENTS.md §5 Step 6, §6, §7).

The B/L inherits from the SI:
- its PARTICULARS (parties, routing, vessel/voyage, cargo lines, containers, seals) are copied from
  the SI when the B/L is created and stored as the B/L's own text (what the B/L says). They are
  compared with the SI; every difference is listed with both values and resolved only by the user
  ("use SI value"). Nothing is fixed automatically.
- freight terms, payable at, B/L type, number of originals, booking and carrier are read live
  from the SI / central data.
Only B/L-specific fields are new: draft reference, carrier B/L number (typed by the user), place and
date of issue, shipped-on-board date, on-board notation, remarks.

Honesty rules:
- Never an invented B/L number: the "Draft ref." is used until the user types the carrier's number.
- "SHIPPED ON BOARD" only when every container is "Loaded on Board" in Step 5; otherwise
  "RECEIVED FOR SHIPMENT" and no on-board date.
- "B/L Issued" / "Released" / "Amended" need the carrier's B/L number AND an uploaded carrier document.
  Until then every page says DRAFT BILL OF LADING — NOT NEGOTIABLE / INTERNAL PREVIEW.
"""

import json
import re
import shutil
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from . import gatein as G
from . import settings
from . import shipments as S
from . import si as SI
from .database import reading, transaction
from .tracking import tracked
from .formatting import fmt_cbm, fmt_count, fmt_kg

STATUSES = ("Draft", "Draft Sent for Review", "Draft Approved", "Issued", "Released", "Amended")
STATUS_LABELS = {
    "Not Started": ("B/L Not Started", "Chưa bắt đầu"),
    "Draft": ("B/L Draft", "Bản nháp"),
    "Draft Sent for Review": ("Draft Sent for Review", "Đã gửi nháp để duyệt"),
    "Draft Approved": ("Draft Approved", "Nháp đã được duyệt"),
    "Issued": ("B/L Issued", "Hãng tàu đã phát hành"),
    "Released": ("B/L Released", "Đã giải phóng (release)"),
    "Amended": ("B/L Amended", "Đã sửa đổi"),
}
CARRIER_STATES = ("Issued", "Released", "Amended")      # need carrier B/L number + carrier document
# allowed previous statuses for each target
TRANSITIONS = {
    "Draft Sent for Review": ("Draft", "Draft Approved"),
    "Draft Approved": ("Draft Sent for Review",),
    "Issued": ("Draft Approved", "Draft Sent for Review", "Draft"),
    "Released": ("Issued", "Amended"),
    "Amended": ("Issued", "Released"),
    "Draft": ("Draft Sent for Review", "Draft Approved"),
}
DOCUMENT_TYPES = (".pdf", ".jpg", ".jpeg", ".png")
NEUTRAL_TERMS = "Subject to the carrier's standard terms and conditions of carriage, available from the carrier."

TEXT_FIELDS = ("carrier_bl_number", "place_of_issue", "remarks")
DATE_FIELDS = ("date_of_issue", "shipped_on_board_date")
SCALAR_KEYS = (("shipper", "Shipper"), ("consignee", "Consignee"), ("notify", "Notify Party"),
               ("port_of_loading", "Port of Loading (POL)"), ("port_of_discharge", "Port of Discharge (POD)"),
               ("vessel_voyage", "Vessel / Voyage"))


class BLError(S.ShipmentError):
    pass


@dataclass
class BLResult:
    shipment_id: str
    status: str
    done: bool = True
    warnings: list[str] = field(default_factory=list)


def status_label(status: str) -> str:
    return STATUS_LABELS.get(status, (status, status))[0]


# ---------------------------------------------------------------------------
# Numbers in words (B/L style: "ONE THOUSAND FIVE HUNDRED FORTY")
# ---------------------------------------------------------------------------
_ONES = ("ZERO ONE TWO THREE FOUR FIVE SIX SEVEN EIGHT NINE TEN ELEVEN TWELVE THIRTEEN FOURTEEN FIFTEEN "
         "SIXTEEN SEVENTEEN EIGHTEEN NINETEEN").split()
_TENS = "_ _ TWENTY THIRTY FORTY FIFTY SIXTY SEVENTY EIGHTY NINETY".split()


def number_to_words(n: int) -> str:
    n = int(n)
    if n < 0:
        return "MINUS " + number_to_words(-n)
    if n < 20:
        return _ONES[n]
    if n < 100:
        return _TENS[n // 10] + (f"-{_ONES[n % 10]}" if n % 10 else "")
    if n < 1000:
        return f"{_ONES[n // 100]} HUNDRED" + (f" {number_to_words(n % 100)}" if n % 100 else "")
    for size, name in ((10 ** 9, "BILLION"), (10 ** 6, "MILLION"), (1000, "THOUSAND")):
        if n >= size:
            return f"{number_to_words(n // size)} {name}" + (f" {number_to_words(n % size)}" if n % size else "")
    return str(n)


def count_in_words(n: int | None) -> str:
    """3 → 'THREE (3)'."""
    return f"{number_to_words(n)} ({fmt_count(n)})" if n is not None else "—"


# ---------------------------------------------------------------------------
# Particulars (what the B/L says) — built from the SI
# ---------------------------------------------------------------------------
def _party_text(ship: dict, role: str) -> str:
    p = SI.party(ship, role)
    return "\n".join(x for x in (p.get("party_name"), p.get("address"), p.get("country")) if x)


def build_particulars(si_view: dict) -> dict:
    """The SI's particulars in B/L form (this is "the SI value" in every comparison)."""
    ship, si = si_view["shipment"], si_view["si"]
    t = SI.totals(si_view)
    lines_by_id = {l["id"]: l for l in ship["cargo"]}
    containers = []
    for c in ship["containers"]:
        got = t["per_container"][c["id"]]
        types = {(lines_by_id[a["cargo_fk"]].get("package_type") or "").upper()
                 for a in si_view["allocations"] if a["container_fk"] == c["id"] and a["cargo_fk"] in lines_by_id}
        containers.append({
            "container_number": c.get("container_number"), "seal_number": c.get("seal_number"),
            "size_type": " ".join(x for x in (f"{c['container_size']}'" if c.get("container_size") else None,
                                              c.get("iso_type_code")) if x),
            "package_count": got["packages"] if got["lines"] else None,
            "package_unit": types.pop() if len(types) == 1 and "" not in types else "PKGS",
            "gross_weight_kg": round(got["gross"], 3) if got["lines"] else None,
            "volume_cbm": round(got["cbm"], 3) if got["lines"] else None,
        })
    also = "\n".join(x for x in (si.get("additional_notify_name"), si.get("additional_notify_address")) if x)
    return {
        "shipper": _party_text(ship, "SHIPPER"), "consignee": _party_text(ship, "CONSIGNEE"),
        "notify": _party_text(ship, "NOTIFY_PARTY"), "also_notify": also,
        "pre_carriage": si.get("pre_carriage"), "place_of_receipt": ship.get("place_of_receipt"),
        "vessel_name": ship.get("vessel_name"), "voyage_number": ship.get("voyage_number"),
        "port_of_loading": ship.get("port_of_loading"), "port_of_discharge": ship.get("port_of_discharge"),
        "transshipment_port": ship.get("transshipment_port"), "place_of_delivery": ship.get("place_of_delivery"),
        "cargo": [{"marks": l.get("marks_and_numbers"), "package_count": l.get("package_count"),
                   "package_type": l.get("package_type"), "description": l.get("cargo_description") or l.get("commodity"),
                   "hs_code": l.get("hs_code"), "gross_weight_kg": l.get("gross_weight_kg"),
                   "volume_cbm": l.get("volume_cbm")} for l in ship["cargo"]],
        "containers": containers,
    }


def all_loaded_on_board(shipment_id: str) -> tuple[bool, list[str]]:
    """(True, []) when every container is "Loaded on Board" in Step 5; else the containers that are not."""
    overview = G.get_shipment_gateins(shipment_id)
    if not overview or not overview["items"]:
        return False, ["(chưa có container)"]
    missing = [i["container"].get("container_number") or f"#{i['no']}" for i in overview["items"]
               if not G.is_active(i, "LOADED_ON_BOARD")]
    return not missing, missing


def get_bl_view(shipment_id: str) -> dict | None:
    si_view = SI.get_si_view(shipment_id)
    if not si_view:
        return None
    ship = si_view["shipment"]
    with reading() as conn:
        row = conn.execute("SELECT * FROM bl_records WHERE shipment_fk = ?", (ship["id"],)).fetchone()
        documents = [dict(r) for r in conn.execute("SELECT * FROM bl_documents WHERE shipment_fk = ? ORDER BY id",
                                                   (ship["id"],))]
        events = [dict(r) for r in conn.execute("SELECT * FROM bl_status_events WHERE shipment_fk = ? ORDER BY id",
                                                (ship["id"],))]
    si_part = build_particulars(si_view)
    record = dict(row) if row else None
    loaded, not_loaded = all_loaded_on_board(shipment_id)
    return {"shipment": ship, "si_view": si_view, "si": si_view["si"], "record": record, "exists": row is not None,
            "particulars": json.loads(record["particulars"]) if record else si_part, "si_particulars": si_part,
            "documents": documents, "events": events, "all_loaded": loaded, "not_loaded": not_loaded,
            "status": record["bl_status"] if record else "Not Started"}


def bl_number_text(view: dict) -> tuple[str, str]:
    """('B/L No.', carrier number) or ('Draft ref.', internal draft reference). Never an invented number."""
    rec = view["record"] or {}
    if rec.get("carrier_bl_number"):
        return "B/L No.", rec["carrier_bl_number"]
    return "Draft ref.", rec.get("draft_reference") or f"BL-DRAFT-{view['shipment']['shipment_id']}"


# ---------------------------------------------------------------------------
# B/L vs SI comparison
# ---------------------------------------------------------------------------
def _norm(value) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip().upper()


def _num_differs(a, b, tolerance: float) -> bool:
    if a in (None, "") and b in (None, ""):
        return False
    try:
        return abs(float(a or 0) - float(b or 0)) > tolerance
    except (TypeError, ValueError):
        return _norm(a) != _norm(b)


def _scalar(part: dict, key: str) -> str:
    if key == "vessel_voyage":
        return " / ".join(x for x in (part.get("vessel_name"), part.get("voyage_number")) if x)
    return part.get(key) or ""


def differences(view: dict) -> list[dict]:
    """Every difference between the B/L text and the SI: key, label, B/L value, SI value."""
    bl, si = view["particulars"], view["si_particulars"]
    out = []
    for key, label in SCALAR_KEYS:
        if _norm(_scalar(bl, key)) != _norm(_scalar(si, key)):
            out.append({"key": key, "label": label, "bl": _scalar(bl, key), "si": _scalar(si, key)})
    bl_numbers = [c.get("container_number") or "" for c in bl["containers"]]
    si_numbers = [c.get("container_number") or "" for c in si["containers"]]
    if [_norm(x) for x in bl_numbers] != [_norm(x) for x in si_numbers]:
        out.append({"key": "containers", "label": "Containers", "bl": ", ".join(bl_numbers) or "—",
                    "si": ", ".join(si_numbers) or "—"})
    else:
        for b, s in zip(bl["containers"], si["containers"]):
            n = s.get("container_number") or "?"
            if _norm(b.get("seal_number")) != _norm(s.get("seal_number")):
                out.append({"key": f"seal:{n}", "label": f"Seal — {n}", "bl": b.get("seal_number") or "—",
                            "si": s.get("seal_number") or "—"})
            if (_num_differs(b.get("package_count"), s.get("package_count"), 0)
                    or _num_differs(b.get("gross_weight_kg"), s.get("gross_weight_kg"), 0.5)
                    or _num_differs(b.get("volume_cbm"), s.get("volume_cbm"), 0.0005)):
                show = lambda c: (f"{fmt_count(c.get('package_count'))} {c.get('package_unit') or ''} · "
                                  f"{fmt_kg(c.get('gross_weight_kg'))} kg · {fmt_cbm(c.get('volume_cbm'))} CBM")
                out.append({"key": f"container_qty:{n}", "label": f"Packages / gross / CBM — {n}",
                            "bl": show(b), "si": show(s)})
    if len(bl["cargo"]) != len(si["cargo"]):
        out.append({"key": "cargo", "label": "Cargo lines", "bl": f"{len(bl['cargo'])} dòng",
                    "si": f"{len(si['cargo'])} dòng"})
    else:
        for i, (b, s) in enumerate(zip(bl["cargo"], si["cargo"]), start=1):
            if _norm(b.get("description")) != _norm(s.get("description")):
                short = lambda t: (t or "—") if len(t or "") <= 160 else t[:160] + "…"
                out.append({"key": f"description:{i}", "label": f"Description of goods — dòng {i}",
                            "bl": short(b.get("description")), "si": short(s.get("description"))})
            if (_num_differs(b.get("package_count"), s.get("package_count"), 0)
                    or _norm(b.get("package_type")) != _norm(s.get("package_type"))):
                out.append({"key": f"packages:{i}", "label": f"Packages — dòng {i}",
                            "bl": f"{fmt_count(b.get('package_count'))} {b.get('package_type') or ''}".strip(),
                            "si": f"{fmt_count(s.get('package_count'))} {s.get('package_type') or ''}".strip()})
            if _num_differs(b.get("gross_weight_kg"), s.get("gross_weight_kg"), 0.5):
                out.append({"key": f"gross:{i}", "label": f"Gross weight — dòng {i}",
                            "bl": f"{fmt_kg(b.get('gross_weight_kg'))} kg", "si": f"{fmt_kg(s.get('gross_weight_kg'))} kg"})
            if _num_differs(b.get("volume_cbm"), s.get("volume_cbm"), 0.0005):
                out.append({"key": f"cbm:{i}", "label": f"Measurement (CBM) — dòng {i}",
                            "bl": fmt_cbm(b.get("volume_cbm")), "si": fmt_cbm(s.get("volume_cbm"))})
    return out


@tracked("BL")
def apply_si_value(shipment_id: str, key: str) -> str:
    """Copy ONE value from the SI into the B/L text (the user's explicit choice). Returns the label."""
    view = get_bl_view(shipment_id)
    if not view or not view["exists"]:
        raise BLError(["Chưa có B/L — bấm “Lưu B/L nháp” trước."])
    diff = next((d for d in differences(view) if d["key"] == key), None)
    if not diff:
        raise BLError(["Không còn khác biệt này (có thể đã được sửa)."])
    bl, si = view["particulars"], view["si_particulars"]
    if key in dict(SCALAR_KEYS):
        if key == "vessel_voyage":
            bl["vessel_name"], bl["voyage_number"] = si["vessel_name"], si["voyage_number"]
        else:
            bl[key] = si[key]
    elif key == "containers":
        bl["containers"] = si["containers"]
    elif key == "cargo":
        bl["cargo"] = si["cargo"]
    else:
        kind, ref = key.split(":", 1)
        if kind in ("seal", "container_qty"):
            idx = next(i for i, c in enumerate(si["containers"]) if (c.get("container_number") or "?") == ref)
            fields = ("seal_number",) if kind == "seal" else ("package_count", "package_unit", "gross_weight_kg",
                                                              "volume_cbm")
        else:
            idx = int(ref) - 1
            fields = {"description": ("description",), "packages": ("package_count", "package_type"),
                      "gross": ("gross_weight_kg",), "cbm": ("volume_cbm",)}[kind]
        target = bl["containers" if kind in ("seal", "container_qty") else "cargo"][idx]
        source = si["containers" if kind in ("seal", "container_qty") else "cargo"][idx]
        for f in fields:
            target[f] = source.get(f)
    _store_particulars(view, bl)
    return diff["label"]


def _store_particulars(view: dict, particulars: dict) -> None:
    with transaction() as conn:
        conn.execute("UPDATE bl_records SET particulars = ?, updated_at = ? WHERE shipment_fk = ?",
                     (json.dumps(particulars, ensure_ascii=False), S.now_text(), view["shipment"]["id"]))


# ---------------------------------------------------------------------------
# Checks, label, step status
# ---------------------------------------------------------------------------
def has_carrier_evidence(view: dict) -> bool:
    rec = view["record"] or {}
    return bool(rec.get("carrier_bl_number")) and any(
        e["document_fk"] for e in view["events"] if e["status"] in CARRIER_STATES)


def changed_since_issue(view: dict) -> bool:
    """The B/L text changed after the carrier issued it (Phase 5: an amendment the carrier must issue)."""
    if not view["exists"] or view["status"] not in CARRIER_STATES:
        return False
    from . import history
    return history.changed_since_lock(view["shipment"]["shipment_id"], "BL")


def is_official_copy(view: dict) -> bool:
    return view["status"] in CARRIER_STATES and has_carrier_evidence(view) and not changed_since_issue(view)


def checks(view: dict) -> list[str]:
    si, rec = view["si"], view["record"] or {}
    out = []
    diffs = differences(view)
    if diffs:
        out.append(f"B/L khác SI ở {len(diffs)} chỗ — xem tab “So sánh với SI”.")
    if not view["si_view"]["exists"]:
        out.append("Chưa có SI (Bước 4) — B/L đang lấy trực tiếp từ dữ liệu chung.")
    elif si.get("si_status") not in SI.SUBMITTED_STATES:
        out.append("SI chưa được gửi cho hãng tàu (Bước 4 vẫn là nháp).")
    if si.get("bl_type") == "SEA_WAYBILL" and SI.is_to_order(SI.party(view["shipment"], "CONSIGNEE").get("party_name")):
        out.append("Sea Waybill không được giao “TO ORDER” — cần consignee có tên cụ thể.")
    if si.get("bl_type") == "ORIGINAL" and not si.get("originals_count"):
        out.append("Original B/L nhưng chưa có số bản gốc (Bước 4).")
    if (rec.get("shipped_on_board_date") or rec.get("on_board_notation")) and not view["all_loaded"]:
        out.append("Có ngày / ghi chú on-board nhưng chưa phải mọi container “Loaded on Board” (Bước 5).")
    if not view["all_loaded"]:
        out.append("Chưa phải mọi container “Loaded on Board” (Bước 5): " + ", ".join(view["not_loaded"])
                   + " → B/L ghi RECEIVED FOR SHIPMENT, không có ngày on-board.")
    if view["status"] in CARRIER_STATES and not has_carrier_evidence(view):
        out.append("Trạng thái hãng tàu nhưng thiếu số B/L hoặc chứng từ của hãng tàu.")
    if changed_since_issue(view):
        out.append("Nội dung B/L đã thay đổi sau khi hãng tàu phát hành → bản nháp sửa đổi. Khi hãng tàu phát hành "
                   "B/L sửa đổi: tải chứng từ lên và chuyển trạng thái “B/L Amended”.")
    for c in view["particulars"].get("containers", []):      # the B/L's own text can be edited
        problem = c.get("container_number") and S.container_number_problem(c["container_number"])
        if problem:
            out.append(f"Container {c['container_number']} trên B/L: {problem} (ISO 6346).")
    no_vgm = [c.get("container_number") or "?" for c in view["shipment"]["containers"] if c.get("vgm_kg") is None]
    if no_vgm:
        out.append("Chưa có VGM đã khai cho: " + ", ".join(no_vgm) + ".")
    return out


def document_label(view: dict) -> dict:
    si = view["si"]
    kind_title = {"SEA_WAYBILL": "SEA WAYBILL"}.get(si.get("bl_type"), "BILL OF LADING")
    if is_official_copy(view):
        label = dict(kind="reference", draft=False,
                     banner=f"COPY OF CARRIER-ISSUED {kind_title} — NOT NEGOTIABLE / REFERENCE COPY",
                     note=(f"Reference copy prepared from the carrier's {kind_title.lower()} No. "
                           f"{view['record']['carrier_bl_number']} (carrier document uploaded by the user). Not the "
                           "carrier's original; the carrier's issued document prevails."))
    elif changed_since_issue(view):
        label = dict(kind="draft", draft=True, banner="DRAFT BILL OF LADING — NOT NEGOTIABLE / INTERNAL PREVIEW",
                     note=("Amendment draft: the content changed after the carrier issued "
                           f"No. {view['record'].get('carrier_bl_number')}. Not issued by the carrier and of no legal "
                           "effect — the carrier must issue the amended bill of lading."))
    else:
        label = dict(kind="draft", draft=True, banner="DRAFT BILL OF LADING — NOT NEGOTIABLE / INTERNAL PREVIEW",
                     note=("Draft prepared from the shipping instruction for checking. Not issued by the carrier, not "
                           "negotiable and of no legal effect. The carrier issues the bill of lading."))
    label.update(title=kind_title, status=view["status"], sample=bool(view["shipment"]["is_sample"]),
                 sample_text=S.sample_text(view["shipment"]))
    return label


def step_status(shipment_id: str) -> str:
    view = get_bl_view(shipment_id)
    if not view or not view["exists"]:
        return "Not Started"
    status = view["status"]
    if status in CARRIER_STATES:
        if not has_carrier_evidence(view) or changed_since_issue(view):
            return "Needs Correction"
        return "Needs Correction" if differences(view) else "Completed"
    if status == "Draft Approved" and differences(view):
        return "Needs Correction"
    if status in ("Draft Sent for Review", "Draft Approved"):
        return "Waiting for External Confirmation"
    return "In Progress"


def count_bls() -> int:
    with reading() as conn:
        return conn.execute("SELECT COUNT(*) FROM bl_records").fetchone()[0]


# ---------------------------------------------------------------------------
# Save
# ---------------------------------------------------------------------------
@tracked("BL")
def save_bl(shipment_id: str, values: dict, particulars: dict | None = None,
            reset_from_si: bool = False) -> BLResult:
    """Save the B/L-only fields (and, if given, the edited B/L text). Never changes the status.

    reset_from_si=True replaces the whole B/L text with the SI's (the user's explicit choice).
    """
    errors, warnings = [], []
    rec = {k: S.clean_text(values.get(k)) for k in TEXT_FIELDS}
    rec.update({k: S.parse_when(values.get(k), False, k.replace("_", " ").capitalize(), errors) for k in DATE_FIELDS})
    rec["on_board_notation"] = 1 if values.get("on_board_notation") else 0
    if rec["carrier_bl_number"]:
        rec["carrier_bl_number"] = re.sub(r"\s+", "", rec["carrier_bl_number"]).upper()
    if errors:
        raise BLError(errors)
    view = get_bl_view(shipment_id)
    if not view:
        raise BLError([f"Không tìm thấy lô hàng {shipment_id}."])
    if (rec["shipped_on_board_date"] or rec["on_board_notation"]) and not view["all_loaded"]:
        warnings.append("Chưa phải mọi container “Loaded on Board” ở Bước 5 (" + ", ".join(view["not_loaded"])
                        + ") → không lưu ngày / ghi chú SHIPPED ON BOARD; B/L ghi RECEIVED FOR SHIPMENT.")
        rec["shipped_on_board_date"], rec["on_board_notation"] = None, 0
    if view["status"] in CARRIER_STATES and view["record"] and \
            (view["record"].get("carrier_bl_number") or None) != rec["carrier_bl_number"]:
        warnings.append("Số B/L của hãng tàu đã đổi sau khi phát hành — kiểm tra lại chứng từ của hãng tàu.")
    if reset_from_si or particulars is None:
        part = view["si_particulars"] if (reset_from_si or not view["exists"]) else view["particulars"]
    else:
        part = particulars
    stamp = S.now_text()
    with transaction() as conn:
        fk = view["shipment"]["id"]
        cols = list(TEXT_FIELDS + DATE_FIELDS) + ["on_board_notation"]
        if view["exists"]:
            conn.execute(f"UPDATE bl_records SET {', '.join(f'{k} = ?' for k in cols)}, particulars = ?, updated_at = ? "
                         f"WHERE shipment_fk = ?", [*(rec[k] for k in cols), json.dumps(part, ensure_ascii=False),
                                                    stamp, fk])
        else:
            all_cols = ["shipment_fk", "bl_status", "draft_reference", *cols, "particulars", "created_at", "updated_at"]
            conn.execute(f"INSERT INTO bl_records ({', '.join(all_cols)}) VALUES ({', '.join('?' * len(all_cols))})",
                         [fk, "Draft", f"BL-DRAFT-{shipment_id}", *(rec[k] for k in cols),
                          json.dumps(part, ensure_ascii=False), stamp, stamp])
        conn.execute("UPDATE shipments SET updated_at = ? WHERE id = ?", (stamp, fk))
    view = get_bl_view(shipment_id)
    return BLResult(shipment_id, view["status"], True, warnings + checks(view))


@tracked("BL")
def add_document(shipment_id: str, source_path: str | Path, description: str | None = None,
                 uploaded_by: str | None = None) -> int:
    source = Path(source_path)
    if not source.exists():
        raise BLError(["Không tìm thấy file tải lên."])
    if source.suffix.lower() not in DOCUMENT_TYPES:
        raise BLError([f"Loại file {source.suffix or '(không có đuôi)'} không được nhận — dùng PDF / JPG / PNG."])
    with transaction() as conn:
        fk = S.get_shipment_fk(conn, shipment_id)
        folder = settings.UPLOAD_DIR / re.sub(r"[^A-Za-z0-9._-]+", "-", shipment_id) / "bl"
        folder.mkdir(parents=True, exist_ok=True)
        safe = re.sub(r"[^A-Za-z0-9._-]+", "-", source.name).strip("-") or f"document{source.suffix}"
        target = folder / f"{datetime.now():%Y%m%d-%H%M%S}_{safe}"
        shutil.copy2(source, target)
        cur = conn.execute("INSERT INTO bl_documents (shipment_fk, file_path, file_name, description, uploaded_by, "
                           "uploaded_at) VALUES (?, ?, ?, ?, ?, ?)",
                           (fk, str(target), source.name, S.clean_text(description), S.clean_text(uploaded_by),
                            S.now_text()))
        return cur.lastrowid


@tracked("BL")
def change_status(shipment_id: str, target: str, event_date, confirmed_by: str | None, note: str | None = None,
                  document_id: int | None = None) -> BLResult:
    """Move the B/L to `target` if the rules allow it; otherwise nothing changes (done=False + reasons)."""
    view = get_bl_view(shipment_id)
    if not view or not view["exists"]:
        raise BLError(["Chưa có B/L — bấm “Lưu B/L nháp” trước."])
    if target not in STATUSES:
        raise BLError([f"Trạng thái “{target}” không hợp lệ."])
    errors = []
    when = S.parse_when(event_date, False, "Ngày", errors)
    confirmed_by = S.clean_text(confirmed_by)
    if errors:
        raise BLError(errors)
    status, rec = view["status"], view["record"]
    need = []
    if status not in TRANSITIONS.get(target, ()):
        need.append(f"Không chuyển từ “{status_label(status)}” sang “{status_label(target)}”.")
    if not confirmed_by:
        need.append("Ghi người xác nhận.")
    if not when:
        need.append("Ghi ngày.")
    if target == "Draft Approved" and differences(view):
        need.append(f"B/L còn {len(differences(view))} chỗ khác SI — xử lý ở tab “So sánh với SI” trước khi duyệt.")
    if target in CARRIER_STATES:
        if not rec.get("carrier_bl_number"):
            need.append("Nhập số B/L thật của hãng tàu (tab 📄 B/L) và lưu.")
        if not document_id or not any(d["id"] == document_id for d in view["documents"]):
            need.append("Chọn chứng từ của hãng tàu đã tải lên (B/L hãng tàu phát hành / xác nhận release).")
        if target == "Issued" and not (rec.get("date_of_issue") and rec.get("place_of_issue")):
            need.append("Nhập nơi và ngày phát hành (Place / date of issue) theo B/L của hãng tàu.")
    if need:
        return BLResult(shipment_id, status, False, need)
    with transaction() as conn:
        fk = view["shipment"]["id"]
        conn.execute("UPDATE bl_records SET bl_status = ?, updated_at = ? WHERE shipment_fk = ?",
                     (target, S.now_text(), fk))
        conn.execute("INSERT INTO bl_status_events (shipment_fk, status, event_date, confirmed_by, note, document_fk, "
                     "recorded_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                     (fk, target, when, confirmed_by, S.clean_text(note),
                      document_id if target in CARRIER_STATES else None, S.now_text()))
    return BLResult(shipment_id, target, True, checks(get_bl_view(shipment_id)))


def record_pdf_export(shipment_id: str, path: str) -> None:
    with transaction() as conn:
        conn.execute("UPDATE bl_records SET last_pdf_path = ?, last_pdf_at = ? WHERE shipment_fk = "
                     "(SELECT id FROM shipments WHERE shipment_id = ?)", (path, S.now_text()[:16], shipment_id))
