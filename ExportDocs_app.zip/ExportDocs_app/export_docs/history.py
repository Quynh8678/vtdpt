"""Phase 5 — version control, change log and the current user (REQUIREMENTS.md §8).

How it works
- Every save function is wrapped with @tracked (tracking.py). Before and after the save the whole
  shipment is captured (central data + every document, with the values each document SHOWS).
- after_change() then
    1. applies the sync rules (sync.py): inherited fields follow the source, but a document that was
       submitted / confirmed / issued, or that has its own value, is never overwritten silently;
    2. writes the change log: one row per changed field with time, user, document, field, old value,
       new value, action and reason;
    3. gives every document whose content changed a NEW VERSION (v1, v2, v3 …). Old versions are never
       changed. A change to a document that was already Confirmed / Submitted / Issued is an "Amended"
       version;
    4. refreshes the shipment status (Completed only when everything is valid — workflow.py).
- restore_version() brings back an old version AS A NEW VERSION, through the document's normal save
  function (so all checks and the Amended rules apply). Statuses and evidence are never restored.
"""

import hashlib
import json
from datetime import datetime

from . import bl as BL
from . import bookings as B
from . import eir as E
from . import gatein as G
from . import shipments as S
from . import si as SI
from . import tracking
from . import vgm as V
from .database import get_meta, reading, set_meta, transaction

DOC_LABELS = {
    "SHIPMENT": "Dữ liệu lô hàng (Master)",
    "BOOKING": "1. Booking Confirmation",
    "EIR": "2. Empty Container EIR",
    "VGM": "3. VGM Declaration",
    "SI": "4. Shipping Instruction",
    "GATEIN": "5. Gate-in & Loading",
    "BL": "6. Bill of Lading",
}
DOC_SHORT = {"SHIPMENT": "Master", "BOOKING": "Booking", "EIR": "EIR", "VGM": "VGM", "SI": "SI",
             "GATEIN": "Gate-in", "BL": "B/L"}
DOC_TYPES = ("BOOKING", "EIR", "VGM", "SI", "GATEIN", "BL")
PER_CONTAINER = ("EIR", "VGM", "GATEIN")
TABLES = {"BOOKING": "bookings", "EIR": "eir_records", "VGM": "vgm_records", "SI": "si_records",
          "GATEIN": "gatein_records", "BL": "bl_records"}
BOOKKEEPING = {"id", "shipment_fk", "container_fk", "created_at", "updated_at", "last_pdf_path", "last_pdf_at",
               "doc_version", "submitted_hash", "booking_basis", "tare_used_kg", "declared_booking_number"}
# status / evidence fields: changing them is a status change, not a change of what the document says
STATUS_KEYS = {
    "BOOKING": {"booking_status", "confirmation_date", "confirmation_source", "confirmation_reference", "confirmed_by"},
    "EIR": {"eir_status"},
    "VGM": {"vgm_status", "submission_date", "submission_channel", "ack_reference"},
    "SI": {"si_status", "submission_date", "submission_channel", "amendment_date", "amendment_reason",
           "draft_bl_received_date", "draft_bl_reference", "draft_bl_approved_date"},
    "GATEIN": {"statuses", "evidence"},
    "BL": {"bl_status"},
}
# a change of these on a locked document = a NEW confirmation (the content fingerprint is renewed)
CONFIRM_KEYS = {"BOOKING": {"booking_status", "confirmation_reference", "confirmation_date", "confirmation_source"},
                "BL": {"bl_status"}}
BL_LOCKED = ("Draft Approved",) + BL.CARRIER_STATES
ACTION_LABELS = {
    "CREATE": "Tạo mới", "EDIT": "Sửa", "SYNC": "Đồng bộ tự động", "AMEND": "Sửa đổi (Amended)",
    "RESTORE": "Khôi phục phiên bản", "APPLY": "Áp dụng giá trị (Trung tâm kiểm tra)", "KEEP": "Giữ giá trị chứng từ",
    "REPLACE": "Thay bằng giá trị mới", "STATUS": "Trạng thái", "DELETE": "Xóa", "DISMISS": "Đã xem thông báo",
    "EXPORT": "Xuất / sao lưu", "UPLOAD": "Tải file lên",
}
KIND_LABELS = {"Baseline": "Bản đầu (trước khi có lịch sử)", "Created": "Tạo mới", "Edited": "Sửa",
               "Status": "Đổi trạng thái", "Synced": "Đồng bộ từ nguồn", "Amended": "Amended (sửa sau khi đã gửi / xác nhận)",
               "Restored": "Khôi phục"}

FIELD_LABELS = {
    "status": "Shipment status", "transport_mode": "Transport mode", "export_type": "Export type",
    "person_in_charge": "Person in charge", "customer_name": "Customer", "contract_reference": "Contract / reference",
    "notes": "Notes", "carrier_name": "Carrier", "booking_number": "Booking No.", "vessel_name": "Vessel",
    "voyage_number": "Voyage", "place_of_receipt": "Place of Receipt", "port_of_loading": "Port of Loading (POL)",
    "port_of_discharge": "Port of Discharge (POD)", "transshipment_port": "Transshipment port",
    "place_of_delivery": "Place of Delivery", "etd": "ETD", "eta": "ETA", "cy_cutoff": "CY cut-off",
    "si_cutoff": "SI cut-off", "vgm_cutoff": "VGM cut-off", "empty_pickup_depot": "Empty pick-up depot",
    "empty_pickup_date": "Empty pick-up date", "container_return_depot": "Container return depot",
    "party_name": "Name", "address": "Address", "country": "Country", "tax_id": "Tax ID", "email": "E-mail",
    "phone": "Phone", "shipper": "Shipper", "consignee": "Consignee", "notify": "Notify Party",
    "freight_payer": "Freight Payer", "also_notify": "Also notify", "eir_status": "EIR status",
    "statuses": "Trạng thái cảng (đang áp dụng)", "evidence": "File bằng chứng",
    "particulars": "Nội dung B/L", "container_number": "Container No.", "seal_number": "Seal No.",
    "gross_weight_kg": "Gross weight (kg)", "volume_cbm": "Measurement (CBM)", "package_count": "Packages",
    "package_type": "Package type", "package_unit": "Package unit", "description": "Description of goods",
    "cargo_description": "Description of goods", "marks": "Marks & Numbers", "marks_and_numbers": "Marks & Numbers",
    "hs_code": "HS Code", "size_type": "Size / type", "container_size": "Size", "iso_type_code": "ISO type",
    "tare_weight_kg": "Tare (kg)", "max_gross_kg": "Max gross (CSC)", "vgm_kg": "VGM (kg)",
    "cargo_weight_kg": "Cargo weight (kg)", "bl_type": "B/L type", "originals_count": "Number of originals",
    "freight_terms": "Freight terms", "pre_carriage": "Pre-carriage", "eir_number": "Depot EIR No.",
}
DEFAULT_USER = "Chưa đặt tên"


# ---------------------------------------------------------------------------
# Current user (Settings) — no login yet
# ---------------------------------------------------------------------------
def current_user() -> str:
    return tracking.acting_user() or get_meta("current_user") or DEFAULT_USER


def set_current_user(name: str | None) -> str:
    name = S.clean_text(name)
    if not name:
        raise S.ShipmentError(["Nhập tên người dùng (VD: Nguyễn Văn A — Phòng chứng từ)."])
    if len(name) > 80:
        raise S.ShipmentError(["Tên người dùng quá dài (tối đa 80 ký tự)."])
    set_meta("current_user", name)
    return name


# ---------------------------------------------------------------------------
# Values
# ---------------------------------------------------------------------------
def show(value) -> str | None:
    """One text form for comparing and displaying values."""
    if value is None:
        return None
    if isinstance(value, bool):
        return "Có" if value else "Không"
    if isinstance(value, float):
        return ("%.3f" % value).rstrip("0").rstrip(".")
    if isinstance(value, dict):
        return party_text(value)
    text = str(value).strip()
    return text or None


def party_text(p: dict | None) -> str | None:
    p = p or {}
    return "\n".join(str(p[f]) for f in ("party_name", "address", "country", "tax_id", "email", "phone")
                     if p.get(f)) or None


def label_of(key: str) -> str:
    last = key.rsplit(".", 1)[-1]
    return FIELD_LABELS.get(last, last.replace("_", " ").capitalize())


def _now() -> str:
    return S.now_text()


# ---------------------------------------------------------------------------
# Capture: everything a shipment and each of its documents says
# ---------------------------------------------------------------------------
def _central(ship: dict, allocations: list[dict]) -> tuple[dict, dict]:
    flat, labels = {}, {}

    def put(key, value, label):
        flat[key], labels[key] = show(value), label

    for k in S.HEADER_FIELDS:
        put(k, ship.get(k), label_of(k))
    for role, en, _, _ in S.PARTY_ROLES:
        p = (ship.get("parties") or {}).get(role) or {}
        for f in S.PARTY_FIELDS:
            put(f"party.{role}.{f}", p.get(f), f"{en} · {label_of(f)}")
    lines = {}
    for n, line in enumerate(ship["cargo"], start=1):
        lines[line["id"]] = n
        for col in S.CARGO_COLUMNS:
            put(f"cargo#{line['id']}.{col.key}", line.get(col.key), f"Dòng hàng {n} · {col.header}")
    names = {}
    for n, c in enumerate(ship["containers"], start=1):
        names[c["id"]] = c.get("container_number") or f"#{n}"
        for col in S.CONTAINER_COLUMNS:
            put(f"container#{c['id']}.{col.key}", c.get(col.key), f"Container {names[c['id']]} · {col.header}")
    for a in allocations:
        base = f"alloc#{a['container_fk']}:{a['cargo_fk']}"
        where = f"Hàng trong container {names.get(a['container_fk'], '?')} · dòng {lines.get(a['cargo_fk'], '?')}"
        for f in ("package_count", "gross_weight_kg", "volume_cbm"):
            put(f"{base}.{f}", a.get(f), f"{where} · {label_of(f)}")
    return flat, labels


def _flatten(prefix: str, obj, out: dict) -> None:
    if isinstance(obj, dict):
        for k, v in obj.items():
            _flatten(f"{prefix}.{k}" if prefix else k, v, out)
    elif isinstance(obj, list):
        for i, v in enumerate(obj, start=1):
            _flatten(f"{prefix}[{i}]", v, out)
    else:
        out[prefix] = show(obj)


def _state(doc_type: str, own: dict, inherited: dict, derived: dict, locked: bool, label: str,
           container_fk=None, version=None) -> dict:
    flat = {k: show(v) for k, v in own.items() if k != "particulars"}
    if "particulars" in own:
        _flatten("particulars", json.loads(own["particulars"] or "{}"), flat)
    flat.update({k: show(v) for k, v in derived.items()})
    flat.update({f"inh.{k}": show(v) for k, v in inherited.items()})
    status = own.get(BL_STATUS.get(doc_type, "")) or derived.get("eir_status") or derived.get("statuses")
    return {"doc_type": doc_type, "container_fk": container_fk, "own": own, "flat": flat, "locked": locked,
            "label": label, "version": version, "status": status}


BL_STATUS = {"BOOKING": "booking_status", "VGM": "vgm_status", "SI": "si_status", "BL": "bl_status"}


def _own(row: dict) -> dict:
    return {k: v for k, v in row.items() if k not in BOOKKEEPING}


def _booking_state(ship: dict, row: dict) -> dict:
    inherited = {k: ship.get(k) for k in B.SHARED_FIELDS}
    inherited["shipper"] = party_text(ship["parties"].get("SHIPPER"))
    locked = row.get("booking_status") in ("Booking Confirmed", "Booking Amended") and B.has_carrier_evidence(row)
    return _state("BOOKING", _own(row), inherited, {}, locked, DOC_LABELS["BOOKING"], version=row.get("doc_version"))


def _si_state(si_ship: dict, row: dict, allocations: list[dict]) -> dict:
    inherited = {k: si_ship.get(k) for k in ("booking_number", "vessel_name", "voyage_number", "place_of_receipt",
                                              "port_of_loading", "transshipment_port", "port_of_discharge",
                                              "place_of_delivery")}
    for role, key in (("SHIPPER", "shipper"), ("CONSIGNEE", "consignee"), ("NOTIFY_PARTY", "notify"),
                      ("FREIGHT_PAYER", "freight_payer")):
        inherited[key] = party_text(si_ship["parties"].get(role))
    lines = {}
    for n, line in enumerate(si_ship["cargo"], start=1):
        lines[line["id"]] = n
        for f in ("marks_and_numbers", "package_count", "package_type", "cargo_description", "hs_code",
                  "gross_weight_kg", "volume_cbm"):
            inherited[f"cargo[{n}].{f}"] = line.get(f)
    names = {}
    for n, c in enumerate(si_ship["containers"], start=1):
        names[c["id"]] = c.get("container_number") or f"#{n}"
        for f in ("container_number", "seal_number", "container_size", "iso_type_code"):
            inherited[f"containers[{n}].{f}"] = c.get(f)
    for a in allocations:
        base = f"cargo_in[{names.get(a['container_fk'], '?')}][line {lines.get(a['cargo_fk'], '?')}]"
        for f in ("package_count", "gross_weight_kg", "volume_cbm"):
            inherited[f"{base}.{f}"] = a.get(f)
    locked = row.get("si_status") in SI.SUBMITTED_STATES
    return _state("SI", _own(row), inherited, {}, locked, DOC_LABELS["SI"], version=row.get("doc_version"))


def _bl_state(si_ship: dict, row: dict, si_row: dict | None) -> dict:
    si_row = si_row or {}
    inherited = {"booking_number": si_ship.get("booking_number"), "carrier_name": si_ship.get("carrier_name"),
                 "bl_type": si_row.get("bl_type"), "originals_count": si_row.get("originals_count"),
                 "freight_terms": si_row.get("freight_terms")}
    return _state("BL", _own(row), inherited, {}, row.get("bl_status") in BL_LOCKED, DOC_LABELS["BL"],
                  version=row.get("doc_version"))


def capture(shipment_id: str | None) -> dict | None:
    """Snapshot of the shipment: central data + every document (own fields and what it shows)."""
    if not shipment_id:
        return None
    ship = S.get_shipment(shipment_id)
    if not ship:
        return None
    fk = ship["id"]
    with reading() as conn:
        rows = {d: [dict(r) for r in conn.execute(f"SELECT * FROM {t} WHERE shipment_fk = ?", (fk,))]
                for d, t in TABLES.items()}
        allocations = [dict(r) for r in conn.execute(
            "SELECT * FROM container_cargo WHERE shipment_fk = ? ORDER BY container_fk, cargo_fk", (fk,))]
        events = [dict(r) for r in conn.execute(
            "SELECT * FROM gatein_status_events WHERE shipment_fk = ? ORDER BY id", (fk,))]
        evidence = [dict(r) for r in conn.execute("SELECT * FROM gatein_evidence WHERE shipment_fk = ? ORDER BY id",
                                                  (fk,))]
        bl_docs = [dict(r) for r in conn.execute("SELECT * FROM bl_documents WHERE shipment_fk = ? ORDER BY id", (fk,))]
    central, labels = _central(ship, allocations)
    containers = {c["id"]: c for c in ship["containers"]}
    names = {c["id"]: c.get("container_number") or f"#{n}" for n, c in enumerate(ship["containers"], start=1)}
    shipper = party_text(ship["parties"].get("SHIPPER"))
    docs = {}
    for row in rows["BOOKING"]:
        docs[("BOOKING", None)] = _booking_state(ship, row)
    for row in rows["EIR"]:
        c = containers.get(row["container_fk"], {})
        inherited = {k: c.get(k) for k in E.CONTAINER_FIELDS}
        inherited.update(booking_number=ship.get("booking_number"), empty_pickup_depot=ship.get("empty_pickup_depot"))
        status = E.eir_status(ship, c, row)
        docs[("EIR", row["container_fk"])] = _state(
            "EIR", _own(row), inherited, {"eir_status": status}, status == "Completed" and bool(c.get("eir_number")),
            f"EIR — {names.get(row['container_fk'], '?')}", row["container_fk"], row.get("doc_version"))
    for row in rows["VGM"]:
        c = containers.get(row["container_fk"], {})
        inherited = {"booking_number": ship.get("booking_number"), "vessel_name": ship.get("vessel_name"),
                     "voyage_number": ship.get("voyage_number"), "shipper": shipper,
                     "container_number": c.get("container_number"), "tare_weight_kg": c.get("tare_weight_kg"),
                     "max_gross_kg": c.get("max_gross_kg")}
        docs[("VGM", row["container_fk"])] = _state(
            "VGM", _own(row), inherited, {}, row.get("vgm_status") in V.DECLARED_STATES,
            f"VGM — {names.get(row['container_fk'], '?')}", row["container_fk"], row.get("doc_version"))
    for row in rows["GATEIN"]:
        cid = row["container_fk"]
        c = containers.get(cid, {})
        latest = {}
        for ev in events:
            if ev["container_fk"] == cid:
                latest[ev["status_key"]] = ev
        active = [G.STATUS_NAMES[k] for k, _, _ in G.STATUSES if latest.get(k, {}).get("action") == "SET"]
        files = [x["file_name"] for x in evidence if x["container_fk"] == cid]
        inherited = {k: ship.get(k) for k in ("booking_number", "vessel_name", "voyage_number", "port_of_loading",
                                              "port_of_discharge")}
        inherited.update(container_number=c.get("container_number"), seal_number=c.get("seal_number"),
                         vgm_kg=c.get("vgm_kg"))
        docs[("GATEIN", cid)] = _state(
            "GATEIN", _own(row), inherited, {"statuses": ", ".join(active) or None, "evidence": ", ".join(files) or None},
            False, f"Gate-in — {names.get(cid, '?')}", cid, row.get("doc_version"))
    si_row = rows["SI"][0] if rows["SI"] else None
    si_ship = S.get_shipment(shipment_id, for_doc="SI") if (si_row or rows["BL"]) else ship
    if si_row:
        docs[("SI", None)] = _si_state(si_ship, si_row, allocations)
    si_part = None
    if rows["BL"]:
        bl_state = _bl_state(si_ship, rows["BL"][0], si_row)
        bl_state["flat"]["carrier_documents"] = ", ".join(d["file_name"] for d in bl_docs) or None
        docs[("BL", None)] = bl_state
        si_part = BL.build_particulars(SI.get_si_view(shipment_id))
    from .sync import sync_values
    return {"shipment_id": shipment_id, "fk": fk, "ship": ship, "central": central, "labels": labels, "docs": docs,
            "names": names, "sync": sync_values(ship), "si_part": si_part}


def doc_state(shipment_id: str, doc_type: str) -> dict | None:
    """The current state of one shipment-level document (used for the confirmation fingerprint)."""
    ship = S.get_shipment(shipment_id)
    if not ship:
        return None
    with reading() as conn:
        row = conn.execute(f"SELECT * FROM {TABLES[doc_type]} WHERE shipment_fk = ?", (ship["id"],)).fetchone()
        si_row = conn.execute("SELECT * FROM si_records WHERE shipment_fk = ?", (ship["id"],)).fetchone()
        bl_docs = [r["file_name"] for r in conn.execute("SELECT file_name FROM bl_documents WHERE shipment_fk = ? "
                                                         "ORDER BY id", (ship["id"],))]
    if not row:
        return None
    if doc_type == "BOOKING":
        return _booking_state(ship, dict(row))
    if doc_type == "BL":
        state = _bl_state(S.get_shipment(shipment_id, for_doc="SI"), dict(row), dict(si_row) if si_row else None)
        state["flat"]["carrier_documents"] = ", ".join(bl_docs) or None
        return state
    raise ValueError(doc_type)


def content_hash(doc_type: str, state: dict) -> str:
    keys = STATUS_KEYS.get(doc_type, set()) | {"carrier_documents"}
    data = sorted((k, v) for k, v in state["flat"].items() if k not in keys)
    return hashlib.sha256(json.dumps(data, ensure_ascii=False).encode()).hexdigest()


def changed_since_lock(shipment_id: str, doc_type: str) -> bool:
    """True when a confirmed Booking / issued B/L now says something else than when it was confirmed."""
    state = doc_state(shipment_id, doc_type)
    if not state or not state["locked"]:
        return False
    with reading() as conn:
        row = conn.execute("SELECT l.content_hash FROM doc_locks l JOIN shipments s ON s.id = l.shipment_fk "
                           "WHERE s.shipment_id = ? AND l.doc_type = ?", (shipment_id, doc_type)).fetchone()
    return bool(row) and row[0] != content_hash(doc_type, state)


# ---------------------------------------------------------------------------
# After a change: sync rules, change log, versions, shipment status
# ---------------------------------------------------------------------------
def after_change(shipment_id: str | None, source_doc: str, before: dict | None, reason: str | None) -> list[str]:
    if not shipment_id:
        return []
    mid = capture(shipment_id)
    if mid is None:
        return []
    report, changed = [], False
    if before is not None:
        from . import sync
        report, changed = sync.apply_rules(shipment_id, source_doc, before, mid)
    after = capture(shipment_id) if changed else mid
    _record(source_doc, before, after, reason)
    from . import workflow
    workflow.refresh_shipment_status(shipment_id)
    return report


def _log(conn, after: dict, doc_type: str, container_fk, doc_label, version, key, label, old, new, action,
         via, reason, user, stamp) -> None:
    conn.execute(
        "INSERT INTO change_log (shipment_fk, shipment_id, doc_type, container_fk, doc_label, doc_version, field_key, "
        "field_label, old_value, new_value, action, via_doc, reason, user_name, changed_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (after["fk"], after["shipment_id"], doc_type, container_fk, doc_label, version, key, label, old, new, action,
         via, reason, user, stamp))


def _changes(old: dict, new: dict) -> list[tuple[str, str | None, str | None]]:
    keys = list(dict.fromkeys([*old.keys(), *new.keys()]))
    return [(k, old.get(k), new.get(k)) for k in keys if (old.get(k) or None) != (new.get(k) or None)]


def _doc_label_key(key: str) -> str:
    if key.startswith("inh."):
        return label_of(key[4:]) + " (kế thừa)"
    if key.startswith("particulars."):
        return "B/L · " + key[len("particulars."):].replace("_", " ")
    return label_of(key)


def _insert_version(conn, fk: int, state: dict, version: int, kind: str, reason, user, stamp) -> None:
    conn.execute(
        "INSERT INTO document_versions (shipment_fk, doc_type, container_fk, version, kind, status, snapshot, reason, "
        "created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (fk, state["doc_type"], state["container_fk"], version, kind, state["status"],
         json.dumps({"own": state["own"], "flat": state["flat"], "label": state["label"]}, ensure_ascii=False,
                    default=str), reason, user, stamp))


def _set_doc_version(conn, fk: int, state: dict, version: int) -> None:
    table = TABLES[state["doc_type"]]
    if state["container_fk"] is None:
        conn.execute(f"UPDATE {table} SET doc_version = ? WHERE shipment_fk = ?", (version, fk))
    else:
        conn.execute(f"UPDATE {table} SET doc_version = ? WHERE container_fk = ?", (version, state["container_fk"]))


def _record(source_doc: str, before: dict | None, after: dict, reason: str | None) -> None:
    user, stamp, act = current_user(), _now(), tracking.current_action()
    fk = after["fk"]
    with transaction() as conn:
        if before is None:
            _log(conn, after, "SHIPMENT", None, DOC_LABELS["SHIPMENT"], None, "*", "Lô hàng", None,
                 f"Tạo lô hàng {after['shipment_id']}", "CREATE", source_doc, reason, user, stamp)
        else:
            for key, old, new in _changes(before["central"], after["central"]):
                label = after["labels"].get(key) or before["labels"].get(key) or key
                _log(conn, after, "SHIPMENT", None, DOC_LABELS["SHIPMENT"], None, key, label, old, new,
                     act or "EDIT", source_doc, reason, user, stamp)
        versions = {(r[0], r[1]): r[2] for r in conn.execute(
            "SELECT doc_type, container_fk, MAX(version) FROM document_versions WHERE shipment_fk = ? "
            "GROUP BY doc_type, container_fk", (fk,))}
        old_docs = before["docs"] if before else {}
        for key, b in old_docs.items():
            if key not in after["docs"]:
                _log(conn, after, b["doc_type"], b["container_fk"], b["label"], b["version"], "*", "Chứng từ", None,
                     f"Đã xóa {b['label']}", "DELETE", source_doc, reason, user, stamp)
        for key, a in after["docs"].items():
            doc_type = a["doc_type"]
            own_change = doc_type == source_doc
            b = old_docs.get(key)
            last = versions.get(key)
            if b is None:
                version = (last or 0) + 1
                _insert_version(conn, fk, a, version, "Created", reason, user, stamp)
                _set_doc_version(conn, fk, a, version)
                _log(conn, after, doc_type, a["container_fk"], a["label"], version, "*", "Chứng từ", None,
                     f"Tạo {a['label']} (v{version})", "CREATE", source_doc, reason, user, stamp)
                _update_lock(conn, fk, None, a, version, stamp)
                continue
            changes = _changes(b["flat"], a["flat"])
            if not changes:
                continue
            content = [c for c in changes if c[0] not in STATUS_KEYS.get(doc_type, set())]
            if b["locked"] and content:
                kind = "Amended"
            elif not content:
                kind = "Status"
            elif act == "RESTORE" and own_change:
                kind = "Restored"
            else:
                kind = "Edited" if own_change else "Synced"
            if last is None:          # first change since Phase 5: keep what it said before as v<current>
                last = b["version"] or 1
                _insert_version(conn, fk, b, last, "Baseline", None, user, stamp)
            version = last + 1
            _insert_version(conn, fk, a, version, kind, reason, user, stamp)
            _set_doc_version(conn, fk, a, version)
            if own_change:
                action = act or ("AMEND" if kind == "Amended" else ("STATUS" if kind == "Status" else "EDIT"))
            else:
                action = "SYNC"          # changed because its source changed
            for k, old, new in changes:
                _log(conn, after, doc_type, a["container_fk"], a["label"], version, k, _doc_label_key(k), old, new,
                     action, source_doc, reason, user, stamp)
            _update_lock(conn, fk, b, a, version, stamp, {c[0] for c in changes})


def _update_lock(conn, fk: int, b: dict | None, a: dict, version: int, stamp: str, changed: set | None = None) -> None:
    doc_type = a["doc_type"]
    if doc_type not in CONFIRM_KEYS or not a["locked"]:
        return
    renewed = b is None or not b["locked"] or bool((changed or set()) & CONFIRM_KEYS[doc_type])
    if renewed:
        conn.execute("INSERT INTO doc_locks (shipment_fk, doc_type, content_hash, version, locked_at) VALUES (?, ?, ?, ?, ?) "
                     "ON CONFLICT(shipment_fk, doc_type) DO UPDATE SET content_hash = excluded.content_hash, "
                     "version = excluded.version, locked_at = excluded.locked_at",
                     (fk, doc_type, content_hash(doc_type, a), version, stamp))


def log_event(shipment_id: str, doc_type: str, field_label: str, old: str | None, new: str | None, action: str,
              reason: str | None = None, doc_label: str | None = None, field_key: str = "*",
              shipment_fk: int | None = None) -> None:
    """A single change-log row that is not a field change (e.g. a shipment deleted, a conflict kept)."""
    with transaction() as conn:
        conn.execute(
            "INSERT INTO change_log (shipment_fk, shipment_id, doc_type, doc_label, field_key, field_label, old_value, "
            "new_value, action, via_doc, reason, user_name, changed_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (shipment_fk, shipment_id, doc_type, doc_label or DOC_LABELS.get(doc_type, doc_type), field_key,
             field_label, old, new, action, doc_type, reason, current_user(), _now()))


# ---------------------------------------------------------------------------
# Reading the history
# ---------------------------------------------------------------------------
def list_changes(shipment_id: str | None = None, doc_type: str | None = None, date_from: str | None = None,
                 date_to: str | None = None, limit: int = 500) -> list[dict]:
    where, params = [], []
    if shipment_id:
        where.append("shipment_id = ?")
        params.append(shipment_id)
    if doc_type:
        where.append("doc_type = ?")
        params.append(doc_type)
    if date_from:
        where.append("changed_at >= ?")
        params.append(date_from)
    if date_to:
        where.append("changed_at < ?")
        params.append(_next_day(date_to))
    sql = "SELECT * FROM change_log" + (" WHERE " + " AND ".join(where) if where else "") + \
          f" ORDER BY changed_at DESC, id DESC LIMIT {int(limit)}"
    with reading() as conn:
        return [dict(r) for r in conn.execute(sql, params)]


def _next_day(day: str) -> str:
    from datetime import timedelta
    return (datetime.strptime(day[:10], "%Y-%m-%d") + timedelta(days=1)).strftime("%Y-%m-%d")


def documents_of(shipment_id: str) -> list[dict]:
    """Every document of a shipment that can have versions: [{key, doc_type, container_fk, label, version}]."""
    snap = capture(shipment_id)
    if not snap:
        return []
    out = []
    for doc_type in DOC_TYPES:
        for (d, cid), state in snap["docs"].items():
            if d == doc_type:
                out.append({"doc_type": d, "container_fk": cid, "label": state["label"],
                            "version": state["version"] or 1, "status": state["status"]})
    return out


def list_versions(shipment_id: str, doc_type: str, container_fk: int | None = None) -> list[dict]:
    """Versions, newest first. A document without history yet shows its current state as its only version."""
    with reading() as conn:
        fk = S.get_shipment_fk(conn, shipment_id)
        rows = [dict(r) for r in conn.execute(
            "SELECT * FROM document_versions WHERE shipment_fk = ? AND doc_type = ? AND container_fk IS ? "
            "ORDER BY version DESC, id DESC", (fk, doc_type, container_fk))]
    if rows:
        return rows
    snap = capture(shipment_id)
    state = (snap or {}).get("docs", {}).get((doc_type, container_fk))
    if not state:
        return []
    return [{"id": None, "version": state["version"] or 1, "kind": "Baseline", "status": state["status"],
             "snapshot": json.dumps({"own": state["own"], "flat": state["flat"], "label": state["label"]},
                                    ensure_ascii=False, default=str),
             "reason": None, "created_by": "—", "created_at": "(hiện tại — chưa có thay đổi nào được ghi)"}]


def get_version(version_id: int) -> dict:
    with reading() as conn:
        row = conn.execute("SELECT v.*, s.shipment_id FROM document_versions v JOIN shipments s ON s.id = v.shipment_fk "
                           "WHERE v.id = ?", (version_id,)).fetchone()
    if not row:
        raise S.ShipmentError(["Không tìm thấy phiên bản này."])
    data = dict(row)
    data["snapshot"] = json.loads(data["snapshot"])
    return data


def latest_version_number(shipment_id: str, doc_type: str, container_fk: int | None = None) -> int:
    rows = list_versions(shipment_id, doc_type, container_fk)
    return rows[0]["version"] if rows else 0


# ---------------------------------------------------------------------------
# Restore an old version AS A NEW VERSION (through the normal save function)
# ---------------------------------------------------------------------------
def restore_version(version_id: int, reason: str | None = None) -> str:
    ver = get_version(version_id)
    sid, doc_type, cid = ver["shipment_id"], ver["doc_type"], ver["container_fk"]
    own = ver["snapshot"]["own"]
    snap = capture(sid)
    current = snap["docs"].get((doc_type, cid)) if snap else None
    if not current:
        raise S.ShipmentError(["Chứng từ này không còn tồn tại — không thể khôi phục."])
    keep = {k: current["own"].get(k) for k in STATUS_KEYS.get(doc_type, set()) if k in current["own"]}
    values = {**own, **keep}          # statuses / evidence stay as they are now
    why = f"Khôi phục từ v{ver['version']}" + (f" — {reason}" if S.clean_text(reason) else "")
    with tracking.action("RESTORE", why):
        if doc_type == "BOOKING":
            flat = ver["snapshot"]["flat"]
            shared = {k: flat.get(f"inh.{k}") for k in B.SHARED_FIELDS}
            B.save_booking(sid, shared, values, reason=why)
        elif doc_type == "EIR":
            container = next(c for c in snap["ship"]["containers"] if c["id"] == cid)
            E.save_eir(sid, cid, {k: container.get(k) for k in E.CONTAINER_FIELDS}, values, reason=why)
        elif doc_type == "VGM":
            container = next(c for c in snap["ship"]["containers"] if c["id"] == cid)
            V.save_vgm(sid, cid, {k: container.get(k) for k in V.CONTAINER_FIELDS}, values,
                       requested_status=current["own"].get("vgm_status") or "Draft", reason=why)
        elif doc_type == "SI":
            SI.save_si(sid, values, action="draft", reason=why)
        elif doc_type == "GATEIN":
            G.save_gatein(sid, cid, values, reason=why)
        elif doc_type == "BL":
            values["carrier_bl_number"] = current["own"].get("carrier_bl_number")
            BL.save_bl(sid, values, particulars=json.loads(own.get("particulars") or "{}"), reason=why)
    return f"Đã khôi phục {current['label']} từ v{ver['version']} thành phiên bản mới v" \
           f"{latest_version_number(sid, doc_type, cid)}."
