"""PDF generation with ReportLab (A4) — REQUIREMENTS.md §11 and §12.

Each document has its OWN function and layout (no generic template with a
different title). Built so far:

    generate_booking_confirmation_pdf()      ← Step 1 (Phase 3)
    generate_empty_eir_pdf()                 ← Step 2 (Phase 4) — one page per container

    generate_vgm_declaration_pdf()           ← Step 3 (Phase 4) — in pdf_vgm.py, one page per container

Coming next: generate_shipping_instruction_pdf(), generate_export_gatein_pdf(),
generate_bill_of_lading_pdf().

Shared here: Unicode font (Noto Sans, Vietnamese + English, always embedded —
no Helvetica anywhere), colours, building blocks, footer with "Page X of Y",
watermarks. Number and date formats come from formatting.py (one standard
for all documents). Never drawn: carrier logos, signatures, stamps or
authentication codes.
"""

import io
import re
from datetime import datetime
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.platypus import (
    CondPageBreak, Flowable, KeepTogether, PageBreak, SimpleDocTemplate, Spacer, Table, TableStyle,
)
from reportlab.platypus import Paragraph as _RLParagraph

from . import APP_NAME, bookings, eir, settings
from .formatting import DASH, fmt_cbm, fmt_date, fmt_datetime, fmt_kg, fmt_packages, packages_total
from . import shipments as S
from .shipments import sample_text

# ---------------------------------------------------------------------------
# Fonts (files live inside the project, so this also works in Colab)
# ---------------------------------------------------------------------------
FONT_DIR = Path(__file__).resolve().parent / "assets" / "fonts"
FONT, FONT_BOLD, FONT_ITALIC = "NotoSans", "NotoSans-Bold", "NotoSans-Italic"
_fonts_ready = False


def register_fonts() -> None:
    global _fonts_ready
    if _fonts_ready:
        return
    pdfmetrics.registerFont(TTFont(FONT, str(FONT_DIR / "NotoSans-Regular.ttf")))
    pdfmetrics.registerFont(TTFont(FONT_BOLD, str(FONT_DIR / "NotoSans-Bold.ttf")))
    pdfmetrics.registerFont(TTFont(FONT_ITALIC, str(FONT_DIR / "NotoSans-Italic.ttf")))
    pdfmetrics.registerFontFamily(FONT, normal=FONT, bold=FONT_BOLD, italic=FONT_ITALIC, boldItalic=FONT_BOLD)
    _fonts_ready = True


# ---------------------------------------------------------------------------
# Page geometry, colours, text styles
# ---------------------------------------------------------------------------
PAGE_W, PAGE_H = A4
MARGIN_X = 14 * mm
MARGIN_TOP = 10 * mm
MARGIN_BOTTOM = 17.5 * mm
FOOTER_Y = 10.5 * mm               # baseline of the first footer line
W = PAGE_W - 2 * MARGIN_X          # usable width: 182 mm
GAP = 4 * mm                       # gap between side-by-side sections
SECTION_SPACE = 2.4 * mm           # space between sections

NAVY = colors.HexColor("#0B2545")
NAVY_SOFT = colors.HexColor("#E9EEF5")
GRID = colors.HexColor("#C5CFDC")
ZEBRA = colors.HexColor("#F6F8FB")
TEXT = colors.HexColor("#1C2B3F")
MUTED = colors.HexColor("#5B6B82")
KIND_COLOURS = {   # status badge: (text/border colour, background)
    "draft": (colors.HexColor("#8A5A00"), colors.HexColor("#FFF4D6")),
    "internal": (colors.HexColor("#9C2F23"), colors.HexColor("#FDECEA")),
    "cancelled": (colors.HexColor("#9C2F23"), colors.HexColor("#FDECEA")),
    "confirmed": (colors.HexColor("#1E6B45"), colors.HexColor("#E6F4EC")),
    "reference": (colors.HexColor("#0B2545"), colors.HexColor("#E9EEF5")),
}
DAMAGE_BG = colors.HexColor("#FDECEA")

# Every table names the font explicitly, so ReportLab never falls back to Helvetica.
TABLE_FONT = [("FONTNAME", (0, 0), (-1, -1), FONT), ("FONTSIZE", (0, 0), (-1, -1), 7.5)]


def _style(name, size=8.5, font=None, color=TEXT, leading=None, align=TA_LEFT, **kw):
    # splitLongWords=0: a reference, code or e-mail is never cut in the middle (see Paragraph below)
    return ParagraphStyle(name, fontName=font or FONT, fontSize=size, leading=leading or size * 1.28,
                          textColor=color, alignment=align, splitLongWords=0, **kw)


# ---------------------------------------------------------------------------
# Paragraph that never splits references, codes, phone numbers or e-mails (all six PDFs use it)
# ---------------------------------------------------------------------------
# A phone number / spaced reference: at least 6 digits, only digits, spaces, + ( ) . - between them.
_SPACED_NUMBER = re.compile(r"(?<![\w])\+?\(?\d[\d ().\-]{4,}\d(?![\w])")
_TAG = re.compile(r"(<[^>]*>)")


def keep_together(text: str) -> str:
    """Spaces inside phone numbers / spaced references become non-breaking spaces (outside markup)."""
    def glue(m):
        value = m.group(0)
        return value.replace(" ", " ") if sum(ch.isdigit() for ch in value) >= 6 else value
    return "".join(part if part.startswith("<") else _SPACED_NUMBER.sub(glue, part) for part in _TAG.split(text))


def _overflows(par) -> bool:
    lines = getattr(getattr(par, "blPara", None), "lines", None) or []
    for line in lines:
        extra = line[0] if isinstance(line, tuple) else getattr(line, "extraSpace", 0)
        if extra < -0.5:
            return True
    return False


class Paragraph(_RLParagraph):
    """ReportLab Paragraph that wraps whole values to the next line instead of splitting them.

    Words are never cut (splitLongWords=0) and phone numbers keep their spaces together. If one
    unbreakable value is wider than its box, the paragraph's font is reduced step by step until it fits;
    only as a very last resort (wider than the box even at 55 %) is the word allowed to break.
    """

    def __init__(self, text, style=None, bulletText=None, frags=None, **kw):
        if isinstance(text, str):
            text = keep_together(text)
        self._kt = (text, bulletText, kw)
        self._kt_base = style
        super().__init__(text, style, bulletText=bulletText, frags=frags, **kw)

    def _kt_reset(self, style):
        text, bullet, kw = self._kt
        _RLParagraph.__init__(self, text, style, bulletText=bullet, **kw)

    def wrap(self, avail_w, avail_h):
        text = self._kt[0]
        if text is None or self._kt_base is None:
            return super().wrap(avail_w, avail_h)
        if self.style is not self._kt_base:
            self._kt_reset(self._kt_base)
        size = super().wrap(avail_w, avail_h)
        if not _overflows(self):
            return size
        base = self._kt_base
        for factor in (0.92, 0.85, 0.78, 0.7, 0.62, 0.55):
            self._kt_reset(ParagraphStyle(base.name + "_fit", parent=base, fontSize=base.fontSize * factor,
                                          leading=base.leading * factor))
            size = super().wrap(avail_w, avail_h)
            if not _overflows(self):
                return size
        self._kt_reset(ParagraphStyle(base.name + "_split", parent=base, fontSize=base.fontSize * 0.55,
                                      leading=base.leading * 0.55, splitLongWords=1))
        return super().wrap(avail_w, avail_h)


def _styles() -> dict:
    register_fonts()
    return {
        "brand": _style("brand", 7, FONT_BOLD, MUTED),
        "title": _style("title", 16, FONT_BOLD, NAVY, leading=19.5),
        "subtitle": _style("subtitle", 8.5, FONT, MUTED),
        "label": _style("label", 6.3, FONT_BOLD, MUTED, leading=7.8),
        "value": _style("value", 8.2, FONT, TEXT, leading=10.2),
        "value_b": _style("value_b", 8.2, FONT_BOLD, TEXT, leading=10.2),
        "value_big": _style("value_big", 11.5, FONT_BOLD, NAVY, leading=14),
        "cutoff": _style("cutoff", 9.2, FONT_BOLD, NAVY, leading=11.5),
        "cell": _style("cell", 7.6, FONT, TEXT, leading=9.4),
        "cell_b": _style("cell_b", 7.6, FONT_BOLD, TEXT, leading=9.4),
        "cell_r": _style("cell_r", 7.6, FONT, TEXT, leading=9.4, align=TA_RIGHT),
        "cell_rb": _style("cell_rb", 7.6, FONT_BOLD, TEXT, leading=9.4, align=TA_RIGHT),
        "th": _style("th", 7, FONT_BOLD, colors.white, leading=8.6),
        "th_r": _style("th_r", 7, FONT_BOLD, colors.white, leading=8.6, align=TA_RIGHT),
        "section": _style("section", 8.6, FONT_BOLD, colors.white, leading=10.5),
        "section_vi": _style("section_vi", 7.2, FONT_ITALIC, colors.HexColor("#C9D4E5"), leading=10.5,
                             align=TA_RIGHT),
        "subhead": _style("subhead", 7.4, FONT_BOLD, NAVY, leading=9.5),
        "subnote": _style("subnote", 6.9, FONT_ITALIC, MUTED, leading=8.8),
        "badge": _style("badge", 9, FONT_BOLD, TEXT, leading=11.5, align=TA_RIGHT),
        "badge_sub": _style("badge_sub", 7, FONT, MUTED, leading=9, align=TA_RIGHT),
        "note": _style("note", 7.3, FONT, TEXT, leading=9.4),
        "note_b": _style("note_b", 7.8, FONT_BOLD, TEXT, leading=10),
        "fine": _style("fine", 6.5, FONT_ITALIC, MUTED, leading=8.4),
        "sample": _style("sample", 7.6, FONT_BOLD, colors.HexColor("#7A5A00"), leading=9.6),
    }


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------
# Characters Noto Sans cannot draw would print as empty boxes; replace them with readable text.
_GLYPH_FALLBACKS = {"→": "->", "←": "<-", "⇒": "=>", "✓": "v", "✔": "v", "✗": "x", "✘": "x",
                    "•": "·", "●": "·", "■": "#", "□": "[ ]", "☐": "[ ]", "☑": "[x]", "☒": "[x]"}
_font_chars: set[int] | None = None


def printable(text: str) -> str:
    """Make sure every character can be drawn with the embedded font."""
    global _font_chars
    if _font_chars is None:
        register_fonts()
        _font_chars = set(pdfmetrics.getFont(FONT).face.charToGlyph)
    if all(ord(ch) in _font_chars or ch in "\n\r\t" for ch in text):
        return text
    return "".join(ch if ord(ch) in _font_chars or ch in "\n\r\t" else _GLYPH_FALLBACKS.get(ch, "?")
                   for ch in text)


def txt(value) -> str:
    """Escape for ReportLab paragraphs; keep line breaks; empty → em dash."""
    if value is None or str(value).strip() == "":
        return DASH
    return escape(printable(str(value).strip())).replace("\n", "<br/>")


def safe_filename_part(text: str | None, fallback: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "-", (text or "").strip()).strip("-")
    return cleaned or fallback


# ---------------------------------------------------------------------------
# Building blocks
# ---------------------------------------------------------------------------
def field(st, label: str, value_html: str, value_style="value") -> list:
    """A labelled value: small grey label above the value."""
    return [Paragraph(escape(label.upper()), st["label"]), Paragraph(value_html, st[value_style])]


def field_grid(st, rows: list[list[tuple]], col_widths: list[float], shade=False) -> Table:
    """Grid of labelled values. rows = [[(label, value_html[, style]), ...], ...]"""
    data = [[field(st, *cell) if cell else "" for cell in row] for row in rows]
    t = Table(data, colWidths=col_widths)
    style = TABLE_FONT + [
        ("BOX", (0, 0), (-1, -1), 0.6, GRID),
        ("INNERGRID", (0, 0), (-1, -1), 0.4, GRID),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 4.5), ("RIGHTPADDING", (0, 0), (-1, -1), 4.5),
        ("TOPPADDING", (0, 0), (-1, -1), 2.2), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]
    if shade:
        style.append(("BACKGROUND", (0, 0), (-1, -1), NAVY_SOFT))
    t.setStyle(TableStyle(style))
    return t


def kv_table(st, rows: list[tuple], width: float, label_ratio=0.46) -> Table:
    """Label | value rows (used where sections sit side by side)."""
    data = [[Paragraph(escape(label.upper()), st["label"]), Paragraph(value, st[style])]
            for label, value, style in rows]
    t = Table(data, colWidths=[width * label_ratio, width * (1 - label_ratio)])
    t.setStyle(TableStyle(TABLE_FONT + [
        ("BOX", (0, 0), (-1, -1), 0.6, GRID), ("INNERGRID", (0, 0), (-1, -1), 0.4, GRID),
        ("BACKGROUND", (0, 0), (0, -1), NAVY_SOFT),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 4.5), ("RIGHTPADDING", (0, 0), (-1, -1), 4.5),
        ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.8),
    ]))
    return t


def section_bar(st, title: str, title_vi: str, width: float = W) -> Table:
    t = Table([[Paragraph(escape(title.upper()), st["section"]),
                Paragraph(escape(title_vi), st["section_vi"])]],
              colWidths=[width * 0.62, width * 0.38])
    t.setStyle(TableStyle(TABLE_FONT + [
        ("BACKGROUND", (0, 0), (-1, -1), NAVY),
        ("LEFTPADDING", (0, 0), (-1, -1), 5.5), ("RIGHTPADDING", (0, 0), (-1, -1), 5.5),
        ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    return t


def section(st, title, title_vi, *content, width: float = W) -> KeepTogether:
    """Heading + content kept on the same page (a heading is never left alone)."""
    return KeepTogether([section_bar(st, title, title_vi, width), Spacer(1, 2.2), *content])


def half_section(st, title, title_vi, *content) -> list:
    """A section for one column of side_by_side()."""
    return [section_bar(st, title, title_vi, (W - GAP) / 2), Spacer(1, 2.2), *content]


def side_by_side(left: list, right: list) -> Table:
    half = (W - GAP) / 2
    t = Table([[left, "", right]], colWidths=[half, GAP, half])
    t.setStyle(TableStyle(TABLE_FONT + [
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
    ]))
    return t


def data_table(st, headers: list[tuple[str, str]], rows: list[list], col_widths: list[float],
               total_row: list | None = None) -> Table:
    """Multi-column table: navy header repeated on every page, wrapped cells, zebra rows.

    headers = [(title, "l"|"r"), ...]; rows = lists of already-formatted strings.
    """
    head = [Paragraph(escape(h), st["th_r" if align == "r" else "th"]) for h, align in headers]
    body = [[Paragraph(v, st["cell_r" if headers[i][1] == "r" else "cell"]) for i, v in enumerate(row)]
            for row in rows]
    data = [head] + body
    style = TABLE_FONT + [
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("LINEBELOW", (0, 0), (-1, -1), 0.4, GRID),
        ("BOX", (0, 0), (-1, -1), 0.6, GRID),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.6),
    ]
    style += [("BACKGROUND", (0, r), (-1, r), ZEBRA) for r in range(2, len(body) + 1, 2)]
    if not rows:
        data.append([Paragraph("<i>No data recorded</i>", st["cell"])] + [""] * (len(headers) - 1))
        style.append(("SPAN", (0, -1), (-1, -1)))
    elif total_row:
        data.append([Paragraph(v, st["cell_rb" if headers[i][1] == "r" else "cell_b"])
                     for i, v in enumerate(total_row)])
        style += [("BACKGROUND", (0, -1), (-1, -1), NAVY_SOFT), ("LINEABOVE", (0, -1), (-1, -1), 0.8, NAVY)]
    t = Table(data, colWidths=col_widths, repeatRows=1)
    t.setStyle(TableStyle(style))
    return t


def note_box(st, kind: str, heading: str, text: str, fine: str = "") -> Table:
    fg, bg = KIND_COLOURS.get(kind, (NAVY, NAVY_SOFT))
    content = [Paragraph(escape(heading), st["note_b"]), Spacer(1, 1.5), Paragraph(escape(text), st["note"])]
    if fine:
        content += [Spacer(1, 2), Paragraph(escape(fine), st["fine"])]
    t = Table([[content]], colWidths=[W])
    t.setStyle(TableStyle(TABLE_FONT + [
        ("BACKGROUND", (0, 0), (-1, -1), bg), ("BOX", (0, 0), (-1, -1), 0.9, fg),
        ("LEFTPADDING", (0, 0), (-1, -1), 6.5), ("RIGHTPADDING", (0, 0), (-1, -1), 6.5),
        ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    return t


def sample_banner(st, sample_text: str) -> Table:
    t = Table([[Paragraph(f"{escape(sample_text)} DATA — invented data for testing only. Not for operational use. "
                          "· DỮ LIỆU MẪU — chỉ dùng để thử.", st["sample"])]], colWidths=[W])
    t.setStyle(TableStyle(TABLE_FONT + [
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#FFF3CD")),
        ("BOX", (0, 0), (-1, -1), 0.8, colors.HexColor("#E5C04A")),
        ("LEFTPADDING", (0, 0), (-1, -1), 6.5), ("TOPPADDING", (0, 0), (-1, -1), 2.5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5),
    ]))
    return t


class CheckBox(Flowable):
    """A drawn tick box (the font has no ✓ glyph): empty square, or square with a tick."""

    def __init__(self, checked: bool, size: float = 3.4 * mm, colour=NAVY):
        super().__init__()
        self.checked, self.size, self.colour = checked, size, colour
        self.hAlign = "CENTER"

    def wrap(self, avail_w, avail_h):
        return self.size, self.size

    def draw(self):
        c, s = self.canv, self.size
        c.saveState()
        # empty boxes stay neutral grey; only a ticked box takes its colour (e.g. red = damaged)
        c.setStrokeColor(self.colour if self.checked else MUTED)
        c.setLineWidth(0.8)
        c.rect(0, 0, s, s)
        if self.checked:
            c.setLineWidth(1.5)
            path = c.beginPath()
            path.moveTo(0.18 * s, 0.52 * s)
            path.lineTo(0.42 * s, 0.24 * s)
            path.lineTo(0.84 * s, 0.82 * s)
            c.drawPath(path, stroke=1, fill=0)
        c.restoreState()


# ---------------------------------------------------------------------------
# Page decoration: watermark, running header, footer with "Page X of Y"
# ---------------------------------------------------------------------------
def _page_decorator(watermark: str | None, running_header: str | None):
    def on_page(canv, doc):
        canv.saveState()
        if watermark:
            canv.setFont(FONT_BOLD, 64 if len(watermark) <= 8 else 46)
            canv.setFillColor(NAVY)
            canv.setFillAlpha(0.06)
            canv.translate(PAGE_W / 2, PAGE_H / 2)
            canv.rotate(35)
            canv.drawCentredString(0, -20, watermark)
            canv.rotate(-35)
            canv.translate(-PAGE_W / 2, -PAGE_H / 2)
            canv.setFillAlpha(1)
        if doc.page > 1 and running_header:
            canv.setFont(FONT, 7)
            canv.setFillColor(MUTED)
            canv.drawString(MARGIN_X, PAGE_H - 6.5 * mm, running_header)
            canv.setStrokeColor(GRID)
            canv.setLineWidth(0.4)
            canv.line(MARGIN_X, PAGE_H - 7.8 * mm, PAGE_W - MARGIN_X, PAGE_H - 7.8 * mm)
        canv.restoreState()
    return on_page


def _numbered_canvas(footer_lines: list[str]):
    """Canvas that knows the total page count, to print 'Page X of Y' in the footer."""

    class NumberedCanvas(rl_canvas.Canvas):
        def __init__(self, *args, **kwargs):
            # ReportLab's default canvas font is Helvetica (the doc template passes None, which
            # means Helvetica). Start every page with Noto Sans so Helvetica is never referenced.
            if not kwargs.get("initialFontName"):
                kwargs["initialFontName"] = FONT
            if not kwargs.get("initialFontSize"):
                kwargs["initialFontSize"] = 8
            super().__init__(*args, **kwargs)
            self._pages = []

        def showPage(self):
            self._pages.append(dict(self.__dict__))
            self._startPage()

        def save(self):
            total = len(self._pages)
            for state in self._pages:
                self.__dict__.update(state)
                self._footer(total)
                super().showPage()
            super().save()

        def _footer(self, total):
            self.saveState()
            y = FOOTER_Y
            self.setStrokeColor(NAVY)
            self.setLineWidth(0.8)
            self.line(MARGIN_X, y + 3.4 * mm, PAGE_W - MARGIN_X, y + 3.4 * mm)
            self.setFillColor(TEXT)
            self.setFont(FONT_BOLD, 7)
            self.drawString(MARGIN_X, y, footer_lines[0])
            self.setFont(FONT, 6.6)
            self.setFillColor(MUTED)
            self.drawString(MARGIN_X, y - 3.3 * mm, footer_lines[1])
            self.setFont(FONT_BOLD, 7.5)
            self.setFillColor(NAVY)
            self.drawRightString(PAGE_W - MARGIN_X, y, f"Page {self._pageNumber} of {total}")
            self.setFont(FONT, 6.6)
            self.setFillColor(MUTED)
            self.drawRightString(PAGE_W - MARGIN_X, y - 3.3 * mm, APP_NAME)
            self.restoreState()

    return NumberedCanvas


# ===========================================================================
# STEP 1 — BOOKING CONFIRMATION
# ===========================================================================
def booking_pdf_filename(view: dict) -> str:
    ship, b = view["shipment"], view["booking"]
    return (f"{safe_filename_part(ship['shipment_id'], 'SHIPMENT')}_"
            f"{safe_filename_part(ship.get('booking_number'), 'NO-BOOKING')}_"
            f"Booking_Confirmation_v{b.get('doc_version') or 1}.pdf")


def _party_key(p: dict) -> tuple:
    norm = lambda s: re.sub(r"\s+", " ", (s or "").strip().lower())
    return norm(p.get("party_name")), norm(p.get("address"))


def _merged_parties(parties: dict) -> list[tuple[str, dict | None]]:
    """Shipper, Booking Party, Forwarder — the same company is printed once,
    e.g. 'BOOKING PARTY (also Forwarder)'. Optional parties that are not
    recorded are left out; the Shipper is always shown."""
    cards: list[list] = []   # [heading, extra roles, party]
    for role, title in (("SHIPPER", "SHIPPER"), ("BOOKING_PARTY", "BOOKING PARTY"), ("FORWARDER", "FORWARDER")):
        p = parties.get(role) or {}
        if not p.get("party_name"):
            if role == "SHIPPER":
                cards.append([title, [], None])
            continue
        same = next((c for c in cards if c[2] and _party_key(c[2]) == _party_key(p)), None)
        if same:
            same[1].append(title.title())
        else:
            cards.append([title, [], p])
    return [(heading + (f" (also {', '.join(extra)})" if extra else ""), p) for heading, extra, p in cards]


def _party_block(st, party: dict | None) -> list:
    p = party or {}
    if not p.get("party_name"):
        return [Paragraph("<i>Not recorded</i>", st["cell"])]
    lines = [Paragraph(txt(p["party_name"]), st["cell_b"])]
    address = ", ".join(x for x in (p.get("address"), p.get("country")) if x)
    if address:
        lines.append(Paragraph(txt(address), st["cell"]))
    contact = []
    if p.get("tax_id"):
        contact.append(f"Tax ID: {txt(p['tax_id'])}")
    if p.get("email"):
        contact.append(txt(p["email"]))
    if p.get("phone"):
        contact.append(f"Tel: {txt(p['phone'])}")
    if contact:
        lines.append(Paragraph(" · ".join(contact), st["cell"]))
    return lines


def _booking_story(view: dict, label: dict, exported_at: datetime) -> list:
    st = _styles()
    ship, b = view["shipment"], view["booking"]
    parties = ship["parties"]
    story = []
    fg, bg = KIND_COLOURS[label["kind"]]
    half = (W - GAP) / 2

    # ---- 1. Document header: name + status badge + references --------------
    badge_style = ParagraphStyle("badge_kind", parent=st["badge"], textColor=fg)
    badge = Table([[Paragraph(escape(label["badge"]), badge_style)],
                   [Paragraph(f"Booking status: {escape(label['status'])}", st["badge_sub"])]],
                  colWidths=[64 * mm])
    badge.setStyle(TableStyle(TABLE_FONT + [
        ("BACKGROUND", (0, 0), (-1, -1), bg), ("BOX", (0, 0), (-1, -1), 1, fg),
        ("LEFTPADDING", (0, 0), (-1, -1), 6), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (0, 0), 4.5), ("BOTTOMPADDING", (0, -1), (-1, -1), 4.5),
    ]))
    left = [Paragraph(escape(label["title"]), st["title"]),
            Paragraph(f"Booking Confirmation · Xác nhận đặt chỗ &nbsp;·&nbsp; "
                      f"<font name='{FONT_BOLD}' size='7'>STEP 1 OF 6 · {escape(APP_NAME)}</font>", st["subtitle"])]
    head = Table([[left, badge]], colWidths=[W - 66 * mm, 66 * mm])
    head.setStyle(TableStyle(TABLE_FONT + [
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("TOPPADDING", (0, 0), (-1, -1), 0),
        ("LINEBELOW", (0, 0), (-1, 0), 1.6, NAVY), ("BOTTOMPADDING", (0, 0), (-1, 0), 5),
    ]))
    references = field_grid(st, [[
        ("Booking Number", txt(ship.get("booking_number")), "value_big"),
        ("Confirmation Date", fmt_date(b.get("confirmation_date")), "value_b"),
        ("Carrier", txt(ship.get("carrier_name")), "value_b"),
        ("Shipment ID", txt(ship["shipment_id"]), "value_b"),
    ]], [W * 0.28, W * 0.20, W * 0.30, W * 0.22], shade=True)
    header = [head, Spacer(1, 3.5)]
    if label["sample"]:
        header += [sample_banner(st, label["sample_text"]), Spacer(1, 3)]
    header.append(references)
    story += [KeepTogether(header), Spacer(1, SECTION_SPACE)]

    # ---- 2. Booking information (no repeat of booking no./carrier/parties) ---
    if bookings.has_carrier_evidence(b):
        source = bookings.CONFIRMATION_SOURCES_EN.get(b["confirmation_source"], b["confirmation_source"])
        confirmation = f"{txt(source)} · Ref. <b>{txt(b['confirmation_reference'])}</b>"
    else:
        confirmation = "Not confirmed by carrier"
    story += [section(st, "Booking Information", "Thông tin đặt chỗ", field_grid(st, [[
        ("Booking Date", fmt_date(b.get("booking_date"))),
        ("Booking Status", txt(b.get("booking_status")), "value_b"),
        ("Customer Reference", txt(b.get("customer_reference"))),
        ("Carrier Confirmation", confirmation),
        ("Recorded By", txt(b.get("confirmed_by"))),
    ]], [W * w for w in (0.13, 0.20, 0.25, 0.27, 0.15)])), Spacer(1, SECTION_SPACE)]

    # ---- 3. Parties (same company printed once) ------------------------------
    cards = _merged_parties(parties)
    n = len(cards)
    party_table = Table([[Paragraph(escape(h), st["label"]) for h, _ in cards],
                         [_party_block(st, p) for _, p in cards]], colWidths=[W / n] * n)
    party_table.setStyle(TableStyle(TABLE_FONT + [
        ("BACKGROUND", (0, 0), (-1, 0), NAVY_SOFT),
        ("BOX", (0, 0), (-1, -1), 0.6, GRID), ("INNERGRID", (0, 0), (-1, -1), 0.4, GRID),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 4.5), ("RIGHTPADDING", (0, 0), (-1, -1), 4.5),
        ("TOPPADDING", (0, 0), (-1, -1), 2.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    story += [section(st, "Parties", "Các bên liên quan", party_table), Spacer(1, SECTION_SPACE)]

    # ---- 4. Routing  |  5. Vessel / Voyage (side by side) -------------------
    routing = half_section(st, "Routing", "Tuyến vận chuyển", kv_table(st, [
        ("Place of Receipt", txt(ship.get("place_of_receipt")), "value"),
        ("Port of Loading (POL)", txt(ship.get("port_of_loading")), "value_b"),
        ("Transshipment Port", txt(ship.get("transshipment_port")), "value"),
        ("Port of Discharge (POD)", txt(ship.get("port_of_discharge")), "value_b"),
        ("Place of Delivery", txt(ship.get("place_of_delivery")), "value"),
    ], half, label_ratio=0.40))
    vessel = half_section(st, "Vessel / Voyage", "Tàu / Chuyến", kv_table(st, [
        ("Ocean Vessel", txt(ship.get("vessel_name")), "value_b"),
        ("Voyage No.", txt(ship.get("voyage_number")), "value_b"),
        ("ETD (estimated departure)", fmt_date(ship.get("etd")), "value_b"),
        ("ETA (estimated arrival)", fmt_date(ship.get("eta")), "value"),
    ], half, label_ratio=0.46))
    story += [KeepTogether([side_by_side(routing, vessel)]), Spacer(1, SECTION_SPACE)]

    # ---- 6. Container & Cargo --------------------------------------------------
    containers = ship["containers"]
    equipment = bookings.equipment_summary(containers)
    eq_rows = [[f"<b>{g['qty']} ×</b>", txt(g["size"] or "Size TBA"), txt(g["iso"]), txt(g["type"])]
               for g in equipment]
    eq_table = data_table(st, [("Qty", "l"), ("Size", "l"), ("ISO Type", "l"), ("Container Type", "l")],
                          eq_rows, [W * 0.12, W * 0.16, W * 0.18, W * 0.54],
                          total_row=([f"<b>{len(containers)}</b>", "containers in total", "", ""]
                                     if len(equipment) > 1 else None))
    assigned = bookings.assigned_containers(containers)
    unassigned = len(containers) - len(assigned)
    # Explain missing container numbers only when some are missing
    numbers_note = []
    if unassigned:
        text = ("Container numbers are normally assigned at empty container release (Step 2 — EIR). "
                + (f"{unassigned} of {len(containers)} not yet assigned." if assigned else "None assigned yet."))
        numbers_note = [Spacer(1, 1.5), Paragraph(escape(text), st["subnote"])]
    story += [CondPageBreak(45 * mm),
              section(st, "Container & Cargo", "Container & hàng hóa",
                      Paragraph("EQUIPMENT", st["subhead"]), Spacer(1, 1.5), eq_table, *numbers_note)]
    if assigned:
        rows = [[str(i), f"<b>{txt(c['container_number'])}</b>",
                 " ".join(x for x in (f"{c['container_size']}'" if c.get("container_size") else None,
                                      c.get("iso_type_code")) if x) or DASH,
                 txt(c.get("container_type")), txt(c.get("load_status")), fmt_kg(c.get("cargo_weight_kg")),
                 txt(c.get("notes"))]
                for i, c in enumerate(assigned, start=1)]
        story += [Spacer(1, 3), CondPageBreak(28 * mm),
                  Paragraph("ASSIGNED CONTAINERS", st["subhead"]), Spacer(1, 1.5),
                  data_table(st, [("No.", "r"), ("Container No.", "l"), ("Size / ISO", "l"),
                                  ("Container Type", "l"), ("Full / Empty", "l"), ("Est. Cargo (kg)", "r"),
                                  ("Remarks", "l")],
                             rows, [W * w for w in (0.06, 0.18, 0.14, 0.15, 0.11, 0.13, 0.23)])]

    cargo = ship["cargo"]
    gw = sum(c.get("gross_weight_kg") or 0 for c in cargo)
    cbm = sum(c.get("volume_cbm") or 0 for c in cargo)
    cargo_rows = [[str(c["line_number"]), txt(c.get("commodity")), txt(c.get("cargo_description")),
                   txt(c.get("hs_code")), fmt_packages(c.get("package_count"), c.get("package_type")),
                   fmt_kg(c.get("gross_weight_kg")), fmt_cbm(c.get("volume_cbm"))] for c in cargo]
    cargo_table = data_table(
        st, [("No.", "r"), ("Commodity", "l"), ("Description of Goods", "l"), ("HS Code", "l"),
             ("Packages", "l"), ("Gross Wt (kg)", "r"), ("CBM", "r")],
        cargo_rows, [W * w for w in (0.05, 0.18, 0.32, 0.10, 0.15, 0.11, 0.09)],
        total_row=["", "TOTAL", "", "", packages_total(cargo), fmt_kg(gw), fmt_cbm(cbm)])
    dg = [f"Line {c['line_number']}: {c['dangerous_goods_info']}" for c in cargo if c.get("dangerous_goods_info")]
    special = b.get("special_cargo_requirements") or ""
    if dg:
        special = (special + "\n" if special else "") + "Dangerous / special cargo: " + "; ".join(dg)
    # Cargo table + commodity box stay together (moved as one block if needed)
    story += [Spacer(1, 3), KeepTogether([
        Paragraph("CARGO", st["subhead"]), Spacer(1, 1.5), cargo_table, Spacer(1, 2.5),
        field_grid(st, [[
            ("Commodity", txt(bookings.commodity_text(view)), "value_b"),
            ("Special Cargo Requirements", txt(special or "None declared")),
        ]], [W * 0.50, W * 0.50]),
    ]), Spacer(1, SECTION_SPACE)]

    # ---- 7. Cut-off  |  8. Empty container pick-up (side by side) -----------
    cutoffs = half_section(st, "Cut-off", "Hạn chót", kv_table(st, [
        ("CY cut-off", fmt_datetime(ship.get("cy_cutoff")), "cutoff"),
        ("SI cut-off", fmt_datetime(ship.get("si_cutoff")), "cutoff"),
        ("VGM cut-off", fmt_datetime(ship.get("vgm_cutoff")), "cutoff"),
    ], half, label_ratio=0.40))
    pickup = half_section(st, "Empty Container Pick-up", "Lấy container rỗng", kv_table(st, [
        ("Pick-up depot / location", txt(ship.get("empty_pickup_depot")), "value_b"),
        ("Pick-up date", fmt_date(ship.get("empty_pickup_date")), "value_b"),
    ], half, label_ratio=0.38))
    story += [KeepTogether([side_by_side(cutoffs, pickup)]), Spacer(1, SECTION_SPACE)]

    # ---- 9. Remarks and carrier instructions ---------------------------------
    story += [section(st, "Remarks and Carrier Instructions", "Ghi chú & hướng dẫn của hãng tàu",
                      field_grid(st, [[
                          ("Remarks", txt(b.get("remarks"))),
                          ("Carrier Instructions", txt(b.get("carrier_instructions"))),
                      ]], [W / 2, W / 2])),
              Spacer(1, SECTION_SPACE)]

    # ---- Document status / legal note ------------------------------------------
    story.append(KeepTogether([note_box(
        st, label["kind"], f"DOCUMENT STATUS: {label['badge']}", label["note"],
        fine=(f"Generated by {APP_NAME} · {exported_at.strftime('%d %b %Y %H:%M').upper()} · "
              "no carrier logo, signature, stamp or authentication code is reproduced."))]))
    return story


def _render_booking_pdf(view: dict, target) -> None:
    register_fonts()
    ship, b = view["shipment"], view["booking"]
    label = bookings.document_label(view)
    exported_at = datetime.now()
    version = f"v{b.get('doc_version') or 1}"
    booking_no = ship.get("booking_number") or DASH
    watermark = "SAMPLE" if label["sample"] else {
        "draft": "DRAFT", "internal": "INTERNAL", "cancelled": "CANCELLED"}.get(label["kind"])
    footer = [
        f"Shipment ID: {ship['shipment_id']}   ·   Booking No.: {booking_no}   ·   Document version: {version}",
        f"Booking Confirmation   ·   {label['badge']}"
        + (f"   ·   {label['sample_text']} DATA" if label["sample"] else "")
        + f"   ·   Exported: {exported_at.strftime('%d %b %Y %H:%M').upper()}",
    ]
    running = f"{label['title']}   ·   Booking No. {booking_no}   ·   {ship['shipment_id']}   (continued)"
    doc = SimpleDocTemplate(
        target, pagesize=A4, leftMargin=MARGIN_X, rightMargin=MARGIN_X,
        topMargin=MARGIN_TOP, bottomMargin=MARGIN_BOTTOM,
        title=f"{label['title']} — {booking_no}", author=APP_NAME,
        subject=f"Booking Confirmation · {ship['shipment_id']} · {version}", creator=APP_NAME,
        initialFontName=FONT, initialFontSize=8)
    decorate = _page_decorator(watermark, running)
    doc.build(_booking_story(view, label, exported_at), onFirstPage=decorate, onLaterPages=decorate,
              canvasmaker=_numbered_canvas(footer))


def build_booking_confirmation_pdf_bytes(shipment_id: str) -> bytes:
    """Build the PDF in memory (for the preview) without saving a file."""
    view = bookings.get_booking_view(shipment_id)
    if not view:
        raise bookings.BookingError([f"Không tìm thấy lô hàng {shipment_id}."])
    buffer = io.BytesIO()
    _render_booking_pdf(view, buffer)
    return buffer.getvalue()


def generate_booking_confirmation_pdf(shipment_id: str, output_path: str | Path | None = None) -> Path:
    """Create the Booking Confirmation PDF and save it in the data folder.

    File: <data>/pdfs/<ShipmentID>/<ShipmentID>_<BookingNo>_Booking_Confirmation_v<N>.pdf
    """
    view = bookings.get_booking_view(shipment_id)
    if not view:
        raise bookings.BookingError([f"Không tìm thấy lô hàng {shipment_id}."])
    if not view["exists"]:
        raise bookings.BookingError(["Bước 1 chưa được lưu. Hãy bấm “Lưu nháp Booking” trước khi xuất PDF."])
    if output_path is None:
        folder = settings.PDF_DIR / safe_filename_part(shipment_id, "SHIPMENT")
        folder.mkdir(parents=True, exist_ok=True)
        output_path = folder / booking_pdf_filename(view)
    output_path = Path(output_path)
    _render_booking_pdf(view, str(output_path))
    bookings.record_pdf_export(shipment_id, str(output_path))
    from .library import register_generated      # Document Library keeps every version
    register_generated(shipment_id, "BOOKING", output_path)
    return output_path


# ===========================================================================
# STEP 2 — EMPTY CONTAINER EIR (equipment interchange receipt layout)
# ===========================================================================
def _container_number_block(st, number: str | None) -> Table:
    """Big stencil-style container number: 'DEMU 123456' + boxed check digit."""
    big = ParagraphStyle("cn_big", parent=st["value_big"], fontSize=19, leading=22, textColor=NAVY)
    if number and re.fullmatch(r"[A-Z]{4}\d{7}", number):
        cells = [[Paragraph(f"{number[:4]}&nbsp;&nbsp;{number[4:10]}", big), Paragraph(number[10], big)]]
        widths = [58 * mm, 8 * mm]
        style = [("BOX", (1, 0), (1, 0), 1.2, NAVY), ("ALIGN", (1, 0), (1, 0), "CENTER")]
    else:
        cells = [[Paragraph(txt(number) if number else "<i>Not yet assigned</i>", big)]]
        widths = [60 * mm]
        style = []
    t = Table(cells, colWidths=widths, hAlign="LEFT")
    t.setStyle(TableStyle(TABLE_FONT + style + [
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 2), ("RIGHTPADDING", (0, 0), (-1, -1), 2),
        ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    return t


def _block(st, title: str, title_vi: str, content: list, width: float) -> Table:
    """Outlined block with a grey title strip (receipt style, different from the booking's navy bars)."""
    head = Table([[Paragraph(escape(title.upper()), st["subhead"]),
                   Paragraph(escape(title_vi), ParagraphStyle("bvi", parent=st["subnote"], alignment=TA_RIGHT))]],
                 colWidths=[width * 0.6, width * 0.4])
    head.setStyle(TableStyle(TABLE_FONT + [
        ("BACKGROUND", (0, 0), (-1, -1), NAVY_SOFT), ("LINEBELOW", (0, 0), (-1, -1), 0.8, NAVY),
        ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 2.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    t = Table([[head], [content]], colWidths=[width])
    t.setStyle(TableStyle(TABLE_FONT + [
        ("BOX", (0, 0), (-1, -1), 1, NAVY),
        ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    return t


def _plain_grid(st, rows: list[list[tuple]], col_widths: list[float]) -> Table:
    """Labelled values inside a block (no outer box — the block draws it)."""
    data = [[field(st, *cell) if cell else "" for cell in row] for row in rows]
    t = Table(data, colWidths=col_widths)
    t.setStyle(TableStyle(TABLE_FONT + [
        ("INNERGRID", (0, 0), (-1, -1), 0.4, GRID),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 2.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5),
    ]))
    return t


def _signature_box(st, title: str, title_vi: str, width: float) -> Table:
    lines = [Paragraph("NAME / HỌ TÊN", st["label"]), Spacer(1, 7 * mm),
             Paragraph("SIGNATURE / CHỮ KÝ", st["label"]), Spacer(1, 12 * mm),
             Paragraph("DATE / TIME", st["label"]), Spacer(1, 5 * mm)]
    inner = Table([[lines]], colWidths=[width])
    inner.setStyle(TableStyle(TABLE_FONT + [
        ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
    ]))
    return _block(st, title, title_vi, [inner], width)


def _eir_page(st, ship: dict, item: dict, index: int, total: int) -> list:
    c, record = item["container"], item["eir"]
    label = eir.document_label(ship, c, record)
    fg, bg = KIND_COLOURS[label["kind"]]
    half = (W - GAP) / 2
    story = []

    # ---- Navy band: document name + direction ------------------------------
    white = ParagraphStyle("band_t", parent=st["title"], textColor=colors.white, fontSize=15, leading=18)
    white_sub = ParagraphStyle("band_s", parent=st["subtitle"], textColor=colors.HexColor("#C9D4E5"))
    direction = ParagraphStyle("band_d", parent=st["value_big"], textColor=NAVY, alignment=TA_RIGHT, fontSize=12)
    out_box = Table([[Paragraph("EMPTY&nbsp;OUT", direction)],
                     [Paragraph("Depot » Trucker", ParagraphStyle("band_d2", parent=st["badge_sub"],
                                                                  textColor=NAVY))]], colWidths=[36 * mm])
    out_box.setStyle(TableStyle(TABLE_FONT + [
        ("BACKGROUND", (0, 0), (-1, -1), colors.white),
        ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (0, 0), 3), ("BOTTOMPADDING", (0, -1), (-1, -1), 3),
    ]))
    band = Table([[[Paragraph("EQUIPMENT INTERCHANGE RECEIPT", white),
                    Paragraph(f"Empty Container EIR · Phiếu EIR cấp container rỗng &nbsp;·&nbsp; "
                              f"<font name='{FONT_BOLD}' size='7'>STEP 2 OF 6 · {escape(APP_NAME)}</font>",
                              white_sub)], out_box]],
                 colWidths=[W - 40 * mm, 40 * mm])
    band.setStyle(TableStyle(TABLE_FONT + [
        ("BACKGROUND", (0, 0), (-1, -1), NAVY), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (1, 0), (1, 0), "RIGHT"),
        ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
    ]))
    story += [band]

    # ---- Document status strip ------------------------------------------------
    strip_style = ParagraphStyle("strip", parent=st["note_b"], textColor=fg)
    strip = Table([[Paragraph(f"{escape(label['badge'])}", strip_style),
                    Paragraph(f"EIR status: <b>{escape(item['status'])}</b> &nbsp;·&nbsp; EIR {index} of {total}"
                              + (f" &nbsp;·&nbsp; <b>{escape(label['sample_text'])} DATA</b>" if label["sample"] else ""),
                              ParagraphStyle("strip_r", parent=st["note"], alignment=TA_RIGHT))]],
                  colWidths=[W * 0.45, W * 0.55])
    strip.setStyle(TableStyle(TABLE_FONT + [
        ("BACKGROUND", (0, 0), (-1, -1), bg), ("LINEBELOW", (0, 0), (-1, -1), 1.2, fg),
        ("LEFTPADDING", (0, 0), (-1, -1), 6), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    story += [strip, Spacer(1, 3.5 * mm)]

    # ---- References -------------------------------------------------------------
    story.append(field_grid(st, [[
        (label["reference_label"], txt(label["reference"]), "value_big"),
        ("EIR Date / Time", fmt_datetime(record.get("eir_datetime")), "value_b"),
        ("Booking No.", txt(ship.get("booking_number")), "value_b"),
        ("Carrier", txt(ship.get("carrier_name"))),
        ("Shipment ID", txt(ship["shipment_id"])),
    ]], [W * w for w in (0.30, 0.19, 0.17, 0.19, 0.15)], shade=True))
    story.append(Spacer(1, 3.5 * mm))

    # ---- Equipment | Depot ---------------------------------------------------------
    size = f"{c['container_size']}'" if c.get("container_size") else None
    handover = (record.get("handover_load_status") or "Empty")
    seal = "— (empty)" if handover == "Empty" else txt(c.get("seal_number"))
    number_block = [_container_number_block(st, c.get("container_number"))]
    number = c.get("container_number")
    if number and S.container_number_problem(number):
        if re.fullmatch(r"[A-Z]{3}[UJZ]\d{7}", number):
            problem = f"check digit should be {S.iso6346_check_digit(number[:10])}, not {number[10]}"
        else:
            problem = "not a valid ISO 6346 container number format"
        warn = ParagraphStyle("cn_warn", parent=st["subnote"], textColor=colors.HexColor("#9C2F23"))
        number_block.append(Paragraph(f"<b>ISO 6346 check failed:</b> {problem} — verify the container number.",
                                      warn))
    equipment = _block(st, "Equipment", "Thiết bị / container", [
        Spacer(1, 2), Table([[number_block]], colWidths=[half],
                            style=TableStyle(TABLE_FONT + [("LEFTPADDING", (0, 0), (-1, -1), 4)])),
        _plain_grid(st, [
            [("Size", txt(size), "value_b"), ("ISO Type", txt(c.get("iso_type_code")), "value_b"),
             ("Container Type", txt(c.get("container_type")))],
            [("Status at Handover", txt(handover.upper()), "value_b"),
             ("Tare (kg)", fmt_kg(c.get("tare_weight_kg"))), ("Seal No.", seal)],
        ], [half * 0.30, half * 0.30, half * 0.40]),
    ], half)
    planned = ship.get("empty_pickup_depot")
    actual = eir.effective_depot(ship, record)
    depot_rows = [[("Depot / Yard", txt(actual), "value_b")]]
    if record.get("depot_yard") and planned and record["depot_yard"] != planned:
        depot_rows.append([("Planned pick-up depot (booking)", txt(planned))])
    depot_rows += [[("Planned pick-up date", fmt_date(ship.get("empty_pickup_date")))],
                   [("Handover information", txt(record.get("handover_info")))]]
    depot = _block(st, "Depot / Location", "Depot / bãi", [_plain_grid(st, depot_rows, [half])], half)
    story += [side_by_side([equipment], [depot]), Spacer(1, 3.5 * mm)]

    # ---- Transport ---------------------------------------------------------------
    story += [_block(st, "Transport", "Phương tiện vận chuyển", [_plain_grid(st, [[
        ("Truck No.", txt(c.get("truck_number")), "value_b"),
        ("Chassis No.", txt(c.get("chassis_number")), "value_b"),
        ("Driver", txt(record.get("driver_info"))),
    ]], [W * 0.25, W * 0.25, W * 0.50])], W), Spacer(1, 3.5 * mm)]

    # ---- Condition checklist ------------------------------------------------------
    head = [Paragraph("AREA / HẠNG MỤC", st["th"]), Paragraph("OK", st["th"]),
            Paragraph("DAMAGED", st["th"]), Paragraph("NOT CHECKED", st["th"]),
            Paragraph("NOTE / GHI CHÚ", st["th"])]
    rows, style = [head], []
    for r, (key, en, vi) in enumerate(eir.CONDITION_AREAS, start=1):
        value = record.get(f"cond_{key}") or "NOT_CHECKED"
        rows.append([[Paragraph(f"<b>{escape(en)}</b>", st["cell"]), Paragraph(escape(vi), st["subnote"])],
                     CheckBox(value == "OK"), CheckBox(value == "DAMAGED", colour=colors.HexColor("#9C2F23")),
                     CheckBox(value == "NOT_CHECKED", colour=MUTED), Paragraph(txt(record.get(f"note_{key}")), st["cell"])])
        if value == "DAMAGED":
            style.append(("BACKGROUND", (0, r), (-1, r), DAMAGE_BG))
    checklist = Table(rows, colWidths=[W * w for w in (0.24, 0.09, 0.11, 0.13, 0.43)], repeatRows=1)
    checklist.setStyle(TableStyle(TABLE_FONT + style + [
        ("BACKGROUND", (0, 0), (-1, 0), NAVY), ("BOX", (0, 0), (-1, -1), 1, NAVY),
        ("INNERGRID", (0, 0), (-1, -1), 0.4, GRID),
        ("ALIGN", (1, 0), (3, -1), "CENTER"), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5),
    ]))
    checked = sum(1 for k, _, _ in eir.CONDITION_AREAS if (record.get(f"cond_{k}") or "NOT_CHECKED") != "NOT_CHECKED")
    damaged = sum(1 for k, _, _ in eir.CONDITION_AREAS if record.get(f"cond_{k}") == "DAMAGED")
    story += [KeepTogether([
        Paragraph(f"CONTAINER CONDITION AT HANDOVER &nbsp;<font name='{FONT}' size='7' color='#5B6B82'>"
                  f"Tình trạng container khi giao · {checked}/7 checked · {damaged} damaged</font>", st["subhead"]),
        Spacer(1, 1.5), checklist]), Spacer(1, 3 * mm)]

    # ---- Damage / condition remarks ---------------------------------------------------
    areas = eir.damaged_areas(record)
    remarks = (record.get("damage_remarks") or "").strip()
    if areas:
        listed = "; ".join(escape(a["en"]) + (f" — {txt(a['note'])}" if a["note"] else "") for a in areas)
        value = (f"<font color='#9C2F23'><b>Damaged areas ({len(areas)}):</b> {listed}</font><br/>"
                 + (txt(remarks) if remarks else
                    "<font color='#9C2F23'><b>Damage remarks not yet recorded — required before this EIR "
                    "can be completed.</b></font>"))
    else:
        value = txt(remarks or "No damage recorded.")
    story += [field_grid(st, [[("Damage / Condition Remarks · Mô tả hư hỏng / tình trạng", value)]], [W]),
              Spacer(1, 3.5 * mm)]

    # ---- Signatures (left empty: the app never creates signatures) ------------------
    story += [KeepTogether([side_by_side(
        [_signature_box(st, "Handed over by — Depot / Yard", "Bên giao (depot)", half)],
        [_signature_box(st, "Received by — Trucker / Driver", "Bên nhận (tài xế)", half)],
    )]), Spacer(1, 3 * mm)]

    story.append(note_box(st, label["kind"], f"DOCUMENT STATUS: {label['badge']}", label["note"],
                          fine=f"Signature boxes are left blank on purpose — {APP_NAME} never reproduces "
                               "signatures, stamps or depot authentication codes."))
    return story


def eir_pdf_filename(ship: dict, items: list[dict], all_eirs: bool) -> str:
    if all_eirs:
        part = "ALL"
    else:
        c = items[0]["container"]
        part = safe_filename_part(c.get("container_number") or items[0]["eir"]["internal_reference"], "EIR")
    version = max((i["eir"].get("doc_version") or 1) for i in items)
    return (f"{safe_filename_part(ship['shipment_id'], 'SHIPMENT')}_"
            f"{safe_filename_part(ship.get('booking_number'), 'NO-BOOKING')}_"
            f"Empty_Container_EIR_{part}_v{version}.pdf")


def _eir_items(shipment_id: str, container_ids: list[int] | None) -> tuple[dict, list[dict]]:
    overview = eir.get_shipment_eirs(shipment_id)
    if not overview:
        raise eir.EIRError([f"Không tìm thấy lô hàng {shipment_id}."])
    items = [i for i in overview["items"] if i["eir"]]
    if container_ids is not None:
        items = [i for i in items if i["container"]["id"] in container_ids]
    if not items:
        raise eir.EIRError(["Chưa có EIR nào được lưu. Hãy bấm “Lưu EIR” trước khi xuất PDF."])
    return overview["shipment"], items


def _render_eir_pdf(ship: dict, items: list[dict], target) -> None:
    register_fonts()
    st = _styles()
    exported_at = datetime.now()
    labels = [eir.document_label(ship, i["container"], i["eir"]) for i in items]
    kinds = {lbl["kind"] for lbl in labels}
    watermark = "SAMPLE" if ship["is_sample"] else ("INTERNAL" if kinds == {"internal"} else
                                                    "COPY" if kinds == {"reference"} else None)
    version = f"v{max((i['eir'].get('doc_version') or 1) for i in items)}"
    booking_no = ship.get("booking_number") or DASH
    footer = [
        f"Shipment ID: {ship['shipment_id']}   ·   Booking No.: {booking_no}   ·   Document version: {version}",
        f"Empty Container EIR   ·   {len(items)} EIR{'s' if len(items) > 1 else ''}"
        + (f"   ·   {sample_text(ship)} DATA" if ship["is_sample"] else "")
        + f"   ·   Exported: {exported_at.strftime('%d %b %Y %H:%M').upper()}",
    ]
    story = []
    for n, item in enumerate(items, start=1):
        if n > 1:
            story.append(PageBreak())
        story += _eir_page(st, ship, item, n, len(items))
    doc = SimpleDocTemplate(
        target, pagesize=A4, leftMargin=MARGIN_X, rightMargin=MARGIN_X,
        topMargin=MARGIN_TOP, bottomMargin=MARGIN_BOTTOM,
        title=f"Empty Container EIR — {ship['shipment_id']}", author=APP_NAME,
        subject=f"Empty Container EIR · {ship['shipment_id']} · {version}", creator=APP_NAME,
        initialFontName=FONT, initialFontSize=8)
    decorate = _page_decorator(watermark, None)
    doc.build(story, onFirstPage=decorate, onLaterPages=decorate, canvasmaker=_numbered_canvas(footer))


def build_empty_eir_pdf_bytes(shipment_id: str, container_ids: list[int] | None = None) -> bytes:
    """EIR PDF in memory (preview): one page per container that has an EIR."""
    ship, items = _eir_items(shipment_id, container_ids)
    buffer = io.BytesIO()
    _render_eir_pdf(ship, items, buffer)
    return buffer.getvalue()


def generate_empty_eir_pdf(shipment_id: str, container_ids: list[int] | None = None,
                           output_path: str | Path | None = None) -> Path:
    """Create the Empty Container EIR PDF and save it in the data folder.

    container_ids=None → every saved EIR of the shipment in one PDF (one page per container).
    File: <data>/pdfs/<ShipmentID>/<ShipmentID>_<BookingNo>_Empty_Container_EIR_<ContainerNo|ALL>_v<N>.pdf
    """
    ship, items = _eir_items(shipment_id, container_ids)
    if output_path is None:
        folder = settings.PDF_DIR / safe_filename_part(shipment_id, "SHIPMENT")
        folder.mkdir(parents=True, exist_ok=True)
        output_path = folder / eir_pdf_filename(ship, items, all_eirs=container_ids is None)
    output_path = Path(output_path)
    _render_eir_pdf(ship, items, str(output_path))
    eir.record_pdf_export([i["container"]["id"] for i in items], str(output_path))
    from .library import register_generated      # Document Library keeps every version
    register_generated(shipment_id, "EIR", output_path)
    return output_path


# ---------------------------------------------------------------------------
# Preview
# ---------------------------------------------------------------------------
def render_pdf_pages(pdf_bytes: bytes, scale: float = 1.5) -> list:
    """Return one PIL image per page."""
    import pypdfium2 as pdfium

    pdf = pdfium.PdfDocument(pdf_bytes)
    try:
        return [pdf[i].render(scale=scale).to_pil() for i in range(len(pdf))]
    finally:
        pdf.close()
