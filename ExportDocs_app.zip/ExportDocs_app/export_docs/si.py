"""Step 4 — Shipping Instruction (SI) business logic (REQUIREMENTS.md §5 Step 4, §6, §7).

One SI per shipment, built from the central data:
- parties, routing, vessel/voyage, cargo lines, containers, seals → central tables
- cargo per container → central `container_cargo` (also used by the B/L in Step 6)
- VGM → read-only from Step 3 (containers.vgm_kg, declared VGMs only). Never filled in here.
Only SI-specific fields live in `si_records`.

The gross weight on the SI is the CARGO gross weight (goods + packaging), NEVER the VGM.

Statuses: SI Not Started, SI Draft, SI Submitted, SI Amended, Draft B/L Received,
Draft B/L Approved. Status changes are the user's own records (submission date and channel,
draft B/L received/approved dates) — the app never assumes the carrier received anything.
Drafts can always be saved; problems are warnings, but they stop "Mark as submitted".
"""

import hashlib
import json
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta

from . import bookings as B
from . import shipments as S
from . import vgm as V
from .database import reading, transaction
from .formatting import fmt_cbm, fmt_count, fmt_date, fmt_kg
from .tracking import tracked

STATUSES = ("Draft", "Submitted", "Amended", "Draft B/L Received", "Draft B/L Approved")
STATUS_LABELS = {
    "Not Started": ("SI Not Started", "Chưa bắt đầu"),
    "Draft": ("SI Draft", "Nháp"),
    "Submitted": ("SI Submitted", "Đã gửi hãng tàu"),
    "Amended": ("SI Amended", "Đã gửi bản sửa đổi"),
    "Draft B/L Received": ("Draft B/L Received", "Đã nhận Draft B/L"),
    "Draft B/L Approved": ("Draft B/L Approved", "Đã duyệt Draft B/L"),
}
SUBMITTED_STATES = ("Submitted", "Amended", "Draft B/L Received", "Draft B/L Approved")

BL_TYPES = {"ORIGINAL": "Original B/L", "SEA_WAYBILL": "Sea Waybill", "TELEX": "Telex release"}
TRANSPORT_DOC_TYPES = ("Bill of Lading — port to port", "Combined Transport Bill of Lading", "Sea Waybill",
                       "House Bill of Lading (forwarder)")
SERVICE_TYPES = ("CY/CY", "CY/Door", "Door/CY", "Door/Door")      # service type / move type
FREIGHT_TERMS = {"PREPAID": "Freight Prepaid", "COLLECT": "Freight Collect"}   # freight terms = who pays when
SUBMISSION_CHANNELS = ("Carrier web portal", "EDI (IFTMIN)", "Email to carrier", "e-Booking platform", "Other")

TEXT_FIELDS = ("si_reference", "bl_type", "transport_doc_type", "shipper_reference", "export_reference",
               "document_receiver", "additional_notify_name", "additional_notify_address", "pre_carriage",
               "service_type", "freight_terms", "payable_at", "freight_charges", "remarks",
               "submission_channel", "amendment_reason", "draft_bl_reference")
INT_FIELDS = ("originals_count", "copies_count")
DATE_FIELDS = ("submission_date", "amendment_date", "draft_bl_received_date", "draft_bl_approved_date")
SI_FIELDS = TEXT_FIELDS + INT_FIELDS + DATE_FIELDS
# what the SI says (changes after submission need an amendment); status records are not part of it
CONTENT_FIELDS = tuple(k for k in TEXT_FIELDS + INT_FIELDS
                       if k not in ("remarks", "submission_channel", "amendment_reason", "draft_bl_reference"))

ACTIONS = ("draft", "submit", "amend", "bl_received", "bl_approved")
CUTOFF_WARNING_HOURS = 24
TO_ORDER = re.compile(r"\bTO\s+(THE\s+)?ORDER\b", re.I)


class SIError(S.ShipmentError):
    pass


@dataclass
class SISaveResult:
    shipment_id: str
    si_reference: str
    status: str
    created: bool
    action_done: bool
    warnings: list[str] = field(default_factory=list)


def status_label(status: str) -> str:
    return STATUS_LABELS.get(status, (status, status))[0]


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------
def _defaults(ship: dict) -> dict:
    data = {k: None for k in SI_FIELDS}
    data.update(si_status="Not Started", si_reference=f"SI-{ship['shipment_id']}", bl_type="ORIGINAL",
                originals_count=3, copies_count=3, transport_doc_type=TRANSPORT_DOC_TYPES[0],
                service_type="CY/CY", booking_basis=None, submitted_hash=None, doc_version=1,
                last_pdf_path=None, last_pdf_at=None)
    return data


def get_si_view(shipment_id: str) -> dict | None:
    """Central shipment + SI record (or defaults) + cargo per container + declared VGMs.

    Fields the SI keeps as submitted to the carrier (sync.py) are shown with that value."""
    ship = S.get_shipment(shipment_id, for_doc="SI")
    if not ship:
        return None
    with reading() as conn:
        row = conn.execute("SELECT * FROM si_records WHERE shipment_fk = ?", (ship["id"],)).fetchone()
        allocations = [dict(r) for r in conn.execute(
            "SELECT * FROM container_cargo WHERE shipment_fk = ? ORDER BY container_fk, cargo_fk", (ship["id"],))]
        booking = conn.execute("SELECT booking_status FROM bookings WHERE shipment_fk = ?", (ship["id"],)).fetchone()
    vgm_view = V.get_shipment_vgms(shipment_id)
    vgms = {i["container"]["id"]: i["vgm"] for i in vgm_view["items"]}
    si = dict(row) if row else _defaults(ship)
    return {"shipment": ship, "si": si, "exists": row is not None, "allocations": allocations, "vgms": vgms,
            "booking_status": booking[0] if booking else None}


def party(ship: dict, role: str) -> dict:
    return (ship.get("parties") or {}).get(role) or {}


def is_to_order(name: str | None) -> bool:
    return bool(name and TO_ORDER.search(name))


def declared_vgm(view: dict, container: dict) -> float | None:
    """The VGM from Step 3 — only a declared one (containers.vgm_kg). Never invented."""
    return container.get("vgm_kg")


# ---------------------------------------------------------------------------
# Cargo per container
# ---------------------------------------------------------------------------
def totals(view: dict) -> dict:
    """Per container, per cargo line and shipment totals of the cargo-per-container rows."""
    ship = view["shipment"]
    per_container = {c["id"]: {"packages": 0, "gross": 0.0, "cbm": 0.0, "lines": []} for c in ship["containers"]}
    per_line = {l["id"]: {"packages": 0, "gross": 0.0, "cbm": 0.0} for l in ship["cargo"]}
    for a in view["allocations"]:
        for bucket in (per_container.get(a["container_fk"]), per_line.get(a["cargo_fk"])):
            if bucket is None:
                continue
            bucket["packages"] += a.get("package_count") or 0
            bucket["gross"] += a.get("gross_weight_kg") or 0.0
            bucket["cbm"] += a.get("volume_cbm") or 0.0
        if a["container_fk"] in per_container:
            per_container[a["container_fk"]]["lines"].append(a["cargo_fk"])
    lines = ship["cargo"]
    cargo_total = {"packages": sum(l.get("package_count") or 0 for l in lines),
                   "gross": sum(l.get("gross_weight_kg") or 0.0 for l in lines),
                   "cbm": sum(l.get("volume_cbm") or 0.0 for l in lines)}
    allocated_total = {k: sum(c[k] for c in per_container.values()) for k in ("packages", "gross", "cbm")}
    return {"per_container": per_container, "per_line": per_line, "cargo": cargo_total, "allocated": allocated_total}


def allocation_problems(view: dict) -> list[str]:
    """Cargo per container must add up to the cargo lines (packages, gross weight, CBM)."""
    ship = view["shipment"]
    t = totals(view)
    problems = []
    if not view["allocations"]:
        return ["Chưa phân bổ hàng vào container (Cargo per container) — tab Cargo Details."]
    for n, line in enumerate(ship["cargo"], start=1):
        got = t["per_line"][line["id"]]
        name = line.get("commodity") or line.get("cargo_description") or f"dòng {n}"
        diffs = []
        if (line.get("package_count") or 0) != got["packages"]:
            diffs.append(f"kiện {fmt_count(got['packages'])} / {fmt_count(line.get('package_count') or 0)}")
        if abs((line.get("gross_weight_kg") or 0) - got["gross"]) > 0.5:
            diffs.append(f"gross {fmt_kg(got['gross'])} / {fmt_kg(line.get('gross_weight_kg') or 0)} kg")
        if abs((line.get("volume_cbm") or 0) - got["cbm"]) > 0.0005:
            diffs.append(f"CBM {fmt_cbm(got['cbm'])} / {fmt_cbm(line.get('volume_cbm') or 0)}")
        if diffs:
            problems.append(f"Dòng hàng {n} ({name}): đã phân bổ ≠ dòng hàng — " + "; ".join(diffs) + ".")
    for c in ship["containers"]:
        if not t["per_container"][c["id"]]["lines"]:
            problems.append(f"Container {c.get('container_number') or '(chưa có số)'} chưa có hàng.")
    return problems


def master_weight_warnings(view: dict) -> list[str]:
    """Allocated cargo gross per container vs the container's cargo weight in Shipment Master Data."""
    t = totals(view)
    out = []
    for c in view["shipment"]["containers"]:
        got = t["per_container"][c["id"]]
        if got["lines"] and c.get("cargo_weight_kg") and abs(got["gross"] - c["cargo_weight_kg"]) > 0.5:
            out.append(f"Container {c.get('container_number') or '(chưa có số)'}: gross trên SI {fmt_kg(got['gross'])} kg ≠ "
                       f"Cargo Weight trong dữ liệu lô hàng {fmt_kg(c['cargo_weight_kg'])} kg.")
    return out


# ---------------------------------------------------------------------------
# Booking basis and change detection
# ---------------------------------------------------------------------------
def booking_basis(ship: dict) -> dict:
    """Booking data the SI is based on (compared later to detect changes)."""
    return {"booking_number": ship.get("booking_number"), "port_of_loading": ship.get("port_of_loading"),
            "port_of_discharge": ship.get("port_of_discharge"), "vessel_name": ship.get("vessel_name"),
            "voyage_number": ship.get("voyage_number"),
            "equipment": sorted(f"{e['qty']} x {e['label']}" for e in B.equipment_summary(ship["containers"]))}


BASIS_LABELS = {"booking_number": "Booking No.", "port_of_loading": "POL", "port_of_discharge": "POD",
                "vessel_name": "Vessel", "voyage_number": "Voyage", "equipment": "Container (số lượng & loại)"}


def basis_changes(view: dict) -> list[str]:
    stored = view["si"].get("booking_basis")
    if not stored:
        return []
    old, new = json.loads(stored), booking_basis(view["shipment"])
    return [f"{BASIS_LABELS[k]}: SI theo “{_show(old.get(k))}”, Booking hiện tại “{_show(new.get(k))}”"
            for k in BASIS_LABELS if old.get(k) != new.get(k)]


def _show(value) -> str:
    return ", ".join(value) if isinstance(value, list) else (value or "—")


def content_hash(view: dict) -> str:
    """Fingerprint of everything the SI says (not status records, not the VGM)."""
    ship, si = view["shipment"], view["si"]
    data = {
        "si": {k: si.get(k) for k in CONTENT_FIELDS},
        "parties": {r: {f: party(ship, r).get(f) for f in S.PARTY_FIELDS}
                    for r in ("SHIPPER", "CONSIGNEE", "NOTIFY_PARTY", "FREIGHT_PAYER")},
        "routing": {k: ship.get(k) for k in ("booking_number", "place_of_receipt", "port_of_loading",
                                             "port_of_discharge", "transshipment_port", "place_of_delivery",
                                             "vessel_name", "voyage_number")},
        "cargo": [{k: l.get(k) for k in ("marks_and_numbers", "package_count", "package_type", "cargo_description",
                                         "hs_code", "gross_weight_kg", "volume_cbm")} for l in ship["cargo"]],
        "containers": [{k: c.get(k) for k in ("container_number", "seal_number", "container_size", "iso_type_code")}
                       for c in ship["containers"]],
        "allocations": [[a["container_fk"], a["cargo_fk"], a.get("package_count"), a.get("gross_weight_kg"),
                         a.get("volume_cbm")] for a in view["allocations"]],
    }
    return hashlib.sha256(json.dumps(data, sort_keys=True, default=str).encode()).hexdigest()


def changed_since_submission(view: dict) -> bool:
    si = view["si"]
    return (si.get("si_status") in SUBMITTED_STATES and bool(si.get("submitted_hash"))
            and si["submitted_hash"] != content_hash(view))


# ---------------------------------------------------------------------------
# Routing vs transport document
# ---------------------------------------------------------------------------
def is_port_to_port(si: dict) -> bool:
    """Port-to-port transport document (merchant haulage): the carrier's contract is POL → POD only."""
    return "port to port" in (si.get("transport_doc_type") or "").lower()


def _same_place(a: str | None, b: str | None) -> bool:
    norm = lambda s: re.sub(r"[\s,.]+", " ", (s or "").strip().lower())
    return norm(a) == norm(b)


def routing_problems(view: dict) -> list[str]:
    """Warn when the routing does not fit the transport document type.

    Port to port (CY/CY, merchant haulage): no pre-carriage; place of receipt empty or = POL;
    place of delivery empty or = POD. A Door move type needs carrier haulage (combined transport).
    """
    ship, si = view["shipment"], view["si"]
    out = []
    if is_port_to_port(si):
        doc = si.get("transport_doc_type")
        if si.get("pre_carriage"):
            out.append(f"“{doc}”: không có pre-carriage (merchant haulage) — xóa “Pre-carriage by” "
                       f"({si['pre_carriage']}) hoặc dùng Combined Transport B/L.")
        if ship.get("place_of_receipt") and not _same_place(ship["place_of_receipt"], ship.get("port_of_loading")):
            out.append(f"“{doc}”: Place of Receipt ({ship['place_of_receipt']}) phải để trống hoặc trùng POL "
                       f"({ship.get('port_of_loading')}) — sửa ở Bước 1.")
        if ship.get("place_of_delivery") and not _same_place(ship["place_of_delivery"], ship.get("port_of_discharge")):
            out.append(f"“{doc}”: Place of Delivery ({ship['place_of_delivery']}) phải để trống hoặc trùng POD "
                       f"({ship.get('port_of_discharge')}) — sửa ở Bước 1.")
        if "door" in (si.get("service_type") or "").lower():
            out.append(f"Service type {si['service_type']} có chặng door (hãng tàu chở nội địa) nhưng chứng từ là "
                       f"“{doc}” — dùng Combined Transport B/L hoặc đổi sang CY/CY.")
    return out


# ---------------------------------------------------------------------------
# Checks
# ---------------------------------------------------------------------------
def checks(view: dict, now: datetime | None = None) -> tuple[list[str], list[str]]:
    """(blocking, warnings). Blocking items stop "Mark as submitted"; drafts can always be saved."""
    now = now or datetime.now()
    ship, si = view["shipment"], view["si"]
    blocking, warnings = [], []

    # parties
    for role, label in (("SHIPPER", "Shipper"), ("CONSIGNEE", "Consignee"), ("NOTIFY_PARTY", "Notify Party")):
        if not party(ship, role).get("party_name"):
            blocking.append(f"Thiếu {label} (nhập ở Quản lý lô hàng → Các bên).")
    consignee = party(ship, "CONSIGNEE").get("party_name")
    if is_to_order(consignee) and not party(ship, "NOTIFY_PARTY").get("party_name"):
        blocking.append(f"Consignee là “{consignee}” (B/L theo lệnh) → BẮT BUỘC có Notify Party.")

    # booking & routing
    for key, label in (("booking_number", "Booking No."), ("port_of_loading", "POL"), ("port_of_discharge", "POD"),
                       ("vessel_name", "Vessel"), ("voyage_number", "Voyage")):
        if not ship.get(key):
            blocking.append(f"Thiếu {label} (nhập ở Bước 1).")
    if view.get("booking_status") not in ("Booking Confirmed", "Booking Amended"):
        warnings.append("Booking chưa được hãng tàu xác nhận (Bước 1) — SI dựa trên booking chưa xác nhận.")
    changes = basis_changes(view)
    if changes:
        target = blocking if si.get("si_status") in SUBMITTED_STATES else warnings
        target.append("Booking đã thay đổi so với SI: " + "; ".join(changes) + ".")

    # cargo & containers
    if not ship["cargo"]:
        blocking.append("Chưa có dòng hàng (Cargo lines).")
    for n, line in enumerate(ship["cargo"], start=1):
        missing = [lbl for k, lbl in (("cargo_description", "mô tả hàng"), ("package_count", "số kiện"),
                                      ("package_type", "loại kiện"), ("gross_weight_kg", "gross weight"))
                   if line.get(k) in (None, "")]
        if missing:
            blocking.append(f"Dòng hàng {n}: thiếu " + ", ".join(missing) + ".")
    if not ship["containers"]:
        blocking.append("Chưa có container.")
    no_number = [str(i) for i, c in enumerate(ship["containers"], start=1) if not c.get("container_number")]
    if no_number:
        blocking.append("Container chưa có số (dòng " + ", ".join(no_number) + ").")
    no_seal = [c.get("container_number") or f"dòng {i}" for i, c in enumerate(ship["containers"], start=1)
               if not c.get("seal_number")]
    if no_seal:
        blocking.append("Container chưa có số seal: " + ", ".join(no_seal) + ".")
    for c in ship["containers"]:
        if c.get("container_number") and S.container_number_problem(c["container_number"]):
            warnings.append(f"Container {c['container_number']}: {S.container_number_problem(c['container_number'])}.")
        if not c.get("container_size") or not c.get("iso_type_code"):
            warnings.append(f"Container {c.get('container_number') or '(chưa có số)'}: thiếu size / ISO type.")
    blocking += allocation_problems(view)
    warnings += master_weight_warnings(view)

    # VGM (Step 3) — warning only, never filled in
    no_vgm = [c.get("container_number") or "(chưa có số)" for c in ship["containers"] if declared_vgm(view, c) is None]
    if no_vgm:
        warnings.append("Chưa có VGM đã khai (Bước 3) cho: " + ", ".join(no_vgm)
                        + ". SI không tự điền VGM — khai VGM ở Bước 3.")

    # B/L instructions & freight
    if si.get("bl_type") not in BL_TYPES:
        blocking.append("Chưa chọn loại B/L (Original B/L / Sea Waybill / Telex release).")
    elif si["bl_type"] == "ORIGINAL" and not si.get("originals_count"):
        blocking.append("Original B/L: chưa nhập số bản gốc (number of originals).")
    if not si.get("service_type"):
        warnings.append("Chưa chọn Service type / Move type (VD CY/CY).")
    if si.get("freight_terms") not in FREIGHT_TERMS:
        blocking.append("Chưa chọn Freight terms (Prepaid / Collect).")
    elif si["freight_terms"] == "COLLECT" and not si.get("payable_at"):
        blocking.append("Freight Collect: bắt buộc nhập nơi thanh toán cước (Payable at).")

    warnings += routing_problems(view)
    for key, o in (ship.get("overrides") or {}).items():
        warnings.append(f"SI giữ giá trị đã gửi hãng tàu cho {key.replace('party:', '').replace('_', ' ').title()} "
                        "(khác dữ liệu lô hàng) — chọn Giữ / Thay ở Trung tâm kiểm tra.")

    # deadline
    if si.get("si_status") not in SUBMITTED_STATES:
        cutoff = S.to_datetime(ship.get("si_cutoff"))
        if cutoff:
            if now > cutoff:
                warnings.append(f"Đã QUÁ hạn SI cut-off ({ship['si_cutoff']}) — liên hệ hãng tàu ngay.")
            elif cutoff - now <= timedelta(hours=CUTOFF_WARNING_HOURS):
                warnings.append(f"SI cut-off còn dưới 24 giờ ({ship['si_cutoff']}, còn "
                                f"~{(cutoff - now).total_seconds() / 3600:.0f} giờ).")
    if changed_since_submission(view):
        warnings.append("Dữ liệu SI đã thay đổi sau khi gửi — bấm “Mark as amended” khi đã gửi bản sửa đổi cho hãng tàu.")
    return blocking, warnings


def document_label(view: dict) -> dict:
    si, ship = view["si"], view["shipment"]
    status = si.get("si_status") or "Not Started"
    if status in ("Draft", "Not Started"):
        label = dict(kind="draft", badge="DRAFT — NOT YET SUBMITTED",
                     note="Draft shipping instruction prepared for checking. Not yet submitted to the carrier.")
    elif changed_since_submission(view):
        label = dict(kind="internal", badge="CHANGED SINCE SUBMISSION",
                     note="The data changed after this SI was submitted. Send an amendment to the carrier and "
                          "mark the SI as amended.")
    elif status == "Submitted":
        label = dict(kind="reference", badge="SUBMITTED",
                     note=(f"Submitted to the carrier on {fmt_date(si.get('submission_date'))} via {si.get('submission_channel')} "
                           "(recorded by the user). The carrier's draft B/L must be checked against this SI."))
    elif status == "Amended":
        label = dict(kind="reference", badge="AMENDED SI",
                     note=(f"Amendment sent on {fmt_date(si.get('amendment_date'))}"
                           + (f" — {si['amendment_reason']}" if si.get("amendment_reason") else "")
                           + " (recorded by the user). Replaces the earlier submission."))
    elif status == "Draft B/L Received":
        label = dict(kind="reference", badge="DRAFT B/L RECEIVED",
                     note=(f"Carrier's draft B/L received on {fmt_date(si.get('draft_bl_received_date'))}"
                           + (f" (ref. {si['draft_bl_reference']})" if si.get("draft_bl_reference") else "")
                           + ", recorded by the user — check it against this SI."))
    else:
        label = dict(kind="confirmed", badge="DRAFT B/L APPROVED",
                     note=(f"Draft B/L approved by the shipper on {fmt_date(si.get('draft_bl_approved_date'))} (recorded by the "
                           "user). The B/L itself is issued by the carrier."))
    label["sample"] = bool(ship["is_sample"])
    label["sample_text"] = S.sample_text(ship)
    label["status"] = status
    return label


def step_status(shipment_id: str) -> str:
    """Step 4 in the 6-step progress."""
    view = get_si_view(shipment_id)
    if not view or not view["exists"]:
        return "Not Started"
    status = view["si"]["si_status"]
    if status in SUBMITTED_STATES and (changed_since_submission(view) or basis_changes(view)):
        return "Needs Correction"
    if status == "Draft B/L Approved":
        return "Completed"
    if status in SUBMITTED_STATES:
        return "Waiting for External Confirmation"
    return "In Progress"


def count_sis() -> int:
    with reading() as conn:
        return conn.execute("SELECT COUNT(*) FROM si_records").fetchone()[0]


# ---------------------------------------------------------------------------
# Save
# ---------------------------------------------------------------------------
def _clean(values: dict, errors: list[str]) -> dict:
    rec = {k: S.clean_text(values.get(k)) for k in TEXT_FIELDS}
    rec.update({k: S.parse_number(values.get(k), k.replace("_", " ").capitalize(), errors, integer=True)
                for k in INT_FIELDS})
    rec.update({k: S.parse_when(values.get(k), False, k.replace("_", " ").capitalize(), errors) for k in DATE_FIELDS})
    for key, allowed in (("bl_type", BL_TYPES), ("freight_terms", FREIGHT_TERMS)):
        if rec[key] and rec[key] not in allowed:
            errors.append(f"{key}: giá trị không hợp lệ “{rec[key]}”.")
    return rec


def _clean_allocations(ship: dict, rows: list[dict], errors: list[str]) -> list[dict]:
    containers = {c["id"] for c in ship["containers"]}
    lines = {l["id"] for l in ship["cargo"]}
    out, seen = [], set()
    for n, r in enumerate(rows, start=1):
        cid, lid = r.get("container_id"), r.get("cargo_id")
        values = {"package_count": S.parse_number(r.get("package_count"), f"Phân bổ dòng {n}: số kiện", errors, True),
                  "gross_weight_kg": S.parse_number(r.get("gross_weight_kg"), f"Phân bổ dòng {n}: gross", errors),
                  "volume_cbm": S.parse_number(r.get("volume_cbm"), f"Phân bổ dòng {n}: CBM", errors)}
        if cid not in containers:
            errors.append(f"Phân bổ dòng {n}: container không thuộc lô hàng này.")
            continue
        if lid not in lines:
            errors.append(f"Phân bổ dòng {n}: dòng hàng không thuộc lô hàng này.")
            continue
        if (cid, lid) in seen:
            errors.append(f"Phân bổ dòng {n}: cặp container + dòng hàng bị trùng — gộp lại thành một dòng.")
            continue
        seen.add((cid, lid))
        out.append({"container_fk": cid, "cargo_fk": lid, **values})
    return out


@tracked("SI")
def save_si(shipment_id: str, si_values: dict, seals: dict[int, str] | None = None,
            allocations: list[dict] | None = None, freight_payer: str | None = None,
            action: str = "draft", now: datetime | None = None) -> SISaveResult:
    """Save the SI (and the central seals, cargo per container, freight payer), then apply `action`.

    seals: {container_id: seal number}; allocations: [{container_id, cargo_id, package_count,
    gross_weight_kg, volume_cbm}] (None = keep the existing ones); freight_payer: central
    FREIGHT_PAYER party name (None = unchanged).
    Raises SIError only for real data errors. A status change whose conditions are not met
    is NOT applied (action_done=False) and the reasons are returned as warnings.
    """
    if action not in ACTIONS:
        raise SIError([f"Thao tác “{action}” không hợp lệ."])
    errors, warnings = [], []
    ship = S.get_shipment(shipment_id)
    if not ship:
        raise SIError([f"Không tìm thấy lô hàng {shipment_id}."])
    rec = _clean(si_values, errors)
    clean_alloc = _clean_allocations(ship, allocations, errors) if allocations is not None else None
    seal_values = {}
    for cid, seal in (seals or {}).items():
        if cid not in {c["id"] for c in ship["containers"]}:
            errors.append("Seal: container không thuộc lô hàng này.")
        seal_values[cid] = (S.clean_text(seal) or "").upper() or None
    if errors:
        raise SIError(errors)
    rec["si_reference"] = rec["si_reference"] or f"SI-{shipment_id}"

    stamp = S.now_text()
    fk = ship["id"]
    with transaction() as conn:
        for cid, seal in seal_values.items():
            conn.execute("UPDATE containers SET seal_number = ? WHERE id = ?", (seal, cid))
        if clean_alloc is not None:
            conn.execute("DELETE FROM container_cargo WHERE shipment_fk = ?", (fk,))
            for a in clean_alloc:
                conn.execute("INSERT INTO container_cargo (shipment_fk, container_fk, cargo_fk, package_count, "
                             "gross_weight_kg, volume_cbm) VALUES (?, ?, ?, ?, ?, ?)",
                             (fk, a["container_fk"], a["cargo_fk"], a["package_count"], a["gross_weight_kg"],
                              a["volume_cbm"]))
        if freight_payer is not None:
            name = S.clean_text(freight_payer)
            conn.execute("INSERT INTO shipment_parties (shipment_fk, party_role, party_name) VALUES (?, 'FREIGHT_PAYER', ?) "
                         "ON CONFLICT(shipment_fk, party_role) DO UPDATE SET party_name = excluded.party_name",
                         (fk, name))
        existing = conn.execute("SELECT * FROM si_records WHERE shipment_fk = ?", (fk,)).fetchone()
        if existing:
            conn.execute(f"UPDATE si_records SET {', '.join(f'{k} = ?' for k in SI_FIELDS)}, updated_at = ? "
                         f"WHERE shipment_fk = ?", [*(rec[k] for k in SI_FIELDS), stamp, fk])
        else:
            cols = ["shipment_fk", "si_status", *SI_FIELDS, "created_at", "updated_at"]
            conn.execute(f"INSERT INTO si_records ({', '.join(cols)}) VALUES ({', '.join('?' * len(cols))})",
                         [fk, "Draft", *(rec[k] for k in SI_FIELDS), stamp, stamp])
        conn.execute("UPDATE shipments SET updated_at = ? WHERE id = ?", (stamp, fk))

    # ---- status change -----------------------------------------------------------------
    view = get_si_view(shipment_id)
    si = view["si"]
    status = si["si_status"]
    blocking, _ = checks(view, now)
    need, new_status = [], status
    if action == "submit":
        if status not in ("Draft", "Submitted"):
            need.append(f"SI đang ở trạng thái “{status_label(status)}” — gửi lại bản sửa thì dùng “Mark as amended”.")
        need += blocking
        need += [m for k, m in (("submission_date", "Chưa nhập ngày gửi (Submission date)."),
                                ("submission_channel", "Chưa nhập kênh gửi (Submission channel).")) if not si.get(k)]
        new_status = "Submitted"
    elif action == "amend":
        if status not in SUBMITTED_STATES:
            need.append("Chỉ sửa đổi (Amended) được SI đã gửi — hãy “Mark as submitted” trước.")
        need += [b for b in blocking if not b.startswith("Booking đã thay đổi")]
        if not si.get("amendment_date"):
            need.append("Chưa nhập ngày gửi bản sửa đổi (Amendment date).")
        new_status = "Amended"
    elif action == "bl_received":
        if status not in ("Submitted", "Amended", "Draft B/L Received"):
            need.append("Draft B/L chỉ có sau khi SI đã gửi.")
        if not si.get("draft_bl_received_date"):
            need.append("Chưa nhập ngày nhận Draft B/L.")
        new_status = "Draft B/L Received"
    elif action == "bl_approved":
        if status not in ("Draft B/L Received", "Draft B/L Approved"):
            need.append("Cần “Draft B/L Received” trước khi duyệt.")
        if not si.get("draft_bl_approved_date"):
            need.append("Chưa nhập ngày duyệt Draft B/L.")
        if changed_since_submission(view):
            need.append("SI đã thay đổi sau khi gửi — gửi bản sửa đổi trước.")
        new_status = "Draft B/L Approved"

    action_done = action == "draft"
    sets = {}
    if action != "draft":
        if need:
            warnings.insert(0, f"Chưa thể chuyển sang “{status_label(new_status)}” — trạng thái giữ nguyên "
                               f"“{status_label(status)}”. Cần: " + " ".join(need))
        else:
            action_done, status = True, new_status
            sets["si_status"] = new_status
            if action in ("submit", "amend"):
                sets["submitted_hash"] = content_hash(view)
                sets["booking_basis"] = json.dumps(booking_basis(view["shipment"]), ensure_ascii=False)
    if status in ("Draft",):
        sets["booking_basis"] = json.dumps(booking_basis(view["shipment"]), ensure_ascii=False)
    if sets:
        with transaction() as conn:
            conn.execute(f"UPDATE si_records SET {', '.join(f'{k} = ?' for k in sets)} WHERE shipment_fk = ?",
                         [*sets.values(), fk])
    view = get_si_view(shipment_id)
    blocking, soft = checks(view, now)
    if view["si"]["si_status"] == "Draft" and blocking:
        warnings.append("Cần sửa trước khi gửi (Mark as submitted): " + " ".join(blocking))
    warnings += soft
    return SISaveResult(shipment_id=shipment_id, si_reference=rec["si_reference"], status=status,
                        created=existing is None, action_done=action_done, warnings=warnings)


def record_pdf_export(shipment_id: str, path: str) -> None:
    with transaction() as conn:
        conn.execute("UPDATE si_records SET last_pdf_path = ?, last_pdf_at = ? WHERE shipment_fk = "
                     "(SELECT id FROM shipments WHERE shipment_id = ?)", (path, S.now_text()[:16], shipment_id))
