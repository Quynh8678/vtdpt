"""Dashboard page — figures come from the database (REQUIREMENTS.md §3)."""

import gradio as gr

from .services import RECENT_SHIPMENT_COLUMNS, STEP_STATUSES
from .ui_common import (
    AMBER, GREEN, GREY, RED, YELLOW, STEP_STATUS_COLOURS, countdown_text, e, notice_html, page_title_html, progress_text,
    section_title_html, status_label,
)
from .shipments import sample_text
from .workflow import completed_steps, dashboard_summary


def _kpi(label: str, value, cls: str = "", caption: str = "") -> str:
    cap = f'<div class="cap">{e(caption)}</div>' if caption else ""
    return (f'<div class="kpi {cls}"><div class="label">{e(label)}</div>'
            f'<div class="value">{e(value)}</div>{cap}</div>')


def kpi_cards_html(s: dict) -> str:
    cards = [
        _kpi("Tổng số lô hàng", s["total_shipments"], caption=f"{s['sample_shipments']} lô dữ liệu mẫu / thử"),
        _kpi("Tổng số chứng từ", s["total_documents"], caption="Booking, EIR, VGM, SI, Gate-in, B/L đã lưu"),
        _kpi("Lô hàng đang xử lý", s["in_progress"], "warn"),
        _kpi("Lô hàng hoàn thành", s["completed"], "good",
             caption="Đủ 6 bước + mọi kiểm tra hợp lệ / đã xác nhận"),
        _kpi("Lô hàng thiếu chứng từ", s["missing_documents"], "bad",
             caption="Lô đang xử lý chưa đủ 6 chứng từ hoàn thành"),
        _kpi("Lô hàng dữ liệu không khớp", len(s["mismatched"]), "bad",
             caption=(", ".join(s["mismatched"][:3]) + (" …" if len(s["mismatched"]) > 3 else "")
                      if s["mismatched"] else "Trung tâm kiểm tra: không có mục không khớp")),
        _kpi("Chứng từ chờ phê duyệt", len(s["waiting_documents"]), "warn",
             caption="Chờ hãng tàu / cảng xác nhận hoặc duyệt (Booking, VGM, SI, Draft B/L)"),
        _kpi("Lô hàng sắp đến hạn cut-off", s["deadline_shipments"], "bad",
             caption=f"Số lô hàng có CY / SI / VGM cut-off trong 72 giờ tới hoặc đã quá hạn "
                     f"({len(s['deadline_alerts'])} hạn cut-off)"),
    ]
    return f'<div class="kpi-grid">{"".join(cards)}</div>'


def waiting_html(s: dict) -> str:
    """Which shipments have mismatched data, which documents wait for approval (real lists)."""
    parts = []
    if s["mismatched"]:
        parts.append(f'<div class="msg msg-error"><b>⚠️ Dữ liệu không khớp</b> — mở <b>Trung tâm kiểm tra</b>: '
                     f'{e(", ".join(s["mismatched"]))}</div>')
    if s["waiting_documents"]:
        items = "".join(f"<li><b>{e(sid)}</b> · {e(doc)}</li>" for sid, doc in s["waiting_documents"][:12])
        more = f"<li>… và {len(s['waiting_documents']) - 12} chứng từ khác</li>" if len(s["waiting_documents"]) > 12 else ""
        parts.append(f'<div class="msg msg-info"><b>🕒 Chứng từ chờ phê duyệt / xác nhận</b><ul>{items}{more}</ul></div>')
    return "".join(parts)


def alerts_html(alerts: list[dict]) -> str:
    if not alerts:
        return notice_html("✅ Không có lô hàng nào sắp đến hạn cut-off trong 72 giờ tới.")
    rows = []
    for a in alerts:
        colour = RED if a["overdue"] else AMBER
        when = (f'<b style="color:{colour}">{"⛔ ĐÃ QUÁ HẠN — " if a["overdue"] else "⏰ "}'
                f'{e(countdown_text(a["hours_left"]))}</b>')
        rows.append(f"<li><b>{e(a['shipment_id'])}</b> · Booking {e(a['booking_number'])} · "
                    f"{e(a['label'])}: {e(a['cutoff'])} — {when}</li>")
    shipments = len({a["shipment_id"] for a in alerts})
    return (f'<div class="msg msg-warning"><b>⏰ {shipments} lô hàng sắp đến hạn cut-off</b> '
            f'({len(alerts)} hạn cut-off trong 72 giờ tới hoặc đã quá hạn)<ul>{"".join(rows)}</ul></div>')


def step_overview_html(overview: list[dict]) -> str:
    """For each step: how many active shipments are in each status (real data)."""
    vi = dict(STEP_STATUSES)
    items = []
    for item in overview:
        step, counts = item["step"], item["counts"]
        lines = "".join(
            f'<div class="st"><i class="dot" style="background:{STEP_STATUS_COLOURS[status]}"></i>'
            f'{e(vi[status])}: <b>{counts[status]}</b></div>'
            for status, _ in STEP_STATUSES if counts.get(status))
        items.append(f'<div class="step"><span class="num">{step.number}</span>'
                     f'<div class="en">{e(step.name_en)}</div><div class="vi">{e(step.name_vi)}</div>'
                     f'{lines or "<div class=st>Chưa có lô hàng</div>"}</div>')
    legend = (
        '<div class="legend">Số lô hàng đang xử lý ở từng trạng thái · '
        f'<span><i class="dot" style="background:{GREEN}"></i>Hoàn thành</span>'
        f'<span><i class="dot" style="background:{YELLOW}"></i>Đang thực hiện / chờ xác nhận</span>'
        f'<span><i class="dot" style="background:{RED}"></i>Cần chỉnh sửa</span>'
        f'<span><i class="dot" style="background:{GREY}"></i>Chưa bắt đầu</span></div>'
    )
    return f'<div class="steps">{"".join(items)}</div>{legend}'


def progress_bar_html(statuses: list[str]) -> str:
    """Six coloured segments (one per step, real step status) + "n/6"."""
    vi = dict(STEP_STATUSES)
    segs = "".join(
        f'<span title="Bước {i}: {e(vi.get(s, s))} ({e(s)})" style="display:inline-block;width:18px;height:10px;'
        f'margin-right:2px;border-radius:2px;background:{STEP_STATUS_COLOURS.get(s, GREY)}"></span>'
        for i, s in enumerate(statuses, start=1))
    return f'<span style="white-space:nowrap">{segs} <b>{completed_steps(statuses)}/6</b></span>'


def recent_html(rows: list[dict]) -> str:
    if not rows:
        return notice_html("Chưa có lô hàng nào.")
    body = []
    for r in rows:
        vessel = " / ".join(x for x in (r.get("vessel_name"), r.get("voyage_number")) if x)
        status = status_label(r["status"]) + (f" · {sample_text(r)}" if r["is_sample"] else "")
        cells = [r["shipment_id"], r.get("booking_number"), r.get("shipper_name"), r.get("consignee_name"),
                 r.get("port_of_loading"), r.get("port_of_discharge"), vessel, r.get("etd"), status]
        body.append("<tr>" + "".join(f"<td>{e(c)}</td>" for c in cells)
                    + f"<td>{progress_bar_html(r['step_statuses'])}</td></tr>")
    head = "".join(f"<th>{e(h)}</th>" for h in RECENT_SHIPMENT_COLUMNS)
    legend = (f'<div class="legend"><span><i class="dot" style="background:{GREEN}"></i>Hoàn thành</span>'
              f'<span><i class="dot" style="background:{YELLOW}"></i>Đang thực hiện / chờ xác nhận</span>'
              f'<span><i class="dot" style="background:{RED}"></i>Cần chỉnh sửa</span>'
              f'<span><i class="dot" style="background:{GREY}"></i>Chưa bắt đầu</span> · rê chuột lên ô để xem bước</div>')
    return f'<div class="table-wrap"><table class="grid"><tr>{head}</tr>{"".join(body)}</table></div>{legend}'


def build_dashboard_page():
    """Build the page. Returns (output components, refresh function)."""
    gr.HTML(page_title_html("Tổng quan", "Dashboard — tình hình các lô hàng và chứng từ"))
    kpis = gr.HTML()
    alerts = gr.HTML()
    gr.HTML(section_title_html("Quy trình 6 bước", "6-step document workflow"))
    overview = gr.HTML()
    gr.HTML(section_title_html("Lô hàng gần đây", "Recent shipments — 10 lô cập nhật gần nhất"))
    recent = gr.HTML()

    def refresh():
        s = dashboard_summary()
        return (kpi_cards_html(s), alerts_html(s["deadline_alerts"]) + waiting_html(s),
                step_overview_html(s["step_overview"]), recent_html(s["recent"]))

    return [kpis, alerts, overview, recent], refresh
