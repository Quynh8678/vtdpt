"""Phase 6 — reference lists managed in Settings: carriers, ports, terminals, depots (REQUIREMENTS.md §3 Settings).

The forms offer these as choices (and still accept a typed value). Ports are pre-filled once with public
UN/LOCODE port names; carriers, terminals and depots start empty — the user adds the ones they work with,
or copies the names already used in their shipments ("Lấy từ các lô hàng").
"""

from . import shipments as S
from .database import get_meta, reading, set_meta, transaction

KINDS = {
    "CARRIER": ("Hãng tàu", "Carriers"),
    "PORT": ("Cảng / địa điểm", "Ports & places (POL, POD, receipt, delivery, transshipment)"),
    "TERMINAL": ("Terminal / cảng hạ bãi", "Terminals (gate-in)"),
    "DEPOT": ("Depot container rỗng", "Empty container depots"),
}
# shipment fields that pick from each list
FIELD_KINDS = {
    "carrier_name": "CARRIER", "place_of_receipt": "PORT", "port_of_loading": "PORT",
    "transshipment_port": "PORT", "port_of_discharge": "PORT", "place_of_delivery": "PORT",
    "empty_pickup_depot": "DEPOT", "container_return_depot": "DEPOT", "terminal_name": "TERMINAL",
}
# Public UN/LOCODE names (no carrier, terminal or depot is assumed)
PORT_SEED = (
    ("Cát Lái, TP. Hồ Chí Minh (VNCLI)", "VNCLI"), ("Cái Mép, Bà Rịa - Vũng Tàu (VNCMT)", "VNCMT"),
    ("Hải Phòng (VNHPH)", "VNHPH"), ("Đà Nẵng (VNDAD)", "VNDAD"), ("Quy Nhơn (VNUIH)", "VNUIH"),
    ("Singapore (SGSIN)", "SGSIN"), ("Port Klang (MYPKG)", "MYPKG"), ("Hong Kong (HKHKG)", "HKHKG"),
    ("Shanghai (CNSHA)", "CNSHA"), ("Busan (KRPUS)", "KRPUS"), ("Tokyo (JPTYO)", "JPTYO"), ("Osaka (JPOSA)", "JPOSA"),
    ("Los Angeles, CA (USLAX)", "USLAX"), ("Long Beach, CA (USLGB)", "USLGB"), ("New York, NY (USNYC)", "USNYC"),
    ("Rotterdam (NLRTM)", "NLRTM"), ("Hamburg (DEHAM)", "DEHAM"), ("Antwerp (BEANR)", "BEANR"),
    ("Felixstowe (GBFXT)", "GBFXT"), ("Sydney (AUSYD)", "AUSYD"),
)


class ReferenceError_(S.ShipmentError):
    pass


def ensure_seed() -> None:
    """Pre-fill the port list once (public UN/LOCODE names)."""
    if get_meta("reference_ports_seeded"):
        return
    with transaction() as conn:
        for name, code in PORT_SEED:
            conn.execute("INSERT OR IGNORE INTO reference_items (kind, name, code, notes, created_at) VALUES "
                         "('PORT', ?, ?, 'UN/LOCODE', ?)", (name, code, S.now_text()))
    set_meta("reference_ports_seeded", "1")


def list_items(kind: str | None = None, active_only: bool = False) -> list[dict]:
    sql, params = "SELECT * FROM reference_items", []
    where = []
    if kind:
        where.append("kind = ?")
        params.append(kind)
    if active_only:
        where.append("active = 1")
    if where:
        sql += " WHERE " + " AND ".join(where)
    with reading() as conn:
        return [dict(r) for r in conn.execute(sql + " ORDER BY kind, name", params)]


def choices(kind: str, current: str | None = None) -> list[str]:
    """Names for a form dropdown; the value already in the form is always kept."""
    names = [r["name"] for r in list_items(kind, active_only=True)]
    if current and current not in names:
        names.insert(0, current)
    return names


def add_item(kind: str, name: str | None, code: str | None = None, notes: str | None = None) -> str:
    name = S.clean_text(name)
    if kind not in KINDS:
        raise ReferenceError_(["Loại danh mục không hợp lệ."])
    if not name:
        raise ReferenceError_(["Nhập tên."])
    with transaction() as conn:
        exists = conn.execute("SELECT id, active FROM reference_items WHERE kind = ? AND name = ?", (kind, name)).fetchone()
        if exists and exists["active"]:
            raise ReferenceError_([f"“{name}” đã có trong danh mục."])
        if exists:
            conn.execute("UPDATE reference_items SET active = 1, code = ?, notes = ? WHERE id = ?",
                         (S.clean_text(code), S.clean_text(notes), exists["id"]))
        else:
            conn.execute("INSERT INTO reference_items (kind, name, code, notes, created_at) VALUES (?, ?, ?, ?, ?)",
                         (kind, name, S.clean_text(code), S.clean_text(notes), S.now_text()))
    return name


def remove_item(item_id: int) -> str:
    """Hide an item from the pick lists (shipments that already use the name keep it)."""
    with transaction() as conn:
        row = conn.execute("SELECT name FROM reference_items WHERE id = ?", (item_id,)).fetchone()
        if not row:
            raise ReferenceError_(["Không tìm thấy mục này."])
        conn.execute("UPDATE reference_items SET active = 0 WHERE id = ?", (item_id,))
    return row["name"]


def import_from_shipments() -> int:
    """Add every carrier / port / depot / terminal name already used in shipments. Returns how many were added."""
    added = 0
    with transaction() as conn:
        for field, kind in FIELD_KINDS.items():
            table = "gatein_records" if field == "terminal_name" else "shipments"
            for (value,) in conn.execute(f"SELECT DISTINCT {field} FROM {table} WHERE {field} IS NOT NULL AND {field} != ''"):
                cur = conn.execute("INSERT OR IGNORE INTO reference_items (kind, name, notes, created_at) VALUES "
                                   "(?, ?, 'Lấy từ lô hàng', ?)", (kind, value.strip(), S.now_text()))
                added += cur.rowcount
    return added
