"""Document History page ("Lịch sử chứng từ") — change log with filters, versions, view and restore
(REQUIREMENTS.md §8)."""

import html

import gradio as gr
import pandas as pd

from . import history as H
from . import shipments as S
from .ui_common import e, message_html, notice_html, page_title_html, section_title_html

LOG_COLUMNS = ["Thời gian", "Người dùng", "Lô hàng", "Chứng từ", "Phiên bản", "Trường", "Giá trị cũ", "Giá trị mới",
               "Thao tác", "Lý do"]
VERSION_COLUMNS = ["Phiên bản", "Loại", "Trạng thái chứng từ", "Thời gian", "Người dùng", "Lý do"]
ALL = "ALL"


def _short(value, limit: int = 120) -> str:
    text = " · ".join(str(value or "").splitlines())
    return text if len(text) <= limit else text[:limit] + "…"


def log_frame(rows: list[dict]) -> pd.DataFrame:
    data = [[r["changed_at"][:16], r["user_name"], r["shipment_id"], r["doc_label"] or H.DOC_LABELS.get(r["doc_type"]),
             f"v{r['doc_version']}" if r["doc_version"] else "", r["field_label"], _short(r["old_value"]),
             _short(r["new_value"]), H.ACTION_LABELS.get(r["action"], r["action"]), r["reason"] or ""] for r in rows]
    return pd.DataFrame(data, columns=LOG_COLUMNS)


def version_frame(rows: list[dict]) -> pd.DataFrame:
    data = [[f"v{r['version']}", H.KIND_LABELS.get(r["kind"], r["kind"]), r["status"] or "", r["created_at"][:16],
             r["created_by"], r["reason"] or ""] for r in rows]
    return pd.DataFrame(data, columns=VERSION_COLUMNS)


def version_html(version: dict, current: dict | None) -> str:
    """Every field of the chosen version, next to today's value (changed ones highlighted)."""
    flat = version["snapshot"]["flat"]
    now = (current or {}).get("flat", {})
    rows = []
    for key in sorted(set(flat) | set(now), key=lambda k: (k.startswith("inh."), k)):
        old, cur = flat.get(key), now.get(key)
        if old is None and cur is None:
            continue
        changed = (old or None) != (cur or None)
        style = ' style="background:#FFF8E1"' if changed else ""
        rows.append(f"<tr{style}><td>{e(H._doc_label_key(key))}</td>"
                    f"<td>{'<br>'.join(html.escape(x) for x in str(old or '—').splitlines())}</td>"
                    f"<td>{'<br>'.join(html.escape(x) for x in str(cur or '—').splitlines())}</td></tr>")
    head = (f"<b>{e(version['snapshot'].get('label'))} — v{version['version']}</b> · "
            f"{e(H.KIND_LABELS.get(version['kind'], version['kind']))} · {e(version['created_at'][:16])} · "
            f"{e(version['created_by'])}" + (f" · Lý do: {e(version['reason'])}" if version.get("reason") else ""))
    return (f'<div class="notice">{head}<br><span class="hint">Dòng tô vàng = khác với hiện tại. '
            "“(kế thừa)” = giá trị chứng từ lấy từ dữ liệu chung (sửa ở nguồn).</span></div>"
            '<div class="table-wrap"><table class="grid"><tr><th>Trường</th><th>Trong phiên bản này</th>'
            "<th>Hiện tại</th></tr>" + "".join(rows) + "</table></div>")


def build_history_page():
    gr.HTML(page_title_html("Lịch sử chứng từ", "Document History — mọi thay đổi, phiên bản và khôi phục"))
    gr.HTML(notice_html(
        "Mỗi lần lưu, hệ thống ghi lại: <b>thời gian, người dùng, chứng từ, trường, giá trị cũ, giá trị mới</b> và "
        "<b>lý do</b>. Chứng từ có nội dung thay đổi được lưu thành <b>phiên bản mới</b> (v1, v2, v3…) — phiên bản "
        "cũ không bao giờ bị ghi đè. Chứng từ đã gửi / đã xác nhận mà bị thay đổi sẽ có phiên bản <b>Amended</b>. "
        "Tên người dùng lấy từ <b>Cài đặt → Người dùng hiện tại</b>."))

    # -------------------------------------------------------------- change log
    gr.HTML(section_title_html("Nhật ký thay đổi", "Change log — lọc theo lô hàng, chứng từ và ngày"))
    with gr.Row():
        f_ship = gr.Dropdown(label="Lô hàng", choices=[("Tất cả lô hàng", ALL)], value=ALL, scale=2)
        f_doc = gr.Dropdown(label="Chứng từ", value=ALL, scale=2,
                            choices=[("Tất cả chứng từ", ALL)] + [(v, k) for k, v in H.DOC_LABELS.items()])
        f_from = gr.DateTime(label="Từ ngày", include_time=False, type="string", scale=1)
        f_to = gr.DateTime(label="Đến ngày", include_time=False, type="string", scale=1)
    filter_btn = gr.Button("🔍 Lọc nhật ký", variant="primary")
    log_info = gr.HTML()
    log_table = gr.Dataframe(value=pd.DataFrame(columns=LOG_COLUMNS), interactive=False, wrap=True,
                             column_widths=["120px", "140px", "120px", "160px", "70px", "200px", "200px", "200px",
                                            "140px", "200px"])

    # -------------------------------------------------------------- versions
    gr.HTML(section_title_html("Phiên bản chứng từ", "Versions — xem phiên bản cũ và khôi phục thành phiên bản mới"))
    with gr.Row():
        v_ship = gr.Dropdown(label="Lô hàng", choices=[], scale=2)
        v_doc = gr.Dropdown(label="Chứng từ", choices=[], scale=2)
    version_table = gr.Dataframe(value=pd.DataFrame(columns=VERSION_COLUMNS), interactive=False, wrap=True)
    v_pick = gr.Dropdown(label="Xem phiên bản", choices=[])
    version_view = gr.HTML()
    gr.HTML(notice_html(
        "<b>Khôi phục</b> tạo một <b>phiên bản mới</b> có nội dung giống phiên bản đã chọn (qua kiểm tra như khi lưu "
        "bình thường). Chỉ khôi phục <b>trường riêng của chứng từ</b>; trạng thái, bằng chứng và dữ liệu dùng chung "
        "(bên liên quan, container…) giữ nguyên — sửa dữ liệu chung ở nguồn để mọi chứng từ cùng cập nhật. "
        "Chứng từ đã gửi / đã xác nhận: bản khôi phục là bản <b>Amended</b> và cần gửi / xác nhận lại."))
    with gr.Row():
        restore_reason = gr.Textbox(label="Lý do khôi phục (ghi vào lịch sử)", scale=3)
        restore_btn = gr.Button("↩ Khôi phục thành phiên bản mới", variant="primary", scale=1)
    restore_msg = gr.HTML()

    # -------------------------------------------------------------- logic
    def load_log(ship_id, doc, date_from, date_to):
        try:
            rows = H.list_changes(None if ship_id in (None, ALL) else ship_id, None if doc in (None, ALL) else doc,
                                  (date_from or "")[:10] or None, (date_to or "")[:10] or None)
        except ValueError:
            return message_html("error", "Ngày không đúng định dạng (YYYY-MM-DD)."), gr.skip()
        note = f"{len(rows)} thay đổi" + (" (500 mới nhất — lọc để xem ít hơn)" if len(rows) == 500 else "") + \
            f" · người dùng hiện tại: <b>{e(H.current_user())}</b>"
        return f'<p class="hint">{note}</p>', log_frame(rows)

    def doc_choices(ship_id):
        docs = H.documents_of(ship_id) if ship_id else []
        return [(f"{d['label']} (v{d['version']})", f"{d['doc_type']}|{d['container_fk'] or ''}") for d in docs]

    def _doc_key(value):
        doc_type, cid = (value or "|").split("|")
        return doc_type, int(cid) if cid else None

    def load_versions(ship_id, doc_value):
        if not ship_id or not doc_value:
            return pd.DataFrame(columns=VERSION_COLUMNS), gr.update(choices=[], value=None), ""
        doc_type, cid = _doc_key(doc_value)
        rows = H.list_versions(ship_id, doc_type, cid)
        choices = [(f"v{r['version']} — {H.KIND_LABELS.get(r['kind'], r['kind'])} — {r['created_at'][:16]}", r["id"])
                   for r in rows if r["id"]]
        value = choices[0][1] if choices else None
        hint = "" if choices else notice_html("Chứng từ này chưa có thay đổi nào sau khi bật lịch sử — "
                                              "phiên bản hiện tại là bản duy nhất.")
        return version_frame(rows), gr.update(choices=choices, value=value), hint if not value else show_version(value)

    def pick_ship(ship_id):
        choices = doc_choices(ship_id)
        value = choices[0][1] if choices else None
        return (gr.update(choices=choices, value=value), *load_versions(ship_id, value))

    def show_version(version_id):
        if not version_id:
            return ""
        ver = H.get_version(int(version_id))
        snap = H.capture(ver["shipment_id"])
        current = (snap or {}).get("docs", {}).get((ver["doc_type"], ver["container_fk"]))
        return version_html(ver, current)

    def do_restore(ship_id, doc_value, version_id, reason):
        if not version_id:
            return [gr.skip()] * 4 + [message_html("warning", "Chọn một phiên bản trước.")]
        try:
            text = H.restore_version(int(version_id), reason)
        except S.ShipmentError as ex:
            return [gr.skip()] * 4 + [message_html("error", "Chưa khôi phục được.", ex.errors)]
        choices = doc_choices(ship_id)
        return [gr.update(choices=choices, value=doc_value), *load_versions(ship_id, doc_value),
                message_html("success", text)]

    def refresh(chosen=None):
        ships = [(f"{r['shipment_id']} · {r.get('customer_name') or r.get('shipper_name') or ''}", r["shipment_id"])
                 for r in S.list_shipments()]
        ids = [s[1] for s in ships]
        pick = chosen if chosen in ids else (ids[0] if ids else None)
        info, frame = load_log(ALL, ALL, None, None)
        return [gr.update(choices=[("Tất cả lô hàng", ALL)] + ships, value=ALL), info, frame,
                gr.update(choices=ships, value=pick), *pick_ship(pick)]

    filter_inputs = [f_ship, f_doc, f_from, f_to]
    filter_btn.click(load_log, filter_inputs, [log_info, log_table])
    f_ship.input(load_log, filter_inputs, [log_info, log_table])
    f_doc.input(load_log, filter_inputs, [log_info, log_table])
    v_ship.input(pick_ship, v_ship, [v_doc, version_table, v_pick, version_view])
    v_doc.input(load_versions, [v_ship, v_doc], [version_table, v_pick, version_view])
    v_pick.input(show_version, v_pick, version_view)
    restore_btn.click(do_restore, [v_ship, v_doc, v_pick, restore_reason],
                      [v_doc, version_table, v_pick, version_view, restore_msg]).then(
        load_log, filter_inputs, [log_info, log_table])
    outputs = [f_ship, log_info, log_table, v_ship, v_doc, version_table, v_pick, version_view]
    return outputs, refresh
