"""Validation Center page ("Trung tâm kiểm tra") + the keep / replace panel (REQUIREMENTS.md §6, §9)."""

import html

import gradio as gr

from . import shipments as S
from . import sync as SY
from . import validation as VAL
from .ui_common import (
    GREEN, GREY, RED, YELLOW, e, message_html, notice_html, page_title_html, section_title_html,
    shipment_tracker_html,
)
from .workflow import shipment_step_statuses

STATE_COLOURS = {VAL.VALID: GREEN, VAL.MISSING: RED, VAL.MISMATCH: RED}
CONFIRM_COLOURS = {VAL.CONFIRMED: GREEN, VAL.PENDING: YELLOW, VAL.NOT_REQUIRED: GREY}
SEVERITY_COLOURS = {"error": RED, "warning": YELLOW, "info": GREY}


def _pill(text: str, colour: str) -> str:
    return (f'<span class="pill" style="border-color:{colour}"><i class="dot" style="background:{colour}"></i>'
            f'{e(text)}</span>')


def _multiline(text) -> str:
    return "<br>".join(html.escape(line) for line in str(text or "—").splitlines()) or "—"


# ---------------------------------------------------------------------------
# Keep / replace panel (used here and on the Shipment Management page)
# ---------------------------------------------------------------------------
def conflicts_html(conflicts: list[dict]) -> str:
    if not conflicts:
        return ""
    from .history import DOC_LABELS
    rows = []
    for c in conflicts:
        rows.append(
            f"<tr><td><b>#{c['id']}</b></td><td>{e(DOC_LABELS.get(c['doc_type'], c['doc_type']))}</td>"
            f"<td><b>{e(c['field_label'])}</b></td><td>{_multiline(SY.show_value(c['doc_value']))}</td>"
            f"<td>{_multiline(SY.show_value(c['new_value']))}</td>"
            f"<td>{e(SY.CAUSES.get(c['cause'], c['cause']))}<br><span class='hint'>{e(c['detail'])}</span></td></tr>")
    return (message_html("warning", f"Dữ liệu nguồn đã thay đổi — {len(conflicts)} chứng từ chờ bạn quyết định "
                                    "(không tự ghi đè):")
            + '<div class="table-wrap"><table class="grid"><tr><th>#</th><th>Chứng từ</th><th>Trường</th>'
              '<th>Giá trị trong chứng từ</th><th>Giá trị mới (nguồn)</th><th>Lý do không tự cập nhật</th></tr>'
            + "".join(rows) + "</table></div>"
            + '<p class="hint"><b>Giữ</b> = chứng từ giữ giá trị của nó · <b>Thay</b> = chứng từ dùng giá trị mới '
              '(chứng từ đã gửi / đã xác nhận sẽ có phiên bản <b>Amended</b> và cần gửi / xác nhận lại).</p>')


def build_conflict_panel(shipment_component):
    """A panel listing pending keep / replace choices for the shipment in `shipment_component`.

    Returns (outputs, refresh, events) — refresh(shipment_id) gives the values for `outputs`; `events` are the
    button events, so a page can chain `.then(...)` to show the result of the choice.
    """
    with gr.Group(visible=False) as box:
        info = gr.HTML()
        with gr.Row():
            pick = gr.Dropdown(label="Chọn mục cần quyết định", choices=[], scale=3)
            reason = gr.Textbox(label="Lý do (ghi vào lịch sử, không bắt buộc)", scale=2)
        with gr.Row():
            keep_btn = gr.Button("✋ Giữ giá trị trong chứng từ")
            replace_btn = gr.Button("🔁 Thay bằng giá trị mới", variant="primary")
            dismiss_btn = gr.Button("👌 Đã hiểu (chỉ là thông báo)")
    msg = gr.HTML()

    def refresh(shipment_id):
        conflicts = SY.list_conflicts(shipment_id) if shipment_id else []
        choices = [(SY.conflict_text(c), c["id"]) for c in conflicts]
        return (gr.update(visible=bool(conflicts)), conflicts_html(conflicts),
                gr.update(choices=choices, value=choices[0][1] if choices else None))

    def choose(shipment_id, conflict_id, why, choice):
        if not conflict_id:
            return (*refresh(shipment_id), message_html("warning", "Hãy chọn một mục trong danh sách."))
        try:
            text = SY.resolve(int(conflict_id), choice, why)
        except S.ShipmentError as ex:
            return (*refresh(shipment_id), message_html("error", "Chưa xử lý được.", ex.errors))
        return (*refresh(shipment_id), message_html("success", text + " Đã ghi vào Lịch sử chứng từ."))

    outputs = [box, info, pick]
    events = [button.click(lambda s, c, r, ch=choice: choose(s, c, r, ch), [shipment_component, pick, reason],
                           [*outputs, msg])
              for button, choice in ((keep_btn, "KEEP"), (replace_btn, "REPLACE"), (dismiss_btn, "DISMISS"))]
    return outputs, refresh, events


# ---------------------------------------------------------------------------
# Validation Center page
# ---------------------------------------------------------------------------
def summary_html(result: dict) -> str:
    counts, conf = result["counts"], result["confirm_counts"]
    data_pills = " ".join(_pill(f"{VAL.STATES[s]} ({s}): {counts[s]}", STATE_COLOURS[s]) for s in VAL.STATES)
    conf_pills = " ".join(_pill(f"{VAL.CONFIRM_STATES[s]} ({s}): {conf[s]}", CONFIRM_COLOURS[s])
                          for s in VAL.CONFIRM_STATES)
    if result["has_mismatch"]:
        data = message_html("error", f"Dữ liệu: {counts[VAL.MISMATCH]} mục KHÔNG KHỚP"
                            + (f" và {len(result['conflicts'])} thay đổi chờ quyết định" if result["conflicts"] else "")
                            + " — xem chi tiết bên dưới. Hệ thống không tự sửa.")
    elif not result["data_ok"]:
        data = message_html("warning", "Dữ liệu: còn mục thiếu (hoặc quá hạn cut-off) — xem chi tiết bên dưới.")
    else:
        data = message_html("success", "Dữ liệu: mọi giá trị có đủ và các chứng từ ghi giống nhau.")
    if result["confirmed_ok"]:
        confirm = message_html("success", "Xác nhận bên ngoài: mọi mục cần xác nhận đã có bằng chứng.")
    else:
        confirm = message_html("info", f"Xác nhận bên ngoài: {conf[VAL.PENDING]} mục còn chờ hãng tàu / depot / cảng "
                                       "xác nhận — đây không phải lỗi dữ liệu.")
    row = 'style="display:flex;flex-wrap:wrap;gap:6px;margin:6px 0;align-items:center"'
    return (f'<div {row}><b>Dữ liệu khớp:</b> {data_pills}</div>'
            f'<div {row}><b>Xác nhận bên ngoài:</b> {conf_pills}</div>{data}{confirm}')


def checks_html(result: dict) -> str:
    rows = []
    order = {VAL.MISMATCH: 0, VAL.MISSING: 1, VAL.VALID: 2}
    conf_order = {VAL.PENDING: 0, VAL.CONFIRMED: 1, VAL.NOT_REQUIRED: 2}
    for c in sorted(result["checks"], key=lambda c: (order[c["state"]], conf_order[c["confirmation"]],
                                                     c["step"] or 9)):
        values = "".join(f"<div><span class='hint'>{e(doc)}:</span> {_multiline(value)}</div>" for doc, value in c["values"])
        extra = []
        if c["suggested"]:
            extra.append(f"<div><b>Gợi ý:</b> {_multiline(c['suggested'])}</div>")
        if c["fix"]:
            extra.append(f"<div><b>Cách sửa:</b> {e(c['fix'])}</div>")
        if c["note"]:
            extra.append(f"<div class='hint'>{e(c['note'])}</div>")
        if c["actions"]:
            extra.append("<div class='hint'>↓ Có nút “Áp dụng giá trị này” bên dưới.</div>")
        sev = c["severity"]
        rows.append(
            f"<tr><td><b>{e(c['field'])}</b><div class='hint'>Bước {e(c['step'])}</div></td>"
            f"<td>{_pill(c['state_vi'], STATE_COLOURS[c['state']])}<div class='hint'>{e(c['state'])}</div></td>"
            f"<td>{_pill(c['confirmation_vi'], CONFIRM_COLOURS[c['confirmation']])}"
            f"<div class='hint'>{e(c['confirmation'])}</div>"
            f"<div class='hint'>{e(c['confirmation_by']) if c['confirmation_by'] else ''}</div></td>"
            f"<td>{_pill(VAL.SEVERITY[sev], SEVERITY_COLOURS[sev]) if sev != 'info' else '—'}</td>"
            f"<td>{values}</td><td>{''.join(extra) or '—'}</td></tr>")
    return ('<div class="table-wrap"><table class="grid"><tr><th>Trường kiểm tra</th>'
            '<th>Dữ liệu khớp<br><span style="font-weight:400">Data agreement</span></th>'
            '<th>Xác nhận bên ngoài<br><span style="font-weight:400">External confirmation</span></th><th>Mức độ</th>'
            '<th>Giá trị trong từng chứng từ</th><th>Gợi ý · cách sửa</th></tr>' + "".join(rows) + "</table></div>")


def _shipment_choices():
    return [(f"{r['shipment_id']} · {r.get('customer_name') or r.get('shipper_name') or ''}", r["shipment_id"])
            for r in S.list_shipments()]


def build_validation_page():
    gr.HTML(page_title_html("Trung tâm kiểm tra", "Validation Center — đối chiếu dữ liệu giữa 6 chứng từ"))
    gr.HTML(notice_html(
        "Kiểm tra chéo: Booking No., số container, seal, Shipper / Consignee / Notify, POL / POD, tàu / chuyến, "
        "mô tả hàng, số kiện, gross weight, CBM, VGM, freight terms và cut-off. Mỗi mục có <b>hai kết quả riêng</b>: "
        "<b>Dữ liệu khớp</b> (Hợp lệ / Thiếu dữ liệu / Không khớp — giá trị có đủ và các chứng từ ghi giống nhau không) và "
        "<b>Xác nhận bên ngoài</b> (Đã xác nhận / Chờ xác nhận / Không cần — hãng tàu, depot, cảng đã xác nhận "
        "bằng chứng từ chưa, và chứng từ nào). "
        "<b>Hệ thống không bao giờ tự sửa</b> — bạn chọn nguồn đúng rồi bấm “Áp dụng giá trị này”; "
        "mọi thay đổi được ghi vào Lịch sử chứng từ."))
    with gr.Row(equal_height=True):
        ship_dd = gr.Dropdown(label="Chọn lô hàng (Shipment)", choices=[], scale=3)
        run_btn = gr.Button("🔍 Kiểm tra lại", variant="primary", scale=1)
    tracker = gr.HTML()
    summary = gr.HTML()
    conflict_outputs, conflict_refresh, conflict_events = build_conflict_panel(ship_dd)
    gr.HTML(section_title_html("Kết quả kiểm tra", "Check results — mục không khớp / thiếu lên đầu"))
    table = gr.HTML()
    gr.HTML(section_title_html("Áp dụng giá trị này", "Apply a value you chose — goes through the change log"))
    with gr.Row():
        action_dd = gr.Dropdown(label="Chọn giá trị cần áp dụng", choices=[], scale=3)
        reason = gr.Textbox(label="Lý do (ghi vào lịch sử)", placeholder="VD: theo packing list ngày 20/11", scale=2)
    apply_btn = gr.Button("✅ Áp dụng giá trị này", variant="primary")
    apply_msg = gr.HTML()

    def render(shipment_id):
        if not shipment_id:
            empty = notice_html("Chọn một lô hàng để kiểm tra.")
            return ["", empty, "", gr.update(choices=[], value=None), *conflict_refresh(None)]
        result = VAL.run(shipment_id)
        if not result:
            return ["", message_html("error", f"Không tìm thấy {shipment_id}."), "", gr.update(choices=[], value=None),
                    *conflict_refresh(None)]
        actions = [(f"{a['check']} · {a['label']}", a["id"]) for a in VAL.actions_of(result)]
        tracker_html = shipment_tracker_html(shipment_step_statuses(shipment_id, result))
        return [tracker_html, summary_html(result), checks_html(result),
                gr.update(choices=actions, value=actions[0][1] if actions else None,
                          info=None if actions else "Không có giá trị nào cần áp dụng."),
                *conflict_refresh(shipment_id)]

    outputs = [tracker, summary, table, action_dd, *conflict_outputs]

    def refresh(chosen=None):
        choices = _shipment_choices()
        ids = [c[1] for c in choices]
        value = chosen if chosen in ids else (ids[0] if ids else None)
        return [gr.update(choices=choices, value=value), *render(value)]

    def do_apply(shipment_id, action_id, why):
        if not shipment_id or not action_id:
            return [*render(shipment_id), message_html("warning", "Chọn lô hàng và giá trị cần áp dụng.")]
        try:
            text = VAL.apply_action(shipment_id, action_id, why)
        except S.ShipmentError as ex:
            return [*render(shipment_id), message_html("error", "Chưa áp dụng được.", ex.errors)]
        return [*render(shipment_id), message_html("success", text + " Đã ghi vào Lịch sử chứng từ.")]

    ship_dd.input(render, ship_dd, outputs)
    run_btn.click(render, ship_dd, outputs)
    apply_btn.click(do_apply, [ship_dd, action_dd, reason], [*outputs, apply_msg])
    # after a keep / replace choice, run the checks again
    for event in conflict_events:
        event.then(lambda s: render(s)[:4], ship_dd, outputs[:4])
    return [ship_dd], [ship_dd, *outputs], refresh
