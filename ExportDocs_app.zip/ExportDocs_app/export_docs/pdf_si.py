"""Step 4 — Shipping Instruction PDF: generate_shipping_instruction_pdf() (REQUIREMENTS.md §5 Step 4, §11).

Its own layout, close to a Bill of Lading (what the SI asks the carrier to issue):

    navy header "SHIPPING INSTRUCTION" + requested document (Original B/L / Sea Waybill / Telex)
    status strip (DRAFT until submitted)
    Shipper / Consignee / Notify boxes (left)  |  references (right)
    routing grid: pre-carriage, place of receipt, vessel/voyage, POL, transshipment, POD, delivery
    cargo table: Marks & Numbers | No. & Kind of Packages | Description of Goods | Gross Weight | CBM
        (header repeated on every page; long descriptions continue over several pages)
    container / seal table: container, seal, size/type, packages, gross weight, CBM, VGM
    freight block | B/L instructions block
    remarks, empty signature / date block, document status note

Gross weight = CARGO gross weight (goods + packaging). The VGM column is the declared VGM from
Step 3, shown separately and never used as the cargo weight; a missing VGM is shown as missing.
"""

import io
import re
from datetime import datetime
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import CondPageBreak, KeepTogether, SimpleDocTemplate, Spacer, Table, TableStyle

from . import APP_NAME, settings, si as SI
from . import bookings as B
from .formatting import DASH, fmt_cbm, fmt_count, fmt_date, fmt_datetime, fmt_kg, fmt_packages, packages_total
from .pdf_generator import (
    FONT, FONT_BOLD, GAP, GRID, KIND_COLOURS, MARGIN_BOTTOM, MARGIN_TOP, MARGIN_X, MUTED, NAVY, NAVY_SOFT,
    TABLE_FONT, W, ZEBRA, _block, _numbered_canvas, _page_decorator, _plain_grid, _styles, field_grid,
    note_box, printable, register_fonts, safe_filename_part, side_by_side, txt, Paragraph,
)
from .shipments import sample_text

RED = colors.HexColor("#9C2F23")
CHUNK_CHARS = 300          # long descriptions are split into rows of about this many characters


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def split_text(text: str | None, limit: int = CHUNK_CHARS) -> list[str]:
    """Split long text into pieces (at line breaks, then at spaces) so a table row never
    has to be taller than a page. Short text stays one piece."""
    if not text:
        return []
    lines = []
    for line in str(text).split("\n"):                     # whole lines; only an over-long line is cut at spaces
        while len(line) > limit:
            cut = line.rfind(" ", 0, limit)
            cut = cut if cut > 0 else limit
            lines.append(line[:cut])
            line = line[cut:].lstrip()
        lines.append(line)
    pieces, current = [], []
    for line in lines:
        if current and len("\n".join(current + [line])) > limit:
            pieces.append("\n".join(current))
            current = []
        current.append(line)
    if current:
        pieces.append("\n".join(current))
    return [p for p in pieces if p.strip()] or []


def _html(text: str) -> str:
    return escape(printable(text)).replace("\n", "<br/>")


def _party_box(st, title: str, title_vi: str, p: dict, width: float, extra: str = "") -> Table:
    if p.get("party_name"):
        lines = [f"<b>{_html(p['party_name'])}</b>"]
        if p.get("address"):
            lines.append(_html(p["address"]))
        if p.get("country"):
            lines.append(_html(p["country"]))
        contact = " · ".join(x for x in (f"Tax ID: {p['tax_id']}" if p.get("tax_id") else None,
                                         f"Tel: {p['phone']}" if p.get("phone") else None,
                                         p.get("email")) if x)
        if contact:
            lines.append(f"<font size='6.8' color='#5B6B82'>{_html(contact)}</font>")
        body = "<br/>".join(lines)
    else:
        body = "<font color='#9C2F23'><b>NOT RECORDED</b></font>"
    if extra:
        body += f"<br/><font size='6.8' color='#9C2F23'>{_html(extra)}</font>"
    inner = Table([[Paragraph(body, st["value"])]], colWidths=[width])
    inner.setStyle(TableStyle(TABLE_FONT + [("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5),
                                            ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
    return _block(st, title, title_vi, [inner], width)


def _band(st, si: dict) -> Table:
    white = ParagraphStyle("sb_t", parent=st["title"], textColor=colors.white, fontSize=15, leading=18)
    white_sub = ParagraphStyle("sb_s", parent=st["subtitle"], textColor=colors.HexColor("#C9D4E5"))
    big = ParagraphStyle("sb_m", parent=st["value_big"], textColor=NAVY, alignment=TA_CENTER, fontSize=11.5, leading=13.5)
    small = ParagraphStyle("sb_m2", parent=st["badge_sub"], textColor=NAVY, alignment=TA_CENTER)
    bl = SI.BL_TYPES.get(si.get("bl_type"), "B/L TYPE NOT SET").upper()
    copies = (f"{si.get('originals_count') or '—'} ORIGINAL(S) · {si.get('copies_count') or 0} COPIES"
              if si.get("bl_type") == "ORIGINAL" else f"{si.get('copies_count') or 0} COPIES")
    box = Table([[Paragraph(escape(bl), big)], [Paragraph(escape(copies), small)]], colWidths=[46 * mm])
    box.setStyle(TableStyle(TABLE_FONT + [("BACKGROUND", (0, 0), (-1, -1), colors.white),
                                          ("TOPPADDING", (0, 0), (0, 0), 4), ("BOTTOMPADDING", (0, -1), (-1, -1), 4)]))
    band = Table([[[Paragraph("SHIPPING INSTRUCTION", white),
                    Paragraph("Instructions for the Bill of Lading · Hướng dẫn lập vận đơn &nbsp;·&nbsp; "
                              f"<font name='{FONT_BOLD}' size='7'>STEP 4 OF 6</font>", white_sub)], box]],
                 colWidths=[W - 50 * mm, 50 * mm])
    band.setStyle(TableStyle(TABLE_FONT + [
        ("BACKGROUND", (0, 0), (-1, -1), NAVY), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("ALIGN", (1, 0), (1, 0), "RIGHT"),
        ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
    ]))
    return band


def _strip(st, label: dict) -> Table:
    fg, bg = KIND_COLOURS[label["kind"]]
    t = Table([[Paragraph(escape(label["badge"]), ParagraphStyle("ss", parent=st["note_b"], textColor=fg)),
                Paragraph(f"Status: <b>{escape(SI.status_label(label['status']))}</b>"
                          + (f" &nbsp;·&nbsp; <b>{escape(label['sample_text'])} DATA</b>" if label["sample"] else ""),
                          ParagraphStyle("ss_r", parent=st["note"], alignment=TA_RIGHT))]],
              colWidths=[W * 0.5, W * 0.5])
    t.setStyle(TableStyle(TABLE_FONT + [
        ("BACKGROUND", (0, 0), (-1, -1), bg), ("LINEBELOW", (0, 0), (-1, -1), 1.2, fg),
        ("LEFTPADDING", (0, 0), (-1, -1), 6), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 4), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    return t


def _cargo_table(st, ship: dict, view: dict) -> Table:
    """Marks & Numbers | No. & Kind of Packages | Description of Goods | Gross Weight (kg) | Measurement (CBM)."""
    widths = [W * w for w in (0.19, 0.15, 0.40, 0.13, 0.13)]
    head = [Paragraph(h, st["th_r" if right else "th"]) for h, right in (
        ("MARKS &amp; NUMBERS", False), ("NO. &amp; KIND OF PACKAGES", False), ("DESCRIPTION OF GOODS", False),
        ("GROSS WEIGHT (KG)", True), ("MEASUREMENT (CBM)", True))]
    rows, style = [head], []
    equipment = ", ".join(f"{e['qty']} x {e['label']}" for e in B.equipment_summary(ship["containers"]))
    rows.append([Paragraph("", st["cell"]),
                 Paragraph(f"<b>{len(ship['containers'])} CONTAINER(S)</b>", st["cell"]),
                 Paragraph(f"<b>SHIPPER'S LOAD, STOW AND COUNT</b><br/>{escape(equipment)} said to contain:", st["cell"]),
                 Paragraph("", st["cell"]), Paragraph("", st["cell"])])
    for line in ship["cargo"]:
        desc = line.get("cargo_description") or line.get("commodity") or ""
        d_parts = split_text(desc) or [""]
        m_parts = split_text(line.get("marks_and_numbers"), 160) or [""]
        first = len(rows)
        for i in range(max(len(d_parts), len(m_parts))):
            d = _html(d_parts[i]) if i < len(d_parts) else ""
            if i == 0 and line.get("hs_code"):
                d = f"<font size='6.8' color='#5B6B82'>HS Code: {escape(line['hs_code'])}</font><br/>{d}"
            rows.append([
                Paragraph(_html(m_parts[i]) if i < len(m_parts) else "", st["cell"]),
                Paragraph(f"<b>{fmt_packages(line.get('package_count'), line.get('package_type'))}</b>" if i == 0 else "",
                          st["cell"]),
                Paragraph(d, st["cell"]),
                Paragraph(fmt_kg(line.get("gross_weight_kg")) if i == 0 else "", st["cell_r"]),
                Paragraph(fmt_cbm(line.get("volume_cbm")) if i == 0 else "", st["cell_r"]),
            ])
        style.append(("LINEABOVE", (0, first), (-1, first), 0.6, GRID))
        if len(rows) - first > 1:          # continuation rows of one cargo line read as one block
            style += [("BOTTOMPADDING", (0, first), (-1, len(rows) - 2), 0),
                      ("TOPPADDING", (0, first + 1), (-1, len(rows) - 1), 0)]
    t = SI.totals(view)
    rows.append([Paragraph("<b>TOTAL</b>", st["cell_b"]), Paragraph(f"<b>{packages_total(ship['cargo'])}</b>", st["cell"]),
                 Paragraph(f"<b>{len(ship['containers'])} container(s)</b> · gross weight = cargo gross weight "
                           "(goods + packaging), not VGM", st["cell"]),
                 Paragraph(f"<b>{fmt_kg(t['cargo']['gross'])}</b>", st["cell_r"]),
                 Paragraph(f"<b>{fmt_cbm(t['cargo']['cbm'])}</b>", st["cell_r"])])
    table = Table(rows, colWidths=widths, repeatRows=1)
    table.setStyle(TableStyle(TABLE_FONT + [
        ("BACKGROUND", (0, 0), (-1, 0), NAVY), ("BOX", (0, 0), (-1, -1), 0.8, NAVY),
        ("LINEAFTER", (0, 0), (-2, -1), 0.4, GRID), ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("BACKGROUND", (0, 1), (-1, 1), ZEBRA),
        ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 2.2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.8),
        ("BACKGROUND", (0, -1), (-1, -1), NAVY_SOFT), ("LINEABOVE", (0, -1), (-1, -1), 0.9, NAVY),
    ] + style))
    return table


def _container_table(st, ship: dict, view: dict) -> Table:
    widths = [W * w for w in (0.17, 0.15, 0.17, 0.14, 0.13, 0.10, 0.14)]
    head = [Paragraph(h, st["th_r" if r else "th"]) for h, r in (
        ("CONTAINER NO.", False), ("SEAL NO.", False), ("SIZE / TYPE", False), ("PACKAGES", True),
        ("GROSS WT (KG)", True), ("CBM", True), ("VGM (KG) · STEP 3", True))]
    t = SI.totals(view)
    rows = [head]
    lines_by_id = {l["id"]: l for l in ship["cargo"]}
    for c in ship["containers"]:
        got = t["per_container"][c["id"]]
        types = {(lines_by_id[a["cargo_fk"]].get("package_type") or "").upper()
                 for a in view["allocations"] if a["container_fk"] == c["id"] and a["cargo_fk"] in lines_by_id}
        unit = types.pop() if len(types) == 1 and "" not in types else "PKGS"
        size = " ".join(x for x in (f"{c['container_size']}'" if c.get("container_size") else None,
                                    c.get("iso_type_code")) if x) or DASH
        vgm = SI.declared_vgm(view, c)
        rows.append([
            Paragraph(f"<b>{txt(c.get('container_number'))}</b>", st["cell"]),
            Paragraph(txt(c.get("seal_number")) if c.get("seal_number") else
                      "<font color='#9C2F23'><b>MISSING</b></font>", st["cell"]),
            Paragraph(escape(size), st["cell"]),
            Paragraph(f"{fmt_count(got['packages'])} {unit}" if got["lines"] else DASH, st["cell_r"]),
            Paragraph(fmt_kg(got["gross"]) if got["lines"] else DASH, st["cell_r"]),
            Paragraph(fmt_cbm(got["cbm"]) if got["lines"] else DASH, st["cell_r"]),
            Paragraph(fmt_kg(vgm) if vgm is not None else "<font color='#9C2F23'><b>NOT DECLARED</b></font>",
                      st["cell_r"]),
        ])
    all_types = {(lines_by_id[a["cargo_fk"]].get("package_type") or "").upper()
                 for a in view["allocations"] if a["cargo_fk"] in lines_by_id}
    total_unit = all_types.pop() if len(all_types) == 1 and "" not in all_types else "PKGS"
    rows.append([Paragraph(f"<b>{len(ship['containers'])} CONTAINER(S)</b>", st["cell"]), "", "",
                 Paragraph(f"<b>{fmt_count(t['allocated']['packages'])} {total_unit}</b>", st["cell_r"]),
                 Paragraph(f"<b>{fmt_kg(t['allocated']['gross'])}</b>", st["cell_r"]),
                 Paragraph(f"<b>{fmt_cbm(t['allocated']['cbm'])}</b>", st["cell_r"]), ""])
    table = Table(rows, colWidths=widths, repeatRows=1)
    table.setStyle(TableStyle(TABLE_FONT + [
        ("BACKGROUND", (0, 0), (-1, 0), NAVY), ("BOX", (0, 0), (-1, -1), 0.6, GRID),
        ("LINEBELOW", (0, 0), (-1, -1), 0.4, GRID), ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.6),
        ("BACKGROUND", (0, -1), (-1, -1), NAVY_SOFT), ("LINEABOVE", (0, -1), (-1, -1), 0.9, NAVY),
        ("SPAN", (0, -1), (2, -1)),
    ] + [("BACKGROUND", (0, r), (-1, r), ZEBRA) for r in range(2, len(rows) - 1, 2)]))
    return table


# ---------------------------------------------------------------------------
# The document
# ---------------------------------------------------------------------------
def _story(st, view: dict) -> list:
    ship, si = view["shipment"], view["si"]
    label = SI.document_label(view)
    half = (W - GAP) / 2
    left_w, right_w = W * 0.56, W * 0.44 - GAP
    story = [_band(st, si), _strip(st, label), Spacer(1, 3 * mm)]

    # ---- Parties (left) | references (right) -----------------------------------
    consignee = SI.party(ship, "CONSIGNEE")
    to_order_note = ("TO ORDER consignee — notify party required" if SI.is_to_order(consignee.get("party_name"))
                     and not SI.party(ship, "NOTIFY_PARTY").get("party_name") else "")
    parties = [_party_box(st, "Shipper", "Người gửi hàng", SI.party(ship, "SHIPPER"), left_w), Spacer(1, 2.2 * mm),
               _party_box(st, "Consignee", "Người nhận hàng", consignee, left_w), Spacer(1, 2.2 * mm),
               _party_box(st, "Notify Party", "Bên nhận thông báo", SI.party(ship, "NOTIFY_PARTY"), left_w, to_order_note)]
    if si.get("additional_notify_name"):
        parties += [Spacer(1, 2.2 * mm), _party_box(st, "Also Notify", "Bên nhận thông báo thêm",
                                                    {"party_name": si["additional_notify_name"],
                                                     "address": si.get("additional_notify_address")}, left_w)]
    refs = _block(st, "References", "Tham chiếu", [_plain_grid(st, [
        [("Booking No.", txt(ship.get("booking_number")), "value_big")],
        [("SI Reference", txt(si.get("si_reference")), "value_b")],
        [("Shipper's Reference", txt(si.get("shipper_reference")))],
        [("Export Reference", txt(si.get("export_reference")))],
        [("Carrier", txt(ship.get("carrier_name")))],
        [("Transport Document", txt(si.get("transport_doc_type")))],
        [("Document Receiver", txt(si.get("document_receiver")))],
        [("Forwarder", txt(SI.party(ship, "FORWARDER").get("party_name")))],
        [("Shipment ID", txt(ship["shipment_id"]))],
    ], [right_w])], right_w)
    top = Table([[parties, "", [refs]]], colWidths=[left_w, GAP, right_w])
    top.setStyle(TableStyle(TABLE_FONT + [("VALIGN", (0, 0), (-1, -1), "TOP"),
                                          ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0),
                                          ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 0)]))
    story += [top, Spacer(1, 3 * mm)]

    # ---- Routing ---------------------------------------------------------------------
    vessel = " / ".join(x for x in (ship.get("vessel_name"), ship.get("voyage_number")) if x)
    story += [_block(st, "Routing", "Tuyến vận chuyển", [_plain_grid(st, [
        [("Pre-carriage by", txt(si.get("pre_carriage"))), ("Place of Receipt", txt(ship.get("place_of_receipt"))),
         ("Ocean Vessel / Voyage", txt(vessel), "value_b"), ("ETD", fmt_date(ship.get("etd")), "value_b")],
        [("Port of Loading", txt(ship.get("port_of_loading")), "value_b"),
         ("Port of Transshipment", txt(ship.get("transshipment_port"))),
         ("Port of Discharge", txt(ship.get("port_of_discharge")), "value_b"),
         ("Place of Delivery", txt(ship.get("place_of_delivery")))],
    ], [W * 0.25] * 4)], W), Spacer(1, 3 * mm)]

    # ---- Cargo ---------------------------------------------------------------------------
    story += [Paragraph(f"PARTICULARS FURNISHED BY THE SHIPPER &nbsp;<font name='{FONT}' size='7' color='#5B6B82'>"
                        "Chi tiết hàng hóa do người gửi hàng cung cấp</font>", st["subhead"]), Spacer(1, 1.5),
              _cargo_table(st, ship, view), Spacer(1, 3 * mm)]
    story += [CondPageBreak(30 * mm),
              Paragraph(f"CONTAINERS &amp; SEALS &nbsp;<font name='{FONT}' size='7' color='#5B6B82'>"
                        "Container, seal và hàng theo từng container</font>", st["subhead"]), Spacer(1, 1.5),
              _container_table(st, ship, view),
              Paragraph("Gross weight = cargo gross weight (goods + packaging). VGM is the verified gross mass "
                        "declared in Step 3 (SOLAS), shown for reference only — never used as the cargo weight.",
                        st["subnote"]), Spacer(1, 3 * mm)]

    # ---- Freight | B/L instructions ------------------------------------------------------------
    payment = SI.FREIGHT_TERMS.get(si.get("freight_terms"))
    freight = _block(st, "Freight & Payment", "Cước & thanh toán", [_plain_grid(st, [
        [("Freight terms", txt(payment.upper() if payment else None), "value_b"),
         ("Service type / Move type", txt(si.get("service_type")), "value_b")],
        [("Payable at", txt(si.get("payable_at"))), ("Freight payer", txt(SI.party(ship, "FREIGHT_PAYER").get("party_name")))],
        [("Freight & charges", txt(si.get("freight_charges"))), None],
    ], [half * 0.5, half * 0.5])], half)
    bl_type = si.get("bl_type")
    bl_note = {"TELEX": "Telex release: originals are surrendered at origin; cargo released at destination "
                        "without presenting an original B/L.",
               "SEA_WAYBILL": "Sea waybill: not a document of title; cargo released to the named consignee.",
               "ORIGINAL": "Original B/L: document of title; cargo released against an original B/L."}.get(bl_type, "")
    instructions = _block(st, "B/L Instructions", "Yêu cầu phát hành vận đơn", [_plain_grid(st, [
        [("Document type", txt(SI.BL_TYPES.get(bl_type)), "value_b"),
         ("Transport document", txt(si.get("transport_doc_type")))],
        [("Originals", txt(si.get("originals_count")) if bl_type == "ORIGINAL" else "n/a", "value_b"),
         ("Copies (non-negotiable)", txt(si.get("copies_count")), "value_b")],
        [("Document receiver", txt(si.get("document_receiver"))), None],
    ], [half * 0.5, half * 0.5]), Table([[Paragraph(escape(bl_note), st["subnote"])]], colWidths=[half],
                                        style=TableStyle(TABLE_FONT + [("LEFTPADDING", (0, 0), (-1, -1), 5),
                                                                       ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))], half)
    story += [KeepTogether([side_by_side([freight], [instructions])]), Spacer(1, 3 * mm)]

    if si.get("remarks"):
        story += [field_grid(st, [[("Remarks · Ghi chú", txt(si.get("remarks")))]], [W]), Spacer(1, 3 * mm)]

    # ---- Signature (empty) | submission record --------------------------------------------------
    sign = _block(st, "Shipper / Authorized signatory", "Người gửi hàng ký", [
        _plain_grid(st, [[("Place & date", "&nbsp;<br/>&nbsp;")], [("Name & position", "&nbsp;<br/>&nbsp;")]], [half]),
        Table([[[Paragraph("SIGNATURE / CHỮ KÝ", st["label"]), Spacer(1, 12 * mm)]]], colWidths=[half],
              style=TableStyle(TABLE_FONT + [("LINEABOVE", (0, 0), (-1, -1), 0.4, GRID),
                                             ("LEFTPADDING", (0, 0), (-1, -1), 5), ("TOPPADDING", (0, 0), (-1, -1), 2.5)]))],
        half)
    record = _block(st, "Submission record", "Ghi nhận gửi SI", [_plain_grid(st, [
        [("Submitted on", fmt_date(si.get("submission_date"))), ("Channel", txt(si.get("submission_channel")))],
        [("Amended on", fmt_date(si.get("amendment_date"))), ("Amendment reason", txt(si.get("amendment_reason")))],
        [("Draft B/L received", fmt_date(si.get("draft_bl_received_date"))),
         ("Draft B/L approved", fmt_date(si.get("draft_bl_approved_date")))],
    ], [half * 0.5, half * 0.5])], half)
    story += [KeepTogether([side_by_side([sign], [record]), Spacer(1, 3 * mm),
                            note_box(st, label["kind"], f"DOCUMENT STATUS: {label['badge']}", label["note"],
                                     fine=f"Signature left blank on purpose — {APP_NAME} never reproduces signatures, "
                                          "stamps or carrier confirmations. Submission and draft B/L dates are "
                                          "recorded by the user.")])]
    return story


def si_pdf_filename(ship: dict, si: dict) -> str:
    return (f"{safe_filename_part(ship['shipment_id'], 'SHIPMENT')}_"
            f"{safe_filename_part(ship.get('booking_number'), 'NO-BOOKING')}_"
            f"Shipping_Instruction_v{si.get('doc_version') or 1}.pdf")


def _view(shipment_id: str) -> dict:
    view = SI.get_si_view(shipment_id)
    if not view:
        raise SI.SIError([f"Không tìm thấy lô hàng {shipment_id}."])
    if not view["exists"]:
        raise SI.SIError(["Chưa lưu SI. Hãy bấm “Lưu nháp” trước khi xuất PDF."])
    return view


def _render(view: dict, target) -> None:
    register_fonts()
    st = _styles()
    ship, si = view["shipment"], view["si"]
    status = si.get("si_status") or "Draft"
    watermark = "SAMPLE" if ship["is_sample"] else ("DRAFT" if status == "Draft" else None)
    version = f"v{si.get('doc_version') or 1}"
    booking_no = ship.get("booking_number") or DASH
    footer = [
        f"Shipment ID: {ship['shipment_id']}   ·   Booking No.: {booking_no}   ·   Document version: {version}",
        f"Shipping Instruction {si.get('si_reference')}   ·   {SI.status_label(status)}"
        + (f"   ·   {sample_text(ship)} DATA" if ship["is_sample"] else "")
        + f"   ·   Exported: {datetime.now().strftime('%d %b %Y %H:%M').upper()}",
    ]
    running = f"SHIPPING INSTRUCTION {si.get('si_reference')}  ·  Booking {booking_no}  ·  {ship['shipment_id']}  (continued)"
    doc = SimpleDocTemplate(
        target, pagesize=A4, leftMargin=MARGIN_X, rightMargin=MARGIN_X, topMargin=MARGIN_TOP + 2 * mm,
        bottomMargin=MARGIN_BOTTOM, title=f"Shipping Instruction — {ship['shipment_id']}", author=APP_NAME,
        subject=f"Shipping Instruction · {ship['shipment_id']} · {version}", creator=APP_NAME,
        initialFontName=FONT, initialFontSize=8)
    decorate = _page_decorator(watermark, running)
    doc.build(_story(st, view), onFirstPage=decorate, onLaterPages=decorate, canvasmaker=_numbered_canvas(footer))


def build_shipping_instruction_pdf_bytes(shipment_id: str) -> bytes:
    buffer = io.BytesIO()
    _render(_view(shipment_id), buffer)
    return buffer.getvalue()


def generate_shipping_instruction_pdf(shipment_id: str, output_path: str | Path | None = None) -> Path:
    """Create the Shipping Instruction PDF and save it in the data folder.

    File: <data>/pdfs/<ShipmentID>/<ShipmentID>_<BookingNo>_Shipping_Instruction_v<N>.pdf
    """
    view = _view(shipment_id)
    if output_path is None:
        folder = settings.PDF_DIR / safe_filename_part(shipment_id, "SHIPMENT")
        folder.mkdir(parents=True, exist_ok=True)
        output_path = folder / si_pdf_filename(view["shipment"], view["si"])
    output_path = Path(output_path)
    _render(view, str(output_path))
    SI.record_pdf_export(shipment_id, str(output_path))
    from .library import register_generated      # Document Library keeps every version
    register_generated(shipment_id, "SI", output_path)
    return output_path
