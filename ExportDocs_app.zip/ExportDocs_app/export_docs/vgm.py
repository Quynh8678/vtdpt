"""Step 3 — VGM Declaration business logic (REQUIREMENTS.md §5 Step 3, §6, §7).

One VGM record per container. SOLAS Chapter VI, Regulation 2 principles:

- Method 1: the whole packed and sealed container is weighed → the user enters that VGM.
- Method 2: VGM = Cargo + Packaging + Pallets + Dunnage + Securing material + Container tare.
  If the cargo weight already includes packaging (gross), packaging is fixed at 0 so it is
  never counted twice.
- Cargo Weight is NEVER used as the VGM.

Data sync rule (§6):
- Booking number, vessel/voyage, shipper come from the central shipment (read-only here).
- Container number, tare and max gross mass (CSC plate) live in `containers`; tare and max
  gross can be edited here (saved centrally, with a warning when tare changes).
- The declared VGM is copied to containers.vgm_kg so Steps 5 and 6 can use it. A draft
  VGM is NOT copied — later steps only see a declared figure.

Honesty rules:
- "VGM Acknowledged" is only possible when the user types the carrier/terminal's
  acknowledgement reference. The app never sets it by itself.
- Saving a draft is always allowed; problems are warnings, and a status the data does not
  support falls back to "VGM Draft" with the reason.
"""

from dataclasses import dataclass, field
from datetime import datetime, timedelta

from . import shipments as S
from .database import reading, transaction
from .tracking import tracked
from .formatting import fmt_date, fmt_kg

METHODS = {
    "METHOD_1": ("Method 1 — weighing the packed container", "Phương pháp 1 — cân cả container đã đóng hàng"),
    "METHOD_2": ("Method 2 — calculated (sum of all contents + tare)",
                 "Phương pháp 2 — cộng khối lượng từng thành phần + tare"),
}
CARGO_BASES = {
    "GROSS": ("Cargo weight already includes packaging (gross)", "Khối lượng hàng ĐÃ GỒM bao bì (gross)"),
    "NET": ("Cargo weight is net goods only", "Khối lượng hàng chỉ là hàng tịnh (net), CHƯA gồm bao bì"),
}
UNITS = {"KGM": "kg", "TNE": "metric tons"}

STATUSES = ("Draft", "Declared", "Submitted", "Acknowledged", "Amended")
STATUS_LABELS = {   # stored value -> (English label, Vietnamese)
    "Not Entered": ("VGM Not Entered", "Chưa nhập VGM"),
    "Draft": ("VGM Draft", "Nháp"),
    "Declared": ("VGM Declared", "Đã khai (người gửi hàng ký)"),
    "Submitted": ("VGM Submitted", "Đã gửi hãng tàu / cảng"),
    "Acknowledged": ("VGM Acknowledged", "Hãng tàu / cảng đã xác nhận"),
    "Amended": ("VGM Amended", "VGM đã sửa đổi"),
}
DECLARED_STATES = ("Declared", "Submitted", "Acknowledged", "Amended")
SUBMITTED_STATES = ("Submitted", "Acknowledged")
SUBMISSION_CHANNELS = ("Carrier web portal", "EDI (VERMAS)", "Email to carrier", "Terminal / port system",
                       "e-Booking platform", "Other")

# Method 2 components, in formula order (tare comes from the central container record)
COMPONENTS = (
    ("cargo_weight_kg", "Cargo", "Hàng hóa"),
    ("packaging_weight_kg", "Packaging", "Bao bì"),
    ("pallet_weight_kg", "Pallets", "Pallet"),
    ("dunnage_weight_kg", "Dunnage", "Vật liệu chèn lót"),
    ("securing_weight_kg", "Securing material", "Vật liệu chằng buộc"),
)
FORMULA = "VGM = Cargo + Packaging + Pallets + Dunnage + Securing material + Container tare"

CONTAINER_FIELDS = ("tare_weight_kg", "max_gross_kg")          # central, editable in Step 3
NUMBER_FIELDS = tuple(k for k, _, _ in COMPONENTS) + ("weighed_vgm_kg",)
TEXT_FIELDS = ("vgm_reference", "responsible_party", "weighing_method", "cargo_basis", "vgm_unit",
               "weighing_location", "weighing_provider", "signatory_name", "signatory_position",
               "submission_channel", "ack_reference", "remarks",
               "method2_certification_ref")   # optional: some countries certify / approve shippers for Method 2
DATE_FIELDS = ("declaration_date", "submission_date")
VGM_FIELDS = NUMBER_FIELDS + TEXT_FIELDS + DATE_FIELDS + ("weighing_datetime",)

CUTOFF_WARNING_HOURS = 24
GROSS_TOLERANCE = 0.05          # 5 % difference to the container gross weight in master data


class VGMError(S.ShipmentError):
    pass


@dataclass
class VGMSaveResult:
    container_id: int
    vgm_reference: str
    status: str
    vgm_kg: float | None
    created: bool
    warnings: list[str] = field(default_factory=list)


def status_label(status: str) -> str:
    return STATUS_LABELS.get(status, (status, status))[0]


# ---------------------------------------------------------------------------
# Calculation
# ---------------------------------------------------------------------------
def effective_packaging(basis: str | None, packaging: float | None) -> float:
    """Gross cargo weight already contains the packaging → packaging counts as 0."""
    return 0.0 if (basis or "GROSS") == "GROSS" else (packaging or 0.0)


def compute_vgm(method: str | None, basis: str | None, values: dict, tare: float | None) -> float | None:
    """The VGM in kg, or None when it cannot be determined yet. Never returns the cargo weight alone."""
    if method == "METHOD_1":
        return values.get("weighed_vgm_kg")
    if method == "METHOD_2":
        cargo = values.get("cargo_weight_kg")
        if cargo is None or tare is None:
            return None
        rest = sum(values.get(k) or 0.0 for k in ("pallet_weight_kg", "dunnage_weight_kg", "securing_weight_kg"))
        return round(cargo + effective_packaging(basis, values.get("packaging_weight_kg")) + rest + tare, 3)
    return None


def breakdown(basis: str | None, values: dict, tare: float | None) -> list[dict]:
    """Method 2 rows: label, Vietnamese label, kg used in the formula, note."""
    gross = (basis or "GROSS") == "GROSS"
    rows = []
    for key, en, vi in COMPONENTS:
        kg = values.get(key)
        note = ""
        if key == "cargo_weight_kg":
            note = "gross — includes packaging" if gross else "net goods only"
        elif key == "packaging_weight_kg" and gross:
            kg, note = 0.0, "included in the gross cargo weight — not counted again"
        rows.append({"key": key, "en": en, "vi": vi, "kg": kg, "note": note})
    rows.append({"key": "tare_weight_kg", "en": "Container tare", "vi": "Tare (vỏ container)", "kg": tare,
                 "note": "from the container record"})
    return rows


def formula_with_numbers(basis: str | None, values: dict, tare: float | None) -> str:
    """'18,500 + 0 + 572 + 45 + 18 + 3,900' (a missing optional component counts as 0)."""
    required = ("cargo_weight_kg", "tare_weight_kg")
    return " + ".join(fmt_kg(r["kg"]) if r["kg"] is not None else ("?" if r["key"] in required else "0")
                      for r in breakdown(basis, values, tare))


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------
def shipper_name(ship: dict) -> str | None:
    return ((ship.get("parties") or {}).get("SHIPPER") or {}).get("party_name")


def record_status(record: dict | None) -> str:
    return record["vgm_status"] if record else "Not Entered"


def get_shipment_vgms(shipment_id: str) -> dict | None:
    """Central shipment data + every container with its VGM record (or None) and status."""
    ship = S.get_shipment(shipment_id)
    if not ship:
        return None
    with reading() as conn:
        records = {r["container_fk"]: dict(r) for r in conn.execute(
            "SELECT * FROM vgm_records WHERE shipment_fk = ?", (ship["id"],))}
    items = []
    for n, c in enumerate(ship["containers"], start=1):
        record = records.get(c["id"])
        items.append({"no": n, "container": c, "vgm": record, "status": record_status(record)})
    return {"shipment": ship, "items": items}


def find_item(overview: dict, container_id: int) -> dict | None:
    return next((i for i in overview["items"] if i["container"]["id"] == container_id), None)


# ---------------------------------------------------------------------------
# Checks
# ---------------------------------------------------------------------------
def checks(ship: dict, container: dict, rec: dict, now: datetime | None = None) -> tuple[list[str], list[str]]:
    """(blocking, warnings).

    blocking = what stops the VGM from being Declared (it can still be saved as a draft).
    warnings = things to look at that do not stop the declaration.
    """
    now = now or datetime.now()
    blocking, warnings = [], []
    number = container.get("container_number")
    if not number:
        blocking.append("Container chưa có số — không khai VGM cho container chưa xác định "
                        "(nhập số ở Bước 2 hoặc Quản lý lô hàng).")
    elif S.container_number_problem(number):
        warnings.append(f"Container {number}: {S.container_number_problem(number)}.")

    booking = ship.get("booking_number")
    declared_booking = rec.get("declared_booking_number")
    if not booking:
        blocking.append("Lô hàng chưa có Booking No. (nhập ở Bước 1).")
    elif declared_booking and declared_booking != booking:
        blocking.append(f"Booking No. trên VGM ({declared_booking}) khác Booking No. hiện tại ({booking}) — "
                        "lưu lại VGM để cập nhật.")

    method = rec.get("weighing_method")
    if method not in METHODS:
        blocking.append("Chưa chọn phương pháp xác định VGM (Method 1 / Method 2).")
    if not rec.get("responsible_party"):
        blocking.append("Chưa nhập bên chịu trách nhiệm (Responsible party / Shipper).")
    if not rec.get("signatory_name"):
        blocking.append("Chưa nhập người ký có thẩm quyền (Authorized signatory).")
    elif not rec.get("signatory_position"):
        warnings.append("Chưa nhập chức vụ người ký (Position).")
    if not rec.get("declaration_date"):
        blocking.append("Chưa nhập ngày khai (Declaration date).")

    tare = container.get("tare_weight_kg")
    cargo = rec.get("cargo_weight_kg")
    if method == "METHOD_1":
        if not rec.get("weighing_location"):
            blocking.append("Method 1: chưa nhập nơi cân (Weighing location).")
        if not rec.get("weighing_provider"):
            blocking.append("Method 1: chưa nhập thiết bị cân / đơn vị cân (Weighing equipment / provider).")
        if rec.get("weighed_vgm_kg") is None:
            blocking.append("Method 1: chưa nhập VGM cân được.")
    elif method == "METHOD_2":
        if cargo is None:
            blocking.append("Method 2: chưa nhập Cargo weight.")
        if tare is None:
            blocking.append("Method 2: chưa có tare của container.")
        tare_used = rec.get("tare_used_kg")
        if tare is not None and tare_used is not None and abs(tare - tare_used) > 0.5:
            blocking.append(f"Tare trong dữ liệu chung đã đổi ({fmt_kg(tare_used)} → {fmt_kg(tare)} kg) sau khi "
                            "tính VGM — lưu lại để tính lại.")
        basis = rec.get("cargo_basis") or "GROSS"
        if basis == "NET" and not rec.get("packaging_weight_kg"):
            warnings.append("Cargo là hàng tịnh (net) nhưng bao bì = 0 — kiểm tra lại khối lượng bao bì.")
        master_cargo = container.get("cargo_weight_kg")
        if (basis == "NET" and cargo is not None and master_cargo is not None and rec.get("packaging_weight_kg")
                and abs(cargo - master_cargo) < 0.5):
            warnings.append(
                f"Có thể đang tính bao bì hai lần: Cargo weight ({fmt_kg(cargo)} kg) bằng Cargo Weight của container "
                "trong dữ liệu chung (thường là gross, đã gồm bao bì). Nếu đúng vậy, hãy chọn "
                "“Khối lượng hàng ĐÃ GỒM bao bì (gross)”.")

    vgm = rec.get("vgm_kg")
    if vgm is not None:
        if tare is not None and vgm <= tare:
            blocking.append(f"VGM ({fmt_kg(vgm)} kg) phải lớn hơn tare ({fmt_kg(tare)} kg).")
        if cargo is not None and vgm <= cargo:
            blocking.append(f"VGM ({fmt_kg(vgm)} kg) phải lớn hơn Cargo weight ({fmt_kg(cargo)} kg) — "
                            "không dùng Cargo Weight làm VGM.")
        max_gross = container.get("max_gross_kg")
        if max_gross and vgm > max_gross:
            blocking.append(f"VGM ({fmt_kg(vgm)} kg) vượt Max gross mass trên biển CSC ({fmt_kg(max_gross)} kg) — "
                            "container quá tải, không được xếp lên tàu.")
        master_gross = container.get("gross_weight_kg")
        if master_gross:
            diff = abs(vgm - master_gross) / master_gross
            if diff > GROSS_TOLERANCE:
                warnings.append(f"VGM ({fmt_kg(vgm)} kg) chênh {diff:.1%} so với Gross Weight của container trong "
                                f"dữ liệu chung ({fmt_kg(master_gross)} kg) — quá 5 %, kiểm tra lại.")

    if rec.get("vgm_status") not in SUBMITTED_STATES:
        cutoff = S.to_datetime(ship.get("vgm_cutoff"))
        if cutoff:
            if now > cutoff:
                warnings.append(f"Đã QUÁ hạn VGM cut-off ({ship['vgm_cutoff']}) — liên hệ hãng tàu ngay.")
            elif cutoff - now <= timedelta(hours=CUTOFF_WARNING_HOURS):
                hours = (cutoff - now).total_seconds() / 3600
                warnings.append(f"VGM cut-off còn dưới 24 giờ ({ship['vgm_cutoff']}, còn ~{hours:.0f} giờ).")
    return blocking, warnings


def requirements_for(status: str, ship: dict, container: dict, rec: dict) -> list[str]:
    """What is missing for the requested status (empty list = allowed)."""
    if status == "Draft":
        return []
    missing = list(checks(ship, container, rec)[0])
    if status in SUBMITTED_STATES:
        if not rec.get("submission_date"):
            missing.append("Chưa nhập ngày gửi (Submission date).")
        if not rec.get("submission_channel"):
            missing.append("Chưa nhập kênh gửi (Submission channel).")
    if status == "Acknowledged" and not rec.get("ack_reference"):
        missing.append("“VGM Acknowledged” cần số xác nhận của hãng tàu / cảng (Acknowledgement reference) "
                       "do bạn nhập từ phản hồi thật.")
    return missing


def document_label(ship: dict, container: dict, rec: dict) -> dict:
    """Badge and note printed on the PDF / shown on screen."""
    status = rec["vgm_status"]
    blocking = checks(ship, container, rec)[0]
    if status in DECLARED_STATES and blocking:
        label = dict(kind="internal", badge="NEEDS CORRECTION",
                     note="The data changed after this VGM was declared: " + " ".join(blocking))
    elif status == "Draft":
        label = dict(kind="draft", badge="DRAFT — NOT YET DECLARED",
                     note=("Draft prepared for checking. Not a valid VGM declaration until it is declared and "
                           "signed by the shipper's authorized signatory."))
    elif status == "Declared":
        label = dict(kind="reference", badge="DECLARED BY SHIPPER",
                     note="Declared by the shipper. Not yet recorded as submitted to the carrier / terminal.")
    elif status == "Submitted":
        label = dict(kind="reference", badge="SUBMITTED — AWAITING ACKNOWLEDGEMENT",
                     note=(f"Submitted on {fmt_date(rec.get('submission_date'))} via {rec.get('submission_channel')} "
                           "(recorded by the user). No carrier/terminal acknowledgement reference recorded."))
    elif status == "Acknowledged":
        label = dict(kind="confirmed", badge=f"ACKNOWLEDGED — REF. {rec.get('ack_reference')}",
                     note=(f"Acknowledgement reference {rec.get('ack_reference')} was entered by the user from the "
                           "carrier/terminal's response. This app does not verify it."))
    else:   # Amended
        label = dict(kind="draft", badge="AMENDED DECLARATION",
                     note=("This VGM replaces an earlier declaration. Submit the amended VGM to the carrier / "
                           "terminal again; any earlier acknowledgement applied to the previous figure."))
    label["sample"] = bool(ship["is_sample"])
    label["sample_text"] = S.sample_text(ship)
    return label


def step_status(shipment_id: str) -> str:
    """Step 3 in the 6-step progress.

    Completed only when EVERY container's VGM is acknowledged (with the user's reference);
    Waiting for External Confirmation when all are submitted; Needs Correction when a
    declared VGM no longer matches the data.
    """
    overview = get_shipment_vgms(shipment_id)
    if not overview or not overview["items"]:
        return "Not Started"
    ship = overview["shipment"]
    statuses = [i["status"] for i in overview["items"]]
    if all(s == "Not Entered" for s in statuses):
        return "Not Started"
    for i in overview["items"]:
        if i["status"] in DECLARED_STATES and checks(ship, i["container"], i["vgm"])[0]:
            return "Needs Correction"
    if all(s == "Acknowledged" for s in statuses):
        return "Completed"
    if all(s in SUBMITTED_STATES for s in statuses):
        return "Waiting for External Confirmation"
    return "In Progress"


def count_vgms() -> int:
    with reading() as conn:
        return conn.execute("SELECT COUNT(*) FROM vgm_records").fetchone()[0]


# ---------------------------------------------------------------------------
# Save
# ---------------------------------------------------------------------------
_FALLBACK = {"Acknowledged": ("Submitted", "Declared"), "Submitted": ("Declared",)}


def _next_reference(conn, fk: int, shipment_id: str) -> str:
    prefix = f"VGM-{shipment_id}-"
    rows = conn.execute("SELECT vgm_reference FROM vgm_records WHERE shipment_fk = ?", (fk,)).fetchall()
    used = [int(r[0].rsplit("-", 1)[1]) for r in rows if r[0].startswith(prefix) and r[0].rsplit("-", 1)[1].isdigit()]
    return f"{prefix}{max(used, default=0) + 1}"


@tracked("VGM")
def save_vgm(shipment_id: str, container_id: int, container_values: dict, vgm_values: dict,
             requested_status: str = "Draft", now: datetime | None = None) -> VGMSaveResult:
    """Save one VGM record. Raises VGMError only for real data errors (not a number, wrong choice)."""
    errors, warnings = [], []
    cont = {k: S.parse_number(container_values.get(k), label, errors)
            for k, label in (("tare_weight_kg", "Tare"), ("max_gross_kg", "Max gross (CSC)"))}
    rec = {k: S.parse_number(vgm_values.get(k), k.replace("_kg", "").replace("_", " ").capitalize(), errors)
           for k in NUMBER_FIELDS}
    rec.update({k: S.clean_text(vgm_values.get(k)) for k in TEXT_FIELDS})
    rec.update({k: S.parse_when(vgm_values.get(k), False, k.replace("_", " ").capitalize(), errors)
                for k in DATE_FIELDS})
    rec["weighing_datetime"] = S.parse_when(vgm_values.get("weighing_datetime"), True, "Weighing date/time", errors)
    rec["cargo_basis"] = rec["cargo_basis"] or "GROSS"
    rec["vgm_unit"] = rec["vgm_unit"] or "KGM"
    if rec["weighing_method"] not in (None, *METHODS):
        errors.append("Phương pháp VGM không hợp lệ.")
    if rec["cargo_basis"] not in CARGO_BASES:
        errors.append("Cơ sở khối lượng hàng phải là GROSS hoặc NET.")
    if rec["vgm_unit"] not in UNITS:
        errors.append("Đơn vị phải là kg hoặc metric tons.")
    requested_status = requested_status or "Draft"
    if requested_status not in STATUSES:
        errors.append(f"Trạng thái “{requested_status}” không hợp lệ.")
    if errors:
        raise VGMError(errors)

    # never count packaging twice
    if rec["cargo_basis"] == "GROSS":
        if rec["packaging_weight_kg"]:
            warnings.append(f"Đã chọn “Cargo ĐÃ GỒM bao bì” → bao bì đặt = 0 (bạn đã nhập "
                            f"{fmt_kg(rec['packaging_weight_kg'])} kg) để không tính bao bì hai lần.")
        rec["packaging_weight_kg"] = 0.0

    stamp = S.now_text()
    ship = S.get_shipment(shipment_id)
    if not ship:
        raise VGMError([f"Không tìm thấy lô hàng {shipment_id}."])
    container = next((c for c in ship["containers"] if c["id"] == container_id), None)
    if not container:
        raise VGMError(["Container không thuộc lô hàng này."])

    old_tare = container.get("tare_weight_kg")
    if cont["tare_weight_kg"] != old_tare and old_tare is not None:
        warnings.append(f"Tare đã đổi từ {fmt_kg(old_tare)} thành {fmt_kg(cont['tare_weight_kg'])} kg trong dữ liệu "
                        "chung — kiểm tra lại số trên cửa container / biển CSC.")
    container = {**container, **cont}
    rec["vgm_kg"] = compute_vgm(rec["weighing_method"], rec["cargo_basis"], rec, container["tare_weight_kg"])
    rec["tare_used_kg"] = container["tare_weight_kg"]
    rec["declared_booking_number"] = ship.get("booking_number")

    with reading() as conn:
        existing = conn.execute("SELECT * FROM vgm_records WHERE container_fk = ?", (container_id,)).fetchone()
    existing = dict(existing) if existing else None
    previous = existing["vgm_status"] if existing else None

    # A changed figure after submission is an amendment (the old acknowledgement no longer applies)
    status = requested_status
    if (previous in ("Submitted", "Acknowledged", "Amended") and status != "Draft"
            and existing.get("vgm_kg") is not None and rec["vgm_kg"] is not None
            and abs(existing["vgm_kg"] - rec["vgm_kg"]) > 0.5):
        if status != "Amended":
            warnings.append(f"VGM đã thay đổi sau khi gửi ({fmt_kg(existing['vgm_kg'])} → {fmt_kg(rec['vgm_kg'])} kg) "
                            "→ trạng thái “VGM Amended”. Hãy gửi lại VGM sửa đổi cho hãng tàu / cảng.")
        status = "Amended"
    if status == "Amended" and previous not in DECLARED_STATES:
        warnings.append("VGM chưa từng được khai nên không phải “Amended” — dùng “VGM Declared”.")
        status = "Declared"
    rec["vgm_status"] = status
    missing = requirements_for(status, ship, container, rec)
    if missing:
        # fall back to the highest status the data supports (never upwards)
        fallback = next((s for s in _FALLBACK.get(status, ()) if not requirements_for(s, ship, container, rec)),
                        "Draft")
        warnings.insert(0, f"Chưa thể đặt “{status_label(status)}” → lưu là {status_label(fallback)}. "
                        "Còn thiếu / cần sửa: " + " ".join(missing))
        status = rec["vgm_status"] = fallback
    _, soft = checks(ship, container, rec, now)
    warnings.extend(soft)

    central_vgm = rec["vgm_kg"] if status in DECLARED_STATES else None
    with transaction() as conn:
        fk = ship["id"]
        conn.execute("UPDATE containers SET tare_weight_kg = ?, max_gross_kg = ?, vgm_kg = ? WHERE id = ?",
                     (cont["tare_weight_kg"], cont["max_gross_kg"], central_vgm, container_id))
        conn.execute("UPDATE shipments SET updated_at = ? WHERE id = ?", (stamp, fk))
        reference = rec["vgm_reference"] or (existing or {}).get("vgm_reference") or _next_reference(conn, fk, shipment_id)
        rec["vgm_reference"] = reference
        cols = [*VGM_FIELDS, "vgm_kg", "tare_used_kg", "declared_booking_number", "vgm_status"]
        if existing:
            conn.execute(f"UPDATE vgm_records SET {', '.join(f'{k} = ?' for k in cols)}, updated_at = ? "
                         f"WHERE container_fk = ?", [*(rec[k] for k in cols), stamp, container_id])
        else:
            all_cols = ["shipment_fk", "container_fk", *cols, "created_at", "updated_at"]
            conn.execute(f"INSERT INTO vgm_records ({', '.join(all_cols)}) VALUES ({', '.join('?' * len(all_cols))})",
                         [fk, container_id, *(rec[k] for k in cols), stamp, stamp])
    if status not in DECLARED_STATES and rec["vgm_kg"] is not None:
        warnings.append("VGM nháp chưa được chuyển sang dữ liệu chung — Bước 5 và 6 chỉ dùng VGM đã khai.")
    return VGMSaveResult(container_id=container_id, vgm_reference=reference, status=status, vgm_kg=rec["vgm_kg"],
                         created=existing is None, warnings=warnings)


@tracked("VGM")
def delete_vgm(shipment_id: str, container_id: int) -> str:
    """Delete one VGM record and clear the container's central VGM. Returns its reference."""
    with transaction() as conn:
        fk = S.get_shipment_fk(conn, shipment_id)
        row = conn.execute("SELECT vgm_reference FROM vgm_records WHERE container_fk = ? AND shipment_fk = ?",
                           (container_id, fk)).fetchone()
        if not row:
            raise VGMError(["Container này chưa có VGM."])
        conn.execute("DELETE FROM vgm_records WHERE container_fk = ?", (container_id,))
        conn.execute("UPDATE containers SET vgm_kg = NULL WHERE id = ?", (container_id,))
        conn.execute("UPDATE shipments SET updated_at = ? WHERE id = ?", (S.now_text(), fk))
    return row[0]


def record_pdf_export(container_ids: list[int], path: str) -> None:
    stamp = S.now_text()[:16]
    with transaction() as conn:
        for cid in container_ids:
            conn.execute("UPDATE vgm_records SET last_pdf_path = ?, last_pdf_at = ? WHERE container_fk = ?",
                         (path, stamp, cid))
