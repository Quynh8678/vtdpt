"""Step 5 — Export Gate-in & Loading Registration PDF: generate_export_gatein_pdf() (§5 Step 5, §11).

Its own layout, like a terminal's container status sheet:

    navy header + "FULL IN · Trucker » Terminal" badge
    INTERNAL RECORD / REFERENCE COPY strip with the statuses currently confirmed
    references → terminal block | container block (seal SI vs seal at gate-in, cargo gross, tare, VGM)
    status timeline: all 9 statuses with date/time, source, confirmed by, evidence (or "—")
    customs block | yard block → transport block | export registration block
    evidence list, checks, remarks, document status note

One page per container (long content shrinks slightly instead of spilling over); all in one PDF.
"""

import io
from datetime import datetime
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import KeepInFrame, PageBreak, SimpleDocTemplate, Spacer, Table, TableStyle

from . import APP_NAME, gatein as G, settings
from .formatting import DASH, fmt_date, fmt_datetime, fmt_kg
from .pdf_generator import (
    FONT, FONT_BOLD, GAP, GRID, KIND_COLOURS, MARGIN_BOTTOM, MARGIN_TOP, MARGIN_X, NAVY, NAVY_SOFT, TABLE_FONT,
    W, ZEBRA, CheckBox, _block, _container_number_block, _numbered_canvas, _page_decorator, _plain_grid, _styles,
    field_grid, note_box, register_fonts, safe_filename_part, side_by_side, txt, Paragraph,
)
from .pdf_vgm import _flatten
from .shipments import sample_text

RED = colors.HexColor("#9C2F23")
GREEN = colors.HexColor("#1E6B45")
GREEN_BG = colors.HexColor("#E6F4EC")
RED_BG = colors.HexColor("#FDECEA")
LANE_COLOURS = {"GREEN": "#1E6B45", "YELLOW": "#8A5A00", "RED": "#9C2F23"}


def _band(st) -> Table:
    white = ParagraphStyle("gb_t", parent=st["title"], textColor=colors.white, fontSize=14, leading=17)
    white_sub = ParagraphStyle("gb_s", parent=st["subtitle"], textColor=colors.HexColor("#C9D4E5"))
    big = ParagraphStyle("gb_m", parent=st["value_big"], textColor=NAVY, alignment=TA_CENTER, fontSize=13, leading=15)
    small = ParagraphStyle("gb_m2", parent=st["badge_sub"], textColor=NAVY, alignment=TA_CENTER)
    box = Table([[Paragraph("FULL&nbsp;IN", big)], [Paragraph("Trucker » Terminal", small)]], colWidths=[38 * mm])
    box.setStyle(TableStyle(TABLE_FONT + [("BACKGROUND", (0, 0), (-1, -1), colors.white),
                                          ("TOPPADDING", (0, 0), (0, 0), 3.5), ("BOTTOMPADDING", (0, -1), (-1, -1), 3.5)]))
    band = Table([[[Paragraph("EXPORT GATE-IN &amp; LOADING REGISTRATION", white),
                    Paragraph("Container status at terminal · Phiếu theo dõi container hàng xuất tại cảng &nbsp;·&nbsp; "
                              f"<font name='{FONT_BOLD}' size='7'>STEP 5 OF 6</font>", white_sub)], box]],
                 colWidths=[W - 42 * mm, 42 * mm])
    band.setStyle(TableStyle(TABLE_FONT + [
        ("BACKGROUND", (0, 0), (-1, -1), NAVY), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("ALIGN", (1, 0), (1, 0), "RIGHT"),
        ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 5.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 6.5),
    ]))
    return band


def _strip(st, label: dict, item: dict, index: int, total: int) -> Table:
    fg, bg = KIND_COLOURS[label["kind"]]
    active = [G.STATUS_NAMES[k] for k in G.active_statuses(item)]
    t = Table([[Paragraph(escape(label["badge"]), ParagraphStyle("gs", parent=st["note_b"], textColor=fg)),
                Paragraph(f"Now: <b>{escape(' · '.join(active) or 'no status confirmed')}</b> &nbsp;·&nbsp; "
                          f"Container {index} of {total}"
                          + (f" &nbsp;·&nbsp; <b>{escape(label['sample_text'])} DATA</b>" if label["sample"] else ""),
                          ParagraphStyle("gs_r", parent=st["note"], alignment=TA_RIGHT))]],
              colWidths=[W * 0.40, W * 0.60])
    t.setStyle(TableStyle(TABLE_FONT + [
        ("BACKGROUND", (0, 0), (-1, -1), bg), ("LINEBELOW", (0, 0), (-1, -1), 1.2, fg),
        ("LEFTPADDING", (0, 0), (-1, -1), 6), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 4), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    return t


def _timeline(st, item: dict) -> Table:
    head = [Paragraph(h, st["th"]) for h in ("#", "STATUS", "", "DATE / TIME", "SOURCE", "CONFIRMED BY",
                                              "EVIDENCE / NOTE")]
    rows, style = [head], []
    for n, (key, en, vi) in enumerate(G.STATUSES, start=1):
        event = item["current"].get(key)
        active = bool(event and event["action"] == "SET")
        if event:
            when = fmt_datetime(event["event_datetime"]) if event["event_datetime"] else DASH
            if event["action"] == "CLEAR":
                when = (f"Cleared {when}" if event["event_datetime"]
                        else f"Cleared (recorded {fmt_datetime(event['recorded_at'][:16])})")
            source = G.SOURCES[event["source"]]
            proof = G.evidence_name(item, event["evidence_fk"]) if event["evidence_fk"] else None
            detail = " · ".join(x for x in (f"File: {proof}" if proof else None, event.get("note")) if x)
            cells = [when, source, event["confirmed_by"], detail or DASH]
        else:
            cells = [DASH, DASH, DASH, DASH]
        rows.append([Paragraph(str(n), st["cell"]),
                     Paragraph(f"<b>{escape(en)}</b><br/><font size='6.4' color='#5B6B82'>{escape(vi)}</font>", st["cell"]),
                     CheckBox(active, colour=RED if key == "HOLD_REJECTED" else GREEN)]
                    + [Paragraph(txt(v) if v != DASH else DASH, st["cell"]) for v in cells])
        if active:
            style.append(("BACKGROUND", (0, n), (-1, n), RED_BG if key == "HOLD_REJECTED" else GREEN_BG))
    t = Table(rows, colWidths=[W * w for w in (0.04, 0.21, 0.05, 0.15, 0.12, 0.15, 0.28)], repeatRows=1)
    t.setStyle(TableStyle(TABLE_FONT + style + [
        ("BACKGROUND", (0, 0), (-1, 0), NAVY), ("BOX", (0, 0), (-1, -1), 1, NAVY),
        ("INNERGRID", (0, 0), (-1, -1), 0.4, GRID), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (2, 0), (2, -1), "CENTER"),
        ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5),
    ]))
    return t


def _page(st, ship: dict, item: dict, index: int, total: int) -> list:
    c, rec = item["container"], item["record"] or {}
    label = G.document_label(ship, item)
    half = (W - GAP) / 2
    story = [_band(st), _strip(st, label, item, index, total), Spacer(1, 2.6 * mm)]

    vessel = " / ".join(x for x in (ship.get("vessel_name"), ship.get("voyage_number")) if x)
    route = " » ".join(x for x in (ship.get("port_of_loading"), ship.get("port_of_discharge")) if x)
    story += [field_grid(st, [[
        ("Booking No.", txt(ship.get("booking_number")), "value_big"), ("Carrier", txt(ship.get("carrier_name"))),
        ("Vessel / Voyage", txt(vessel), "value_b"), ("POL » POD", txt(route)), ("Shipment ID", txt(ship["shipment_id"])),
    ]], [W * w for w in (0.19, 0.18, 0.19, 0.30, 0.14)], shade=True), Spacer(1, 2.6 * mm)]

    terminal = _block(st, "Terminal", "Cảng / bãi", [_plain_grid(st, [
        [("Terminal", txt(rec.get("terminal_name")), "value_b"), ("Area", txt(rec.get("terminal_area")))],
        [("Transaction ref.", txt(rec.get("transaction_ref"))), ("Registration no.", txt(rec.get("registration_no")))],
        [("Gate-in EIR no.", txt(rec.get("gatein_eir_no"))),
         ("Gate-in date / time", fmt_datetime(rec.get("gatein_datetime")), "value_b")],
    ], [half * 0.5, half * 0.5]), Paragraph("Terminal references are typed in by the user — never generated.",
                                            ParagraphStyle("tn", parent=st["subnote"], leftIndent=5))], half)
    si_seal, gate_seal = c.get("seal_number"), rec.get("gatein_seal_number")
    differs = bool(si_seal and gate_seal and si_seal.strip().upper() != gate_seal.strip().upper())
    gate_seal_html = (f"<font color='#9C2F23'><b>{txt(gate_seal)}</b><br/>DIFFERS FROM SI</font>" if differs
                      else txt(gate_seal))
    vgm = c.get("vgm_kg")
    size = " ".join(x for x in (f"{c['container_size']}'" if c.get("container_size") else None,
                                c.get("iso_type_code"), c.get("container_type")) if x)
    container = _block(st, "Container", "Container", [
        Spacer(1, 2), Table([[_container_number_block(st, c.get("container_number"))]], colWidths=[half],
                            style=TableStyle(TABLE_FONT + [("LEFTPADDING", (0, 0), (-1, -1), 4)])),
        _plain_grid(st, [
            [("Size / ISO / Type", txt(size or None), "value_b"), ("Full / Empty", "FULL", "value_b"),
             ("Seal (SI)", txt(si_seal), "value_b")],
            [("Seal at gate-in", gate_seal_html), ("Cargo gross (kg)", fmt_kg(item["cargo_gross"])),
             ("Tare (kg)", fmt_kg(c.get("tare_weight_kg")))],
            [("VGM (kg) · Step 3", fmt_kg(vgm) if vgm is not None else
              "<font color='#9C2F23'><b>NOT DECLARED</b></font>", "value_b"), None, None],
        ], [half * 0.36, half * 0.30, half * 0.34]),
    ], half)
    story += [side_by_side([terminal], [container]), Spacer(1, 2.6 * mm)]

    story += [Paragraph(f"STATUS TIMELINE &nbsp;<font name='{FONT}' size='7' color='#5B6B82'>9 trạng thái riêng biệt — "
                        "mỗi trạng thái chỉ đổi khi được xác nhận riêng, kèm nguồn và người xác nhận</font>",
                        st["subhead"]), Spacer(1, 1.5), _timeline(st, item), Spacer(1, 2.6 * mm)]

    lane = rec.get("customs_lane")
    lane_html = (f"<font color='{LANE_COLOURS[lane]}'><b>{escape(G.CUSTOMS_LANES[lane][0].upper())}</b></font>"
                 if lane in G.CUSTOMS_LANES else DASH)
    decl = rec.get("customs_declaration_no")
    decl_html = txt(decl) + (f"<br/><font size='6.4' color='#9C2F23'>not 12 digits — check</font>"
                             if G.customs_number_problem(decl) else "")
    customs = _block(st, "Customs", "Hải quan", [_plain_grid(st, [
        [("Declaration no.", decl_html, "value_b"), ("Declaration date", fmt_date(rec.get("customs_declaration_date")))],
        [("Customs office", txt(rec.get("customs_office"))), ("Lane", lane_html)],
        [("Clearance date", fmt_date(rec.get("customs_clearance_date"))),
         ("Supervision", txt(rec.get("customs_supervision_status")))],
    ], [half * 0.5, half * 0.5])], half)
    tier = " / ".join(f"{k} {rec[f'yard_{k.lower()}']}" for k in ("Block", "Bay", "Row", "Tier") if rec.get(f"yard_{k.lower()}"))
    yard = _block(st, "Yard", "Vị trí bãi", [_plain_grid(st, [
        [("Yard location", txt(rec.get("yard_location")), "value_b")],
        [("Block / Bay / Row / Tier", txt(tier or None))],
        [("Container condition", txt(rec.get("container_condition")))],
    ], [half])], half)
    story += [side_by_side([customs], [yard]), Spacer(1, 2.6 * mm)]

    transport = _block(st, "Transport", "Phương tiện", [_plain_grid(st, [
        [("Truck no.", txt(rec.get("truck_number")), "value_b"), ("Chassis no.", txt(rec.get("chassis_number")))],
        [("Vehicle arrival", fmt_datetime(rec.get("vehicle_arrival"))),
         ("Container arrival", fmt_datetime(rec.get("container_arrival")))],
    ], [half * 0.5, half * 0.5])], half)
    export = _block(st, "Export registration & loading", "Đăng ký xuất & xếp tàu", [_plain_grid(st, [
        [("Registration status (timeline)", txt(G.export_registration_text(item))),
         ("Vessel loading status", txt(rec.get("vessel_loading_status")))],
        [("Loading confirmation ref.", txt(rec.get("loading_confirmation_ref"))),
         ("Actual loading", fmt_datetime(rec.get("actual_loading_datetime")))],
    ], [half * 0.5, half * 0.5])], half)
    story += [side_by_side([transport], [export]), Spacer(1, 2.6 * mm)]

    ev_rows = [[Paragraph(str(n), st["cell"]), Paragraph(txt(x["file_name"]), st["cell"]),
                Paragraph(txt(x.get("description")), st["cell"]),
                Paragraph(txt(" · ".join(v for v in (x.get("uploaded_by"), fmt_datetime(x["uploaded_at"][:16])) if v)),
                          st["cell"])] for n, x in enumerate(item["evidence"], start=1)]
    if not ev_rows:
        ev_rows = [[Paragraph("<i>No evidence file uploaded — statuses are manual entries only.</i>", st["cell"]),
                    "", "", ""]]
    ev = Table([[Paragraph(h, st["th"]) for h in ("#", "FILE", "DESCRIPTION", "UPLOADED BY / AT")]] + ev_rows,
               colWidths=[W * w for w in (0.05, 0.33, 0.37, 0.25)], repeatRows=1)
    ev.setStyle(TableStyle(TABLE_FONT + [
        ("BACKGROUND", (0, 0), (-1, 0), NAVY), ("BOX", (0, 0), (-1, -1), 0.6, GRID),
        ("LINEBELOW", (0, 0), (-1, -1), 0.4, GRID), ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 4), ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5),
    ] + ([("SPAN", (0, 1), (-1, 1))] if not item["evidence"] else [])))
    story += [Paragraph(f"EVIDENCE &nbsp;<font name='{FONT}' size='7' color='#5B6B82'>File bằng chứng (xác nhận của "
                        "cảng, ảnh)</font>", st["subhead"]), Spacer(1, 1.5), ev, Spacer(1, 2.6 * mm)]

    warnings = G.checks(ship, item)
    if warnings:
        box = Table([[[Paragraph("CHECKS · CẦN LƯU Ý", ParagraphStyle("ck", parent=st["note_b"], textColor=RED))]
                      + [Paragraph("– " + escape(w), st["note"]) for w in warnings]]], colWidths=[W])
        box.setStyle(TableStyle(TABLE_FONT + [("BACKGROUND", (0, 0), (-1, -1), RED_BG), ("BOX", (0, 0), (-1, -1), 0.8, RED),
                                              ("LEFTPADDING", (0, 0), (-1, -1), 6), ("TOPPADDING", (0, 0), (-1, -1), 3),
                                              ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
        story += [box, Spacer(1, 2.6 * mm)]
    if rec.get("remarks"):
        story += [field_grid(st, [[("Remarks · Ghi chú", txt(rec["remarks"]))]], [W]), Spacer(1, 2.6 * mm)]
    story.append(note_box(st, label["kind"], f"DOCUMENT STATUS: {label['badge']}", label["note"],
                          fine=f"{APP_NAME} never generates port transaction, registration or EIR numbers and never "
                               "changes one status because another changed."))
    return story


def gatein_pdf_filename(ship: dict, items: list[dict], all_items: bool) -> str:
    part = "ALL" if all_items else safe_filename_part(items[0]["container"].get("container_number"), "CONTAINER")
    version = max(((i.get("record") or {}).get("doc_version") or 1) for i in items)
    return (f"{safe_filename_part(ship['shipment_id'], 'SHIPMENT')}_"
            f"{safe_filename_part(ship.get('booking_number'), 'NO-BOOKING')}_Export_Gate-in_{part}_v{version}.pdf")


def _items(shipment_id: str, container_ids: list[int] | None) -> tuple[dict, list[dict]]:
    overview = G.get_shipment_gateins(shipment_id)
    if not overview:
        raise G.GateInError([f"Không tìm thấy lô hàng {shipment_id}."])
    items = [i for i in overview["items"] if i["record"] or i["events"]]
    if container_ids is not None:
        items = [i for i in items if i["container"]["id"] in container_ids]
    if not items:
        raise G.GateInError(["Chưa có dữ liệu gate-in nào được lưu cho container đã chọn."])
    return overview["shipment"], items


def _render(ship: dict, items: list[dict], target) -> None:
    register_fonts()
    st = _styles()
    footer = [
        f"Shipment ID: {ship['shipment_id']}   ·   Booking No.: {ship.get('booking_number') or DASH}   ·   "
        f"Document version: v{max(((i.get('record') or {}).get('doc_version') or 1) for i in items)}",
        f"Export Gate-in · internal record / reference copy · {len(items)} container(s)"
        + (f" · {sample_text(ship)} DATA" if ship["is_sample"] else "")
        + f" · Exported: {datetime.now().strftime('%d %b %Y %H:%M').upper()}",
    ]
    doc = SimpleDocTemplate(
        target, pagesize=A4, leftMargin=MARGIN_X, rightMargin=MARGIN_X, topMargin=MARGIN_TOP, bottomMargin=MARGIN_BOTTOM,
        title=f"Export Gate-in — {ship['shipment_id']}", author=APP_NAME,
        subject=f"Export Gate-in & Loading Registration · {ship['shipment_id']}", creator=APP_NAME,
        initialFontName=FONT, initialFontSize=8)
    story = []
    for n, item in enumerate(items, start=1):
        if n > 1:
            story.append(PageBreak())
        story.append(KeepInFrame(W, doc.height - 12, _flatten(_page(st, ship, item, n, len(items))), mode="shrink"))
    decorate = _page_decorator("SAMPLE" if ship["is_sample"] else "INTERNAL", None)
    doc.build(story, onFirstPage=decorate, onLaterPages=decorate, canvasmaker=_numbered_canvas(footer))


def build_export_gatein_pdf_bytes(shipment_id: str, container_ids: list[int] | None = None) -> bytes:
    ship, items = _items(shipment_id, container_ids)
    buffer = io.BytesIO()
    _render(ship, items, buffer)
    return buffer.getvalue()


def generate_export_gatein_pdf(shipment_id: str, container_ids: list[int] | None = None,
                               output_path: str | Path | None = None) -> Path:
    """Create the Export Gate-in PDF (one page per container) and save it in the data folder.

    File: <data>/pdfs/<ShipmentID>/<ShipmentID>_<BookingNo>_Export_Gate-in_<ContainerNo|ALL>_v1.pdf
    """
    ship, items = _items(shipment_id, container_ids)
    if output_path is None:
        folder = settings.PDF_DIR / safe_filename_part(shipment_id, "SHIPMENT")
        folder.mkdir(parents=True, exist_ok=True)
        output_path = folder / gatein_pdf_filename(ship, items, all_items=container_ids is None)
    output_path = Path(output_path)
    _render(ship, items, str(output_path))
    G.record_pdf_export([i["container"]["id"] for i in items], str(output_path))
    from .library import register_generated      # Document Library keeps every version
    register_generated(shipment_id, "GATEIN", output_path)
    return output_path
