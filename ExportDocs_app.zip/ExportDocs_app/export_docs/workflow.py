"""Workflow: the real status of the 6 document steps per shipment, the shipment status, and the
dashboard figures built from it (REQUIREMENTS.md §3, §7).

Step statuses (everywhere): Not Started, In Progress, Completed, Needs Correction,
Waiting for External Confirmation.

Each step first gets its own status from its module (Step 1 Booking … Step 6 B/L — see each module's
step_status()). Then the Validation Center (validation.py) is applied: a step that has an error-level
mismatch, or a sync conflict waiting for the user's choice, is "Needs Correction".

A shipment is "Completed" only when all six steps are Completed AND every validation check is Valid /
Confirmed (required fields valid, confirmations with evidence) with no open conflict. The status is set
here, automatically, after every saved change — never by hand.
"""

from . import bl, bookings, eir, gatein, si, vgm
from . import shipments as S
from .database import transaction
from .services import DOCUMENT_STEPS

CONFLICT_STEP = {"BOOKING": 1, "EIR": 2, "VGM": 3, "SI": 4, "GATEIN": 5, "BL": 6}


def module_step_statuses(shipment_id: str) -> list[str]:
    """Six step statuses from the document modules only, in order 1 → 6."""
    return [
        bookings.step_status(bookings.get_booking_view(shipment_id)),
        eir.step_status(shipment_id),
        vgm.step_status(shipment_id),
        si.step_status(shipment_id),
        gatein.step_status(shipment_id),
        bl.step_status(shipment_id),
    ]


def shipment_step_statuses(shipment_id: str, result: dict | None = None) -> list[str]:
    """Six step statuses, in order 1 → 6, including the Validation Center's findings."""
    from . import validation
    statuses = module_step_statuses(shipment_id)
    result = result if result is not None else validation.run(shipment_id)
    if not result:
        return statuses
    flagged = {c["step"] for c in result["checks"] if c["state"] == validation.MISMATCH and c["severity"] == "error"}
    flagged |= {CONFLICT_STEP[c["doc_type"]] for c in result["conflicts"] if c["doc_type"] in CONFLICT_STEP}
    for step in flagged:
        if step and statuses[step - 1] != "Not Started":
            statuses[step - 1] = "Needs Correction"
    return statuses


def completed_steps(statuses: list[str]) -> int:
    return sum(s == "Completed" for s in statuses)


def refresh_shipment_status(shipment_id: str) -> str | None:
    """Set / remove "Completed" automatically. Returns the new status if it changed."""
    from . import validation
    from .history import log_event
    ship = S.get_shipment(shipment_id)
    if not ship or ship["status"] == "Cancelled":
        return None
    result = validation.run(shipment_id)
    statuses = shipment_step_statuses(shipment_id, result)
    complete = completed_steps(statuses) == len(DOCUMENT_STEPS) and result["complete_ok"]
    new = None
    if ship["status"] == "Not Started" and statuses[0] != "Not Started":
        new = "In Progress"                      # Step 1 (Booking) has been saved → the shipment has started
    elif complete and ship["status"] != "Completed":
        new = "Completed"
    elif not complete and ship["status"] == "Completed":
        new = "In Progress"
    if new:
        with transaction() as conn:
            conn.execute("UPDATE shipments SET status = ? WHERE id = ?", (new, ship["id"]))
        log_event(shipment_id, "SHIPMENT", "Shipment status", ship["status"], new, "STATUS",
                  {"Completed": "Hệ thống: đủ 6 bước hoàn thành và mọi kiểm tra hợp lệ / đã xác nhận"}.get(
                      new, "Hệ thống: đã lưu Bước 1 (Booking)" if ship["status"] == "Not Started"
                      else "Hệ thống: không còn đủ điều kiện Hoàn thành"), field_key="status", shipment_fk=ship["id"])
    return new


def dashboard_summary() -> dict:
    from . import validation
    rows = S.list_shipments()
    waiting_docs = []
    for r in rows:
        result = validation.run(r["shipment_id"])
        r["validation"] = result
        r["step_statuses"] = shipment_step_statuses(r["shipment_id"], result)
    active = [r for r in rows if r["status"] in S.ACTIVE_STATUSES]
    for r in active:
        waiting_docs += [(r["shipment_id"], d) for d in validation.documents_waiting(r["shipment_id"])]
    alerts = S.deadline_alerts(rows)

    # per step: how many active shipments are in each status
    overview = []
    for i, step in enumerate(DOCUMENT_STEPS):
        counts = {}
        for r in active:
            status = r["step_statuses"][i]
            counts[status] = counts.get(status, 0) + 1
        overview.append({"step": step, "counts": counts})

    return {
        "total_shipments": len(rows),
        "sample_shipments": sum(1 for r in rows if r["is_sample"]),
        "total_documents": bookings.count_bookings() + eir.count_eirs() + vgm.count_vgms() + si.count_sis()
                           + gatein.count_records() + bl.count_bls(),
        "in_progress": len(active),
        "completed": sum(r["status"] == "Completed" for r in rows),
        "missing_documents": sum(completed_steps(r["step_statuses"]) < 6 for r in active),
        "mismatched": [r["shipment_id"] for r in active if r["validation"]["has_mismatch"]],
        "waiting_documents": waiting_docs,
        "deadline_alerts": alerts,
        "deadline_shipments": len({a["shipment_id"] for a in alerts}),
        "recent": rows[:10],
        "step_overview": overview,
    }
