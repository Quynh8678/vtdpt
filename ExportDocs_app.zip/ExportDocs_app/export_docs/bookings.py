"""Step 1 — Booking Confirmation business logic (REQUIREMENTS.md §5 Step 1, §6, §7).

Data sync rule: the booking form SHOWS shipment-level fields (booking number,
carrier, routing, vessel/voyage, dates, cut-offs, empty pick-up) but they are
stored once, in `shipments`. Editing them here updates the central record, so
every other step sees the same value. Only booking-specific fields are stored
in the `bookings` table.

Honesty rules:
- A booking is shown as carrier-confirmed only when status is Confirmed/Amended
  AND a carrier confirmation source + reference were recorded.
  Otherwise the document is labelled BOOKING DRAFT or INTERNAL BOOKING RECORD.
- Saving a draft is always allowed; missing data only produces warnings.
"""

from dataclasses import dataclass, field
from datetime import datetime

from . import shipments as S
from .database import reading, transaction
from .tracking import tracked

BOOKING_STATUSES = {
    "Booking Request": "Yêu cầu đặt chỗ",
    "Booking Confirmed": "Đã được xác nhận",
    "Booking Amended": "Đã sửa đổi",
    "Booking Cancelled": "Đã hủy",
}
CONFIRMATION_SOURCES = {
    "NONE": "Chưa có xác nhận từ hãng tàu",
    "CARRIER_DOCUMENT": "Văn bản / PDF Booking Confirmation của hãng tàu",
    "CARRIER_EMAIL": "Email xác nhận của hãng tàu",
    "CARRIER_PORTAL": "Hệ thống eBooking / portal của hãng tàu",
}
CONFIRMATION_SOURCES_EN = {
    "NONE": "No carrier confirmation",
    "CARRIER_DOCUMENT": "Carrier document",
    "CARRIER_EMAIL": "Carrier e-mail",
    "CARRIER_PORTAL": "Carrier eBooking portal",
}

# Booking-only fields (stored in `bookings`)
BOOKING_FIELDS = (
    "booking_status", "booking_date", "confirmation_date", "customer_reference",
    "commodity", "special_cargo_requirements", "carrier_instructions", "remarks",
    "confirmation_source", "confirmation_reference", "confirmed_by",
)
BOOKING_DATE_FIELDS = ("booking_date", "confirmation_date")

# Shipment-level fields shown and edited in Step 1 (stored in `shipments`)
SHARED_FIELDS = (
    "booking_number", "carrier_name",
    "place_of_receipt", "port_of_loading", "transshipment_port", "port_of_discharge", "place_of_delivery",
    "vessel_name", "voyage_number", "etd", "eta",
    "cy_cutoff", "si_cutoff", "vgm_cutoff",
    "empty_pickup_depot", "empty_pickup_date",
)

# Needed for Step 1 to be "Completed" (drafts can still be saved without them)
REQUIRED = (
    ("booking_number", "Booking Number"),
    ("booking_date", "Booking date (ngày đặt chỗ)"),
    ("carrier_name", "Carrier (hãng tàu)"),
    ("shipper", "Shipper"),
    ("port_of_loading", "POL"),
    ("port_of_discharge", "POD"),
    ("vessel_name", "Vessel"),
    ("voyage_number", "Voyage"),
    ("etd", "ETD"),
    ("containers", "Container (số lượng & loại)"),
    ("commodity", "Commodity (tên hàng)"),
    ("cy_cutoff", "CY cut-off"),
    ("si_cutoff", "SI cut-off"),
    ("vgm_cutoff", "VGM cut-off"),
    ("empty_pickup_depot", "Depot lấy container rỗng"),
)
REQUIRED_KEYS = {key for key, _ in REQUIRED}


class BookingError(S.ShipmentError):
    pass


@dataclass
class BookingSaveResult:
    shipment_id: str
    created: bool
    warnings: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------
def _empty_booking() -> dict:
    data = {k: None for k in BOOKING_FIELDS}
    data.update(booking_status="Booking Request", confirmation_source="NONE", doc_version=1,
                last_pdf_path=None, last_pdf_at=None, created_at=None, updated_at=None)
    return data


def get_booking_view(shipment_id: str) -> dict | None:
    """Everything Step 1 needs: the central shipment data + the booking record.

    Returns {"shipment": ..., "booking": ..., "exists": bool} or None.
    """
    ship = S.get_shipment(shipment_id)
    if not ship:
        return None
    with reading() as conn:
        row = conn.execute("SELECT * FROM bookings WHERE shipment_fk = ?", (ship["id"],)).fetchone()
    booking = dict(row) if row else _empty_booking()
    return {"shipment": ship, "booking": booking, "exists": row is not None}


def commodity_text(view: dict) -> str | None:
    """Booking commodity; if empty, the commodity names from the cargo lines."""
    if view["booking"].get("commodity"):
        return view["booking"]["commodity"]
    names = [c["commodity"] for c in view["shipment"]["cargo"] if c.get("commodity")]
    return "; ".join(dict.fromkeys(names)) or None


def equipment_summary(containers: list[dict]) -> list[dict]:
    """Group containers by size / ISO type / type.

    → [{"qty": 2, "size": "40'", "iso": "45G1", "type": "High Cube", "label": "40' 45G1 High Cube"}, ...]
    """
    groups: dict[tuple, int] = {}
    for c in containers:
        key = (f"{c['container_size']}'" if c.get("container_size") else None,
               c.get("iso_type_code"), c.get("container_type"))
        groups[key] = groups.get(key, 0) + 1
    return [{"qty": n, "size": size, "iso": iso, "type": ctype,
             "label": " ".join(x for x in (size or "Size TBA", iso, ctype) if x)}
            for (size, iso, ctype), n in groups.items()]


def assigned_containers(containers: list[dict]) -> list[dict]:
    """Containers that already have a number (normally assigned at Step 2 — EIR)."""
    return [c for c in containers if c.get("container_number")]


def missing_required(view: dict) -> list[str]:
    ship, booking = view["shipment"], view["booking"]
    missing = []
    for key, label in REQUIRED:
        if key == "shipper":
            ok = bool((ship["parties"].get("SHIPPER") or {}).get("party_name"))
        elif key == "containers":
            ok = bool(ship["containers"]) and all(c.get("container_size") for c in ship["containers"])
        elif key == "commodity":
            ok = bool(commodity_text(view))
        elif key in BOOKING_FIELDS:
            ok = bool(booking.get(key))
        else:
            ok = bool(ship.get(key))
        if not ok:
            missing.append(label)
    return missing


def has_carrier_evidence(booking: dict) -> bool:
    return (booking.get("confirmation_source") or "NONE") != "NONE" and bool(booking.get("confirmation_reference"))


def changed_since_confirmation(view: dict) -> bool:
    """The booking says something else than when the carrier's confirmation was recorded (Phase 5)."""
    if not view.get("exists"):
        return False
    from . import history
    return history.changed_since_lock(view["shipment"]["shipment_id"], "BOOKING")


def document_label(view: dict) -> dict:
    """How the document must be labelled (title, badge, colour, legal note)."""
    b = view["booking"]
    status = b.get("booking_status") or "Booking Request"
    sample = bool(view["shipment"]["is_sample"])
    confirmed = status in ("Booking Confirmed", "Booking Amended") and has_carrier_evidence(b)
    if status == "Booking Cancelled":
        label = dict(kind="cancelled", title="BOOKING CANCELLATION RECORD", badge="BOOKING CANCELLED",
                     note="This booking is recorded as CANCELLED. Internal record only — not issued by the carrier.")
    elif confirmed and changed_since_confirmation(view):
        label = dict(kind="internal", title="BOOKING — CHANGED AFTER CARRIER CONFIRMATION",
                     badge="CHANGED SINCE CONFIRMATION",
                     note=(f"The data changed after the carrier's confirmation (ref. {b['confirmation_reference']}) "
                           "was recorded. INTERNAL RECORD only — ask the carrier to confirm the amendment, then record "
                           "it (status Booking Amended + the new confirmation reference)."))
    elif confirmed:
        source = CONFIRMATION_SOURCES_EN.get(b["confirmation_source"], b["confirmation_source"])
        amended = status == "Booking Amended"
        label = dict(
            kind="confirmed",
            title="BOOKING CONFIRMATION" + (" — AMENDED" if amended else ""),
            badge="CARRIER CONFIRMED" + (" · AMENDED" if amended else ""),
            note=(f"Prepared from the carrier's confirmation ({source}, ref. {b['confirmation_reference']}). "
                  "Copy generated by EXPORT DOCS MANAGEMENT — not issued by the carrier; "
                  "the carrier's original prevails."))
    elif status in ("Booking Confirmed", "Booking Amended"):
        label = dict(kind="internal", title="INTERNAL BOOKING RECORD", badge="INTERNAL BOOKING RECORD",
                     note="Marked as confirmed, but no carrier confirmation source/reference is recorded. "
                          "INTERNAL RECORD only — not the carrier's booking confirmation; space is not confirmed.")
    else:
        label = dict(kind="draft", title="BOOKING DRAFT", badge="BOOKING DRAFT",
                     note="Booking request prepared internally — NOT confirmed by the carrier. Space, vessel, "
                          "schedule and cut-off times are not confirmed.")
    label["sample"] = sample
    label["sample_text"] = S.sample_text(view["shipment"])   # 'SAMPLE / DEMO', 'SAMPLE / TEST' or None
    label["status"] = status
    return label


def step_status(view: dict | None) -> str:
    """Workflow status of Step 1 (REQUIREMENTS.md §7)."""
    if not view or not view["exists"]:
        return "Not Started"
    b = view["booking"]
    if b["booking_status"] == "Booking Cancelled":
        return "Needs Correction"
    if missing_required(view):
        return "In Progress"
    if b["booking_status"] in ("Booking Confirmed", "Booking Amended") and has_carrier_evidence(b):
        return "Needs Correction" if changed_since_confirmation(view) else "Completed"
    return "Waiting for External Confirmation"


def count_bookings() -> int:
    """Number of saved Booking Confirmation documents."""
    with reading() as conn:
        return conn.execute("SELECT COUNT(*) FROM bookings").fetchone()[0]


# ---------------------------------------------------------------------------
# Save
# ---------------------------------------------------------------------------
@tracked("BOOKING")
def save_booking(shipment_id: str, shared: dict, booking: dict) -> BookingSaveResult:
    """Save Step 1. Shared fields → `shipments`; booking-only fields → `bookings`.

    Raises BookingError only for real data errors (e.g. a date that cannot be read).
    """
    errors, warnings = [], []
    shared_clean = S.clean_header_values(shared, SHARED_FIELDS, errors)
    b = {k: S.clean_text(booking.get(k)) for k in BOOKING_FIELDS}
    for key in BOOKING_DATE_FIELDS:
        b[key] = S.parse_when(booking.get(key), False, key.replace("_", " ").capitalize(), errors)
    b["booking_status"] = b["booking_status"] or "Booking Request"
    b["confirmation_source"] = b["confirmation_source"] or "NONE"
    if b["booking_status"] not in BOOKING_STATUSES:
        errors.append(f"Booking status “{b['booking_status']}” không hợp lệ.")
    if b["confirmation_source"] not in CONFIRMATION_SOURCES:
        errors.append("Nguồn xác nhận không hợp lệ.")
    if errors:
        raise BookingError(errors)

    stamp = S.now_text()
    with transaction() as conn:
        fk = S.get_shipment_fk(conn, shipment_id)
        sets = ", ".join(f"{k} = ?" for k in SHARED_FIELDS)
        conn.execute(f"UPDATE shipments SET {sets}, updated_at = ? WHERE id = ?",
                     [*(shared_clean[k] for k in SHARED_FIELDS), stamp, fk])
        exists = conn.execute("SELECT id FROM bookings WHERE shipment_fk = ?", (fk,)).fetchone()
        if exists:
            sets = ", ".join(f"{k} = ?" for k in BOOKING_FIELDS)
            conn.execute(f"UPDATE bookings SET {sets}, updated_at = ? WHERE shipment_fk = ?",
                         [*(b[k] for k in BOOKING_FIELDS), stamp, fk])
        else:
            cols = ["shipment_fk", *BOOKING_FIELDS, "created_at", "updated_at"]
            conn.execute(f"INSERT INTO bookings ({', '.join(cols)}) VALUES ({', '.join('?' * len(cols))})",
                         [fk, *(b[k] for k in BOOKING_FIELDS), stamp, stamp])
        warnings.extend(S.booking_number_duplicates(conn, shared_clean.get("booking_number"), fk))

    view = get_booking_view(shipment_id)
    missing = missing_required(view)
    if missing:
        warnings.insert(0, "Còn thiếu thông tin bắt buộc: " + ", ".join(missing) + ".")
    warnings.extend(S.schedule_warnings(view["shipment"]))
    status = b["booking_status"]
    if status in ("Booking Confirmed", "Booking Amended") and not has_carrier_evidence(b):
        warnings.append("Trạng thái là đã xác nhận nhưng chưa ghi nguồn + số tham chiếu xác nhận của hãng tàu — "
                        "PDF sẽ được đánh dấu INTERNAL BOOKING RECORD.")
    if b["confirmation_source"] != "NONE" and not b["confirmation_reference"]:
        warnings.append("Đã chọn nguồn xác nhận nhưng chưa nhập số tham chiếu xác nhận.")
    if status in ("Booking Confirmed", "Booking Amended") and not b["confirmation_date"]:
        warnings.append("Chưa có ngày xác nhận (Confirmation date).")
    return BookingSaveResult(shipment_id=shipment_id, created=not exists, warnings=warnings)


def record_pdf_export(shipment_id: str, path: str) -> None:
    with transaction() as conn:
        fk = S.get_shipment_fk(conn, shipment_id)
        conn.execute("UPDATE bookings SET last_pdf_path = ?, last_pdf_at = ? WHERE shipment_fk = ?",
                     (path, datetime.now().strftime("%Y-%m-%d %H:%M"), fk))
