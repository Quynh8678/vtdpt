"""Phase 6 — backup and restore (REQUIREMENTS.md §13 "Backup and restore supported").

create_backup()  → <data>/backups/ExportDocs_backup_<time>.zip with
                   database/export_docs.sqlite3 (a consistent copy made with SQLite's backup API),
                   uploads/, pdfs/, exports/ and manifest.json.
restore_backup(zip, target_folder)
                 → restores into a NEW / EMPTY folder (the safe way: check it, then point the app at it with
                   EXPORT_DOCS_DATA_DIR), or into the current data folder (the current data is backed up first).
File paths stored in the database are moved to the restored folder.
"""

import json
import shutil
import sqlite3
import tempfile
import zipfile
from contextlib import closing
from datetime import datetime
from pathlib import Path

from . import APP_NAME, __version__, drive_sync, settings
from . import shipments as S

FOLDERS = ("uploads", "pdfs", "exports")
DB_NAME = "database/export_docs.sqlite3"


class BackupError(S.ShipmentError):
    pass


def _copy_db(source: Path, target: Path) -> None:
    src = sqlite3.connect(source)
    dst = sqlite3.connect(target)
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()


def create_backup(target_dir: Path | None = None) -> Path:
    """Zip the database and all files. Returns the backup file."""
    from .history import current_user, log_event
    drive_sync.flush()                                   # Colab: the Drive copy is up to date before the backup
    target_dir = Path(target_dir or settings.BACKUP_DIR)
    target_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now()
    path = target_dir / f"ExportDocs_backup_{stamp:%Y%m%d-%H%M%S}.zip"
    n = 2
    while path.exists():                 # two backups in the same second (e.g. the safety backup before a restore)
        path = target_dir / f"ExportDocs_backup_{stamp:%Y%m%d-%H%M%S}-{n}.zip"
        n += 1
    with tempfile.TemporaryDirectory() as tmp:
        db_copy = Path(tmp) / "export_docs.sqlite3"
        _copy_db(settings.DATABASE_PATH, db_copy)
        with closing(sqlite3.connect(db_copy)) as conn:
            shipments = conn.execute("SELECT COUNT(*) FROM shipments").fetchone()[0]
        files = 0
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
            z.write(db_copy, DB_NAME)
            for folder in FOLDERS:
                base = settings.DATA_DIR / folder
                for f in sorted(base.rglob("*")) if base.exists() else []:
                    if f.is_file():
                        z.write(f, f"{folder}/{f.relative_to(base).as_posix()}")
                        files += 1
            z.writestr("manifest.json", json.dumps({
                "app": APP_NAME, "format": "export-docs-backup/1", "created_at": stamp.isoformat(timespec="seconds"),
                "created_by": current_user(), "data_dir": str(settings.DATA_DIR), "shipments": shipments,
                "app_version": __version__,
                "files": files}, ensure_ascii=False, indent=2))
    log_event("—", "SHIPMENT", "Sao lưu dữ liệu", None, f"{path.name} · {shipments} lô hàng · {files} file", "EXPORT",
              "Backup toàn bộ cơ sở dữ liệu và file", doc_label="Cài đặt · Sao lưu", field_key="backup")
    return path


def read_manifest(zip_path: str | Path) -> dict:
    try:
        with zipfile.ZipFile(zip_path) as z:
            names = set(z.namelist())
            if "manifest.json" not in names or DB_NAME not in names:
                raise BackupError(["File này không phải bản sao lưu của EXPORT DOCS MANAGEMENT (thiếu manifest / database)."])
            return json.loads(z.read("manifest.json"))
    except zipfile.BadZipFile:
        raise BackupError(["File không phải ZIP hợp lệ."]) from None


def _repoint_paths(db_path: Path, old_dir: str, new_dir: Path) -> int:
    """Stored absolute file paths (uploads, PDFs) → the restored data folder."""
    changed = 0
    old = str(Path(old_dir))
    conn = sqlite3.connect(db_path)
    try:
        tables = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type = 'table'")]
        for table in tables:
            cols = [r[1] for r in conn.execute(f"PRAGMA table_info({table})") if r[1] in ("file_path", "last_pdf_path")]
            for col in cols:
                for row_id, value in conn.execute(f"SELECT rowid, {col} FROM {table} WHERE {col} LIKE ?", (old + "%",)).fetchall():
                    conn.execute(f"UPDATE {table} SET {col} = ? WHERE rowid = ?",
                                 (str(new_dir) + value[len(old):], row_id))
                    changed += 1
        conn.commit()
    finally:
        conn.close()
    return changed


def restore_backup(zip_path: str | Path, target_dir: str | Path | None = None) -> dict:
    """Restore a backup.

    target_dir = a new or EMPTY folder → everything is restored there (nothing else is touched).
    target_dir = None → the CURRENT data folder is replaced; a backup of the current data is made first.
    """
    from .history import log_event
    manifest = read_manifest(zip_path)
    replace_current = target_dir is None
    target = settings.DATA_DIR if replace_current else Path(target_dir).expanduser().resolve()
    if not replace_current:
        if target.resolve() == settings.DATA_DIR.resolve():
            raise BackupError(["Đây là thư mục dữ liệu đang dùng — chọn “Thay dữ liệu hiện tại” nếu muốn ghi đè."])
        if target.exists() and any(target.iterdir()):
            raise BackupError([f"Thư mục {target} không trống — chọn một thư mục mới hoặc trống."])
    safety = create_backup() if replace_current else None
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        with zipfile.ZipFile(zip_path) as z:
            for name in z.namelist():
                if name.startswith("/") or ".." in Path(name).parts:
                    raise BackupError(["Bản sao lưu có đường dẫn không hợp lệ."])
            z.extractall(tmp)
        restored_db = tmp / DB_NAME
        repointed = _repoint_paths(restored_db, manifest.get("data_dir") or "", target)
        with closing(sqlite3.connect(restored_db)) as conn:
            if conn.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise BackupError(["Cơ sở dữ liệu trong bản sao lưu bị lỗi."])
            shipments = conn.execute("SELECT COUNT(*) FROM shipments").fetchone()[0]
        (target / "database").mkdir(parents=True, exist_ok=True)
        for folder in FOLDERS:
            dest = target / folder
            if replace_current and dest.exists():
                shutil.rmtree(dest)
            if (tmp / folder).exists():
                shutil.copytree(tmp / folder, dest, dirs_exist_ok=True)
            else:
                dest.mkdir(parents=True, exist_ok=True)
        (target / "backups").mkdir(parents=True, exist_ok=True)
        # SQLite backup API: safe while the app is running. The current data → the file the app works on
        # (in Colab the local working copy, copied to Drive right after).
        _copy_db(restored_db, settings.DATABASE_PATH if replace_current else target / DB_NAME)
    result = {"target": str(target), "shipments": shipments, "files": manifest.get("files"),
              "backup_of_current": str(safety) if safety else None, "paths_updated": repointed,
              "created_at": manifest.get("created_at")}
    if replace_current:
        drive_sync.after_commit()
        log_event("—", "SHIPMENT", "Khôi phục dữ liệu", None, f"{Path(zip_path).name} → thư mục hiện tại", "RESTORE",
                  f"Bản sao lưu ngày {manifest.get('created_at')}; dữ liệu cũ đã được sao lưu: {safety.name}",
                  doc_label="Cài đặt · Khôi phục", field_key="restore")
    return result
