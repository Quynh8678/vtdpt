"""One SAMPLE/DEMO shipment for testing (REQUIREMENTS.md §14: demo data must be
clearly marked and never used as real data).

All names, numbers and the carrier are invented. It is created only once:
if you delete it, it does not come back on the next start.
"""

from datetime import date, timedelta

from . import database
from .shipments import SAMPLE_DEMO, iso6346_check_digit, save_shipment

_META_KEY = "sample_shipment_created"


def _demo_container_number(serial: str) -> str:
    """A container number with a valid ISO 6346 check digit (owner code DEMU = demo)."""
    first_ten = "DEMU" + serial
    return first_ten + str(iso6346_check_digit(first_ten))


def build_sample_shipment() -> dict:
    today = date.today()
    d = lambda days: (today + timedelta(days=days)).isoformat()
    header = {
        "status": "In Progress",
        "transport_mode": "Sea — FCL (nguyên container)",
        "export_type": "Xuất kinh doanh (Commercial export)",
        "person_in_charge": "Nhân viên mẫu (DEMO)",
        "customer_name": "CÔNG TY TNHH XUẤT KHẨU MẪU ABC (SAMPLE)",
        "contract_reference": "DEMO-CONTRACT-2026-001",
        "notes": "DỮ LIỆU MẪU (SAMPLE/DEMO) — chỉ dùng để thử, không dùng cho lô hàng thật.",
        "carrier_name": "DEMO CARRIER (SAMPLE)",
        "booking_number": "DEMOBKG0001",
        "vessel_name": "SAMPLE VESSEL",
        "voyage_number": "DM001E",
        # port-to-port B/L (CY/CY, merchant haulage): receipt = POL, delivery = POD
        "place_of_receipt": "Cat Lai, Ho Chi Minh City (VNCLI)",
        "port_of_loading": "Cat Lai, Ho Chi Minh City (VNCLI)",
        "port_of_discharge": "Los Angeles, CA (USLAX)",
        "transshipment_port": "Singapore (SGSIN)",
        "place_of_delivery": "Los Angeles, CA (USLAX)",
        "etd": d(7),
        "eta": d(30),
        "cy_cutoff": f"{d(5)} 12:00",
        "si_cutoff": f"{d(3)} 17:00",
        "vgm_cutoff": f"{d(2)} 17:00",
        "empty_pickup_depot": "DEMO DEPOT — Thủ Đức (SAMPLE)",
        "empty_pickup_date": d(1),
        "container_return_depot": "Cat Lai Terminal (SAMPLE)",
    }
    parties = {
        "SHIPPER": {
            "party_name": "CÔNG TY TNHH XUẤT KHẨU MẪU ABC (SAMPLE)",
            "address": "Số 1 Đường Mẫu, Phường Bến Nghé, Quận 1, TP. Hồ Chí Minh",
            "country": "Vietnam", "tax_id": "0000000000 (DEMO)",
            "email": "export@sample-abc.example", "phone": "+84 28 0000 0000",
        },
        "CONSIGNEE": {
            "party_name": "SAMPLE IMPORTS LLC (DEMO)",
            "address": "100 Example Street, Los Angeles, CA 90001",
            "country": "United States", "email": "import@sample-imports.example",
            "phone": "+1 213 000 0000",
        },
        "NOTIFY_PARTY": {
            "party_name": "DEMO CUSTOMS BROKER INC. (SAMPLE)",
            "address": "200 Sample Avenue, Long Beach, CA 90802",
            "country": "United States", "email": "notify@demo-broker.example",
        },
        "BOOKING_PARTY": {
            "party_name": "DEMO LOGISTICS CO., LTD. (SAMPLE)",
            "address": "Số 2 Đường Mẫu, Quận 4, TP. Hồ Chí Minh", "country": "Vietnam",
            "tax_id": "0000000001 (DEMO)", "email": "booking@demo-logistics.example",
        },
        "FORWARDER": {
            "party_name": "DEMO LOGISTICS CO., LTD. (SAMPLE)",
            "address": "Số 2 Đường Mẫu, Quận 4, TP. Hồ Chí Minh", "country": "Vietnam",
            "tax_id": "0000000001 (DEMO)", "email": "ops@demo-logistics.example",
        },
        "FREIGHT_PAYER": {
            "party_name": "CÔNG TY TNHH XUẤT KHẨU MẪU ABC (SAMPLE)", "country": "Vietnam",
            "tax_id": "0000000000 (DEMO)",
        },
    }
    cargo = [
        {"commodity": "Hạt điều nhân WW320", "cargo_description": "VIETNAMESE CASHEW KERNELS WW320",
         "hs_code": "080132", "quantity": 17690.4, "quantity_unit": "KGM", "package_count": 780,
         "package_type": "CARTONS", "gross_weight_kg": 18500, "net_weight_kg": 17690.4,
         "volume_cbm": 60.5, "marks_and_numbers": "SAMPLE ABC / WW320 / LOS ANGELES",
         "storage_conditions": "Khô ráo, thoáng mát", "dangerous_goods_info": None},
        {"commodity": "Hạt điều nhân WW240", "cargo_description": "VIETNAMESE CASHEW KERNELS WW240",
         "hs_code": "080132", "quantity": 17236.8, "quantity_unit": "KGM", "package_count": 760,
         "package_type": "CARTONS", "gross_weight_kg": 17950, "net_weight_kg": 17236.8,
         "volume_cbm": 58.9, "marks_and_numbers": "SAMPLE ABC / WW240 / LOS ANGELES",
         "storage_conditions": "Khô ráo, thoáng mát", "dangerous_goods_info": None},
    ]
    containers = [
        {"container_number": _demo_container_number("123456"), "container_size": "40",
         "iso_type_code": "45G1", "container_type": "High Cube", "load_status": "Full",
         "tare_weight_kg": 3900, "cargo_weight_kg": 18500, "gross_weight_kg": 22400, "max_gross_kg": 32500,
         "seal_number": "DEMOSEAL001", "truck_number": "51C-000.01 (DEMO)",
         "chassis_number": "51R-000.01 (DEMO)", "notes": "SAMPLE"},
        {"container_number": _demo_container_number("654321"), "container_size": "40",
         "iso_type_code": "45G1", "container_type": "High Cube", "load_status": "Full",
         "tare_weight_kg": 3880, "cargo_weight_kg": 17950, "gross_weight_kg": 21830, "max_gross_kg": 32500,
         "seal_number": "DEMOSEAL002", "truck_number": "51C-000.02 (DEMO)",
         "chassis_number": "51R-000.02 (DEMO)", "notes": "SAMPLE"},
    ]
    return {"header": header, "parties": parties, "cargo": cargo, "containers": containers}


def ensure_sample_shipment() -> str | None:
    """Create the sample shipment the first time the app starts. Returns its ID."""
    if database.get_meta(_META_KEY):
        return None
    data = build_sample_shipment()
    result = save_shipment(None, data["header"], data["parties"], data["cargo"],
                           data["containers"], is_sample=True, sample_label=SAMPLE_DEMO)
    database.set_meta(_META_KEY, result.shipment_id)
    return result.shipment_id


_BOOKING_META_KEY = "sample_booking_created"


def ensure_sample_booking() -> str | None:
    """Add Step 1 data to the sample shipment once (Phase 3).

    Status stays "Booking Request": no carrier confirmation is invented, even for
    sample data, so the PDF is labelled BOOKING DRAFT.
    """
    from .bookings import SHARED_FIELDS, get_booking_view, save_booking

    if database.get_meta(_BOOKING_META_KEY):
        return None
    sample_id = database.get_meta(_META_KEY)
    view = get_booking_view(sample_id) if sample_id else None
    if not view or view["exists"] or not view["shipment"]["is_sample"]:
        database.set_meta(_BOOKING_META_KEY, "skipped")
        return None
    today = date.today()
    shared = {k: view["shipment"].get(k) for k in SHARED_FIELDS}
    booking = {
        "booking_status": "Booking Request",
        "booking_date": (today - timedelta(days=1)).isoformat(),
        "customer_reference": "DEMO-PO-2026-0001 (SAMPLE)",
        "commodity": "Vietnamese cashew kernels (Hạt điều nhân) WW320 / WW240",
        "special_cargo_requirements": "Không có hàng nguy hiểm. Giữ khô ráo (keep dry). Không cần container lạnh.",
        "carrier_instructions": "Chưa có hướng dẫn từ hãng tàu (SAMPLE).",
        "remarks": "Đề nghị cấp 2 container 40' HC sạch, khô, không mùi. (SAMPLE)",
        "confirmation_source": "NONE",
    }
    save_booking(sample_id, shared, booking)
    database.set_meta(_BOOKING_META_KEY, sample_id)
    return sample_id


# ---------------------------------------------------------------------------
# Step 2 — demo EIRs (one per demo container)
# ---------------------------------------------------------------------------
_EIR_META_KEY = "sample_eirs_v1"
# Invented, clearly marked depot EIR number (the app never creates real depot numbers;
# this is demo data typed in as if the user had copied it from the depot's EIR).
DEMO_DEPOT_EIR_NUMBER = "SAMPLE-EIR-2611-04587"
# Left in the demo by earlier Step 2 testing (wrong check digit) — removed once.
_TEST_LEFTOVER_CONTAINERS = ("MSKU1234560",)


def build_sample_eirs(ship: dict) -> list[tuple[dict, dict]]:
    """(container values, EIR values) for the two demo containers, in order."""
    from .eir import CONDITION_AREAS

    day = ship.get("empty_pickup_date") or date.today().isoformat()
    all_ok = {f"cond_{k}": "OK" for k, _, _ in CONDITION_AREAS}
    base = build_sample_shipment()["containers"]
    keep = ("container_number", "container_size", "iso_type_code", "container_type", "truck_number",
            "chassis_number")
    first = ({**{k: base[0][k] for k in keep}, "eir_number": None},
             {**all_ok, "eir_datetime": f"{day} 08:30", "driver_info": "Tài xế mẫu 01 (DEMO)",
              "handover_info": "Nhận rỗng tại cổng 1, container sạch, khô, không mùi. (SAMPLE)",
              "damage_remarks": None})
    second = ({**{k: base[1][k] for k in keep}, "eir_number": DEMO_DEPOT_EIR_NUMBER},
              {**all_ok, "cond_left_side": "DAMAGED", "note_left_side": "Móp nhẹ (minor dent)",
               "eir_datetime": f"{day} 09:15", "driver_info": "Tài xế mẫu 02 (DEMO)",
               "handover_info": "Nhận rỗng tại cổng 1. (SAMPLE)",
               "damage_remarks": ("Minor dent left side panel (approx. 15 × 10 cm), no hole, no light leak — "
                                  "accepted by trucker. (SAMPLE)")})
    return [first, second]


def ensure_sample_eirs() -> str | None:
    """Give the demo shipment its two demo EIRs, once.

    On a database where Step 2 was tried on the demo shipment, this also removes the
    test leftovers (container MSKU1234560 and its EIR) and resets both demo EIRs to the
    realistic demo above. Only ever touches the SAMPLE demo shipment.
    """
    from . import eir as E
    from .shipments import get_shipment

    if database.get_meta(_EIR_META_KEY):
        return None
    sample_id = database.get_meta(_META_KEY)
    ship = get_shipment(sample_id) if sample_id else None
    if not ship or not ship["is_sample"]:
        database.set_meta(_EIR_META_KEY, "skipped")
        return None

    with database.transaction() as conn:
        for c in ship["containers"]:
            if c.get("container_number") in _TEST_LEFTOVER_CONTAINERS:
                conn.execute("DELETE FROM eir_records WHERE container_fk = ?", (c["id"],))
                conn.execute("DELETE FROM containers WHERE id = ?", (c["id"],))
        conn.execute("UPDATE eir_records SET last_pdf_path = NULL, last_pdf_at = NULL WHERE shipment_fk = ?",
                     (ship["id"],))

    ship = get_shipment(sample_id)
    by_number = {c["container_number"]: c for c in ship["containers"]}
    for cont, rec in build_sample_eirs(ship):
        c = by_number.get(cont["container_number"])
        if c:                                   # the user may have renamed/removed a demo container
            E.save_eir(sample_id, c["id"], cont, rec)
    database.set_meta(_EIR_META_KEY, sample_id)
    return sample_id


# ---------------------------------------------------------------------------
# Step 3 — demo VGMs (container 1: Method 2, container 2: Method 1)
# ---------------------------------------------------------------------------
_VGM_META_KEY = "sample_vgms_v1"
DEMO_MAX_GROSS_KG = 32500       # typical CSC max gross mass for a 40' high cube


def build_sample_vgms(ship: dict) -> list[tuple[str, dict, dict, str]]:
    """(container number, container values, VGM values, status) for the two demo containers.

    Container 1 — Method 2: cargo weight is GROSS (cartons included) → packaging 0,
    plus 26 pallets, dunnage and securing material + tare = 23,035 kg. Declared.
    Container 2 — Method 1: the packed container weighed at a (sample) weighbridge. Submitted
    (no acknowledgement — the demo never invents a carrier reference).
    """
    day =ship.get("empty_pickup_date") or date.today().isoformat()
    base = build_sample_shipment()["containers"]
    shipper = ((ship.get("parties") or {}).get("SHIPPER") or {}).get("party_name")
    signer = {"responsible_party": shipper, "signatory_name": "Nguyễn Văn Mẫu (SAMPLE)",
              "signatory_position": "Trưởng phòng Xuất khẩu / Export Manager", "declaration_date": day,
              "vgm_unit": "KGM"}
    first = (base[0]["container_number"],
             {"tare_weight_kg": base[0]["tare_weight_kg"], "max_gross_kg": DEMO_MAX_GROSS_KG},
             {**signer, "weighing_method": "METHOD_2", "cargo_basis": "GROSS",
              "cargo_weight_kg": 18500, "packaging_weight_kg": 0, "pallet_weight_kg": 572,
              "dunnage_weight_kg": 45, "securing_weight_kg": 18,
              "remarks": "26 pallets × 22 kg. Cargo weight is the gross weight of the cartons (packaging "
                         "included). (SAMPLE)"},
             "Declared")
    second = (base[1]["container_number"],
              {"tare_weight_kg": base[1]["tare_weight_kg"], "max_gross_kg": DEMO_MAX_GROSS_KG},
              {**signer, "weighing_method": "METHOD_1", "cargo_basis": "GROSS", "cargo_weight_kg": 17950,
               "weighed_vgm_kg": 21910, "weighing_datetime": f"{day} 15:40",
               "weighing_location": "Trạm cân DEMO — cổng B, Cảng Cát Lái (SAMPLE)",
               "weighing_provider": "Cân điện tử 80 tấn, Công ty Cân Mẫu DEMO — tem kiểm định DEMO-KD-0457 (SAMPLE)",
               "submission_date": day, "submission_channel": "Carrier web portal",
               "remarks": "Weighed after packing and sealing. (SAMPLE)"},
              "Submitted")
    return [first, second]


def ensure_sample_vgms() -> str | None:
    """Give the demo shipment its two demo VGMs, once. Only touches the SAMPLE demo shipment."""
    from . import vgm as V
    from .shipments import get_shipment

    if database.get_meta(_VGM_META_KEY):
        return None
    sample_id = database.get_meta(_META_KEY)
    ship = get_shipment(sample_id) if sample_id else None
    if not ship or not ship["is_sample"]:
        database.set_meta(_VGM_META_KEY, "skipped")
        return None
    by_number = {c["container_number"]: c for c in ship["containers"]}
    for number, cont, rec, status in build_sample_vgms(ship):
        c = by_number.get(number)
        if c and not V.find_item(V.get_shipment_vgms(sample_id), c["id"])["vgm"]:
            V.save_vgm(sample_id, c["id"], cont, rec, status)
    database.set_meta(_VGM_META_KEY, sample_id)
    return sample_id


# ---------------------------------------------------------------------------
# Step 4 — demo Shipping Instruction (cargo line 1 → container 1, line 2 → container 2)
# ---------------------------------------------------------------------------
_SI_META_KEY = "sample_si_v1"


def build_sample_si() -> dict:
    """SI-only fields of the demo SI (everything else comes from the central demo data)."""
    return {
        "bl_type": "ORIGINAL", "originals_count": 3, "copies_count": 3,
        "transport_doc_type": "Bill of Lading — port to port",
        "shipper_reference": "DEMO-PO-2026-0001 (SAMPLE)", "export_reference": "DEMO-INV-2026-001 (SAMPLE)",
        "document_receiver": "Phòng Xuất khẩu — CÔNG TY TNHH XUẤT KHẨU MẪU ABC (SAMPLE)",
        "service_type": "CY/CY", "freight_terms": "PREPAID", "payable_at": "Ho Chi Minh City, Vietnam",
        "freight_charges": "Ocean freight and THC at origin: as arranged (SAMPLE)",
        "remarks": "Cargo is not dangerous. Keep dry. (SAMPLE)",
    }


def ensure_sample_si() -> str | None:
    """Give the demo shipment its draft SI once. Only touches the SAMPLE demo shipment.

    It stays an SI Draft: the demo never pretends the SI was sent to the carrier.
    """
    from . import si as SI
    from .shipments import get_shipment

    if database.get_meta(_SI_META_KEY):
        return None
    sample_id = database.get_meta(_META_KEY)
    ship = get_shipment(sample_id) if sample_id else None
    if not ship or not ship["is_sample"] or SI.get_si_view(sample_id)["exists"]:
        database.set_meta(_SI_META_KEY, "skipped")
        return None
    allocations = [{"container_id": c["id"], "cargo_id": line["id"], "package_count": line.get("package_count"),
                    "gross_weight_kg": line.get("gross_weight_kg"), "volume_cbm": line.get("volume_cbm")}
                   for c, line in zip(ship["containers"], ship["cargo"])]
    SI.save_si(sample_id, build_sample_si(), allocations=allocations)
    database.set_meta(_SI_META_KEY, sample_id)
    return sample_id


# ---------------------------------------------------------------------------
# Step 5 — demo gate-in records
# ---------------------------------------------------------------------------
_GATEIN_META_KEY = "sample_gatein_v1"
DEMO_CONFIRMED_BY = "Nhân viên mẫu (DEMO)"


def build_sample_gateins(ship: dict) -> list[tuple[str, dict, list[tuple]]]:
    """(container number, gate-in values, [(status, action, time, note), …]) for the two demo containers.

    Container 1: Ready to Load — customs Green lane, cleared.
    Container 2: Gate-in Completed + Customs Pending — Yellow lane.
    All statuses are MANUAL entries (no evidence file is invented). Terminal transaction /
    registration / EIR numbers stay EMPTY: the demo never invents port references. The customs
    declaration numbers are obviously fake 12-digit sample numbers (999999…).
    """
    pickup = date.fromisoformat(ship.get("empty_pickup_date") or date.today().isoformat())
    day = (pickup + timedelta(days=1)).isoformat()
    base = build_sample_shipment()["containers"]
    common = {"terminal_name": "DEMO TERMINAL — Cảng Cát Lái (SAMPLE)", "terminal_area": "Bãi hàng xuất B (SAMPLE)",
              "customs_office": "Chi cục Hải quan mẫu — KV Cát Lái (SAMPLE)", "customs_declaration_date": day,
              "container_condition": "Sound — no visible damage"}
    first = (base[0]["container_number"], {
        **common, "gatein_datetime": f"{day} 09:10", "gatein_seal_number": base[0]["seal_number"],
        "truck_number": base[0]["truck_number"], "chassis_number": base[0]["chassis_number"],
        "vehicle_arrival": f"{day} 08:55", "container_arrival": f"{day} 09:10",
        "yard_location": "Block B2 (SAMPLE)", "yard_block": "B2", "yard_bay": "14", "yard_row": "03", "yard_tier": "2",
        "customs_declaration_no": "999999000001", "customs_lane": "GREEN", "customs_clearance_date": day,
        "customs_supervision_status": "Supervision confirmed (passed control area)",
        "export_registration_status": "Registered", "vessel_loading_status": "Loading planned",
        "remarks": "Green lane — cleared automatically. (SAMPLE)"},
        [("GATE_IN_COMPLETED", "SET", f"{day} 09:10", "Seen on the terminal's ePort screen (SAMPLE)"),
         ("CUSTOMS_CLEARED", "SET", f"{day} 10:05", "Green lane result on the customs system (SAMPLE)"),
         ("EXPORT_REGISTERED", "SET", f"{day} 10:40", EXPORT_REG_NOTE),
         ("READY_TO_LOAD", "SET", f"{day} 11:00", "ePort shows the container as ready to load (SAMPLE)")])
    second = (base[1]["container_number"], {
        **common, "gatein_datetime": f"{day} 09:40", "gatein_seal_number": base[1]["seal_number"],
        "truck_number": base[1]["truck_number"], "chassis_number": base[1]["chassis_number"],
        "vehicle_arrival": f"{day} 09:20", "container_arrival": f"{day} 09:40",
        "yard_location": "Block B2 (SAMPLE)", "yard_block": "B2", "yard_bay": "15", "yard_row": "01", "yard_tier": "1",
        "customs_declaration_no": "999999000002", "customs_lane": "YELLOW",
        "customs_supervision_status": "Under customs supervision", "export_registration_status": "Not registered",
        "vessel_loading_status": "Not loaded",
        "remarks": "Yellow lane — documents under customs check. (SAMPLE)"},
        [("GATE_IN_COMPLETED", "SET", f"{day} 09:40", "Seen on the terminal's ePort screen (SAMPLE)"),
         ("CUSTOMS_PENDING", "SET", f"{day} 10:20", "Yellow lane — waiting for document check (SAMPLE)")])
    return [first, second]


EXPORT_REG_NOTE = "ePort shows the export registration as done (SAMPLE)"
_EXPORT_REG_META_KEY = "sample_export_registration_timeline"


def ensure_sample_export_registration() -> str | None:
    """Demo container 1 was "Registered" in the former field: give it the matching timeline step once.

    Only touches the SAMPLE demo shipment (invented data, marked SAMPLE). Real shipments are never changed.
    """
    from . import gatein as G
    from .shipments import get_shipment

    if database.get_meta(_EXPORT_REG_META_KEY):
        return None
    sample_id = database.get_meta(_META_KEY)
    ship = get_shipment(sample_id) if sample_id else None
    if not ship or not ship["is_sample"]:
        database.set_meta(_EXPORT_REG_META_KEY, "skipped")
        return None
    done = None
    first_number, values, events = build_sample_gateins(ship)[0]
    item = next((i for i in G.get_shipment_gateins(sample_id)["items"]
                 if i["container"]["container_number"] == first_number), None)
    if item and (item["record"] or {}).get("export_registration_status") == "Registered"             and not item["current"].get("EXPORT_REGISTERED"):
        when = next(w for k, _, w, _ in events if k == "EXPORT_REGISTERED")
        G.record_status(sample_id, item["container"]["id"], "EXPORT_REGISTERED", "SET", when, "MANUAL",
                        DEMO_CONFIRMED_BY, EXPORT_REG_NOTE)
        done = sample_id
    database.set_meta(_EXPORT_REG_META_KEY, sample_id)
    return done


def ensure_sample_gatein() -> str | None:
    """Give the demo shipment its gate-in records once. Only touches the SAMPLE demo shipment."""
    from . import gatein as G
    from .shipments import get_shipment

    if database.get_meta(_GATEIN_META_KEY):
        return None
    sample_id = database.get_meta(_META_KEY)
    ship = get_shipment(sample_id) if sample_id else None
    if not ship or not ship["is_sample"]:
        database.set_meta(_GATEIN_META_KEY, "skipped")
        return None
    overview = G.get_shipment_gateins(sample_id)
    by_number = {i["container"]["container_number"]: i for i in overview["items"]}
    for number, values, events in build_sample_gateins(ship):
        item = by_number.get(number)
        if not item or item["record"] or item["events"]:
            continue
        cid = item["container"]["id"]
        G.save_gatein(sample_id, cid, values)
        for key, action, when, note in events:
            G.record_status(sample_id, cid, key, action, when, "MANUAL", DEMO_CONFIRMED_BY, note)
    database.set_meta(_GATEIN_META_KEY, sample_id)
    return sample_id


# ---------------------------------------------------------------------------
# Step 6 — demo draft B/L
# ---------------------------------------------------------------------------
_BL_META_KEY = "sample_bl_v1"


def ensure_sample_bl() -> str | None:
    """Give the demo shipment its draft B/L once (Original B/L, 3 originals — from the demo SI).

    Status stays B/L Draft and RECEIVED FOR SHIPMENT: the containers are not loaded on board, and
    no carrier B/L number or date of issue is invented.
    """
    from . import bl as BLM
    from .shipments import get_shipment

    if database.get_meta(_BL_META_KEY):
        return None
    sample_id = database.get_meta(_META_KEY)
    ship = get_shipment(sample_id) if sample_id else None
    if not ship or not ship["is_sample"] or BLM.get_bl_view(sample_id)["exists"]:
        database.set_meta(_BL_META_KEY, "skipped")
        return None
    BLM.save_bl(sample_id, {"place_of_issue": "Ho Chi Minh City, Vietnam",
                            "remarks": "Draft for checking against the SI. (SAMPLE)"})
    database.set_meta(_BL_META_KEY, sample_id)
    return sample_id


_ROUTING_META_KEY = "sample_routing_port_to_port_v1"
# Earlier demo values that did not fit a port-to-port B/L (fixed once on existing databases)
_OLD_DEMO_ROUTING = {"place_of_receipt": "Ho Chi Minh City, Vietnam", "place_of_delivery": "Los Angeles, CA, USA"}
_OLD_DEMO_PRE_CARRIAGE = "Truck — Thủ Đức to Cat Lai (SAMPLE)"


def ensure_sample_routing_fix() -> str | None:
    """Make the demo's routing fit its port-to-port B/L, once (central data → Steps 1, 4 and 6).

    Place of receipt = POL, place of delivery = POD, no pre-carriage. Only values that are still
    the old demo values are changed — anything the user typed is kept.
    """
    if database.get_meta(_ROUTING_META_KEY):
        return None
    sample_id = database.get_meta(_META_KEY)
    changed = False
    with database.transaction() as conn:
        row = conn.execute("SELECT id, is_sample, port_of_loading, port_of_discharge, place_of_receipt, "
                           "place_of_delivery FROM shipments WHERE shipment_id = ?", (sample_id,)).fetchone() \
            if sample_id else None
        if row and row["is_sample"]:
            if row["place_of_receipt"] == _OLD_DEMO_ROUTING["place_of_receipt"]:
                conn.execute("UPDATE shipments SET place_of_receipt = ? WHERE id = ?", (row["port_of_loading"], row["id"]))
                changed = True
            if row["place_of_delivery"] == _OLD_DEMO_ROUTING["place_of_delivery"]:
                conn.execute("UPDATE shipments SET place_of_delivery = ? WHERE id = ?",
                             (row["port_of_discharge"], row["id"]))
                changed = True
            cur = conn.execute("UPDATE si_records SET pre_carriage = NULL WHERE shipment_fk = ? AND pre_carriage = ?",
                               (row["id"], _OLD_DEMO_PRE_CARRIAGE))
            changed = changed or cur.rowcount > 0
    database.set_meta(_ROUTING_META_KEY, sample_id or "skipped")
    return sample_id if changed else None
