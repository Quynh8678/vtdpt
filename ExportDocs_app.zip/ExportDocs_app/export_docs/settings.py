"""App settings — the ONE place that decides where data is stored.

Local (now):  data is saved in the "data" folder next to app.py.
Google Colab: set the environment variable before starting the app, e.g.

    import os
    os.environ["EXPORT_DOCS_DATA_DIR"] = "/content/drive/MyDrive/ExportDocs"

or simply change DEFAULT_DATA_DIR below. Nothing else in the code needs to change.
"""

import os
import time
from pathlib import Path

# Project root = the folder that contains app.py
PROJECT_ROOT = Path(__file__).resolve().parent.parent

# ---- Data folder (change this one setting to move all data) ----------------
DEFAULT_DATA_DIR = PROJECT_ROOT / "data"
DATA_DIR = Path(os.environ.get("EXPORT_DOCS_DATA_DIR", DEFAULT_DATA_DIR)).expanduser()

# Sub-folders inside the data folder
DATABASE_DIR = DATA_DIR / "database"
PDF_DIR = DATA_DIR / "pdfs"
UPLOAD_DIR = DATA_DIR / "uploads"
BACKUP_DIR = DATA_DIR / "backups"
EXPORT_DIR = DATA_DIR / "exports"          # combined PDFs, ZIPs and JSON exports (Phase 6)

# The database file kept in the data folder (on Google Drive in Colab).
STORED_DATABASE_PATH = DATABASE_DIR / "export_docs.sqlite3"

# Google Colab: SQLite must not run directly on Google Drive. When EXPORT_DOCS_LOCAL_DB is set, the app works on
# a LOCAL copy (Colab's own disk); drive_sync.py copies it from Drive at start and back to Drive after every save.
_LOCAL_DB = os.environ.get("EXPORT_DOCS_LOCAL_DB", "").strip()
USE_LOCAL_COPY = bool(_LOCAL_DB)
# The file the app reads and writes.
DATABASE_PATH = Path(_LOCAL_DB).expanduser() if USE_LOCAL_COPY else STORED_DATABASE_PATH

# ---- Runtime environment ---------------------------------------------------
IS_COLAB = "COLAB_RELEASE_TAG" in os.environ or "COLAB_GPU" in os.environ

# Colab computers run on UTC; cut-off countdowns and "created at" times must use the shipper's local time.
TIMEZONE = os.environ.get("EXPORT_DOCS_TIMEZONE", "Asia/Ho_Chi_Minh" if IS_COLAB else "")
if TIMEZONE and hasattr(time, "tzset"):        # Linux (Colab); Windows uses the computer's own time zone
    os.environ["TZ"] = TIMEZONE
    time.tzset()

SERVER_HOST = "127.0.0.1"
SERVER_PORT = int(os.environ.get("EXPORT_DOCS_PORT", "7860"))
# Colab needs a public share link; locally we keep the app private on this computer.
SHARE_LINK = IS_COLAB


def ensure_data_folders() -> None:
    """Create the data folder and its sub-folders if they do not exist yet."""
    for folder in (DATA_DIR, DATABASE_DIR, PDF_DIR, UPLOAD_DIR, BACKUP_DIR, EXPORT_DIR, DATABASE_PATH.parent):
        folder.mkdir(parents=True, exist_ok=True)
