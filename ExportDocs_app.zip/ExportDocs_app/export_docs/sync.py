"""Phase 5 — sync rules (REQUIREMENTS.md §6, "most important rule").

One central copy of the data; documents inherit from it. When source data changes:
- documents that read the central data show the new value at once (logged as "Đồng bộ tự động");
- a document that was SUBMITTED / CONFIRMED / ISSUED, or that has its OWN value (edited in the document),
  is NOT overwritten silently. A conflict is created and the user chooses:
      KEEP     the document keeps its value
      REPLACE  the document takes the new value (a confirmed document then gets an "Amended" version)
  · SI already sent to the carrier → the SI keeps the submitted value (a document override) until the
    user decides. Replace = the SI must be amended (Step 4 shows "changed since submission").
  · Booking confirmed by the carrier → KEEP puts the confirmed value back into the central data (all
    documents follow); REPLACE accepts the new value → the booking needs the carrier's re-confirmation.
  · B/L: its text is its own copy of the SI. It follows the SI automatically when it said the same as
    the SI before; a value edited in the B/L, or a B/L already approved / issued → conflict.
  · EIR / VGM / Gate-in records already declared or confirmed → a notice (they must be redone).
Nothing is ever fixed automatically when a choice is needed.
"""

import json

from . import bl as BL
from . import shipments as S
from . import si as SI
from .database import reading, transaction
from .tracking import action, tracked

SYNC_FIELDS = (
    ("booking_number", "Booking No."), ("vessel_name", "Vessel"), ("voyage_number", "Voyage"),
    ("place_of_receipt", "Place of Receipt"), ("port_of_loading", "Port of Loading (POL)"),
    ("port_of_discharge", "Port of Discharge (POD)"), ("place_of_delivery", "Place of Delivery"),
    ("party:SHIPPER", "Shipper"), ("party:CONSIGNEE", "Consignee"), ("party:NOTIFY_PARTY", "Notify Party"),
)
SYNC_LABELS = dict(SYNC_FIELDS)
_ROUTING = ("booking_number", "vessel_name", "voyage_number", "place_of_receipt", "port_of_loading",
            "port_of_discharge", "place_of_delivery")
USES = {
    "BOOKING": set(_ROUTING) | {"party:SHIPPER"},
    "EIR": {"booking_number"},
    "VGM": {"booking_number", "vessel_name", "voyage_number", "party:SHIPPER"},
    "SI": set(SYNC_LABELS),
    "GATEIN": {"booking_number", "vessel_name", "voyage_number", "port_of_loading", "port_of_discharge"},
}
CAUSES = {"LOCKED": "Chứng từ đã gửi / đã được xác nhận", "MANUAL": "Chứng từ có giá trị riêng (đã sửa trong chứng từ)",
          "NOTICE": "Đã khai / xác nhận với giá trị cũ"}
CHOICES = {"KEEP": "Giữ giá trị trong chứng từ", "REPLACE": "Thay bằng giá trị mới", "DISMISS": "Đã hiểu"}


def sync_values(ship: dict) -> dict:
    out = {}
    for key, _ in SYNC_FIELDS:
        if key.startswith("party:"):
            p = (ship.get("parties") or {}).get(key[6:]) or {}
            out[key] = {f: p.get(f) for f in S.PARTY_FIELDS}
        else:
            out[key] = ship.get(key)
    return out


def norm(value) -> str:
    if isinstance(value, dict):
        value = "\n".join(str(value.get(f) or "").strip() for f in S.PARTY_FIELDS)
    return " ".join(str(value or "").split()).upper()


def show_value(value) -> str:
    from .history import party_text
    if isinstance(value, dict):
        return party_text(value) or "—"
    return str(value) if value not in (None, "") else "—"


def _json(value) -> str:
    return json.dumps(value, ensure_ascii=False)


# ---------------------------------------------------------------------------
# Document overrides (a document keeps its own value of an inherited field)
# ---------------------------------------------------------------------------
def overrides(shipment_fk: int, doc_type: str) -> dict:
    with reading() as conn:
        return {r["field_key"]: json.loads(r["value"]) for r in conn.execute(
            "SELECT field_key, value FROM doc_overrides WHERE shipment_fk = ? AND doc_type = ?", (shipment_fk, doc_type))}


def _set_override(conn, fk: int, doc_type: str, key: str, value, note: str, user: str) -> None:
    conn.execute("INSERT INTO doc_overrides (shipment_fk, doc_type, field_key, value, source, note, created_by, created_at) "
                 "VALUES (?, ?, ?, ?, 'EXTERNAL', ?, ?, ?) ON CONFLICT(shipment_fk, doc_type, field_key) DO UPDATE SET "
                 "value = excluded.value, note = excluded.note", (fk, doc_type, key, _json(value), note, user, S.now_text()))


@tracked("BOOKING")
def keep_booking_value(shipment_id: str, field_key: str, value) -> None:
    """Put the carrier-confirmed booking value back into the central data (every document follows)."""
    S.write_central(shipment_id, {field_key: value})


@tracked("SI")
def remove_si_override(shipment_id: str, field_key: str) -> None:
    """The SI follows the central value again for this field (logged + versioned by @tracked)."""
    with transaction() as conn:
        fk = S.get_shipment_fk(conn, shipment_id)
        conn.execute("DELETE FROM doc_overrides WHERE shipment_fk = ? AND doc_type = 'SI' AND field_key = ?",
                     (fk, field_key))


# ---------------------------------------------------------------------------
# Conflicts
# ---------------------------------------------------------------------------
def _conflict(conn, fk: int, doc_type: str, key: str, label: str, doc_value, new_value, cause: str, detail: str,
              user: str) -> None:
    row = conn.execute("SELECT id FROM sync_conflicts WHERE shipment_fk = ? AND doc_type = ? AND field_key = ? "
                       "AND status = 'PENDING'", (fk, doc_type, key)).fetchone()
    if row:
        conn.execute("UPDATE sync_conflicts SET new_value = ?, detail = ?, cause = ? WHERE id = ?",
                     (_json(new_value), detail, cause, row[0]))
    else:
        conn.execute("INSERT INTO sync_conflicts (shipment_fk, doc_type, field_key, field_label, doc_value, new_value, "
                     "cause, detail, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                     (fk, doc_type, key, label, _json(doc_value), _json(new_value), cause, detail, user, S.now_text()))


def list_conflicts(shipment_id: str, pending_only: bool = True) -> list[dict]:
    with reading() as conn:
        row = conn.execute("SELECT id FROM shipments WHERE shipment_id = ?", (shipment_id,)).fetchone()
        if not row:
            return []
        rows = [dict(r) for r in conn.execute(
            "SELECT * FROM sync_conflicts WHERE shipment_fk = ?" + (" AND status = 'PENDING'" if pending_only else "")
            + " ORDER BY id", (row[0],))]
    for r in rows:
        r["doc_value"], r["new_value"] = json.loads(r["doc_value"]), json.loads(r["new_value"])
        r["choices"] = ["DISMISS"] if r["cause"] == "NOTICE" else ["KEEP", "REPLACE"]
    return rows


def conflict_text(c: dict) -> str:
    from .history import DOC_SHORT
    return (f"#{c['id']} · {DOC_SHORT.get(c['doc_type'], c['doc_type'])} · {c['field_label']}: "
            f"chứng từ “{show_value(c['doc_value']).splitlines()[0]}” → mới “{show_value(c['new_value']).splitlines()[0]}”")


# ---------------------------------------------------------------------------
# The rules — called by history.after_change() after every tracked save
# ---------------------------------------------------------------------------
def apply_rules(shipment_id: str, source_doc: str, before: dict, mid: dict) -> tuple[list[str], bool]:
    from .history import DOC_SHORT, current_user
    user = current_user()
    fk = mid["fk"]
    report, changed, auto = [], False, {}
    changes = [(k, label, before["sync"][k], mid["sync"][k]) for k, label in SYNC_FIELDS
               if norm(before["sync"][k]) != norm(mid["sync"][k])]
    si_over = overrides(fk, "SI")
    with transaction() as conn:
        for key, label, old, new in changes:
            for doc in ("BOOKING", "EIR", "VGM", "SI", "GATEIN"):
                if key not in USES[doc] or doc == source_doc:
                    continue
                states = [s for (d, _), s in mid["docs"].items() if d == doc]
                if not states:
                    continue
                locked = [s for s in states if s["locked"]]
                if doc == "SI" and key in si_over:
                    if norm(si_over[key]) != norm(new):
                        _conflict(conn, fk, "SI", key, label, si_over[key], new, "MANUAL",
                                  "SI đang giữ giá trị riêng (đã gửi hãng tàu) — không tự ghi đè.", user)
                        report.append(f"⚠️ {label}: SI vẫn giữ giá trị đã gửi hãng tàu → chọn Giữ / Thay.")
                elif doc == "SI" and locked:
                    status = SI.status_label(locked[0]["status"])
                    _set_override(conn, fk, "SI", key, old, f"Giá trị trên SI đã gửi hãng tàu ({status})", user)
                    changed = True
                    _conflict(conn, fk, "SI", key, label, old, new, "LOCKED",
                              f"SI đã gửi hãng tàu ({status}) — SI giữ giá trị cũ cho đến khi bạn chọn.", user)
                    report.append(f"⚠️ {label}: SI đã gửi hãng tàu ({status}) → KHÔNG tự ghi đè; SI giữ "
                                  f"“{show_value(old).splitlines()[0]}”. Chọn Giữ / Thay ở Trung tâm kiểm tra.")
                elif doc == "BOOKING" and locked:
                    _conflict(conn, fk, "BOOKING", key, label, old, new, "LOCKED",
                              "Booking đã được hãng tàu xác nhận. Giữ = trả lại giá trị đã xác nhận cho mọi chứng từ; "
                              "Thay = dùng giá trị mới (cần hãng tàu xác nhận lại booking).", user)
                    report.append(f"⚠️ {label}: Booking đã được hãng tàu xác nhận với “{show_value(old)}” → "
                                  "chọn Giữ / Thay ở Trung tâm kiểm tra.")
                elif doc in ("EIR", "VGM", "GATEIN") and locked:
                    names = ", ".join(s["label"] for s in locked)
                    _conflict(conn, fk, doc, key, label, old, new, "NOTICE",
                              f"Đã khai / xác nhận với giá trị cũ: {names} — cần khai / xác nhận lại với giá trị mới.",
                              user)
                    report.append(f"ℹ️ {label}: {names} đã khai / xác nhận với giá trị cũ — cần làm lại.")
                    auto.setdefault(label, []).append(DOC_SHORT[doc])
                else:
                    auto.setdefault(label, []).append(DOC_SHORT[doc])
        # an override that equals the central value again is no longer needed
        central = mid["sync"]
        for key, value in overrides(fk, "SI").items():
            if key in central and norm(value) == norm(central[key]):
                conn.execute("DELETE FROM doc_overrides WHERE shipment_fk = ? AND doc_type = 'SI' AND field_key = ?",
                             (fk, key))
                changed = True
                _auto_resolve(conn, fk, "SI", key, user)
        for r in conn.execute("SELECT id, field_key, doc_value FROM sync_conflicts WHERE shipment_fk = ? "
                              "AND doc_type = 'BOOKING' AND status = 'PENDING'", (fk,)).fetchall():
            if r["field_key"] in central and norm(json.loads(r["doc_value"])) == norm(central[r["field_key"]]):
                _auto_resolve(conn, fk, "BOOKING", r["field_key"], user)
    for label, docs in auto.items():
        report.append(f"🔄 {label}: đã cập nhật theo dữ liệu nguồn trong " + ", ".join(dict.fromkeys(docs)) + ".")

    bl_report, bl_changed = _cascade_bl(shipment_id, source_doc, before, user)
    return report + bl_report, changed or bl_changed


def close_conflicts(shipment_id: str, doc_type: str, keys: list[str], note: str) -> None:
    """Pending conflicts settled by an action elsewhere (e.g. the Validation Center)."""
    from .history import current_user
    with transaction() as conn:
        fk = S.get_shipment_fk(conn, shipment_id)
        for key in keys:
            conn.execute("UPDATE sync_conflicts SET status = 'RESOLVED', resolved_by = ?, resolved_at = ?, "
                         "resolution_note = ? WHERE shipment_fk = ? AND doc_type = ? AND field_key = ? "
                         "AND status = 'PENDING'", (current_user(), S.now_text(), note, fk, doc_type, key))


def _auto_resolve(conn, fk: int, doc_type: str, key: str, user: str) -> None:
    conn.execute("UPDATE sync_conflicts SET status = 'RESOLVED', resolved_by = ?, resolved_at = ?, "
                 "resolution_note = 'Giá trị đã trùng với dữ liệu nguồn' WHERE shipment_fk = ? AND doc_type = ? "
                 "AND field_key = ? AND status = 'PENDING'", (user, S.now_text(), fk, doc_type, key))


def _cascade_bl(shipment_id: str, source_doc: str, before: dict, user: str) -> tuple[list[str], bool]:
    """The B/L text follows the SI where it said the same as the SI; otherwise the user chooses."""
    if source_doc == "BL" or before.get("si_part") is None:
        return [], False
    view = BL.get_bl_view(shipment_id)
    if not view or not view["exists"]:
        return [], False
    bl_text, si_old, si_new = view["particulars"], before["si_part"], view["si_particulars"]
    was_different = {d["key"] for d in BL.differences({"particulars": bl_text, "si_particulars": si_old})}
    si_changed = {d["key"] for d in BL.differences({"particulars": si_old, "si_particulars": si_new})}
    locked = view["status"] in ("Draft Approved",) + BL.CARRIER_STATES
    report, changed, updated = [], False, []
    for d in BL.differences(view):
        if d["key"] not in si_changed:
            continue                  # an older difference, not caused by this change
        if d["key"] in was_different or locked:
            cause = "LOCKED" if locked else "MANUAL"
            detail = (f"B/L đang ở “{BL.status_label(view['status'])}” — không tự ghi đè." if locked
                      else "Nội dung B/L đã được sửa riêng (khác SI từ trước) — không tự ghi đè.")
            with transaction() as conn:
                _conflict(conn, view["shipment"]["id"], "BL", d["key"], d["label"], d["bl"], d["si"], cause, detail, user)
            report.append(f"⚠️ B/L · {d['label']}: {detail} Chọn Giữ / Thay ở Trung tâm kiểm tra.")
        else:
            BL.apply_si_value(shipment_id, d["key"])
            updated.append(d["label"])
            changed = True
    if updated:
        report.append("🔄 B/L: đã cập nhật theo SI — " + ", ".join(updated) + ".")
    return report, changed


# ---------------------------------------------------------------------------
# The user's choice
# ---------------------------------------------------------------------------
def resolve(conflict_id: int, choice: str, reason: str | None = None) -> str:
    from .history import DOC_SHORT, current_user, log_event
    with reading() as conn:
        row = conn.execute("SELECT c.*, s.shipment_id FROM sync_conflicts c JOIN shipments s ON s.id = c.shipment_fk "
                           "WHERE c.id = ?", (conflict_id,)).fetchone()
    if not row:
        raise S.ShipmentError(["Không tìm thấy mục cần chọn (có thể đã được xử lý)."])
    c = dict(row)
    if c["status"] != "PENDING":
        raise S.ShipmentError(["Mục này đã được xử lý trước đó."])
    allowed = ("DISMISS",) if c["cause"] == "NOTICE" else ("KEEP", "REPLACE")
    if choice not in allowed:
        raise S.ShipmentError([f"Lựa chọn không hợp lệ cho mục này ({', '.join(CHOICES[a] for a in allowed)})."])
    sid, doc, key = c["shipment_id"], c["doc_type"], c["field_key"]
    doc_value, new_value = json.loads(c["doc_value"]), json.loads(c["new_value"])
    reason = S.clean_text(reason)
    status = {"KEEP": "KEPT", "REPLACE": "REPLACED", "DISMISS": "DISMISSED"}[choice]
    with transaction() as conn:
        conn.execute("UPDATE sync_conflicts SET status = ?, resolved_by = ?, resolved_at = ?, resolution_note = ? "
                     "WHERE id = ?", (status, current_user(), S.now_text(), reason, conflict_id))
    why = f"{CHOICES[choice]} — {c['field_label']}" + (f" — {reason}" if reason else "")
    with action(choice, why):
        if choice == "KEEP" and doc == "BOOKING":
            keep_booking_value(sid, key, doc_value, reason=why)        # the confirmed value back for every document
        elif choice == "REPLACE" and doc == "SI":
            remove_si_override(sid, key, reason=why)
        elif choice == "REPLACE" and doc == "BL":
            try:
                BL.apply_si_value(sid, key, reason=why)
            except BL.BLError:
                pass                     # already the same as the SI
        else:
            log_event(sid, doc, c["field_label"], show_value(doc_value), show_value(new_value), choice, why,
                      field_key=key, shipment_fk=c["shipment_fk"])
    what = {"KEEP": f"{DOC_SHORT[doc]} giữ “{show_value(doc_value).splitlines()[0]}”",
            "REPLACE": f"{DOC_SHORT[doc]} dùng “{show_value(new_value).splitlines()[0]}”",
            "DISMISS": "Đã ghi nhận"}[choice]
    return f"{c['field_label']}: {what}."
