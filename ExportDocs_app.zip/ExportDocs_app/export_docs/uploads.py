"""Phase 6 — upload area (REQUIREMENTS.md §10, optional helper).

1. Upload a PDF / JPG / PNG / XLSX file and classify it (booking confirmation, EIR, weighing ticket, port
   confirmation, invoice, packing list, carrier B/L …), linked to a shipment and, if relevant, a container
   and a step.
2. Text extraction: NO OCR yet. extract_fields() is the one place an OCR / AI service plugs in later; today it
   returns "not available" and the user types the values next to the file preview (manual entry). The values
   are compared with the app's data, differences are shown — nothing is applied automatically.
3. Evidence: a port confirmation (Step 5, with a container) can be registered as gate-in evidence, a carrier
   B/L (Step 6) as a carrier document for "Issued" / "Released". The upload itself never changes a status:
   the user still records the status in Step 5 / Step 6 and picks the file there.
Uploads are NEVER treated as official or confirmed automatically.
"""

import json
import re
import shutil
from datetime import datetime
from pathlib import Path

from . import settings
from . import shipments as S
from .database import reading, transaction
from .tracking import tracked

ALLOWED = (".pdf", ".jpg", ".jpeg", ".png", ".xlsx")
MAX_BYTES = 20 * 1024 * 1024
# key: (Vietnamese label, English, default step, linked to a container?)
CATEGORIES = {
    "BOOKING_CONFIRMATION": ("Booking Confirmation của hãng tàu", "Booking Confirmation", 1, False),
    "EIR": ("EIR của depot", "Depot EIR", 2, True),
    "WEIGHING_TICKET": ("Phiếu cân (Weighing ticket)", "Weighing ticket", 3, True),
    "VGM": ("VGM / xác nhận VGM", "VGM / VGM acknowledgement", 3, True),
    "SI": ("Shipping Instruction đã gửi", "Shipping Instruction", 4, False),
    "PORT_CONFIRMATION": ("Xác nhận hạ bãi / đăng ký xuất tàu (cảng)", "Gate-in / export registration confirmation", 5, True),
    "CUSTOMS_DECLARATION": ("Tờ khai hải quan xuất khẩu", "Export customs declaration", 5, False),
    "DRAFT_BL": ("Draft B/L của hãng tàu", "Carrier draft B/L", 6, False),
    "FINAL_BL": ("B/L do hãng tàu phát hành", "Carrier-issued B/L", 6, False),
    "COMMERCIAL_INVOICE": ("Commercial Invoice", "Commercial invoice", None, False),
    "PACKING_LIST": ("Packing List", "Packing list", None, False),
    "OTHER": ("Chứng từ khác", "Other", None, False),
}
# fields the user can type from the file (manual entry) — later filled by OCR
FIELDS = {
    "BOOKING_CONFIRMATION": [("booking_number", "Booking No."), ("vessel_name", "Vessel"), ("voyage_number", "Voyage"),
                             ("etd", "ETD"), ("port_of_loading", "POL"), ("port_of_discharge", "POD"),
                             ("si_cutoff", "SI cut-off"), ("cy_cutoff", "CY cut-off")],
    "EIR": [("container_number", "Container No."), ("eir_number", "Depot EIR No."), ("eir_datetime", "EIR date / time")],
    "WEIGHING_TICKET": [("container_number", "Container No."), ("vgm_kg", "Weighed VGM (kg)"),
                        ("weighing_datetime", "Weighing date / time"), ("ticket_number", "Ticket No.")],
    "VGM": [("container_number", "Container No."), ("vgm_kg", "VGM (kg)"), ("ack_reference", "Acknowledgement ref.")],
    "SI": [("booking_number", "Booking No."), ("consignee", "Consignee"), ("si_reference", "SI reference")],
    "PORT_CONFIRMATION": [("container_number", "Container No."), ("seal_number", "Seal No."),
                          ("gatein_datetime", "Gate-in date / time"), ("terminal_reference", "Terminal ref. / EIR No.")],
    "CUSTOMS_DECLARATION": [("customs_declaration_no", "Declaration No."), ("customs_lane", "Lane (Green/Yellow/Red)"),
                            ("package_count", "Packages"), ("gross_weight_kg", "Gross weight (kg)")],
    "DRAFT_BL": [("bl_number", "B/L No."), ("consignee", "Consignee"), ("description", "Description (dòng 1)")],
    "FINAL_BL": [("bl_number", "B/L No."), ("date_of_issue", "Date of issue"), ("consignee", "Consignee"),
                 ("shipped_on_board_date", "Shipped on board date")],
    "COMMERCIAL_INVOICE": [("invoice_number", "Invoice No."), ("package_count", "Packages"),
                           ("gross_weight_kg", "Gross weight (kg)")],
    "PACKING_LIST": [("package_count", "Packages"), ("gross_weight_kg", "Gross weight (kg)"),
                     ("volume_cbm", "Measurement (CBM)")],
    "OTHER": [("reference", "Số tham chiếu"), ("notes", "Ghi chú")],
}
EVIDENCE_FOR = {5: "gatein_evidence", 6: "bl_documents"}
STEPS = {1: "Bước 1 · Booking", 2: "Bước 2 · EIR", 3: "Bước 3 · VGM", 4: "Bước 4 · SI", 5: "Bước 5 · Gate-in",
         6: "Bước 6 · B/L"}


class UploadError(S.ShipmentError):
    pass


# ---------------------------------------------------------------------------
# OCR plug-in point (not built yet)
# ---------------------------------------------------------------------------
OCR_ENGINE = None      # set to a callable(path, category) -> {"fields": {...}, "uncertain": [...]} to enable OCR


def extract_fields(path: str | Path, category: str) -> dict:
    """Text extraction from an uploaded file.

    THIS is where an OCR / AI extraction service plugs in later: call it here and return
    {"status": "OK", "fields": {field_key: value}, "uncertain": [field_key, …], "engine": name}.
    The UI then shows the values as SUGGESTIONS next to the file; the user edits and confirms them (they
    are stored as extraction_source "OCR" with time and user). Nothing is applied to a document
    automatically, and an uploaded file never becomes official by itself.
    """
    if OCR_ENGINE is None:
        return {"status": "NOT_AVAILABLE", "fields": {}, "uncertain": [],
                "message": "Chưa có OCR — hãy nhập tay các giá trị đọc được từ file (ô bên cạnh bản xem trước)."}
    result = OCR_ENGINE(Path(path), category)
    return {"status": "OK", "fields": result.get("fields", {}), "uncertain": result.get("uncertain", []),
            "engine": getattr(OCR_ENGINE, "__name__", "OCR")}


# ---------------------------------------------------------------------------
# Upload
# ---------------------------------------------------------------------------
def _ship(conn, shipment_id: str) -> dict:
    row = conn.execute("SELECT id FROM shipments WHERE shipment_id = ?", (shipment_id,)).fetchone()
    if not row:
        raise UploadError([f"Không tìm thấy lô hàng {shipment_id}."])
    return row


def upload(shipment_id: str, source_path: str | Path, category: str, step: int | None = None,
           container_id: int | None = None, description: str | None = None, use_as_evidence: bool = False) -> dict:
    """Store the file, classify it, link it; optionally register it as evidence (Step 5 / Step 6).

    Never changes a status: the user still records "Gate-in Completed", "B/L Issued" … with the file.
    """
    from .history import current_user, log_event
    source = Path(source_path) if source_path else None
    errors = []
    if not source or not source.exists():
        errors.append("Chưa chọn file, hoặc không tìm thấy file tải lên.")
    elif source.suffix.lower() not in ALLOWED:
        errors.append(f"Loại file {source.suffix or '(không có đuôi)'} không được nhận — dùng PDF, JPG, PNG hoặc XLSX.")
    elif source.stat().st_size > MAX_BYTES:
        errors.append("File lớn hơn 20 MB.")
    if category not in CATEGORIES:
        errors.append("Chọn loại chứng từ.")
    step = int(step) if step not in (None, "", 0) else (CATEGORIES.get(category, (None, None, None))[2])
    if step is not None and step not in STEPS:
        errors.append("Bước không hợp lệ.")
    if use_as_evidence:
        if step not in EVIDENCE_FOR:
            errors.append("Chỉ dùng làm bằng chứng cho Bước 5 (Gate-in, chọn container) hoặc Bước 6 (B/L của hãng tàu).")
        elif step == 5 and not container_id:
            errors.append("Bằng chứng Gate-in phải gắn với một container.")
    if errors:
        raise UploadError(errors)
    user = current_user()
    with transaction() as conn:
        fk = _ship(conn, shipment_id)["id"]
        if container_id:
            owner = conn.execute("SELECT shipment_fk FROM containers WHERE id = ?", (container_id,)).fetchone()
            if not owner or owner[0] != fk:
                raise UploadError(["Container không thuộc lô hàng này."])
        folder = settings.UPLOAD_DIR / re.sub(r"[^A-Za-z0-9._-]+", "-", shipment_id) / "library"
        folder.mkdir(parents=True, exist_ok=True)
        safe = re.sub(r"[^A-Za-z0-9._-]+", "-", source.name).strip("-") or f"file{source.suffix.lower()}"
        target = folder / f"{datetime.now():%Y%m%d-%H%M%S}_{safe}"
        shutil.copy2(source, target)
        cur = conn.execute(
            "INSERT INTO uploaded_documents (shipment_fk, container_fk, step, category, file_path, file_name, file_size, "
            "description, uploaded_by, uploaded_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (fk, container_id or None, step, category, str(target), source.name, target.stat().st_size,
             S.clean_text(description), user, S.now_text()))
        upload_id = cur.lastrowid
    label = CATEGORIES[category][0]
    log_event(shipment_id, "SHIPMENT", f"File tải lên · {label}", None, source.name, "UPLOAD",
              S.clean_text(description), doc_label="Thư viện chứng từ", field_key=f"upload#{upload_id}",
              shipment_fk=fk)
    evidence = None
    if use_as_evidence:
        evidence = link_as_evidence(upload_id)
    return {"id": upload_id, "path": str(target), "evidence": evidence}


@tracked("GATEIN")
def _gatein_evidence(shipment_id: str, container_id: int, path: str, name: str, description: str | None,
                     user: str) -> int:
    with transaction() as conn:
        fk = _ship(conn, shipment_id)["id"]
        stamp = S.now_text()
        conn.execute("INSERT OR IGNORE INTO gatein_records (shipment_fk, container_fk, created_at, updated_at) "
                     "VALUES (?, ?, ?, ?)", (fk, container_id, stamp, stamp))
        return conn.execute("INSERT INTO gatein_evidence (shipment_fk, container_fk, file_path, file_name, description, "
                            "uploaded_by, uploaded_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                            (fk, container_id, path, name, description, user, stamp)).lastrowid


@tracked("BL")
def _bl_document(shipment_id: str, path: str, name: str, description: str | None, user: str) -> int:
    with transaction() as conn:
        fk = _ship(conn, shipment_id)["id"]
        return conn.execute("INSERT INTO bl_documents (shipment_fk, file_path, file_name, description, uploaded_by, "
                            "uploaded_at) VALUES (?, ?, ?, ?, ?, ?)",
                            (fk, path, name, description, user, S.now_text())).lastrowid


def link_as_evidence(upload_id: int) -> str:
    """Register an upload as gate-in evidence (Step 5) or as a carrier document for the B/L (Step 6).

    The file then appears in Step 5 / Step 6, where the user records the status with it. No status changes here.
    """
    from .history import current_user
    up = get_upload(upload_id)
    if up["evidence_table"]:
        return f"Đã là bằng chứng ({up['evidence_table']} #{up['evidence_id']})."
    desc = f"{CATEGORIES[up['category']][0]} — từ Thư viện chứng từ" + (f": {up['description']}" if up["description"] else "")
    if up["step"] == 5:
        if not up["container_fk"]:
            raise UploadError(["Bằng chứng Gate-in phải gắn với một container."])
        evidence_id = _gatein_evidence(up["shipment_id"], up["container_fk"], up["file_path"], up["file_name"], desc,
                                       current_user(), reason="File tải lên dùng làm bằng chứng Gate-in")
        table, where = "gatein_evidence", "Bước 5 (chọn file khi ghi trạng thái, nguồn “Uploaded file”)"
    elif up["step"] == 6:
        evidence_id = _bl_document(up["shipment_id"], up["file_path"], up["file_name"], desc, current_user(),
                                   reason="File tải lên dùng làm chứng từ hãng tàu cho B/L")
        table, where = "bl_documents", "Bước 6 (chọn file khi chuyển trạng thái Issued / Released)"
    else:
        raise UploadError(["Chỉ dùng làm bằng chứng cho Bước 5 (Gate-in) hoặc Bước 6 (B/L)."])
    with transaction() as conn:
        conn.execute("UPDATE uploaded_documents SET evidence_table = ?, evidence_id = ? WHERE id = ?",
                     (table, evidence_id, upload_id))
    return f"Đã đưa vào danh sách bằng chứng của {where}. Trạng thái KHÔNG tự thay đổi."


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------
def get_upload(upload_id: int) -> dict:
    with reading() as conn:
        row = conn.execute("SELECT u.*, s.shipment_id, c.container_number FROM uploaded_documents u JOIN shipments s ON "
                           "s.id = u.shipment_fk LEFT JOIN containers c ON c.id = u.container_fk WHERE u.id = ?",
                           (upload_id,)).fetchone()
    if not row:
        raise UploadError(["Không tìm thấy file này."])
    data = dict(row)
    data["manual_fields"] = json.loads(data["manual_fields"]) if data["manual_fields"] else {}
    return data


def list_uploads(shipment_id: str) -> list[dict]:
    with reading() as conn:
        rows = conn.execute("SELECT u.id FROM uploaded_documents u JOIN shipments s ON s.id = u.shipment_fk WHERE "
                            "s.shipment_id = ? ORDER BY u.id DESC", (shipment_id,)).fetchall()
    return [get_upload(r[0]) for r in rows]


# ---------------------------------------------------------------------------
# Manual entry, compared with the app's data (never applied automatically)
# ---------------------------------------------------------------------------
def app_values(shipment_id: str, category: str, container_id: int | None) -> dict:
    """What the app currently says for each field of this kind of file."""
    from . import bl as BL, gatein as G, si as SI
    from .formatting import fmt_kg
    ship = S.get_shipment(shipment_id)
    c = next((x for x in ship["containers"] if x["id"] == container_id), {}) if container_id else {}
    out = {k: None for k, _ in FIELDS.get(category, [])}
    out.update({k: ship.get(k) for k in out if k in ship and not isinstance(ship.get(k), (list, dict))})
    out.update({k: c.get(k) for k in out if k in c})
    totals = {"package_count": sum(l.get("package_count") or 0 for l in ship["cargo"]),
              "gross_weight_kg": sum(l.get("gross_weight_kg") or 0 for l in ship["cargo"]),
              "volume_cbm": sum(l.get("volume_cbm") or 0 for l in ship["cargo"])}
    for k, v in totals.items():
        if k in out:
            out[k] = v
    if category in ("PORT_CONFIRMATION", "CUSTOMS_DECLARATION"):
        items = (G.get_shipment_gateins(shipment_id) or {"items": []})["items"]
        rec = next(((i["record"] or {}) for i in items if i["container"]["id"] == container_id), {}) if container_id \
            else next(((i["record"] or {}) for i in items if i["record"]), {})
        out.update({"seal_number": rec.get("gatein_seal_number") or c.get("seal_number")} if "seal_number" in out else {})
        for k in ("gatein_datetime", "customs_declaration_no", "customs_lane"):
            if k in out:
                out[k] = rec.get(k)
        if "terminal_reference" in out:
            out["terminal_reference"] = rec.get("gatein_eir_no") or rec.get("transaction_ref")
    if category in ("SI", "DRAFT_BL", "FINAL_BL"):
        view = BL.get_bl_view(shipment_id)
        if "si_reference" in out:
            out["si_reference"] = view["si"].get("si_reference")
        if "consignee" in out:
            text = view["particulars"].get("consignee") if (category != "SI" and view["exists"]) else \
                SI.party(view["si_view"]["shipment"], "CONSIGNEE").get("party_name")
            out["consignee"] = (text or "").splitlines()[0] if text else None
        rec = view["record"] or {}
        for k, src in (("bl_number", "carrier_bl_number"), ("date_of_issue", "date_of_issue"),
                       ("shipped_on_board_date", "shipped_on_board_date")):
            if k in out:
                out[k] = rec.get(src)
        if "description" in out and view["exists"] and view["particulars"]["cargo"]:
            out["description"] = view["particulars"]["cargo"][0].get("description")
    if category in ("VGM",) and "ack_reference" in out and container_id:
        from . import vgm as V
        item = next((i for i in V.get_shipment_vgms(shipment_id)["items"] if i["container"]["id"] == container_id), None)
        out["ack_reference"] = ((item or {}).get("vgm") or {}).get("ack_reference")
    if "eir_datetime" in out and container_id:
        from . import eir as E
        item = next((i for i in E.get_shipment_eirs(shipment_id)["items"] if i["container"]["id"] == container_id), None)
        out["eir_datetime"] = ((item or {}).get("eir") or {}).get("eir_datetime")
    return {k: (fmt_kg(v) if k in ("vgm_kg", "gross_weight_kg") and isinstance(v, (int, float)) else v)
            for k, v in out.items()}


def _same(a, b) -> bool:
    norm = lambda v: re.sub(r"[\s,]+", "", str(v or "")).upper().rstrip("0").rstrip(".") if v not in (None, "") else ""
    return norm(a) == norm(b)


def comparison(upload_id: int, typed: dict | None = None) -> list[dict]:
    """[{key, label, file_value, app_value, differs}] — typed values (or the saved ones) vs the app's data."""
    up = get_upload(upload_id)
    typed = up["manual_fields"] if typed is None else typed
    app = app_values(up["shipment_id"], up["category"], up["container_fk"])
    rows = []
    for key, label in FIELDS.get(up["category"], []):
        file_value = S.clean_text(typed.get(key))
        rows.append({"key": key, "label": label, "file_value": file_value, "app_value": app.get(key),
                     "differs": bool(file_value) and not _same(file_value, app.get(key))})
    return rows


def save_manual_fields(upload_id: int, values: dict) -> list[dict]:
    """Store the values the user read from the file. Nothing is applied to any document."""
    from .history import current_user, log_event
    up = get_upload(upload_id)
    allowed = {k for k, _ in FIELDS.get(up["category"], [])}
    clean = {k: S.clean_text(v) for k, v in values.items() if k in allowed and S.clean_text(v)}
    with transaction() as conn:
        conn.execute("UPDATE uploaded_documents SET manual_fields = ?, extraction_source = 'MANUAL', extracted_by = ?, "
                     "extracted_at = ? WHERE id = ?",
                     (json.dumps(clean, ensure_ascii=False), current_user(), S.now_text(), upload_id))
    log_event(up["shipment_id"], "SHIPMENT", f"Dữ liệu nhập tay từ file {up['file_name']}",
              json.dumps(up["manual_fields"], ensure_ascii=False) if up["manual_fields"] else None,
              json.dumps(clean, ensure_ascii=False), "EDIT", "Nhập tay từ file tải lên (không tự áp dụng)",
              doc_label="Thư viện chứng từ", field_key=f"upload#{upload_id}.manual_fields")
    return comparison(upload_id)
