"""Phase 6 — export the document set (REQUIREMENTS.md §12).

- check(): which of the six documents exist, their version and status, and which steps are incomplete
  (a warning before exporting — finished documents can always be exported).
- combined PDF: a cover page (documents, version, status, step status, page range) + the chosen documents in
  the fixed order 01 Booking → 06 B/L. Each document is rendered on its own, so it keeps its own page
  numbering, footer and label (DRAFT / INTERNAL RECORD / REFERENCE COPY …).
- ZIP of the separate PDFs, named 01_… 06_ + ShipmentID_BookingNumber_DocumentName_Version.pdf.
- JSON of all shipment data.
Every export is saved in <data folder>/exports/<ShipmentID>/, listed in the Document Library and logged in the
change log. Exporting never changes a document (the PDFs are built in memory, nothing is "issued").
"""

import io
import json
import zipfile
from datetime import datetime
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Spacer, Table, TableStyle

from . import APP_NAME, settings
from . import bl as BL
from . import bookings as B
from . import eir as E
from . import gatein as G
from . import shipments as S
from . import si as SI
from . import vgm as V
from .database import reading

# doc type, combined-set name (§12), file name part, Vietnamese name, step
DOCUMENTS = (
    ("BOOKING", "01_Booking_Confirmation", "Booking_Confirmation", "Xác nhận đặt chỗ", 1),
    ("EIR", "02_Empty_Container_EIR", "Empty_Container_EIR", "Phiếu EIR cấp container rỗng", 2),
    ("VGM", "03_VGM_Declaration", "VGM_Declaration", "Phiếu xác nhận khối lượng toàn bộ container", 3),
    ("SI", "04_Shipping_Instruction", "Shipping_Instruction", "Phiếu hướng dẫn lập vận đơn", 4),
    ("GATEIN", "05_Export_GateIn_Registration", "Export_GateIn_Registration", "Xác nhận hạ bãi và đăng ký xuất tàu", 5),
    ("BL", "06_Bill_of_Lading", "Bill_of_Lading", "Vận đơn đường biển", 6),
)
DOC_TYPES = tuple(d[0] for d in DOCUMENTS)


def display_name(set_name: str) -> str:
    """"05_Export_GateIn_Registration" → "05 Export Gate-in Registration"."""
    return set_name.replace("_", " ").replace("GateIn", "Gate-in")


class ExportError(S.ShipmentError):
    pass


def _builders():
    from . import pdf_bl, pdf_gatein, pdf_generator, pdf_si, pdf_vgm
    return {"BOOKING": pdf_generator.build_booking_confirmation_pdf_bytes,
            "EIR": pdf_generator.build_empty_eir_pdf_bytes, "VGM": pdf_vgm.build_vgm_declaration_pdf_bytes,
            "SI": pdf_si.build_shipping_instruction_pdf_bytes, "GATEIN": pdf_gatein.build_export_gatein_pdf_bytes,
            "BL": pdf_bl.build_bill_of_lading_pdf_bytes}


# ---------------------------------------------------------------------------
# What can be exported
# ---------------------------------------------------------------------------
def check(shipment_id: str, selected: list[str] | None = None, only_completed: bool = False) -> dict:
    """Documents with existence, version, status and step status; warnings; the documents that will be exported."""
    from .library import document_status
    from .workflow import shipment_step_statuses
    ship = S.get_shipment(shipment_id)
    if not ship:
        raise ExportError([f"Không tìm thấy lô hàng {shipment_id}."])
    steps = shipment_step_statuses(shipment_id)
    bkv = B.get_booking_view(shipment_id)
    eirs = [i["eir"] for i in E.get_shipment_eirs(shipment_id)["items"] if i["eir"]]
    vgms = [i["vgm"] for i in V.get_shipment_vgms(shipment_id)["items"] if i["vgm"]]
    siv = SI.get_si_view(shipment_id)
    gates = [i for i in G.get_shipment_gateins(shipment_id)["items"] if i["record"] or i["events"]]
    blv = BL.get_bl_view(shipment_id)
    info = {
        "BOOKING": (bkv["exists"], bkv["booking"].get("doc_version")),
        "EIR": (bool(eirs), max((r.get("doc_version") or 1 for r in eirs), default=None)),
        "VGM": (bool(vgms), max((r.get("doc_version") or 1 for r in vgms), default=None)),
        "SI": (siv["exists"], siv["si"].get("doc_version")),
        "GATEIN": (bool(gates), max(((i["record"] or {}).get("doc_version") or 1 for i in gates), default=None)),
        "BL": (blv["exists"], (blv["record"] or {}).get("doc_version")),
    }
    selected = list(selected) if selected is not None else list(DOC_TYPES)
    docs, warnings, export = [], [], []
    for n, (doc_type, set_name, file_part, name_vi, step) in enumerate(DOCUMENTS):
        exists, version = info[doc_type]
        step_status = steps[n]
        doc = {"doc_type": doc_type, "set_name": set_name, "file_part": file_part, "name_vi": name_vi, "step": step,
               "exists": exists, "version": f"v{version or 1}" if exists else None,
               "status": document_status(shipment_id, doc_type) if exists else "Chưa có",
               "step_status": step_status, "selected": doc_type in selected}
        if doc["selected"]:
            if not exists:
                warnings.append(f"{display_name(set_name)}: chưa có chứng từ ở Bước {step} — không có trong bộ xuất.")
            elif only_completed and step_status != "Completed":
                warnings.append(f"{display_name(set_name)}: bước {step} chưa hoàn thành ({step_status}) — bỏ qua vì chỉ xuất chứng từ "
                                "đã hoàn thành.")
            else:
                export.append(doc_type)
                if step_status != "Completed":
                    warnings.append(f"{display_name(set_name)}: bước {step} chưa hoàn thành ({step_status}) — PDF vẫn xuất, ghi rõ "
                                    "nhãn DRAFT / INTERNAL trên chứng từ.")
        docs.append(doc)
    incomplete = [d for d in docs if d["step_status"] != "Completed"]
    return {"shipment": ship, "documents": docs, "export": export, "warnings": warnings,
            "incomplete": [f"Bước {d['step']} · {display_name(d['set_name'])}: {d['step_status']}" for d in incomplete]}


def file_name(ship: dict, doc: dict) -> str:
    """ShipmentID_BookingNumber_DocumentName_Version.pdf (REQUIREMENTS.md §12)."""
    from .pdf_generator import safe_filename_part
    return (f"{safe_filename_part(ship['shipment_id'], 'SHIPMENT')}_"
            f"{safe_filename_part(ship.get('booking_number'), 'NO-BOOKING')}_{doc['file_part']}_{doc['version']}.pdf")


def _folder(shipment_id: str) -> Path:
    from .pdf_generator import safe_filename_part
    folder = settings.EXPORT_DIR / safe_filename_part(shipment_id, "SHIPMENT")
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def _stamp() -> str:
    return datetime.now().strftime("%Y%m%d-%H%M%S")


def _log(shipment_id: str, kind: str, path: Path, result: dict, docs: list[str]) -> None:
    from .history import log_event
    from .library import register
    register(shipment_id, "EXPORT", kind, path, status=f"{len(docs)} chứng từ",
             details={"documents": docs, "warnings": result["warnings"]})
    log_event(shipment_id, "SHIPMENT", f"Xuất {kind}", None, f"{path.name} — " + (", ".join(docs) or "dữ liệu"),
              "EXPORT", "; ".join(result["incomplete"]) or None, doc_label="Xuất chứng từ", field_key=f"export.{kind}")


# ---------------------------------------------------------------------------
# Combined PDF with a cover page
# ---------------------------------------------------------------------------
def _cover(result: dict, pages: dict, exported_at: datetime) -> bytes:
    from .pdf_generator import (MARGIN_BOTTOM, MARGIN_TOP, MARGIN_X, NAVY, NAVY_SOFT, TABLE_FONT, W, Paragraph,
                                _numbered_canvas, _page_decorator, _styles, note_box, sample_banner, txt)
    from .services import STEP_STATUSES
    st = _styles()
    ship = result["shipment"]
    vi = dict(STEP_STATUSES)
    sample = S.sample_text(ship)
    story = [Paragraph("EXPORT DOCUMENT SET", st["title"]),
             Paragraph("Bộ chứng từ xuất khẩu container · cover page / trang bìa", st["subtitle"]), Spacer(1, 4 * mm)]
    if sample:
        story += [sample_banner(st, sample), Spacer(1, 3 * mm)]
    head = [("Shipment ID", ship["shipment_id"]), ("Booking No.", ship.get("booking_number")),
            ("Shipper", (ship["parties"].get("SHIPPER") or {}).get("party_name")),
            ("Consignee", (ship["parties"].get("CONSIGNEE") or {}).get("party_name")),
            ("Vessel / Voyage", " / ".join(x for x in (ship.get("vessel_name"), ship.get("voyage_number")) if x) or None),
            ("POL → POD".replace("→", "»"), " » ".join(x for x in (ship.get("port_of_loading"), ship.get("port_of_discharge")) if x) or None),
            ("Exported", exported_at.strftime("%d %b %Y %H:%M").upper())]
    t = Table([[Paragraph(k.upper(), st["label"]), Paragraph(txt(v), st["value_b"])] for k, v in head],
              colWidths=[W * 0.25, W * 0.75])
    t.setStyle(TableStyle(TABLE_FONT + [("BOX", (0, 0), (-1, -1), 0.6, NAVY), ("INNERGRID", (0, 0), (-1, -1), 0.3,
                                                                                  colors.HexColor("#C5CFDC")),
                                        ("BACKGROUND", (0, 0), (0, -1), NAVY_SOFT), ("VALIGN", (0, 0), (-1, -1), "MIDDLE")]))
    story += [t, Spacer(1, 5 * mm), Paragraph("DOCUMENTS IN THIS SET · CHỨNG TỪ TRONG BỘ", st["subhead"]),
              Spacer(1, 1.5 * mm)]
    rows = [[Paragraph(h, st["th"]) for h in ("#", "DOCUMENT", "VERSION", "DOCUMENT STATUS", "STEP STATUS", "PAGES")]]
    for d in result["documents"]:
        included = d["doc_type"] in pages
        rows.append([Paragraph(d["set_name"][:2], st["cell"]),
                     Paragraph(f"<b>{display_name(d['set_name'])[3:]}</b><br/><font size='6.6' color='#5B6B82'>"
                               f"{d['name_vi']}</font>", st["cell"]),
                     Paragraph(d["version"] or "—", st["cell"]),
                     Paragraph(txt(d["status"]), st["cell"]),
                     Paragraph(f"{d['step_status']}<br/><font size='6.6' color='#5B6B82'>{vi.get(d['step_status'], '')}"
                               "</font>", st["cell"]),
                     Paragraph((f"{pages[d['doc_type']][0]}" if pages[d['doc_type']][0] == pages[d['doc_type']][1]
                                else f"{pages[d['doc_type']][0]}–{pages[d['doc_type']][1]}") if included else
                               "<font color='#9C2F23'>not included</font>", st["cell"])])
    table = Table(rows, colWidths=[W * w for w in (0.06, 0.34, 0.09, 0.2, 0.19, 0.12)], repeatRows=1)
    table.setStyle(TableStyle(TABLE_FONT + [("BACKGROUND", (0, 0), (-1, 0), NAVY), ("BOX", (0, 0), (-1, -1), 0.6, NAVY),
                                            ("LINEBELOW", (0, 0), (-1, -1), 0.3, colors.HexColor("#C5CFDC")),
                                            ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    story += [table, Spacer(1, 5 * mm)]
    if result["incomplete"]:
        story += [note_box(st, "draft", "INCOMPLETE STEPS · BƯỚC CHƯA HOÀN THÀNH", " · ".join(result["incomplete"]),
                           fine="Each document carries its own label (DRAFT / INTERNAL RECORD / REFERENCE COPY). Documents "
                                "that are not completed are not confirmed by the carrier, depot or terminal."),
                  Spacer(1, 3 * mm)]
    story.append(note_box(st, "reference", "ABOUT THIS SET",
                          f"Compiled by {APP_NAME} from the documents above, in the fixed order 01-06. Every document keeps "
                          "its own page numbering and footer. This cover page is not part of any document.",
                          fine=f"{APP_NAME} never invents official numbers, signatures, stamps or confirmations."))
    buffer = io.BytesIO()
    footer = [f"Shipment ID: {ship['shipment_id']}   ·   Booking No.: {ship.get('booking_number') or '—'}   ·   Cover page",
              "Export document set" + (f" · {sample} DATA" if sample else "")
              + f" · Exported: {exported_at.strftime('%d %b %Y %H:%M').upper()}"]
    doc = SimpleDocTemplate(buffer, pagesize=A4, leftMargin=MARGIN_X, rightMargin=MARGIN_X, topMargin=MARGIN_TOP,
                            bottomMargin=MARGIN_BOTTOM, title=f"Export document set — {ship['shipment_id']}",
                            author=APP_NAME)
    decorate = _page_decorator("SAMPLE" if sample else None, None)
    doc.build(story, onFirstPage=decorate, onLaterPages=decorate, canvasmaker=_numbered_canvas(footer))
    return buffer.getvalue()


def _render_documents(shipment_id: str, export: list[str]) -> dict:
    builders = _builders()
    return {doc_type: builders[doc_type](shipment_id) for doc_type in export}


def combined_pdf_bytes(shipment_id: str, selected: list[str] | None = None, only_completed: bool = False) -> tuple[bytes, dict]:
    import pypdfium2 as pdfium
    result = check(shipment_id, selected, only_completed)
    if not result["export"]:
        raise ExportError(["Không có chứng từ nào để xuất (chưa có, hoặc chưa chọn)."] + result["warnings"])
    parts = _render_documents(shipment_id, result["export"])
    counts = {k: len(pdfium.PdfDocument(v)) for k, v in parts.items()}
    exported_at = datetime.now()
    cover = _cover(result, {}, exported_at)
    cover_pages = len(pdfium.PdfDocument(cover))
    pages, start = {}, cover_pages + 1
    for doc_type in result["export"]:
        pages[doc_type] = (start, start + counts[doc_type] - 1)
        start += counts[doc_type]
    cover = _cover(result, pages, exported_at)
    merged = pdfium.PdfDocument.new()
    for data in [cover] + [parts[d] for d in result["export"]]:
        merged.import_pages(pdfium.PdfDocument(data))
    buffer = io.BytesIO()
    merged.save(buffer)
    result["pages"] = pages
    result["cover_pages"] = cover_pages
    return buffer.getvalue(), result


def export_combined_pdf(shipment_id: str, selected: list[str] | None = None, only_completed: bool = False) -> tuple[Path, dict]:
    data, result = combined_pdf_bytes(shipment_id, selected, only_completed)
    ship = result["shipment"]
    from .pdf_generator import safe_filename_part
    path = _folder(shipment_id) / (f"{safe_filename_part(ship['shipment_id'], 'SHIPMENT')}_"
                                   f"{safe_filename_part(ship.get('booking_number'), 'NO-BOOKING')}_"
                                   f"Document_Set_{_stamp()}.pdf")
    path.write_bytes(data)
    _log(shipment_id, "COMBINED", path, result, result["export"])
    return path, result


# ---------------------------------------------------------------------------
# ZIP of separate PDFs
# ---------------------------------------------------------------------------
def export_zip(shipment_id: str, selected: list[str] | None = None, only_completed: bool = False) -> tuple[Path, dict]:
    result = check(shipment_id, selected, only_completed)
    if not result["export"]:
        raise ExportError(["Không có chứng từ nào để xuất (chưa có, hoặc chưa chọn)."] + result["warnings"])
    parts = _render_documents(shipment_id, result["export"])
    ship = result["shipment"]
    from .pdf_generator import safe_filename_part
    path = _folder(shipment_id) / (f"{safe_filename_part(ship['shipment_id'], 'SHIPMENT')}_"
                                   f"{safe_filename_part(ship.get('booking_number'), 'NO-BOOKING')}_"
                                   f"Documents_{_stamp()}.zip")
    names = []
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for doc in result["documents"]:
            if doc["doc_type"] in parts:
                name = f"{doc['set_name'][:2]}_{file_name(ship, doc)}"     # 01_… 06_: the fixed order
                z.writestr(name, parts[doc["doc_type"]])
                names.append(name)
    result["files"] = names
    _log(shipment_id, "ZIP", path, result, result["export"])
    return path, result


# ---------------------------------------------------------------------------
# JSON of all shipment data
# ---------------------------------------------------------------------------
def shipment_data(shipment_id: str) -> dict:
    from . import validation
    from .workflow import shipment_step_statuses
    ship = S.get_shipment(shipment_id)
    if not ship:
        raise ExportError([f"Không tìm thấy lô hàng {shipment_id}."])
    fk = ship["id"]

    def rows(sql):
        with reading() as conn:
            return [dict(r) for r in conn.execute(sql, (fk,))]

    strip = lambda items: [{k: v for k, v in r.items() if k not in ("file_path", "last_pdf_path")} for r in items]
    bl_rows = rows("SELECT * FROM bl_records WHERE shipment_fk = ?")
    for r in bl_rows:
        r["particulars"] = json.loads(r["particulars"]) if r.get("particulars") else None
    result = validation.run(shipment_id)
    return {
        "export": {"app": APP_NAME, "format": "export-docs-shipment/1", "exported_at": datetime.now().isoformat(timespec="seconds"),
                   "sample_label": S.sample_text(ship),
                   "note": "Data recorded in the app. Statuses are the user's records; confirmations need the "
                           "carrier's / terminal's own documents."},
        "shipment": {k: v for k, v in ship.items() if k not in ("parties", "cargo", "containers", "overrides")},
        "parties": ship["parties"], "cargo_lines": ship["cargo"], "containers": ship["containers"],
        "cargo_per_container": rows("SELECT * FROM container_cargo WHERE shipment_fk = ?"),
        "documents": {
            "booking": strip(rows("SELECT * FROM bookings WHERE shipment_fk = ?")),
            "eir": strip(rows("SELECT * FROM eir_records WHERE shipment_fk = ?")),
            "vgm": strip(rows("SELECT * FROM vgm_records WHERE shipment_fk = ?")),
            "shipping_instruction": strip(rows("SELECT * FROM si_records WHERE shipment_fk = ?")),
            "gate_in": strip(rows("SELECT * FROM gatein_records WHERE shipment_fk = ?")),
            "gate_in_status_events": rows("SELECT * FROM gatein_status_events WHERE shipment_fk = ?"),
            "gate_in_evidence": strip(rows("SELECT * FROM gatein_evidence WHERE shipment_fk = ?")),
            "bill_of_lading": strip(bl_rows),
            "bl_status_events": rows("SELECT * FROM bl_status_events WHERE shipment_fk = ?"),
            "bl_carrier_documents": strip(rows("SELECT * FROM bl_documents WHERE shipment_fk = ?")),
        },
        "uploads": strip(rows("SELECT * FROM uploaded_documents WHERE shipment_fk = ?")),
        "document_versions": _versions(shipment_id),
        "step_statuses": dict(zip([d[1] for d in DOCUMENTS], shipment_step_statuses(shipment_id, result))),
        "validation": [{"field": c["field"], "data": c["state"], "confirmation": c["confirmation"],
                        "confirmed_by": c["confirmation_by"], "values": c["values"]} for c in result["checks"]],
        "open_sync_conflicts": [{k: c[k] for k in ("doc_type", "field_label", "doc_value", "new_value", "cause")}
                                for c in result["conflicts"]],
    }


def _versions(shipment_id: str) -> list[dict]:
    """Every version of every document, oldest first — v1 included even for a document never changed since it
    was created (it has no stored history yet: its current content IS v1)."""
    from . import history as H
    out = []
    for doc in H.documents_of(shipment_id):
        for v in reversed(H.list_versions(shipment_id, doc["doc_type"], doc["container_fk"])):
            stored = v["id"] is not None
            out.append({"doc_type": doc["doc_type"], "document": doc["label"], "container_fk": doc["container_fk"],
                        "version": v["version"], "kind": v["kind"] if stored else "Current (no change recorded)",
                        "status": v["status"], "reason": v["reason"], "created_by": v["created_by"] if stored else None,
                        "created_at": v["created_at"] if stored else None, "stored_in_history": stored})
    return out


def export_json(shipment_id: str) -> tuple[Path, dict]:
    data = shipment_data(shipment_id)
    ship = S.get_shipment(shipment_id)
    from .pdf_generator import safe_filename_part
    path = _folder(shipment_id) / (f"{safe_filename_part(shipment_id, 'SHIPMENT')}_"
                                   f"{safe_filename_part(ship.get('booking_number'), 'NO-BOOKING')}_"
                                   f"Shipment_Data_{_stamp()}.json")
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    _log(shipment_id, "JSON", path, {"warnings": [], "incomplete": []}, [])
    return path, data
