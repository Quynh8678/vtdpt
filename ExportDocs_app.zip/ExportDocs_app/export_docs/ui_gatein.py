"""Step 5 — Export Gate-in & Loading Registration page (REQUIREMENTS.md §5 Step 5).

Central data (🔗) is read-only. The port facts are typed in by the user; each of the 9 statuses is
recorded on its own (source, who, when) and never changes because another one changed.
"""

from pathlib import Path

import gradio as gr
import pandas as pd

from . import gatein as G
from . import reference
from . import pdf_gatein as PG
from . import shipments as S
from .formatting import fmt_datetime, fmt_kg
from .pdf_generator import render_pdf_pages
from .ui_common import e, message_html, notice_html, page_title_html, section_title_html, shipment_tracker_html
from .workflow import shipment_step_statuses

OVERVIEW_COLUMNS = ["#", "Container No.", "Seal (SI)", "Cargo gross (kg)", "VGM (kg)", "Gate-in", "Luồng HQ",
                    "Trạng thái hiện tại", "Bằng chứng"]
STATUS_CHOICES = [(f"{en} — {vi}", k) for k, en, vi in G.STATUSES]
ACTION_CHOICES = [("Xác nhận (SET)", "SET"), ("Bỏ — không còn đúng (CLEAR)", "CLEAR")]
SOURCE_CHOICES = [("Nhập tay (Manual entry)", "MANUAL"), ("File đã tải lên (Uploaded file)", "UPLOADED_FILE")]
LANE_CHOICES = [(f"{en} — {vi}", k) for k, (en, vi) in G.CUSTOMS_LANES.items()]
LANE_ICON = {"GREEN": "🟢", "YELLOW": "🟡", "RED": "🔴"}
TABLE_CSS = """
.gi-table{width:100%;border-collapse:collapse;font-size:13px;margin:4px 0 8px}
.gi-table th{background:#0B2545;color:#fff;text-align:left;padding:5px 6px;font-weight:600}
.gi-table td{border-bottom:1px solid #E1E7EF;padding:4px 6px;vertical-align:top}
.gi-table tr.on td{background:#E6F4EC}
.gi-table tr.hold td{background:#FDECEA}
"""


def central_info_html(ship: dict | None) -> str:
    if not ship:
        return notice_html("Chọn một lô hàng để bắt đầu Bước 5.")
    vessel = " / ".join(x for x in (ship.get("vessel_name"), ship.get("voyage_number")) if x) or None
    route = " → ".join(x for x in (ship.get("port_of_loading"), ship.get("port_of_discharge")) if x) or None
    cells = [("Booking No.", ship.get("booking_number")), ("Carrier", ship.get("carrier_name")),
             ("Vessel / Voyage", vessel), ("POL → POD", route),
             ("CY cut-off", fmt_datetime(ship.get("cy_cutoff")) if ship.get("cy_cutoff") else None)]
    items = "".join(f'<div class="kpi"><div class="label">🔗 {e(k)}</div>'
                    f'<div class="value" style="font-size:14px">{e(v) if v else "⚠️ thiếu"}</div></div>' for k, v in cells)
    return (f'<div class="kpi-grid">{items}</div>'
            '<div class="hint">🔗 Dữ liệu chung — chỉ xem. Sửa ở Bước 1 (nút bên dưới).</div>')


def overview_table(overview: dict | None) -> pd.DataFrame:
    rows = []
    for i in (overview or {}).get("items", []):
        c, rec = i["container"], i["record"] or {}
        lane = rec.get("customs_lane")
        rows.append([i["no"], c.get("container_number") or "(chưa có số)", c.get("seal_number") or "⚠️ thiếu",
                     fmt_kg(i["cargo_gross"]), fmt_kg(c.get("vgm_kg")) if c.get("vgm_kg") is not None else "⚠️ chưa có",
                     fmt_datetime(rec.get("gatein_datetime")) if rec.get("gatein_datetime") else "—",
                     f"{LANE_ICON[lane]} {G.CUSTOMS_LANES[lane][0]}" if lane in G.CUSTOMS_LANES else "—",
                     ", ".join(G.STATUS_NAMES[k] for k in G.active_statuses(i)) or "—", len(i["evidence"])])
    return pd.DataFrame(rows, columns=OVERVIEW_COLUMNS)


def picker_choices(overview: dict | None) -> list:
    return [(f"{i['no']}. {i['container'].get('container_number') or '(chưa có số)'} · "
             f"{', '.join(G.STATUS_NAMES[k] for k in G.active_statuses(i)) or 'chưa có trạng thái'}",
             str(i["container"]["id"])) for i in (overview or {}).get("items", [])]


def container_html(item: dict | None) -> str:
    if not item:
        return ""
    c = item["container"]
    size = " ".join(x for x in (f"{c['container_size']}'" if c.get("container_size") else None,
                                c.get("iso_type_code"), c.get("container_type")) if x) or None
    cells = [("Container No.", c.get("container_number")), ("Size / ISO / Type", size), ("Seal (SI)", c.get("seal_number")),
             (f"Cargo gross (kg) — {item['cargo_gross_source']}",
              fmt_kg(item["cargo_gross"]) if item["cargo_gross"] is not None else None),
             ("Tare (kg)", fmt_kg(c.get("tare_weight_kg")) if c.get("tare_weight_kg") is not None else None),
             ("VGM (kg) — Bước 3", fmt_kg(c.get("vgm_kg")) if c.get("vgm_kg") is not None else None)]
    items = "".join(f'<div class="kpi"><div class="label">🔗 {e(k)}</div>'
                    f'<div class="value" style="font-size:14px">{e(v) if v else "⚠️ thiếu"}</div></div>' for k, v in cells)
    return f'<div class="kpi-grid">{items}</div>'


def status_html(overview: dict | None, item: dict | None) -> str:
    if not overview or not item:
        return ""
    warnings = G.checks(overview["shipment"], item)
    name = item["container"].get("container_number") or f"container #{item['no']}"
    active = ", ".join(G.STATUS_NAMES[k] for k in G.active_statuses(item)) or "chưa có trạng thái nào được xác nhận"
    title = f"{name}: {active} · INTERNAL RECORD / REFERENCE COPY"
    if G.is_active(item, "HOLD_REJECTED"):
        return message_html("error", title, warnings)
    return message_html("warning" if warnings else "success", title, warnings or ["Không có cảnh báo."])


def timeline_html(item: dict | None) -> str:
    if not item:
        return ""
    rows = []
    for n, (key, en, vi) in enumerate(G.STATUSES, start=1):
        ev = item["current"].get(key)
        active = bool(ev and ev["action"] == "SET")
        if ev:
            when = fmt_datetime(ev["event_datetime"]) if ev["event_datetime"] else "—"
            proof = G.evidence_name(item, ev["evidence_fk"]) if ev["evidence_fk"] else None
            detail = " · ".join(x for x in (f"📎 {proof}" if proof else None, ev.get("note")) if x)
            cells = [("Bỏ · " if ev["action"] == "CLEAR" else "") + when, G.SOURCES[ev["source"]], ev["confirmed_by"],
                     detail or "—", fmt_datetime(ev["recorded_at"][:16])]
        else:
            cells = ["—"] * 5
        cls = ("hold" if key == "HOLD_REJECTED" else "on") if active else ""
        rows.append(f"<tr class='{cls}'><td>{n}</td><td>{'✅' if active else '⬜'} <b>{e(en)}</b><br>"
                    f"<span class='hint'>{e(vi)}</span></td>" + "".join(f"<td>{e(v)}</td>" for v in cells) + "</tr>")
    table = ("<table class='gi-table'><tr><th>#</th><th>Trạng thái</th><th>Thời điểm (theo nguồn)</th><th>Nguồn</th>"
             "<th>Người xác nhận</th><th>Bằng chứng / ghi chú</th><th>Ghi nhận lúc</th></tr>" + "".join(rows) + "</table>")
    history = "".join(
        f"<tr><td>{fmt_datetime(ev['recorded_at'][:16])}</td><td>{e(G.STATUS_NAMES[ev['status_key']])}</td>"
        f"<td>{'Xác nhận' if ev['action'] == 'SET' else 'Bỏ'}</td><td>{e(G.SOURCES[ev['source']])}</td>"
        f"<td>{e(ev['confirmed_by'])}</td></tr>" for ev in reversed(item["events"]))
    if history:
        table += ("<details><summary>Lịch sử thay đổi (mới nhất trước)</summary><table class='gi-table'>"
                  "<tr><th>Ghi nhận lúc</th><th>Trạng thái</th><th>Thao tác</th><th>Nguồn</th><th>Người</th></tr>"
                  + history + "</table></details>")
    return table


def evidence_html(item: dict | None) -> str:
    if not item:
        return ""
    if not item["evidence"]:
        return notice_html("Chưa có file bằng chứng. Tải lên xác nhận của cảng (PDF / ảnh) để dùng làm nguồn cho trạng thái.")
    rows = "".join(f"<tr><td>{x['id']}</td><td>📎 {e(x['file_name'])}</td><td>{e(x.get('description'))}</td>"
                   f"<td>{e(x.get('uploaded_by'))}</td><td>{fmt_datetime(x['uploaded_at'][:16])}</td></tr>"
                   for x in item["evidence"])
    return ("<table class='gi-table'><tr><th>ID</th><th>File</th><th>Mô tả</th><th>Người tải</th><th>Lúc</th></tr>"
            + rows + "</table>")


def evidence_choices(item: dict | None) -> list:
    return [(f"#{x['id']} · {x['file_name']}", str(x["id"])) for x in (item or {}).get("evidence", [])]


def build_gatein_page():
    """Returns (inputs, outputs, refresh, edit-at-source button, shipment dropdown)."""
    rec_in = {}
    gr.HTML(page_title_html("Bước 5 · Export Gate-in & Loading Registration",
                            "Theo dõi container hàng xuất tại cảng — mỗi container một bản ghi"))
    gr.HTML(f"<style>{TABLE_CSS}</style>")
    ship_dd = gr.Dropdown(label="Chọn lô hàng (Shipment)", choices=[])
    tracker = gr.HTML()
    central = gr.HTML(central_info_html(None))
    edit_source_btn = gr.Button("✏️ Sửa Booking / Vessel / POL / POD / CY cut-off ở Bước 1", size="sm",
                                elem_classes="fit-btn")
    gr.HTML(notice_html("<b>INTERNAL RECORD / REFERENCE COPY</b> — app không kết nối ePort của cảng. Số giao dịch, số "
                        "đăng ký, số EIR của cảng chỉ do bạn nhập từ dữ liệu thật; app <b>không bao giờ tự tạo</b>."))
    gr.HTML(section_title_html("Container của lô hàng", "Containers at the terminal"))
    overview_df = gr.Dataframe(value=pd.DataFrame(columns=OVERVIEW_COLUMNS), interactive=False, wrap=True)
    picker = gr.Dropdown(label="Chọn container", choices=[])
    container_box = gr.HTML()
    status_box = gr.HTML()

    with gr.Tabs(selected="info"):
        with gr.Tab("📝 Thông tin cảng", id="info"):
            with gr.Accordion("Terminal — cảng / bãi", open=True):
                with gr.Row():
                    rec_in["terminal_name"] = gr.Dropdown(label="Tên cảng / terminal", allow_custom_value=True,
                                                          choices=reference.choices("TERMINAL"), value=None)
                    rec_in["terminal_area"] = gr.Textbox(label="Khu vực (Terminal area)")
                    rec_in["gatein_datetime"] = gr.DateTime(label="Ngày giờ gate-in", include_time=True, type="string")
                with gr.Row():
                    rec_in["transaction_ref"] = gr.Textbox(label="Số giao dịch của cảng (Transaction ref.)",
                                                           placeholder="Chỉ nhập số thật từ cảng")
                    rec_in["registration_no"] = gr.Textbox(label="Số đăng ký (Registration no.)",
                                                           placeholder="Chỉ nhập số thật từ cảng")
                    rec_in["gatein_eir_no"] = gr.Textbox(label="Số EIR gate-in của cảng",
                                                         placeholder="Chỉ nhập số thật từ cảng")
                rec_in["gatein_seal_number"] = gr.Textbox(
                    label="Số seal lúc gate-in (seal at gate-in)",
                    info="Gõ số seal thực tế trên container khi vào cổng — app so với seal trên SI.")
            with gr.Accordion("Vận chuyển (Transport)", open=True):
                with gr.Row():
                    rec_in["truck_number"] = gr.Textbox(label="Số xe (Truck no.)")
                    rec_in["chassis_number"] = gr.Textbox(label="Số rơ-moóc (Chassis no.)")
                    rec_in["vehicle_arrival"] = gr.DateTime(label="Xe đến cảng lúc", include_time=True, type="string")
                    rec_in["container_arrival"] = gr.DateTime(label="Container vào bãi lúc", include_time=True,
                                                              type="string")
            with gr.Accordion("Bãi (Yard)", open=False):
                with gr.Row():
                    rec_in["yard_location"] = gr.Textbox(label="Vị trí bãi (Yard location)")
                    rec_in["yard_block"] = gr.Textbox(label="Block")
                    rec_in["yard_bay"] = gr.Textbox(label="Bay")
                    rec_in["yard_row"] = gr.Textbox(label="Row")
                    rec_in["yard_tier"] = gr.Textbox(label="Tier")
                rec_in["container_condition"] = gr.Dropdown(label="Tình trạng container", choices=list(G.CONDITIONS),
                                                            allow_custom_value=True)
            with gr.Accordion("Hải quan (Customs)", open=True):
                with gr.Row():
                    rec_in["customs_declaration_no"] = gr.Textbox(label="Số tờ khai hải quan",
                                                                  info="Tờ khai xuất khẩu Việt Nam: 12 chữ số.")
                    rec_in["customs_declaration_date"] = gr.DateTime(label="Ngày tờ khai", include_time=False,
                                                                     type="string")
                    rec_in["customs_office"] = gr.Textbox(label="Chi cục hải quan")
                with gr.Row():
                    rec_in["customs_lane"] = gr.Radio(label="Phân luồng (Customs lane)", choices=LANE_CHOICES, value=None)
                    rec_in["customs_clearance_date"] = gr.DateTime(label="Ngày thông quan", include_time=False,
                                                                   type="string")
                    rec_in["customs_supervision_status"] = gr.Dropdown(
                        label="Giám sát hải quan (Supervision)", choices=list(G.SUPERVISION_STATUSES),
                        allow_custom_value=True)
            with gr.Accordion("Đăng ký xuất & xếp tàu (Export registration)", open=False):
                gr.HTML(notice_html("Tình trạng <b>đăng ký xuất tàu</b> được ghi ở tab 🚦 Trạng thái — bước "
                                    "<b>Export Registration Pending</b> / <b>Export Registration Confirmed</b>, "
                                    "có ngày, nguồn và người xác nhận."))
                with gr.Row():
                    rec_in["vessel_loading_status"] = gr.Dropdown(
                        label="Tình trạng xếp tàu", choices=list(G.LOADING_STATUSES), allow_custom_value=True)
                with gr.Row():
                    rec_in["loading_confirmation_ref"] = gr.Textbox(label="Số xác nhận xếp tàu (nếu có, từ cảng)")
                    rec_in["actual_loading_datetime"] = gr.DateTime(label="Thời điểm xếp tàu thực tế",
                                                                    include_time=True, type="string")
            rec_in["remarks"] = gr.Textbox(label="Ghi chú (Remarks)", lines=2)
            gr.HTML(notice_html("Lưu thông tin ở đây <b>không đổi trạng thái nào</b>. Trạng thái được ghi nhận riêng "
                                "ở tab 🚦 Trạng thái."))
            info_msg = gr.HTML()
            save_btn = gr.Button("💾 Lưu thông tin cảng", variant="primary")

        with gr.Tab(f"🚦 Trạng thái ({len(G.STATUSES)})", id="status"):
            gr.HTML(notice_html(f"{len(G.STATUSES)} trạng thái <b>riêng biệt</b>. Mỗi lần ghi nhận chỉ đổi <b>một</b> trạng thái — "
                                "app không bao giờ tự đổi trạng thái khác (VD: thông quan ≠ sẵn sàng xếp tàu). "
                                "Luôn ghi <b>nguồn</b>, <b>người xác nhận</b> và <b>thời điểm</b>."))
            timeline = gr.HTML()
            with gr.Group():
                with gr.Row():
                    ev_status = gr.Dropdown(label="Trạng thái", choices=STATUS_CHOICES, value="GATE_IN_COMPLETED")
                    ev_action = gr.Radio(label="Thao tác", choices=ACTION_CHOICES, value="SET")
                    ev_when = gr.DateTime(label="Thời điểm xảy ra (theo nguồn)", include_time=True, type="string")
                with gr.Row():
                    ev_source = gr.Radio(label="Nguồn", choices=SOURCE_CHOICES, value="MANUAL")
                    ev_evidence = gr.Dropdown(label="File bằng chứng (khi nguồn là file)", choices=[])
                with gr.Row():
                    ev_by = gr.Textbox(label="Người xác nhận (Confirmed by) *")
                    ev_note = gr.Textbox(label="Ghi chú / lấy thông tin từ đâu (bắt buộc khi nhập tay)",
                                         placeholder="VD: màn hình ePort, email của cảng lúc 10:05")
                status_msg = gr.HTML()
                status_btn = gr.Button("🚦 Ghi nhận trạng thái này", variant="primary")

        with gr.Tab("📎 Bằng chứng", id="evidence"):
            evidence_box = gr.HTML()
            with gr.Row():
                upload = gr.File(label="Tải lên xác nhận của cảng / ảnh (PDF, JPG, PNG, XLSX)",
                                 file_types=list(G.EVIDENCE_TYPES), type="filepath")
                with gr.Column():
                    up_desc = gr.Textbox(label="Mô tả file")
                    up_by = gr.Textbox(label="Người tải lên")
                    upload_btn = gr.Button("📎 Lưu file bằng chứng")
            evidence_msg = gr.HTML()

        with gr.Tab("👁 Xem trước & Xuất PDF", id="pdf"):
            gr.HTML(notice_html("Xem trước dùng <b>dữ liệu đã lưu</b>. Mỗi container một trang A4."))
            with gr.Row():
                preview_one_btn = gr.Button("👁 Xem trước container đang chọn")
                preview_all_btn = gr.Button("👁 Xem trước tất cả")
            with gr.Row():
                export_one_btn = gr.Button("📄 Xuất PDF container đang chọn", variant="primary")
                export_all_btn = gr.Button("📄 Xuất PDF tất cả (1 file)", variant="primary")
            with gr.Row():
                download_one = gr.DownloadButton("⬇ Tải", visible=False)
                download_all = gr.DownloadButton("⬇ Tải tất cả", visible=False)
            export_msg = gr.HTML()
            gallery = gr.Gallery(label="Bản xem trước (mỗi ảnh là một trang A4)", columns=1, height="auto",
                                 object_fit="contain")

    rec_keys = list(G.RECORD_FIELDS)
    rec_inputs = [rec_in[k] for k in rec_keys]
    item_outputs = [container_box, status_box, *rec_inputs, timeline, evidence_box, ev_evidence]
    head_outputs = [tracker, central, overview_df, picker]

    # ------------------------------------------------------------------ logic
    def _cid(value):
        return None if value in (None, "") else int(value)

    def item_values(overview, container_id):
        item = G.find_item(overview, container_id) if overview and container_id is not None else None
        c = (item or {}).get("container") or {}
        rec = (item or {}).get("record") or {}
        values = []
        for k in rec_keys:
            v = rec.get(k)
            if not rec and k in ("truck_number", "chassis_number"):
                v = c.get(k)                                   # first gate-in: suggest the truck from Step 2
            if k in G.DATETIME_FIELDS:
                v = f"{v}:00" if v else None
            elif k in G.DATE_FIELDS or k in ("customs_lane", "container_condition", "customs_supervision_status",
                                              "export_registration_status", "vessel_loading_status"):
                v = v or None
            elif k == "terminal_name":                         # pick list from Settings, typing still works
                v = gr.update(value=v or None, choices=reference.choices("TERMINAL", v))
            else:
                v = v or ""
            values.append(v)
        return [container_html(item), status_html(overview, item), *values, timeline_html(item), evidence_html(item),
                gr.update(choices=evidence_choices(item), value=None)]

    def load(shipment_id, preferred=None):
        overview = G.get_shipment_gateins(shipment_id) if shipment_id else None
        choices = picker_choices(overview)
        ids = [v for _, v in choices]
        pick = preferred if preferred in ids else (ids[0] if ids else None)
        tracker_html = shipment_tracker_html(shipment_step_statuses(shipment_id) if overview else ["Not Started"] * 6)
        return ([tracker_html, central_info_html(overview["shipment"] if overview else None), overview_table(overview),
                 gr.update(choices=choices, value=pick)] + item_values(overview, _cid(pick)))

    def refresh(shipment_id):
        choices = [(f"{r['shipment_id']} · {r.get('booking_number') or 'chưa có booking'} · "
                    f"{r.get('customer_name') or r.get('shipper_name') or ''}", r["shipment_id"])
                   for r in S.list_shipments()]
        ids = [c[1] for c in choices]
        if shipment_id not in ids:
            shipment_id = ids[0] if ids else None
        return [gr.update(choices=choices, value=shipment_id), *load(shipment_id)]

    def on_pick(shipment_id, picked):
        overview = G.get_shipment_gateins(shipment_id) if shipment_id else None
        return item_values(overview, _cid(picked))

    skip = lambda: [gr.skip()] * (len(head_outputs) + len(item_outputs))

    def save(shipment_id, picked, *values):
        cid = _cid(picked)
        if not shipment_id or cid is None:
            return skip() + [message_html("warning", "Hãy chọn lô hàng và container trước.")]
        try:
            result = G.save_gatein(shipment_id, cid, dict(zip(rec_keys, values)))
        except S.ShipmentError as ex:
            return skip() + [message_html("error", "Chưa lưu được:", ex.errors)]
        msg = message_html("warning" if result.warnings else "success",
                           "Đã lưu thông tin cảng (không trạng thái nào thay đổi)." + (" Lưu ý:" if result.warnings else ""),
                           result.warnings)
        return load(shipment_id, picked) + [msg]

    def add_status(shipment_id, picked, key, action, when, source, evidence, by, note):
        cid = _cid(picked)
        if not shipment_id or cid is None:
            return skip() + [message_html("warning", "Hãy chọn lô hàng và container trước.")]
        try:
            result = G.record_status(shipment_id, cid, key, action, when, source, by, note,
                                     int(evidence) if evidence else None)
        except S.ShipmentError as ex:
            return skip() + [message_html("error", "Chưa ghi nhận được:", ex.errors)]
        verb = "Đã xác nhận" if action == "SET" else "Đã bỏ"
        msg = message_html("warning" if result.warnings else "success",
                           f"{verb} “{G.STATUS_NAMES[key]}” — chỉ trạng thái này thay đổi."
                           + (" Lưu ý:" if result.warnings else ""), result.warnings)
        return load(shipment_id, picked) + [msg]

    def do_upload(shipment_id, picked, path, desc, by):
        cid = _cid(picked)
        if not shipment_id or cid is None:
            return skip() + [message_html("warning", "Hãy chọn lô hàng và container trước."), gr.skip()]
        if not path:
            return skip() + [message_html("warning", "Hãy chọn file trước."), gr.skip()]
        try:
            eid = G.add_evidence(shipment_id, cid, path, desc, by)
        except S.ShipmentError as ex:
            return skip() + [message_html("error", "Chưa lưu được file:", ex.errors), gr.skip()]
        return load(shipment_id, picked) + [message_html(
            "success", f"Đã lưu file bằng chứng #{eid}.", ["Dùng file này làm nguồn khi ghi nhận trạng thái (tab 🚦)."]),
            None]

    def _preview(shipment_id, ids):
        if not shipment_id:
            return None, message_html("warning", "Hãy chọn lô hàng trước.")
        try:
            pages = render_pdf_pages(PG.build_export_gatein_pdf_bytes(shipment_id, ids), scale=1.6)
        except S.ShipmentError as ex:
            return None, message_html("error", "Không tạo được bản xem trước.", ex.errors)
        return pages, message_html("info", f"Bản xem trước: {len(pages)} trang.")

    def _export(shipment_id, ids):
        if not shipment_id:
            return gr.skip(), message_html("warning", "Hãy chọn lô hàng trước.")
        try:
            path = PG.generate_export_gatein_pdf(shipment_id, ids)
        except S.ShipmentError as ex:
            return gr.skip(), message_html("error", "Chưa xuất được PDF.", ex.errors)
        return (gr.update(value=str(path), visible=True, label=f"⬇ Tải ({path.name})"),
                message_html("success", f"Đã xuất PDF: {path.name}", [f"Lưu tại: {path}"]))

    def _one(fn, shipment_id, picked):
        cid = _cid(picked)
        if cid is None:
            return (gr.skip() if fn is _export else None), message_html("warning", "Hãy chọn một container.")
        return fn(shipment_id, [cid])

    # ------------------------------------------------------------------ events
    all_outputs = [*head_outputs, *item_outputs]
    ship_dd.change(lambda s: load(s) + ["", "", "", None, ""], ship_dd,
                   [*all_outputs, info_msg, status_msg, evidence_msg, gallery, export_msg])
    picker.change(on_pick, [ship_dd, picker], item_outputs)
    save_btn.click(save, [ship_dd, picker, *rec_inputs], [*all_outputs, info_msg])
    status_btn.click(add_status, [ship_dd, picker, ev_status, ev_action, ev_when, ev_source, ev_evidence, ev_by, ev_note],
                     [*all_outputs, status_msg])
    upload_btn.click(do_upload, [ship_dd, picker, upload, up_desc, up_by], [*all_outputs, evidence_msg, upload])
    preview_one_btn.click(lambda s, p: _one(_preview, s, p), [ship_dd, picker], [gallery, export_msg])
    preview_all_btn.click(lambda s: _preview(s, None), ship_dd, [gallery, export_msg])
    export_one_btn.click(lambda s, p: _one(_export, s, p), [ship_dd, picker], [download_one, export_msg])
    export_all_btn.click(lambda s: _export(s, None), ship_dd, [download_all, export_msg])

    return [ship_dd], [ship_dd, *all_outputs], refresh, edit_source_btn, ship_dd
