"""Phase 5 — Validation Center (REQUIREMENTS.md §9).

run(shipment_id) checks, across all six steps: booking no., container nos., seals, shipper, consignee,
notify party, POL / POD, vessel / voyage, cargo description, packages, gross weight, CBM, VGM, freight
terms and cut-offs. Every check has TWO independent results:

    Data agreement         Valid · Missing · Mismatch
                           (is the value there, and do Master / SI / B/L / … say the same?)
    External confirmation  Confirmed · Pending confirmation · Not required
                           (has the outside party confirmed it, with evidence — and which document?)
        booking no., POL, POD, vessel / voyage, cut-offs → the carrier's booking confirmation (Step 1)
        container nos.                                    → the depot's EIR number per container (Step 2)
        VGM                                               → acknowledgement per container (Step 3)
        seals                                             → seal recorded at gate-in WITH evidence: an uploaded
                                                            file or a terminal reference (Step 5)
        parties, cargo, packages, weight, CBM, freight    → the B/L issued by the carrier (Step 6)

A mismatch shows the field, the value in each document, a suggested value, the severity and how to fix
it. Nothing is ever fixed automatically: "apply this value" actions are offered and only run when the
user clicks them — through the normal save functions, so every change is in the change log.
"""

from datetime import datetime, timedelta

from . import bl as BL
from . import bookings as B
from . import eir as E
from . import gatein as G
from . import shipments as S
from . import si as SI
from . import sync
from . import tracking
from . import vgm as V
from .formatting import fmt_cbm, fmt_count, fmt_kg

VALID, MISSING, MISMATCH = "Valid", "Missing", "Mismatch"                          # data agreement
CONFIRMED, PENDING, NOT_REQUIRED = "Confirmed", "Pending confirmation", "Not required"  # external confirmation
STATES = {VALID: "Hợp lệ (khớp)", MISSING: "Thiếu dữ liệu", MISMATCH: "Không khớp"}
CONFIRM_STATES = {CONFIRMED: "Đã xác nhận", PENDING: "Chờ xác nhận", NOT_REQUIRED: "Không cần xác nhận"}
# which outside confirmation covers each check
CONFIRMED_BY = {
    "booking_number": "booking", "port_of_loading": "booking", "port_of_discharge": "booking",
    "vessel_voyage": "booking", "cy_cutoff": "booking", "si_cutoff": "booking", "vgm_cutoff": "booking",
    "containers": "eir", "vgm": "vgm", "seals": "gatein",
    "shipper": "bl", "consignee": "bl", "notify": "bl", "description": "bl", "package_count": "bl",
    "gross_weight_kg": "bl", "volume_cbm": "bl", "freight_terms": "bl",
}
SEVERITY = {"error": "Lỗi — phải sửa", "warning": "Cảnh báo — nên kiểm tra", "info": "Thông tin"}
M, BK, EI, VG, SIN, GT, BLN = ("Dữ liệu lô hàng (Master)", "Booking (Bước 1)", "EIR (Bước 2)", "VGM (Bước 3)",
                               "SI (Bước 4)", "Gate-in (Bước 5)", "B/L (Bước 6)")
TOL_KG, TOL_CBM = 0.5, 0.0005


def _norm(value) -> str:
    return sync.norm(value)


def _check(key, field, state, step, values, severity=None, suggested=None, fix=None, actions=None, note=None) -> dict:
    if severity is None:
        severity = {MISMATCH: "error", MISSING: "error"}.get(state, "info")
    return {"key": key, "field": field, "state": state, "state_vi": STATES[state], "step": step, "values": values,
            "severity": severity, "suggested": suggested, "fix": fix, "actions": actions or [], "note": note,
            "confirmation": NOT_REQUIRED, "confirmation_vi": CONFIRM_STATES[NOT_REQUIRED], "confirmation_by": None}


# ---------------------------------------------------------------------------
# External confirmation — separate from data agreement
# ---------------------------------------------------------------------------
def _confirmations(ctx: dict) -> dict:
    """{source: (Confirmed / Pending confirmation, what confirms it or what is still needed)}."""
    bk = ctx["bkv"]["booking"]
    if ctx["booking_confirmed"]:
        booking = (CONFIRMED, f"Hãng tàu đã xác nhận booking — ref. {bk.get('confirmation_reference')} (Bước 1)")
    elif ctx["bkv"]["exists"] and bk.get("booking_status") in ("Booking Confirmed", "Booking Amended")             and B.has_carrier_evidence(bk):
        booking = (PENDING, "Dữ liệu đã đổi sau khi hãng tàu xác nhận — cần hãng tàu xác nhận lại "
                            "(Booking Amended + số tham chiếu mới, Bước 1)")
    else:
        booking = (PENDING, "Chờ hãng tàu xác nhận booking: ghi trạng thái Booking Confirmed + nguồn + "
                            "số tham chiếu xác nhận (Bước 1)")
    containers = ctx["ship"]["containers"]
    n = len(containers)
    depot = sum(1 for c in containers if c.get("eir_number"))
    eir = ((CONFIRMED, "Mọi container có số EIR của depot (Bước 2)") if n and depot == n else
           (PENDING, f"Chờ số EIR của depot: {depot}/{n} container (Bước 2)"))
    items = ctx["vgm"]["items"]
    ack = sum(1 for i in items if (i["vgm"] or {}).get("vgm_status") == "Acknowledged")
    vgm = ((CONFIRMED, "Hãng tàu / cảng đã xác nhận VGM (acknowledgement) cho mọi container (Bước 3)") if n and ack == n
           else (PENDING, f"Chờ xác nhận VGM (acknowledgement): {ack}/{n} container (Bước 3)"))
    # a seal is confirmed only by a gate-in record WITH evidence: an uploaded file or a terminal reference
    gate = {i["container"]["id"]: i for i in ctx["gate"]["items"]}
    matching, evidenced = 0, 0
    for c in containers:
        item = gate.get(c["id"]) or {}
        rec = item.get("record") or {}
        if rec.get("gatein_seal_number") and _norm(rec["gatein_seal_number"]) == _norm(c.get("seal_number")):
            matching += 1
            if item.get("evidence") or rec.get("gatein_eir_no") or rec.get("transaction_ref"):
                evidenced += 1
    if n and evidenced == n:
        gatein = (CONFIRMED, "Seal khi hạ bãi trùng SI, có bằng chứng (file tải lên / số tham chiếu của cảng) "
                             "cho mọi container (Bước 5)")
    else:
        gatein = (PENDING, f"Chờ bằng chứng seal khi hạ bãi: {evidenced}/{n} container có file tải lên hoặc số "
                           f"tham chiếu của cảng (Gate-in EIR No. / Transaction ref.)"
                           + (f"; {matching - evidenced} container chỉ nhập tay" if matching > evidenced else "")
                           + " (Bước 5)")
    if ctx["bl_official"]:
        bl = (CONFIRMED, f"B/L do hãng tàu phát hành — số {ctx['blv']['record'].get('carrier_bl_number')} (Bước 6)")
    elif ctx["si_submitted"]:
        bl = (PENDING, "SI đã gửi hãng tàu — chờ hãng tàu phát hành B/L (Bước 6)")
    else:
        bl = (PENDING, "Chờ: gửi SI cho hãng tàu (Bước 4) → hãng tàu phát hành B/L (Bước 6)")
    return {"booking": booking, "eir": eir, "vgm": vgm, "gatein": gatein, "bl": bl}


def _attach_confirmation(check: dict, confirmations: dict) -> dict:
    source = CONFIRMED_BY.get(check["key"])
    if source and not (check["key"] == "notify" and check.get("not_required")):
        check["confirmation"], check["confirmation_by"] = confirmations[source]
    check["confirmation_vi"] = CONFIRM_STATES[check["confirmation"]]
    return check




# ---------------------------------------------------------------------------
# Context: every document of the shipment, read once
# ---------------------------------------------------------------------------
def _context(shipment_id: str) -> dict | None:
    ship = S.get_shipment(shipment_id)
    if not ship:
        return None
    blv = BL.get_bl_view(shipment_id)
    siv = blv["si_view"]
    bkv = B.get_booking_view(shipment_id)
    booking = bkv["booking"]
    booking_confirmed = (bkv["exists"] and booking["booking_status"] in ("Booking Confirmed", "Booking Amended")
                         and B.has_carrier_evidence(booking) and not B.changed_since_confirmation(bkv))
    return {
        "ship": ship, "si_ship": siv["shipment"], "siv": siv, "si_exists": siv["exists"], "si": siv["si"],
        "si_submitted": siv["exists"] and siv["si"]["si_status"] in SI.SUBMITTED_STATES,
        "blv": blv, "bl_exists": blv["exists"], "bl_official": blv["exists"] and BL.is_official_copy(blv),
        "bl_part": blv["particulars"] if blv["exists"] else None,
        "bl_diffs": {d["key"]: d for d in BL.differences(blv)} if blv["exists"] else {},
        "bkv": bkv, "booking_confirmed": booking_confirmed,
        "vgm": V.get_shipment_vgms(shipment_id), "gate": G.get_shipment_gateins(shipment_id),
        "eir": E.get_shipment_eirs(shipment_id), "overrides": siv["shipment"].get("overrides") or {},
    }


# ---------------------------------------------------------------------------
# Field checks: Master vs SI vs B/L
# ---------------------------------------------------------------------------
def _override_actions(ctx: dict, keys: list[str], label: str) -> list[dict]:
    out = []
    over = [k for k in keys if k in ctx["overrides"]]
    if over:
        out.append({"id": f"si_master|{'+'.join(over)}", "kind": "si_use_master", "fields": over,
                    "label": f"SI dùng giá trị Master cho {label} (SI phải gửi bản sửa đổi cho hãng tàu)"})
        out.append({"id": f"master_from_si|{'+'.join(over)}", "kind": "master_from_si", "fields": over,
                    "values": {k: ctx["overrides"][k]["value"] for k in over},
                    "label": f"Master dùng giá trị SI đã gửi hãng tàu cho {label} (mọi chứng từ theo)"})
    return out


def _bl_action(ctx: dict, key: str, label: str) -> list[dict]:
    d = ctx["bl_diffs"].get(key)
    if not d:
        return []
    return [{"id": f"bl_si|{key}", "kind": "bl_use_si", "key": key,
             "label": f"B/L dùng giá trị SI cho {d['label']}: “{(d['si'] or '—').splitlines()[0]}”"}]


def _scalar_check(ctx, key, field, step, master, si_value, bl_value, override_keys, bl_key, required=True):
    values = [(M, master or "—")]
    if ctx["si_exists"]:
        values.append((SIN, si_value or "—"))
    if ctx["bl_exists"]:
        values.append((BLN, bl_value or "—"))
    if required and not _norm(master):
        return _check(key, field, MISSING, step, values, fix=f"Nhập {field} (Bước 1 hoặc Quản lý lô hàng).")
    problems, actions = [], []
    suggested = master
    if ctx["si_exists"] and _norm(si_value) != _norm(master):
        problems.append(f"SI giữ giá trị đã gửi hãng tàu “{si_value or '—'}”, Master đã đổi thành “{master or '—'}”.")
        actions += _override_actions(ctx, override_keys, field)
    if ctx["bl_exists"] and bl_key in ctx["bl_diffs"]:
        problems.append(f"B/L ghi “{bl_value or '—'}”, SI ghi “{si_value or '—'}” (B/L được đối chiếu với SI).")
        actions += _bl_action(ctx, bl_key, field)
        if not problems[:-1]:
            suggested = si_value
    if problems:
        return _check(key, field, MISMATCH, step, values, suggested=suggested,
                      fix=" ".join(problems) + " Chọn nguồn đúng rồi bấm “Áp dụng giá trị này”; "
                                                "chứng từ đã gửi / đã phát hành cần bản sửa đổi.",
                      actions=actions)
    return _check(key, field, VALID, step, values)


def _party_checks(ctx) -> list[dict]:
    out = []
    consignee = SI.party(ctx["ship"], "CONSIGNEE").get("party_name")
    for role, key, field in (("SHIPPER", "shipper", "Shipper"), ("CONSIGNEE", "consignee", "Consignee"),
                             ("NOTIFY_PARTY", "notify", "Notify Party")):
        master = BL._party_text(ctx["ship"], role)
        si_value = BL._party_text(ctx["si_ship"], role)
        bl_value = ctx["bl_part"].get(key) if ctx["bl_part"] else None
        required = role != "NOTIFY_PARTY" or SI.is_to_order(consignee)
        if role == "NOTIFY_PARTY" and not master and not required:
            check = _check(key, field, VALID, 4, [(M, "— (không bắt buộc: consignee có tên cụ thể)")])
            check["not_required"] = True
            out.append(check)
            continue
        out.append(_scalar_check(ctx, key, field, 4, master, si_value, bl_value, [f"party:{role}"], key,
                                 required=required))
    return out


def _routing_checks(ctx) -> list[dict]:
    ship, si_ship, part = ctx["ship"], ctx["si_ship"], ctx["bl_part"] or {}
    out = []
    for key, field in (("port_of_loading", "Port of Loading (POL)"), ("port_of_discharge", "Port of Discharge (POD)")):
        out.append(_scalar_check(ctx, key, field, 1, ship.get(key), si_ship.get(key), part.get(key), [key], key))
    vv = lambda d: " / ".join(x for x in (d.get("vessel_name"), d.get("voyage_number")) if x) or None
    check = _scalar_check(ctx, "vessel_voyage", "Vessel / Voyage", 1, vv(ship), vv(si_ship), vv(part),
                          ["vessel_name", "voyage_number"], "vessel_voyage")
    if check["state"] == MISSING or (not ship.get("vessel_name") or not ship.get("voyage_number")):
        check = _check("vessel_voyage", "Vessel / Voyage", MISSING, 1, check["values"],
                       fix="Nhập Vessel và Voyage ở Bước 1.")
    out.append(check)
    return out


def _booking_check(ctx) -> dict:
    ship, si_ship = ctx["ship"], ctx["si_ship"]
    master = ship.get("booking_number")
    values = [(M + " / " + BK, master or "—")]
    if ctx["si_exists"]:
        values.append((SIN, si_ship.get("booking_number") or "—"))
    stale = []
    for item in ctx["vgm"]["items"]:
        rec = item["vgm"]
        if rec and rec["vgm_status"] in V.DECLARED_STATES and rec.get("declared_booking_number") \
                and rec["declared_booking_number"] != master:
            stale.append(item)
            values.append((f"{VG} — {item['container'].get('container_number') or '#' + str(item['no'])}",
                           rec["declared_booking_number"]))
    if not master:
        return _check("booking_number", "Booking No.", MISSING, 1, values, fix="Nhập Booking No. ở Bước 1.")
    problems, actions = [], []
    if ctx["si_exists"] and _norm(si_ship.get("booking_number")) != _norm(master):
        problems.append("SI đã gửi hãng tàu với Booking No. khác.")
        actions += _override_actions(ctx, ["booking_number"], "Booking No.")
    if stale:
        problems.append("VGM đã khai với Booking No. cũ — mở Bước 3 và lưu / khai lại VGM của các container này.")
    if problems:
        return _check("booking_number", "Booking No.", MISMATCH, 1, values, suggested=master,
                      fix=" ".join(problems), actions=actions)
    return _check("booking_number", "Booking No.", VALID, 1, values)


def _container_checks(ctx) -> list[dict]:
    """Container numbers in Master, SI, Gate-in and B/L.

    SI and Gate-in show the central container record (one copy), so they can only differ from Master if
    that rule is broken; the B/L keeps its own copy (its text), compared with the SI.
    """
    ship = ctx["ship"]
    containers = ship["containers"]
    numbers = [c.get("container_number") for c in containers]
    show = lambda ns: ", ".join(n or "(chưa có số)" for n in ns) or "—"
    values = [(M, show(numbers))]
    problems = []
    if ctx["si_exists"]:
        si_numbers = [c.get("container_number") for c in ctx["si_ship"]["containers"]]
        values.append((SIN, show(si_numbers)))
        if [_norm(n) for n in si_numbers] != [_norm(n) for n in numbers]:
            problems.append("Danh sách container trên SI khác Master.")
    gated = [i for i in ctx["gate"]["items"] if i["record"] or i["events"]]
    if gated:
        gate_numbers = [i["container"].get("container_number") for i in gated]
        values.append((f"{GT} — {len(gated)}/{len(containers)} container đã có dữ liệu cảng", show(gate_numbers)))
        master_numbers = {_norm(n) for n in numbers}
        if any(_norm(n) not in master_numbers for n in gate_numbers):
            problems.append("Container ở Gate-in không có trong Master.")
    if ctx["bl_exists"]:
        values.append((BLN, show(c.get("container_number") for c in ctx["bl_part"]["containers"])))
        if "containers" in ctx["bl_diffs"]:
            problems.append("Danh sách container trên B/L khác SI.")
    out = []
    if not containers or not all(numbers):
        out.append(_check("containers", "Container No.", MISSING, 2, values,
                          fix=f"{sum(1 for n in numbers if not n)} container chưa có số — nhập ở Bước 2 (EIR) "
                              "hoặc Quản lý lô hàng." if containers else "Lô hàng chưa có container."))
    elif problems:
        out.append(_check("containers", "Container No.", MISMATCH, 6 if "containers" in ctx["bl_diffs"] else 2,
                          values, suggested=values[0][1], fix=" ".join(problems),
                          actions=_bl_action(ctx, "containers", "containers")))
    else:
        out.append(_check("containers", "Container No.", VALID, 2, values))
    bad = [(n, S.container_number_problem(n)) for n in numbers if n and S.container_number_problem(n)]
    if bad:
        out.append(_check("container_digits", "Container No. (ISO 6346)", MISMATCH, 2,
                          [(M, f"{n}: {p}") for n, p in bad], severity="warning",
                          fix="Kiểm tra lại số container trên cửa container / EIR của depot.",
                          suggested="Số container đúng theo ISO 6346"))
    return out


def _seal_check(ctx) -> dict:
    items = {i["container"]["id"]: i for i in ctx["gate"]["items"]}
    bl_containers = {c.get("container_number"): c for c in (ctx["bl_part"] or {}).get("containers", [])}
    values, problems, actions, missing, confirmed = [], [], [], [], 0
    for c in ctx["ship"]["containers"]:
        name = c.get("container_number") or "(chưa có số)"
        seal = c.get("seal_number")
        if not seal:
            missing.append(name)
        values.append((f"{M} / {SIN} — {name}", seal or "—"))
        rec = (items.get(c["id"]) or {}).get("record") or {}
        gate_seal = rec.get("gatein_seal_number")
        if gate_seal:
            values.append((f"{GT} — {name}", gate_seal))
            if _norm(gate_seal) != _norm(seal):
                problems.append(f"{name}: seal khi hạ bãi “{gate_seal}” ≠ seal trên SI “{seal or '—'}”.")
                actions.append({"id": f"seal_gate|{c['id']}", "kind": "container_set", "container_id": c["id"],
                                "field": "seal_number", "value": gate_seal,
                                "label": f"Dữ liệu chung / SI dùng seal ghi nhận khi hạ bãi cho {name}: {gate_seal}"})
            else:
                confirmed += 1
        bl_c = bl_containers.get(c.get("container_number"))
        if bl_c is not None and f"seal:{name}" in ctx["bl_diffs"]:
            values.append((f"{BLN} — {name}", bl_c.get("seal_number") or "—"))
            problems.append(f"{name}: seal trên B/L khác SI.")
            actions += _bl_action(ctx, f"seal:{name}", f"seal {name}")
    if problems:
        return _check("seals", "Seal No.", MISMATCH, 5, values, suggested="Seal ghi nhận khi hạ bãi (thực tế tại cảng)",
                      fix=" ".join(problems) + " Kiểm tra seal thật trên container.", actions=actions)
    if missing or not ctx["ship"]["containers"]:
        return _check("seals", "Seal No.", MISSING, 4, values, severity="warning",
                      fix="Chưa có số seal: " + ", ".join(missing) + " — nhập ở Bước 4 (SI) khi đã niêm phong.")
    return _check("seals", "Seal No.", VALID, 4, values)


def _cargo_checks(ctx) -> list[dict]:
    ship, siv = ctx["ship"], ctx["siv"]
    lines = ship["cargo"]
    t = SI.totals(siv)
    allocated = bool(siv["allocations"])
    bl_cargo = (ctx["bl_part"] or {}).get("cargo") or []
    out = []

    # description, per line: Master vs SI vs B/L
    si_cargo = ctx["si_ship"]["cargo"] if ctx["si_exists"] else []
    values, missing, actions, problems = [], [], [], []
    for n, line in enumerate(lines, start=1):
        desc = line.get("cargo_description")
        short = lambda d: (d or "—")[:160] + ("…" if len(d or "") > 160 else "")
        values.append((f"{M} — dòng {n}", short(desc)))
        if not desc:
            missing.append(str(n))
        if ctx["si_exists"]:
            si_desc = si_cargo[n - 1].get("cargo_description") if n <= len(si_cargo) else None
            values.append((f"{SIN} — dòng {n}", short(si_desc)))
            if _norm(si_desc) != _norm(desc):
                problems.append(f"Dòng {n}: mô tả trên SI khác Master.")
        if ctx["bl_exists"]:
            bl_desc = bl_cargo[n - 1].get("description") if n <= len(bl_cargo) else None
            values.append((f"{BLN} — dòng {n}", short(bl_desc)))
            if f"description:{n}" in ctx["bl_diffs"]:
                problems.append(f"Dòng {n}: mô tả trên B/L khác SI.")
                actions += _bl_action(ctx, f"description:{n}", f"mô tả dòng {n}")
    if not lines or missing:
        out.append(_check("description", "Cargo description", MISSING, 4, values,
                          fix=("Chưa có dòng hàng." if not lines else f"Dòng {', '.join(missing)} chưa có mô tả hàng "
                                                                       "tiếng Anh — nhập ở Quản lý lô hàng → Cargo.")))
    elif problems:
        out.append(_check("description", "Cargo description", MISMATCH, 6, values, suggested="Mô tả trên SI (= Master)",
                          fix=" ".join(problems) + " B/L được đối chiếu với SI; SI lấy mô tả từ Master.",
                          actions=actions))
    else:
        out.append(_check("description", "Cargo description", VALID, 4, values))

    # packages / gross / CBM totals
    def total(key):
        return sum(l.get(key) or 0 for l in lines)

    for key, field, fmt, tol, alloc_key, kind in (
            ("package_count", "Number of packages", fmt_count, 0, "packages", "packages"),
            ("gross_weight_kg", "Gross weight (kg)", fmt_kg, TOL_KG, "gross", "gross"),
            ("volume_cbm", "Measurement (CBM)", fmt_cbm, TOL_CBM, "cbm", "cbm")):
        line_total = total(key)
        values = [(f"{M} — dòng hàng ({len(lines)} dòng)", fmt(line_total))]
        problems, actions = [], []
        missing = [str(n) for n, l in enumerate(lines, start=1) if l.get(key) in (None, "")]
        if allocated:
            values.append((f"{SIN} — hàng theo container", fmt(t["allocated"][alloc_key])))
            if abs(t["allocated"][alloc_key] - line_total) > tol:
                problems.append(f"Hàng đã phân bổ vào container ({fmt(t['allocated'][alloc_key])}) ≠ dòng hàng "
                                f"({fmt(line_total)}) — sửa ở Bước 4 → tab Cargo Details.")
        if key == "gross_weight_kg":
            weights = [c.get("cargo_weight_kg") for c in ship["containers"]]
            if weights and all(w is not None for w in weights):
                cont_total = sum(weights)
                numbered = sum(c["cargo_weight_kg"] for c in ship["containers"] if c.get("container_number"))
                values.append((f"{M} — Cargo Weight của {len(weights)} container", fmt(cont_total)))
                if numbered != cont_total:
                    values.append((f"   trong đó {sum(1 for c in ship['containers'] if c.get('container_number'))} "
                                   "container đã có số", fmt(numbered)))
                if abs(cont_total - line_total) > tol:
                    problems.append(f"Tổng Cargo Weight của container ({fmt(cont_total)} kg) ≠ Gross của dòng hàng "
                                    f"({fmt(line_total)} kg).")
                    if cont_total:
                        actions.append({"id": "scale_containers", "kind": "containers_scale", "target": line_total,
                                        "label": f"Đặt Cargo Weight các container theo tổng dòng hàng "
                                                 f"{fmt(line_total)} kg (chia theo tỷ lệ hiện tại)"})
                    if len(lines) == 1:
                        actions.append({"id": "line_from_containers", "kind": "cargo_line_set", "line_id": lines[0]["id"],
                                        "field": "gross_weight_kg", "value": round(cont_total, 3),
                                        "label": f"Đặt Gross của dòng hàng = tổng Cargo Weight container "
                                                 f"({fmt(cont_total)} kg)"})
        if ctx["bl_exists"]:
            bl_total = sum(l.get(key) or 0 for l in bl_cargo)
            values.append((BLN, fmt(bl_total)))
            for n in range(1, len(lines) + 1):
                if f"{kind}:{n}" in ctx["bl_diffs"]:
                    problems.append(f"B/L dòng {n} khác SI.")
                    actions += _bl_action(ctx, f"{kind}:{n}", f"dòng {n}")
        if not lines or (missing and key != "volume_cbm"):
            out.append(_check(key, field, MISSING, 4, values, fix=f"Dòng {', '.join(missing)} chưa có {field.lower()} "
                                                                  "— nhập ở Quản lý lô hàng → Cargo."))
        elif problems:
            out.append(_check(key, field, MISMATCH, 4, values, suggested=f"{fmt(line_total)} (dòng hàng — nguồn của SI "
                                                                         "và B/L; đối chiếu packing list / phiếu cân)",
                              fix=" ".join(problems) + " Người dùng chọn nguồn đúng — không tự sửa.", actions=actions))
        elif missing:
            out.append(_check(key, field, MISSING, 4, values, severity="warning",
                              fix=f"Dòng {', '.join(missing)} chưa có CBM — nên nhập trước khi gửi SI."))
        else:
            out.append(_check(key, field, VALID, 4, values))
    return out


def _vgm_check(ctx) -> dict:
    ship = ctx["ship"]
    values, missing, problems, acknowledged, declared = [], [], [], 0, 0
    for item in ctx["vgm"]["items"]:
        c, rec = item["container"], item["vgm"]
        name = c.get("container_number") or f"#{item['no']}"
        if not rec or rec["vgm_status"] not in V.DECLARED_STATES or c.get("vgm_kg") is None:
            missing.append(name)
            values.append((f"{VG} — {name}", "chưa khai" if not rec else f"{V.status_label(rec['vgm_status'])} (chưa khai)"))
            continue
        declared += 1
        values.append((f"{VG} — {name}", f"{fmt_kg(c['vgm_kg'])} kg · {V.status_label(rec['vgm_status'])}"))
        blocking, _ = V.checks(ship, c, rec)
        if blocking:
            problems.append(f"{name}: " + " ".join(blocking))
        if rec["vgm_status"] == "Acknowledged":
            acknowledged += 1
    if problems:
        return _check("vgm", "VGM", MISMATCH, 3, values, suggested="Khai lại VGM với dữ liệu hiện tại",
                      fix=" ".join(problems) + " — sửa và lưu lại ở Bước 3.")
    if missing or not ship["containers"]:
        cutoff = S.to_datetime(ship.get("vgm_cutoff"))
        late = bool(cutoff and datetime.now() > cutoff)
        return _check("vgm", "VGM", MISSING, 3, values, severity="error" if late else "warning",
                      fix=f"Chưa khai VGM: {', '.join(missing)} — khai ở Bước 3." + (" ĐÃ QUÁ VGM cut-off." if late else ""))
    return _check("vgm", "VGM", VALID, 3, values)


def _freight_check(ctx) -> dict:
    si = ctx["si"]
    terms = SI.FREIGHT_TERMS.get(si.get("freight_terms")) if ctx["si_exists"] else None
    values = [(SIN, (terms or "—") + (f" · payable at {si['payable_at']}" if si.get("payable_at") else ""))]
    if ctx["bl_exists"]:
        values.append((BLN, values[0][1] + " (lấy trực tiếp từ SI)"))
    if not ctx["si_exists"] or not terms:
        return _check("freight_terms", "Freight terms", MISSING, 4, values,
                      fix="Chọn Freight terms (Prepaid / Collect) ở Bước 4 → tab Freight.")
    if si["freight_terms"] == "COLLECT" and not si.get("payable_at"):
        return _check("freight_terms", "Freight terms", MISSING, 4, values,
                      fix="Freight Collect: nhập nơi thanh toán (Payable at) ở Bước 4.")
    return _check("freight_terms", "Freight terms", VALID, 4, values)


def _cutoff_checks(ctx, now: datetime) -> list[dict]:
    ship = ctx["ship"]
    items = ctx["gate"]["items"]
    done = {
        "si_cutoff": ctx["si_submitted"],
        "vgm_cutoff": bool(ctx["vgm"]["items"]) and all((i["vgm"] or {}).get("vgm_status") in V.SUBMITTED_STATES
                                                        for i in ctx["vgm"]["items"]),
        "cy_cutoff": bool(items) and all(any(G.is_active(i, k) for k in ("GATE_IN_COMPLETED", *G.AT_LEAST_READY))
                                         for i in items),
    }
    what = {"si_cutoff": "SI chưa gửi", "vgm_cutoff": "VGM chưa gửi hết", "cy_cutoff": "chưa hạ bãi hết container"}
    step = {"si_cutoff": 4, "vgm_cutoff": 3, "cy_cutoff": 5}
    out = []
    for key, label in S.CUTOFF_LABELS.items():
        value = ship.get(key)
        values = [(M + " / " + BK, value or "—")]
        if not value:
            out.append(_check(key, label, MISSING, 1, values, fix=f"Nhập {label} ở Bước 1."))
            continue
        cutoff = S.to_datetime(value)
        severity, note = "info", None
        if not done[key] and cutoff and now > cutoff:
            severity, note = "error", f"ĐÃ QUÁ HẠN — {what[key]}. Liên hệ hãng tàu ngay."
        elif not done[key] and cutoff and cutoff - now <= timedelta(hours=24):
            severity, note = "warning", f"Còn dưới 24 giờ — {what[key]}."
        elif done[key]:
            note = "Đã hoàn thành trước hạn." if cutoff and now <= cutoff else "Đã hoàn thành."
        out.append(_check(key, label, VALID, step[key], values, severity=severity, note=note,
                          fix="Liên hệ hãng tàu ngay." if severity == "error" else None))
    return out


# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------
def run(shipment_id: str, now: datetime | None = None) -> dict | None:
    ctx = _context(shipment_id)
    if not ctx:
        return None
    now = now or datetime.now()
    checks = [_booking_check(ctx), *_container_checks(ctx), _seal_check(ctx), *_party_checks(ctx),
              *_routing_checks(ctx), *_cargo_checks(ctx), _vgm_check(ctx), _freight_check(ctx),
              *_cutoff_checks(ctx, now)]
    confirmations = _confirmations(ctx)
    checks = [_attach_confirmation(c, confirmations) for c in checks]
    conflicts = sync.list_conflicts(shipment_id)
    counts = {s: sum(c["state"] == s for c in checks) for s in STATES}
    confirm_counts = {s: sum(c["confirmation"] == s for c in checks) for s in CONFIRM_STATES}
    errors = [c for c in checks if c["severity"] == "error"]
    data_ok = all(c["state"] == VALID for c in checks) and not conflicts and not errors
    confirmed_ok = all(c["confirmation"] in (CONFIRMED, NOT_REQUIRED) for c in checks)
    return {
        "shipment_id": shipment_id, "checks": checks, "counts": counts, "confirm_counts": confirm_counts,
        "conflicts": conflicts, "has_mismatch": counts[MISMATCH] > 0 or bool(conflicts), "errors": errors,
        "data_ok": data_ok, "confirmed_ok": confirmed_ok,
        # a shipment can only be Completed when every value agrees AND every confirmation has evidence
        "complete_ok": data_ok and confirmed_ok,
        "ship": ctx["ship"],
    }


def actions_of(result: dict) -> list[dict]:
    return [dict(a, check=c["field"]) for c in result["checks"] for a in c["actions"]]


def apply_action(shipment_id: str, action_id: str, reason: str | None = None) -> str:
    """Run ONE "apply this value" action chosen by the user (through the normal, logged save functions)."""
    result = run(shipment_id)
    act = next((a for a in actions_of(result or {"checks": []}) if a["id"] == action_id), None)
    if not act:
        raise S.ShipmentError(["Hành động này không còn áp dụng (dữ liệu có thể đã thay đổi) — bấm “Kiểm tra lại”."])
    why = f"Trung tâm kiểm tra — {act['check']}: {act['label']}" + (f" — {S.clean_text(reason)}" if S.clean_text(reason) else "")
    with tracking.action("APPLY", why):
        kind = act["kind"]
        if kind == "bl_use_si":
            BL.apply_si_value(shipment_id, act["key"], reason=why)
        elif kind == "si_use_master":
            for key in act["fields"]:
                sync.remove_si_override(shipment_id, key, reason=why)
            sync.close_conflicts(shipment_id, "SI", act["fields"], "Áp dụng giá trị Master ở Trung tâm kiểm tra")
        elif kind == "master_from_si":
            S.update_central(shipment_id, act["values"], reason=why)
        elif kind == "container_set":
            S.update_rows(shipment_id, containers={act["container_id"]: {act["field"]: act["value"]}}, reason=why)
        elif kind == "cargo_line_set":
            S.update_rows(shipment_id, cargo={act["line_id"]: {act["field"]: act["value"]}}, reason=why)
        elif kind == "containers_scale":
            S.update_rows(shipment_id, containers=_scaled(result["ship"]["containers"], act["target"]), reason=why)
        else:
            raise S.ShipmentError(["Hành động không hợp lệ."])
    return f"Đã áp dụng: {act['label']}."


def _scaled(containers: list[dict], target: float) -> dict:
    """Container cargo weights scaled to `target` (same proportions); rounding goes to the last container."""
    current = sum(c["cargo_weight_kg"] for c in containers)
    out, running = {}, 0.0
    for i, c in enumerate(containers):
        if i == len(containers) - 1:
            value = round(target - running, 3)
        else:
            value = round(c["cargo_weight_kg"] * target / current, 1)
            running += value
        out[c["id"]] = {"cargo_weight_kg": value}
    return out


# ---------------------------------------------------------------------------
# Dashboard helpers
# ---------------------------------------------------------------------------
def documents_waiting(shipment_id: str) -> list[str]:
    """Documents waiting for approval / an outside confirmation (counted on the dashboard)."""
    out = []
    bkv = B.get_booking_view(shipment_id)
    if bkv and B.step_status(bkv) == "Waiting for External Confirmation":
        out.append("Booking — chờ hãng tàu xác nhận")
    for item in (V.get_shipment_vgms(shipment_id) or {"items": []})["items"]:
        if item["vgm"] and item["vgm"]["vgm_status"] == "Submitted":
            out.append(f"VGM {item['container'].get('container_number') or '#' + str(item['no'])} — chờ xác nhận")
    siv = SI.get_si_view(shipment_id)
    if siv and siv["exists"] and siv["si"]["si_status"] in ("Submitted", "Amended", "Draft B/L Received"):
        out.append(f"SI — {SI.status_label(siv['si']['si_status'])} (chờ duyệt Draft B/L)")
    blv = BL.get_bl_view(shipment_id)
    if blv and blv["exists"] and blv["status"] in ("Draft Sent for Review", "Draft Approved"):
        out.append(f"B/L — {BL.status_label(blv['status'])} (chờ hãng tàu)")
    return out
