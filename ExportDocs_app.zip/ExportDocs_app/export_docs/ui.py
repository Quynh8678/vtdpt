"""Gradio interface: theme, header, sidebar navigation and pages."""

import gradio as gr

from . import APP_NAME, __version__, history, settings
from . import shipments as S
from .services import DOCUMENT_STEPS, MODULES
from .ui_common import (
    GREY_BG, NAVY, NAVY_LIGHT, coming_soon_html, e, message_html, notice_html, page_title_html, section_title_html,
)
from .ui_booking import build_booking_page
from .ui_export import build_export_page
from .ui_history import build_history_page
from .ui_library import build_library_page
from .ui_validation import build_validation_page
from .ui_dashboard import build_dashboard_page
from .ui_eir import build_eir_page
from .ui_bl import build_bl_page
from .ui_gatein import build_gatein_page
from .ui_si import build_si_page
from .ui_vgm import build_vgm_page
from .ui_shipments import build_shipments_page

# Below this window width (px) the sidebar starts closed and closes after each click.
NARROW_SCREEN_PX = 1024

# ---- Look & feel: navy / white / light grey --------------------------------
THEME = gr.themes.Base(
    primary_hue=gr.themes.colors.blue,
    neutral_hue=gr.themes.colors.slate,
    # System fonts: load instantly, and all support Vietnamese.
    font=["Segoe UI", "Roboto", "Helvetica Neue", "Arial", "sans-serif"],
    # Tables use the same readable font instead of a typewriter-style one.
    font_mono=["Segoe UI", "Roboto", "Helvetica Neue", "Arial", "sans-serif"],
).set(
    body_background_fill=GREY_BG,
    block_background_fill="white",
    block_border_color="#DDE2EA",
    button_primary_background_fill=NAVY,
    button_primary_background_fill_hover=NAVY_LIGHT,
    button_primary_text_color="white",
    button_secondary_background_fill="white",
    button_secondary_background_fill_hover="#E6EBF2",
    button_secondary_text_color=NAVY,
    button_cancel_background_fill="#C0392B",
    button_cancel_background_fill_hover="#A93226",
    button_cancel_text_color="white",
)

CSS = f"""
/* ---------- header ---------- */
.app-header {{
    background: {NAVY}; border-radius: 10px; padding: 18px 24px;
    display: flex; flex-wrap: wrap; gap: 10px; justify-content: space-between; align-items: center;
}}
.app-header h1 {{ margin: 0; font-size: 22px; letter-spacing: 1px; color: #FFFFFF !important; }}
.app-header p {{ margin: 4px 0 0; font-size: 13px; color: #C9D4E5 !important; }}
.app-header .badge {{
    background: #FFFFFF; color: {NAVY} !important; font-weight: 600;
    border-radius: 999px; padding: 5px 14px; font-size: 12px; white-space: nowrap;
}}
@media (max-width: 640px) {{
    .app-header {{ padding: 14px 16px; }}
    .app-header h1 {{ font-size: 18px; }}
}}

/* ---------- sidebar ---------- */
.sidebar-brand {{ font-weight: 700; color: {NAVY}; font-size: 15px; letter-spacing: .5px; }}
.sidebar-section {{
    font-size: 11px; font-weight: 700; text-transform: uppercase; color: #6B7A90;
    margin: 14px 0 4px; letter-spacing: .8px;
}}
button.nav-btn {{ justify-content: flex-start !important; text-align: left !important; }}

/* ---------- page text ---------- */
.page-title h2 {{ color: {NAVY}; margin: 4px 0 0; }}
.page-title p, .section-title p {{ color: #5B6B82; margin: 2px 0 0; font-size: 13px; }}
.section-title h3 {{ color: {NAVY}; margin: 14px 0 0; font-size: 16px; }}
.hint {{ color: #5B6B82; font-size: 13px; }}
.notice {{
    background: #EEF3FA; border: 1px solid #C9D6EA; color: {NAVY};
    border-radius: 8px; padding: 10px 14px; font-size: 14px;
}}
.fit-btn {{ max-width: 260px; }}

/* ---------- messages ---------- */
.msg {{ border-radius: 8px; padding: 10px 14px; font-size: 14px; border: 1px solid; }}
.msg ul {{ margin: 6px 0 0 18px; padding: 0; }}
.msg-success {{ background: #EAF6EF; border-color: #A9D8BC; color: #1E5E3B; }}
.msg-warning {{ background: #FFF8E1; border-color: #EBCB6B; color: #6B5100; }}
.msg-error   {{ background: #FDECEA; border-color: #EBA59E; color: #8A1F14; }}
.msg-info    {{ background: #EEF3FA; border-color: #C9D6EA; color: {NAVY}; }}

/* ---------- dashboard ---------- */
.kpi-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(190px, 1fr)); gap: 12px; }}
.kpi {{
    background: white; border: 1px solid #DDE2EA; border-left: 4px solid {NAVY};
    border-radius: 8px; padding: 12px 14px;
}}
.kpi .label {{ font-size: 12px; color: #5B6B82; }}
.kpi .value {{ font-size: 26px; font-weight: 700; color: {NAVY}; margin-top: 4px; }}
.kpi .cap {{ font-size: 11px; color: #8A96A8; margin-top: 2px; }}
.kpi.warn {{ border-left-color: #D4A017; }}
.kpi.bad {{ border-left-color: #C0392B; }}
.kpi.good {{ border-left-color: #2E8B57; }}
.steps {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 8px; }}
.step {{ background: white; border: 1px solid #DDE2EA; border-radius: 8px; padding: 10px; }}
.step .num {{
    display: inline-block; width: 24px; height: 24px; line-height: 24px; text-align: center;
    border-radius: 50%; background: #CBD3DF; color: white; font-weight: 700; font-size: 12px;
}}
.step .en {{ font-weight: 600; color: {NAVY}; font-size: 13px; margin-top: 6px; }}
.step .vi {{ color: #5B6B82; font-size: 12px; }}
.step .st {{ color: #8A96A8; font-size: 11px; margin-top: 4px; }}
.legend {{ margin-top: 8px; }}
.legend span {{ display: inline-block; margin-right: 14px; font-size: 12px; color: #5B6B82; }}
.dot {{ display: inline-block; width: 10px; height: 10px; border-radius: 50%; margin-right: 5px; }}

/* ---------- shipment details ---------- */
.pill {{
    display: inline-flex; align-items: center; border: 1px solid; border-radius: 999px;
    padding: 2px 10px; font-size: 12px; background: white; color: {NAVY};
}}
.sample-badge {{
    display: inline-block; background: #FFF3CD; color: #7A5A00 !important; border: 1px solid #E5C04A;
    border-radius: 4px; padding: 1px 8px; font-size: 12px; font-weight: 700; vertical-align: middle;
}}
.form-head h3 {{ color: {NAVY}; margin: 0; font-size: 18px; }}
.form-head p {{ margin: 6px 0 0; color: #5B6B82; font-size: 13px; }}
.details {{ background: white; border: 1px solid #DDE2EA; border-radius: 10px; padding: 16px; }}
.two-col {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 16px; }}
table.kv, table.kv tr, table.kv th, table.kv td {{ border: none !important; }}
table.kv {{ width: 100%; border-collapse: collapse; font-size: 13px; }}
table.kv th {{ text-align: left; color: #5B6B82; font-weight: 500; width: 45%; padding: 5px 8px 5px 0 !important;
              border-bottom: 1px solid #EEF1F5 !important; vertical-align: top; }}
table.kv td {{ color: #1C2B3F; padding: 5px 0 !important; border-bottom: 1px solid #EEF1F5 !important; }}
table.grid, table.grid tr, table.grid th, table.grid td {{ border-left: none !important; border-right: none !important; }}
.table-wrap {{ overflow-x: auto; }}
table.grid {{ width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 6px; }}
table.grid th {{ background: {NAVY}; color: white !important; text-align: left; padding: 6px 8px;
                font-weight: 600; white-space: nowrap; }}
table.grid td {{ padding: 6px 8px; border-bottom: 1px solid #E3E8EF; color: #1C2B3F; }}
table.grid tr:nth-child(even) td {{ background: #F7F9FB; }}
.empty {{ color: #8A96A8; font-style: italic; }}
.parties {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 10px; margin-top: 6px; }}
.party {{ border: 1px solid #E3E8EF; border-radius: 8px; padding: 10px; font-size: 13px; color: #1C2B3F; }}
.party .role {{ font-weight: 700; color: {NAVY}; font-size: 12px; margin-bottom: 4px; }}
.totals {{ color: {NAVY}; font-size: 13px; padding: 4px 2px; }}

/* ---------- phones / narrow screens: one column, tables scroll sideways ---------- */
@media (max-width: 700px) {{
    .two-col, .parties {{ grid-template-columns: 1fr !important; }}
    .steps {{ grid-template-columns: repeat(2, minmax(0, 1fr)) !important; }}
    .kpi-grid {{ grid-template-columns: repeat(2, minmax(0, 1fr)) !important; }}
    .kpi .value {{ font-size: 22px; }}
    .details {{ padding: 10px; }}
    table.kv th {{ width: 40%; }}
    .table-wrap {{ -webkit-overflow-scrolling: touch; }}
}}
"""

# Gradio follows the computer's dark mode; strip it so the navy/white look stays.
FORCE_LIGHT_JS = """
() => {
  const strip = () => document.querySelectorAll('.dark').forEach(el => el.classList.remove('dark'));
  strip();
  new MutationObserver(strip).observe(document.documentElement,
      { attributes: true, attributeFilter: ['class'], subtree: true });
}
"""
WINDOW_WIDTH_JS = "(w) => window.innerWidth"


def header_html() -> str:
    return f"""
    <div class="app-header">
      <div>
        <h1>{e(APP_NAME)}</h1>
        <p>Hệ thống quản lý bộ chứng từ xuất khẩu container</p>
      </div>
      <span class="badge">Phiên bản {e(__version__)}</span>
    </div>"""


def build_settings_page(module):
    """Settings: current user, reference lists, data folder, backup and restore."""
    import pandas as pd
    from . import backup, reference
    gr.HTML(page_title_html(module.label_vi, module.label_en))

    # ---- current user -----------------------------------------------------------------
    gr.HTML(section_title_html("Người dùng hiện tại", "Current user — chưa có đăng nhập"))
    gr.HTML(notice_html(
        "Tên này được ghi vào <b>mọi</b> bản ghi lịch sử (ai sửa, sửa gì, lúc nào). Chưa có đăng nhập: "
        "mỗi người dùng chung máy hãy đổi tên trước khi làm việc."))
    with gr.Row(equal_height=True):
        user_box = gr.Textbox(label="Người dùng hiện tại", placeholder="VD: Nguyễn Văn A — Phòng chứng từ", scale=3)
        user_btn = gr.Button("💾 Lưu tên người dùng", variant="primary", scale=1)
    user_msg = gr.HTML()

    # ---- reference lists ----------------------------------------------------------------
    gr.HTML(section_title_html("Danh mục", "Carriers, ports, terminals, depots — các biểu mẫu chọn từ đây"))
    gr.HTML(notice_html(
        "Các ô <b>Carrier, POL / POD / Place of receipt / delivery / transshipment, depot</b> (Quản lý lô hàng, "
        "Bước 1) và <b>Terminal</b> (Bước 5) cho chọn từ danh mục, và vẫn gõ được giá trị mới. "
        "Danh mục cảng có sẵn tên UN/LOCODE công khai; hãng tàu, terminal, depot do bạn thêm "
        "(hoặc bấm “Lấy từ các lô hàng”)."))
    with gr.Row():
        kind = gr.Dropdown(label="Danh mục", value="CARRIER", scale=1,
                           choices=[(f"{vi} ({en})", k) for k, (vi, en) in reference.KINDS.items()])
        new_name = gr.Textbox(label="Tên mới", scale=2)
        new_code = gr.Textbox(label="Mã (không bắt buộc, VD: VNCLI)", scale=1)
        add_btn = gr.Button("➕ Thêm", scale=1)
    ref_table = gr.Dataframe(value=pd.DataFrame(columns=["ID", "Tên", "Mã", "Ghi chú"]), interactive=False, wrap=True)
    with gr.Row():
        ref_pick = gr.Dropdown(label="Chọn mục cần ẩn", choices=[], scale=3)
        hide_btn = gr.Button("🗑 Ẩn khỏi danh mục", scale=1)
        import_btn = gr.Button("📥 Lấy từ các lô hàng", scale=1)
    ref_msg = gr.HTML()

    # ---- data folder -----------------------------------------------------------------------
    gr.HTML(section_title_html("Thư mục dữ liệu", "Data folder"))
    gr.HTML(notice_html(
        f"Thư mục dữ liệu hiện tại (Data folder):<br><code>{e(str(settings.DATA_DIR))}</code><br>"
        "Gồm: <code>database/</code> (SQLite), <code>pdfs/</code>, <code>uploads/</code>, <code>exports/</code>, "
        "<code>backups/</code>. Đổi thư mục: đặt biến môi trường <code>EXPORT_DOCS_DATA_DIR</code> trước khi chạy "
        "(VD: Google Drive khi chạy trên Colab) hoặc sửa <code>export_docs/settings.py</code>."
        + ("<br><br><b>Google Colab:</b> ứng dụng làm việc trên bản sao cơ sở dữ liệu ở ổ đĩa Colab "
           f"(<code>{e(str(settings.DATABASE_PATH))}</code>) và chép lên Drive "
           f"(<code>{e(str(settings.STORED_DATABASE_PATH))}</code>) khoảng 1 giây sau mỗi lần lưu. "
           "File <code>ExportDocs_DANG_MO.lock</code> trong thư mục dữ liệu cho biết dữ liệu đang được mở — "
           "một phiên Colab khác sẽ không mở được cùng lúc." if settings.USE_LOCAL_COPY else "")))

    # ---- backup / restore --------------------------------------------------------------------
    gr.HTML(section_title_html("Sao lưu & khôi phục", "Backup (database + files in one ZIP) and restore"))
    with gr.Row(equal_height=True):
        backup_btn = gr.Button("💾 Tạo bản sao lưu ngay", variant="primary", scale=1)
        backup_file = gr.File(label="Bản sao lưu (bấm để tải về)", interactive=False, scale=2)
    backup_msg = gr.HTML()
    with gr.Row():
        restore_file = gr.File(label="Chọn file sao lưu (.zip) để khôi phục", type="filepath", file_types=[".zip"],
                               scale=2)
        with gr.Column(scale=2):
            restore_mode = gr.Radio(label="Khôi phục vào", value="NEW", choices=[
                ("Thư mục MỚI (an toàn — kiểm tra trước, dữ liệu hiện tại không đổi)", "NEW"),
                ("THAY dữ liệu hiện tại (tự sao lưu dữ liệu hiện tại trước)", "CURRENT")])
            restore_dir = gr.Textbox(label="Thư mục mới (khi chọn “Thư mục MỚI”)",
                                     value=str(settings.DATA_DIR.parent / f"{settings.DATA_DIR.name}_restored"))
            restore_ok = gr.Checkbox(label="Tôi hiểu: “THAY dữ liệu hiện tại” ghi đè toàn bộ lô hàng và file hiện tại")
            restore_btn = gr.Button("♻️ Khôi phục")
    restore_msg = gr.HTML()

    # ---- logic --------------------------------------------------------------------------------
    def save_user(name):
        try:
            saved = history.set_current_user(name)
        except S.ShipmentError as ex:
            return gr.skip(), message_html("error", "Chưa lưu.", ex.errors)
        return saved, message_html("success", f"Đã lưu. Từ bây giờ lịch sử ghi người dùng: {saved}.")

    def load_refs(k):
        items = reference.list_items(k, active_only=True)
        frame = pd.DataFrame([[i["id"], i["name"], i["code"] or "", i["notes"] or ""] for i in items],
                             columns=["ID", "Tên", "Mã", "Ghi chú"])
        return frame, gr.update(choices=[(i["name"], i["id"]) for i in items], value=None)

    def add_ref(k, name, code):
        try:
            added = reference.add_item(k, name, code)
        except S.ShipmentError as ex:
            return (*load_refs(k), message_html("error", "Chưa thêm.", ex.errors), gr.skip(), gr.skip())
        return (*load_refs(k), message_html("success", f"Đã thêm “{added}”."), "", "")

    def hide_ref(k, item_id):
        if not item_id:
            return (*load_refs(k), message_html("warning", "Chọn một mục."))
        name = reference.remove_item(int(item_id))
        return (*load_refs(k), message_html("success", f"Đã ẩn “{name}” (lô hàng đang dùng tên này vẫn giữ)."))

    def import_refs(k):
        n = reference.import_from_shipments()
        return (*load_refs(k), message_html("success", f"Đã thêm {n} tên từ các lô hàng vào danh mục."))

    def do_backup():
        path = backup.create_backup()
        return str(path), message_html("success", f"Đã tạo bản sao lưu {path.name}",
                                       [f"Lưu tại: {path}",
                                        "Bấm vào file ở trên để tải về máy tính — nên giữ một bản ngoài Google Drive."
                                        if settings.USE_LOCAL_COPY else
                                        "Nên chép file này sang nơi khác (ổ ngoài / Google Drive)."])

    def do_restore(path, mode, folder, ok):
        if not path:
            return message_html("warning", "Chọn file sao lưu (.zip).")
        if mode == "CURRENT" and not ok:
            return message_html("warning", "Đánh dấu ô xác nhận trước khi thay dữ liệu hiện tại.")
        try:
            result = backup.restore_backup(path, None if mode == "CURRENT" else folder)
        except S.ShipmentError as ex:
            return message_html("error", "Chưa khôi phục được.", ex.errors)
        items = [f"{result['shipments']} lô hàng, {result['files']} file (bản sao lưu ngày {result['created_at']}).",
                 f"Thư mục: {result['target']}"]
        if result["backup_of_current"]:
            items.append(f"Dữ liệu trước khi khôi phục đã được sao lưu: {result['backup_of_current']}")
            items.append("Bấm sang trang khác (VD: Tổng quan) để xem dữ liệu đã khôi phục.")
        else:
            items.append("Để mở dữ liệu này: Google Colab — bấm ■ ở ô 6, đổi THU_MUC_DU_LIEU ở ô 2 thành thư mục "
                         "trên, rồi chạy lại ô 2 → 6 (Runtime → Restart session trước). Trên máy tính — dừng app, "
                         "đặt EXPORT_DOCS_DATA_DIR = thư mục trên, rồi chạy lại."
                         if settings.USE_LOCAL_COPY else
                         "Để mở dữ liệu này: dừng app, đặt EXPORT_DOCS_DATA_DIR = thư mục trên, rồi chạy lại.")
        return message_html("success", "Đã khôi phục.", items)

    user_btn.click(save_user, user_box, [user_box, user_msg])
    kind.input(load_refs, kind, [ref_table, ref_pick])
    add_btn.click(add_ref, [kind, new_name, new_code], [ref_table, ref_pick, ref_msg, new_name, new_code])
    hide_btn.click(hide_ref, [kind, ref_pick], [ref_table, ref_pick, ref_msg])
    import_btn.click(import_refs, kind, [ref_table, ref_pick, ref_msg])
    backup_btn.click(do_backup, None, [backup_file, backup_msg])
    restore_btn.click(do_restore, [restore_file, restore_mode, restore_dir, restore_ok], restore_msg)

    def refresh(k="CARRIER"):
        current = history.current_user()
        return (current if current != history.DEFAULT_USER else "",
                message_html("warning", "Chưa đặt tên người dùng — lịch sử đang ghi “Chưa đặt tên”.")
                if current == history.DEFAULT_USER else "", *load_refs(k or "CARRIER"))

    return [kind], [user_box, user_msg, ref_table, ref_pick], refresh


def build_placeholder_page(title: str, subtitle: str, phase: int) -> None:
    gr.HTML(page_title_html(title, subtitle))
    gr.HTML(coming_soon_html(phase))


def build_app() -> gr.Blocks:
    # Every navigation target: key -> (button label, section)
    nav = {m.key: (f"{m.icon}  {m.label_vi}", "module") for m in MODULES}
    nav.update({f"step{s.number}": (f"{s.number}. {s.name_en}", "step") for s in DOCUMENT_STEPS})
    modules = {m.key: m for m in MODULES}
    steps = {f"step{s.number}": s for s in DOCUMENT_STEPS}

    with gr.Blocks(title=APP_NAME) as demo:
        buttons, pages = {}, {}
        window_width = gr.Number(visible=False)

        with gr.Sidebar(open=True, width=290) as sidebar:
            gr.HTML(f'<div class="sidebar-brand">{e(APP_NAME)}</div>')
            for section, title in (("module", "Chức năng chính"), ("step", "6 bước chứng từ")):
                gr.HTML(f'<div class="sidebar-section">{title}</div>')
                for key, (label, kind) in nav.items():
                    if kind == section:
                        buttons[key] = gr.Button(
                            label, size="sm", elem_classes="nav-btn",
                            variant="primary" if key == "dashboard" else "secondary")

        gr.HTML(header_html())
        for key in nav:
            with gr.Column(visible=(key == "dashboard")) as page:
                if key == "dashboard":
                    dash_outputs, dash_refresh = build_dashboard_page()
                elif key == "shipments":
                    ship_inputs, ship_outputs, ship_refresh = build_shipments_page()
                elif key == "step1":
                    book_inputs, book_outputs, book_refresh = build_booking_page()
                elif key == "step2":
                    eir_inputs, eir_outputs, eir_refresh, eir_edit_btn, eir_ship_dd = build_eir_page()
                elif key == "step3":
                    vgm_inputs, vgm_outputs, vgm_refresh, vgm_edit_btn, vgm_ship_dd = build_vgm_page()
                elif key == "step4":
                    (si_inputs, si_outputs, si_refresh, si_routing_btn, si_parties_btn, si_vgm_btn,
                     si_ship_dd) = build_si_page()
                elif key == "step5":
                    gate_inputs, gate_outputs, gate_refresh, gate_edit_btn, gate_ship_dd = build_gatein_page()
                elif key == "step6":
                    bl_inputs, bl_outputs, bl_refresh, bl_edit_si_btn, bl_ship_dd = build_bl_page()
                elif key == "settings":
                    set_inputs, set_outputs, set_refresh = build_settings_page(modules[key])
                elif key == "export":
                    exp_inputs, exp_outputs, exp_refresh = build_export_page()
                elif key == "library":
                    lib_outputs, lib_refresh = build_library_page()
                elif key == "validation":
                    val_inputs, val_outputs, val_refresh = build_validation_page()
                elif key == "history":
                    hist_outputs, hist_refresh = build_history_page()
                elif key in modules:
                    m = modules[key]
                    build_placeholder_page(m.label_vi, m.label_en, m.build_phase)
                else:
                    s = steps[key]
                    build_placeholder_page(f"Bước {s.number} · {s.name_en}", s.name_vi, s.build_phase)
            pages[key] = page

        keys = list(pages)
        nav_outputs = [pages[k] for k in keys] + [buttons[k] for k in keys] + [sidebar]

        def show(target: str, width):
            narrow = bool(width) and width < NARROW_SCREEN_PX
            return (
                [gr.update(visible=(k == target)) for k in keys]
                + [gr.update(variant="primary" if k == target else "secondary") for k in keys]
                + [gr.update(open=False) if narrow else gr.skip()]
            )

        for key in keys:
            event = buttons[key].click(lambda w, k=key: show(k, w), window_width, nav_outputs,
                                       js=WINDOW_WIDTH_JS)
            if key == "dashboard":
                event.then(dash_refresh, None, dash_outputs)
            elif key == "shipments":
                event.then(ship_refresh, ship_inputs, ship_outputs)
            elif key == "step1":
                event.then(book_refresh, book_inputs, book_outputs)
            elif key == "step2":
                event.then(eir_refresh, eir_inputs, eir_outputs)
            elif key == "step3":
                event.then(vgm_refresh, vgm_inputs, vgm_outputs)
            elif key == "step4":
                event.then(si_refresh, si_inputs, si_outputs)
            elif key == "step5":
                event.then(gate_refresh, gate_inputs, gate_outputs)
            elif key == "step6":
                event.then(bl_refresh, bl_inputs, bl_outputs)
            elif key == "validation":
                event.then(val_refresh, val_inputs, val_outputs)
            elif key == "history":
                event.then(hist_refresh, None, hist_outputs)
            elif key == "settings":
                event.then(set_refresh, set_inputs, set_outputs)
            elif key == "export":
                event.then(exp_refresh, exp_inputs, exp_outputs)
            elif key == "library":
                event.then(lib_refresh, None, lib_outputs)

        # Steps 2–5 "edit at the source": open Step 1 with the same shipment selected
        for edit_btn, step_ship_dd in ((eir_edit_btn, eir_ship_dd), (vgm_edit_btn, vgm_ship_dd),
                                       (si_routing_btn, si_ship_dd), (gate_edit_btn, gate_ship_dd)):
            edit_btn.click(lambda w: show("step1", w), window_width, nav_outputs, js=WINDOW_WIDTH_JS) \
                .then(book_refresh, [step_ship_dd], book_outputs)
        # SI parties → Shipment Management with the same shipment picked; SI VGM tab → Step 3
        si_parties_btn.click(lambda w: show("shipments", w), window_width, nav_outputs, js=WINDOW_WIDTH_JS) \
            .then(ship_refresh, [ship_inputs[0], ship_inputs[1], si_ship_dd], ship_outputs)
        si_vgm_btn.click(lambda w: show("step3", w), window_width, nav_outputs, js=WINDOW_WIDTH_JS) \
            .then(vgm_refresh, [si_ship_dd], vgm_outputs)
        # B/L → the SI (Step 4) for B/L type, originals and freight
        bl_edit_si_btn.click(lambda w: show("step4", w), window_width, nav_outputs, js=WINDOW_WIDTH_JS) \
            .then(si_refresh, [bl_ship_dd], si_outputs)

        # Remember the shipment the user picks on any page (the Export page opens with it)
        for picker in (book_inputs[0], eir_ship_dd, vgm_ship_dd, si_ship_dd, gate_ship_dd, bl_ship_dd,
                       val_inputs[0]):
            picker.input(S.remember_opened, picker, None)
        ship_inputs[2].change(S.remember_opened, ship_inputs[2], None)   # also set by clicking a table row

        # On page load: close the sidebar on narrow screens, then load real data.
        demo.load(lambda w: gr.update(open=not (w and w < NARROW_SCREEN_PX)), window_width, sidebar,
                  js=WINDOW_WIDTH_JS) \
            .then(dash_refresh, None, dash_outputs) \
            .then(ship_refresh, ship_inputs, ship_outputs)

    return demo
