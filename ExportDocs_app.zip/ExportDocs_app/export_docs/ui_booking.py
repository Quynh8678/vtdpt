"""Step 1 — Booking Confirmation page (REQUIREMENTS.md §5 Step 1).

Fields marked 🔗 come from the central shipment data and are saved back there
(one copy for all steps). Parties, containers and cargo lines are shown
read-only here and edited in "Quản lý lô hàng".
"""

from pathlib import Path

import gradio as gr

from . import bookings as B
from . import reference
from . import pdf_generator as P
from . import shipments as S
from .formatting import fmt_kg, fmt_packages
from .ui_common import (
    cutoff_badges_html, e, message_html, notice_html, page_title_html, sample_badge, shipment_tracker_html,
)
from .ui_shipments import FIELD_LABELS
from .workflow import shipment_step_statuses
from .services import STEP_STATUSES

BOOKING_LABELS = {
    "booking_status": "Trạng thái booking (Booking status)",
    "booking_date": "Ngày đặt chỗ (Booking date)",
    "confirmation_date": "Ngày xác nhận (Confirmation date)",
    "customer_reference": "Số tham chiếu của khách (Customer reference)",
    "commodity": "Tên hàng (Commodity)",
    "special_cargo_requirements": "Yêu cầu hàng đặc biệt (Special cargo requirements)",
    "carrier_instructions": "Hướng dẫn của hãng tàu (Carrier instructions)",
    "remarks": "Ghi chú (Remarks)",
    "confirmation_source": "Nguồn xác nhận từ hãng tàu (Confirmation source)",
    "confirmation_reference": "Số tham chiếu xác nhận (Confirmation reference)",
    "confirmed_by": "Người ghi nhận xác nhận (Recorded by)",
}
KIND_MSG = {"draft": "warning", "internal": "error", "cancelled": "error", "confirmed": "success"}


def _label(key: str) -> str:
    """Label with 🔗 for central (shared) fields and * for required ones."""
    if key in B.SHARED_FIELDS:
        text = "🔗 " + FIELD_LABELS[key].rstrip(" *")
    else:
        text = BOOKING_LABELS[key]
    return text + (" *" if key in B.REQUIRED_KEYS else "")


def _party_card(title: str, p: dict | None) -> str:
    p = p or {}
    if not p.get("party_name"):
        body = '<span class="empty">Chưa nhập — thêm ở Quản lý lô hàng → tab “Các bên liên quan”</span>'
    else:
        lines = [p.get("party_name"), p.get("address"), p.get("country"),
                 f"Tax ID: {p['tax_id']}" if p.get("tax_id") else None, p.get("email"), p.get("phone")]
        body = "<br>".join(e(x) for x in lines if x)
    return f'<div class="party"><div class="role">{e(title)}</div>{body}</div>'


def parties_html(ship: dict) -> str:
    p = ship["parties"]
    return ('<div class="parties">'
            + _party_card("Shipper · Người gửi hàng *", p.get("SHIPPER"))
            + _party_card("Booking Party · Bên đặt chỗ", p.get("BOOKING_PARTY"))
            + _party_card("Forwarder · Đại lý giao nhận", p.get("FORWARDER"))
            + '</div><div class="hint">🔗 Dữ liệu chung — sửa ở <b>Quản lý lô hàng</b>.</div>')


def cargo_html(view: dict) -> str:
    ship = view["shipment"]
    eq = B.equipment_summary(ship["containers"])
    eq_text = " + ".join(f"<b>{g['qty']} × {e(g['label'])}</b>" for g in eq) or '<span class="empty">Chưa có container</span>'
    conts = ", ".join(e(c["container_number"]) for c in ship["containers"] if c.get("container_number"))
    unassigned = sum(1 for c in ship["containers"] if not c.get("container_number"))
    cargo_lines = "".join(
        f"<li>{e(c.get('commodity'))} — {e(c.get('cargo_description'))} · "
        f"{e(fmt_packages(c.get('package_count'), c.get('package_type')))} · {fmt_kg(c.get('gross_weight_kg'))} kg</li>"
        for c in ship["cargo"]) or '<li class="empty">Chưa có dòng hàng</li>'
    return (f'<div class="details" style="padding:10px 14px">'
            f'<div>Container: {eq_text} (tổng {len(ship["containers"])})</div>'
            f'<div class="hint">Số container: {conts or "chưa có"}'
            f'{f" · {unassigned} chưa có số" if unassigned else ""}</div>'
            f'<div style="margin-top:6px">Hàng hóa:</div><ul style="margin:2px 0 0 18px">{cargo_lines}</ul>'
            f'<div class="hint">🔗 Container và dòng hàng là dữ liệu chung — sửa ở <b>Quản lý lô hàng</b> '
            f'(tab Container / Hàng hóa). Để trống “Tên hàng” bên dưới thì PDF dùng tên hàng từ các dòng hàng.</div></div>')


def status_box_html(view: dict | None) -> str:
    if not view:
        return notice_html("Chọn một lô hàng để bắt đầu Bước 1.")
    label = B.document_label(view)
    step = B.step_status(view)
    vi = dict(STEP_STATUSES)
    sample = f" {sample_badge(view['shipment'])}" if label["sample"] else ""
    if not view["exists"]:
        return message_html("info", "Bước 1 chưa được lưu cho lô hàng này. Các ô 🔗 đã được điền sẵn từ dữ liệu "
                                    "lô hàng — hãy bổ sung thông tin booking rồi bấm “Lưu nháp Booking”.")
    items = [f"Trạng thái Bước 1: {vi[step]} ({step})",
             f"PDF sẽ được đánh dấu: {label['badge']}"]
    missing = B.missing_required(view)
    if missing:
        items.append("Còn thiếu: " + ", ".join(missing))
    b = view["booking"]
    if b.get("last_pdf_at"):
        items.append(f"PDF xuất lần cuối: {b['last_pdf_at']}")
    return (message_html(KIND_MSG[label["kind"]], label["title"], items).replace("</b>", f"</b>{sample}", 1)
            + cutoff_badges_html(view["shipment"]))


def _choices():
    return [(f"{r['shipment_id']} · {r.get('booking_number') or 'chưa có booking'} · "
             f"{r.get('customer_name') or r.get('shipper_name') or ''}", r["shipment_id"])
            for r in S.list_shipments()]


def _pick(key: str, **kw):
    """Carrier / port / depot: pick list from Settings (typing a new value still works)."""
    return gr.Dropdown(label=_label(key), choices=reference.choices(reference.FIELD_KINDS[key]), value=None,
                       allow_custom_value=True, **kw)


def build_booking_page():
    """Build the page. Returns (inputs, outputs, refresh function) used when the page opens."""
    shared, booking = {}, {}

    gr.HTML(page_title_html("Bước 1 · Booking Confirmation",
                            "Xác nhận đặt chỗ — tạo, lưu nháp, xem trước và xuất PDF"))
    ship_dd = gr.Dropdown(label="Chọn lô hàng (Shipment)", choices=[], elem_classes="ship-picker")
    tracker = gr.HTML()
    status_box = gr.HTML(status_box_html(None))

    with gr.Tabs(selected="form") as tabs:
        with gr.Tab("📝 Biểu mẫu Booking", id="form"):
            gr.HTML(notice_html(
                "🔗 = <b>dữ liệu chung của lô hàng</b>: tự điền từ dữ liệu gốc; sửa ở đây sẽ cập nhật cho mọi bước. "
                "<b>*</b> = cần có để hoàn thành Bước 1 — bạn vẫn luôn <b>lưu nháp</b> được khi còn thiếu."))

            with gr.Accordion("1. Thông tin chứng từ (Document header)", open=True):
                with gr.Row():
                    shared["booking_number"] = gr.Textbox(label=_label("booking_number"))
                    shared["carrier_name"] = _pick("carrier_name")
                    booking["confirmation_date"] = gr.DateTime(label=_label("confirmation_date"),
                                                               include_time=False, type="string")

            with gr.Accordion("2. Thông tin booking (Booking information)", open=True):
                with gr.Row():
                    booking["booking_date"] = gr.DateTime(label=_label("booking_date"), include_time=False,
                                                          type="string")
                    booking["booking_status"] = gr.Dropdown(
                        label=_label("booking_status") + " *", value="Booking Request",
                        choices=[(f"{en} — {vi}", en) for en, vi in B.BOOKING_STATUSES.items()])
                    booking["customer_reference"] = gr.Textbox(label=_label("customer_reference"))
                booking_party = gr.HTML()
                gr.HTML('<div class="section-title"><h3>Bằng chứng xác nhận từ hãng tàu</h3>'
                        '<p>Chỉ khi có nguồn + số tham chiếu thật, PDF mới được ghi là CARRIER CONFIRMED. '
                        'Nếu không, PDF luôn ghi BOOKING DRAFT hoặc INTERNAL BOOKING RECORD.</p></div>')
                with gr.Row():
                    booking["confirmation_source"] = gr.Dropdown(
                        label=_label("confirmation_source"), value="NONE",
                        choices=[(vi, key) for key, vi in B.CONFIRMATION_SOURCES.items()])
                    booking["confirmation_reference"] = gr.Textbox(
                        label=_label("confirmation_reference"), placeholder="VD: số email / mã xác nhận của hãng tàu")
                    booking["confirmed_by"] = gr.Textbox(label=_label("confirmed_by"))

            with gr.Accordion("3. Các bên liên quan (Parties)", open=True):
                parties = gr.HTML()

            with gr.Accordion("4. Tuyến đường (Routing)", open=True):
                with gr.Row():
                    for key in ("place_of_receipt", "port_of_loading", "transshipment_port"):
                        shared[key] = _pick(key)
                with gr.Row():
                    for key in ("port_of_discharge", "place_of_delivery"):
                        shared[key] = _pick(key)

            with gr.Accordion("5. Tàu / chuyến (Vessel / Voyage)", open=True):
                with gr.Row():
                    shared["vessel_name"] = gr.Textbox(label=_label("vessel_name"))
                    shared["voyage_number"] = gr.Textbox(label=_label("voyage_number"))
                    shared["etd"] = gr.DateTime(label=_label("etd"), include_time=False, type="string")
                    shared["eta"] = gr.DateTime(label=_label("eta"), include_time=False, type="string")

            with gr.Accordion("6. Container & hàng hóa (Container & Cargo)", open=True):
                cargo = gr.HTML()
                with gr.Row():
                    booking["commodity"] = gr.Textbox(label=_label("commodity"))
                    booking["special_cargo_requirements"] = gr.Textbox(
                        label=_label("special_cargo_requirements"), lines=2)

            with gr.Accordion("7. Hạn chót (Cut-off)", open=True):
                with gr.Row():
                    for key in ("cy_cutoff", "si_cutoff", "vgm_cutoff"):
                        shared[key] = gr.DateTime(label=_label(key), include_time=True, type="string")

            with gr.Accordion("8. Lấy container rỗng (Empty container pick-up)", open=True):
                with gr.Row():
                    shared["empty_pickup_depot"] = _pick("empty_pickup_depot", scale=2)
                    shared["empty_pickup_date"] = gr.DateTime(label=_label("empty_pickup_date"),
                                                              include_time=False, type="string")

            with gr.Accordion("9. Ghi chú & hướng dẫn của hãng tàu (Remarks and Carrier Instructions)", open=True):
                with gr.Row():
                    booking["remarks"] = gr.Textbox(label=_label("remarks"), lines=3)
                    booking["carrier_instructions"] = gr.Textbox(label=_label("carrier_instructions"), lines=3)

            form_msg = gr.HTML()
            with gr.Row():
                save_btn = gr.Button("💾 Lưu nháp Booking", variant="primary", scale=2)
                save_preview_btn = gr.Button("💾 Lưu & xem trước PDF", scale=1)

        with gr.Tab("👁 Xem trước & Xuất PDF", id="preview"):
            gr.HTML(notice_html(
                "Bản xem trước dùng <b>dữ liệu đã lưu</b>. Nếu vừa sửa biểu mẫu, hãy bấm “Lưu” trước. "
                "PDF được lưu trong thư mục dữ liệu: <code>pdfs/&lt;Shipment ID&gt;/</code>."))
            with gr.Row():
                preview_btn = gr.Button("👁 Tạo bản xem trước", scale=1)
                export_btn = gr.Button("📄 Xuất PDF", variant="primary", scale=1)
                download_btn = gr.DownloadButton("⬇ Tải PDF về máy", visible=False, scale=1)
            export_msg = gr.HTML()
            gallery = gr.Gallery(label="Bản xem trước (mỗi ảnh là một trang A4)", columns=1, height="auto",
                                 object_fit="contain", allow_preview=True)

    shared_list = [shared[k] for k in B.SHARED_FIELDS]
    booking_keys = [k for k in B.BOOKING_FIELDS]
    booking_list = [booking[k] for k in booking_keys]
    view_outputs = [tracker, status_box, *shared_list, *booking_list, parties, booking_party, cargo,
                    download_btn]

    # ------------------------------------------------------------------ logic
    def _date_value(key, value):
        if value and key in S.DATETIME_FIELDS:
            return f"{value}:00"
        return value

    def view_values(shipment_id):
        view = B.get_booking_view(shipment_id) if shipment_id else None
        if not view:
            empty = [None if k in S.DATE_FIELDS + S.DATETIME_FIELDS else
                     (gr.update(value=None, choices=reference.choices(reference.FIELD_KINDS[k]))
                      if k in reference.FIELD_KINDS else "") for k in B.SHARED_FIELDS]
            return [shipment_tracker_html(["Not Started"] * 6), status_box_html(None), *empty,
                    *[None] * len(booking_keys), "", "", "", gr.update(visible=False)]
        ship, b = view["shipment"], view["booking"]
        shared_vals = [_date_value(k, ship.get(k)) if k in S.DATE_FIELDS + S.DATETIME_FIELDS
                       else (gr.update(value=ship.get(k) or None,
                                       choices=reference.choices(reference.FIELD_KINDS[k], ship.get(k)))
                             if k in reference.FIELD_KINDS else (ship.get(k) or "")) for k in B.SHARED_FIELDS]
        booking_vals = []
        for k in booking_keys:
            v = b.get(k)
            if k == "booking_status":
                v = v or "Booking Request"
            elif k == "confirmation_source":
                v = v or "NONE"
            elif k not in B.BOOKING_DATE_FIELDS:
                v = v or ""
            booking_vals.append(v)
        bp = ship["parties"].get("BOOKING_PARTY") or {}
        bp_html = (f'<div class="hint">🔗 Booking Party: <b>{e(bp.get("party_name"))}</b> '
                   f'(sửa ở Quản lý lô hàng → Các bên liên quan)</div>')
        pdf = b.get("last_pdf_path")
        download = (gr.update(value=pdf, visible=True, label=f"⬇ Tải PDF ({Path(pdf).name})")
                    if pdf and Path(pdf).exists() else gr.update(value=None, visible=False))
        return [shipment_tracker_html(shipment_step_statuses(shipment_id)), status_box_html(view),
                *shared_vals, *booking_vals, parties_html(ship), bp_html, cargo_html(view), download]

    def on_pick(shipment_id):
        return [*view_values(shipment_id), "", None, ""]

    def refresh(shipment_id):
        choices = _choices()
        ids = [c[1] for c in choices]
        if shipment_id not in ids:
            shipment_id = ids[0] if ids else None
        return [gr.update(choices=choices, value=shipment_id), *view_values(shipment_id)]

    def _save(shipment_id, values):
        n = len(shared_list)
        shared_vals = dict(zip(B.SHARED_FIELDS, values[:n]))
        booking_vals = dict(zip(booking_keys, values[n:]))
        result = B.save_booking(shipment_id, shared_vals, booking_vals)
        verb = "Đã tạo" if result.created else "Đã lưu"
        if result.warnings:
            return message_html("warning", f"{verb} Bước 1 cho {shipment_id} (bản nháp). Lưu ý:", result.warnings)
        return message_html("success", f"{verb} Bước 1 cho {shipment_id}. Đầy đủ thông tin bắt buộc.")

    def _save_outputs(shipment_id, values) -> tuple[bool, list]:
        if not shipment_id:
            return False, [gr.skip()] * len(view_outputs) + [message_html("warning", "Hãy chọn lô hàng trước.")]
        try:
            msg = _save(shipment_id, values)
        except S.ShipmentError as ex:
            return False, [gr.skip()] * len(view_outputs) + [message_html("error", "Chưa lưu được:", ex.errors)]
        return True, [*view_values(shipment_id), msg]

    def do_save(shipment_id, *values):
        return _save_outputs(shipment_id, values)[1]

    def preview_images(shipment_id):
        pdf_bytes = P.build_booking_confirmation_pdf_bytes(shipment_id)
        return P.render_pdf_pages(pdf_bytes, scale=1.6)

    def do_preview(shipment_id):
        if not shipment_id:
            return None, message_html("warning", "Hãy chọn lô hàng trước.")
        try:
            pages = preview_images(shipment_id)
        except S.ShipmentError as ex:
            return None, message_html("error", "Không tạo được bản xem trước.", ex.errors)
        return pages, message_html("info", f"Bản xem trước: {len(pages)} trang. "
                                           "Bấm “Xuất PDF” để lưu file và tải về.")

    def do_save_preview(shipment_id, *values):
        ok, saved = _save_outputs(shipment_id, values)
        if not ok:
            return [*saved, gr.skip(), gr.skip(), gr.skip()]
        pages, msg = do_preview(shipment_id)
        return [*saved, pages, msg, gr.Tabs(selected="preview")]

    def do_export(shipment_id):
        if not shipment_id:
            return gr.skip(), message_html("warning", "Hãy chọn lô hàng trước."), gr.skip()
        try:
            path = P.generate_booking_confirmation_pdf(shipment_id)
        except S.ShipmentError as ex:
            return gr.skip(), message_html("error", "Chưa xuất được PDF.", ex.errors), gr.skip()
        view = B.get_booking_view(shipment_id)
        label = B.document_label(view)
        msg = message_html("success", f"Đã xuất PDF: {path.name}",
                           [f"Lưu tại: {path}", f"Nhãn chứng từ: {label['badge']}",
                            "Bấm “⬇ Tải PDF về máy” để tải file."])
        return (gr.update(value=str(path), visible=True, label=f"⬇ Tải PDF ({path.name})"), msg,
                status_box_html(view))

    # ------------------------------------------------------------------ events
    inputs_all = [ship_dd, *shared_list, *booking_list]
    ship_dd.change(on_pick, ship_dd, [*view_outputs, form_msg, gallery, export_msg])
    save_btn.click(do_save, inputs_all, [*view_outputs, form_msg])
    save_preview_btn.click(do_save_preview, inputs_all, [*view_outputs, form_msg, gallery, export_msg, tabs])
    preview_btn.click(do_preview, ship_dd, [gallery, export_msg])
    export_btn.click(do_export, ship_dd, [download_btn, export_msg, status_box]).then(
        lambda sid: shipment_tracker_html(shipment_step_statuses(sid)) if sid else gr.skip(), ship_dd, tracker)

    return [ship_dd], [ship_dd, *view_outputs], refresh
