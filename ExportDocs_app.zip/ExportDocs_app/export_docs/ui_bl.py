"""Step 6 — Bill of Lading (draft) page (REQUIREMENTS.md §5 Step 6).

Tabs: B/L fields · B/L text (what the B/L says) · B/L vs SI comparison ("use SI value", one at a
time — never automatic) · statuses (carrier number + carrier document for Issued / Released /
Amended) · preview and PDF.
"""

from pathlib import Path

import gradio as gr
import pandas as pd

from . import bl as BL
from . import pdf_bl as PB
from . import shipments as S
from . import si as SI
from .formatting import fmt_datetime, fmt_kg
from .pdf_generator import render_pdf_pages
from .ui_common import e, message_html, notice_html, page_title_html, section_title_html, shipment_tracker_html
from .workflow import shipment_step_statuses

CARGO_HEADERS = ["#", "Marks & Numbers", "Số kiện", "Loại kiện", "Description of Goods", "HS", "Gross (kg)", "CBM"]
CONT_HEADERS = ["Container No.", "Seal No.", "Size / Type", "Số kiện", "Đơn vị", "Gross (kg)", "CBM"]
STATUS_CHOICES = [(f"{BL.status_label(s)} — {BL.STATUS_LABELS[s][1]}", s) for s in BL.STATUSES]
CSS = """
.bl-table{width:100%;border-collapse:collapse;font-size:13px;margin:4px 0 8px}
.bl-table th{background:#0B2545;color:#fff;text-align:left;padding:5px 6px;font-weight:600}
.bl-table td{border-bottom:1px solid #E1E7EF;padding:4px 6px;vertical-align:top}
.bl-table td.bl{background:#FDECEA} .bl-table td.si{background:#E6F4EC}
"""


def _cards(cells) -> str:
    return '<div class="kpi-grid">' + "".join(
        f'<div class="kpi"><div class="label">🔗 {e(k)}</div><div class="value" style="font-size:14px">{e(v) or "—"}</div></div>'
        for k, v in cells) + "</div>"


def inherited_html(view: dict | None) -> str:
    if not view:
        return notice_html("Chọn một lô hàng để bắt đầu Bước 6.")
    si, ship = view["si"], view["shipment"]
    label = BL.document_label(view)
    no_label, no_value = BL.bl_number_text(view)
    return _cards([
        (no_label, no_value), ("Booking No.", ship.get("booking_number")), ("Carrier", ship.get("carrier_name")),
        ("Loại chứng từ (từ SI)", f"{SI.BL_TYPES.get(si.get('bl_type'), '—')} · {label['title']}"),
        ("Số bản gốc", PB.originals_text(si)),
        ("Freight (từ SI)", f"{SI.FREIGHT_TERMS.get(si.get('freight_terms'), '—')}"
                            + (f" · payable at {si['payable_at']}" if si.get("payable_at") else "")),
    ]) + '<div class="hint">🔗 Loại B/L, số bản gốc, cước: kế thừa từ SI (Bước 4) — sửa ở Bước 4.</div>'


def onboard_html(view: dict | None) -> str:
    if not view:
        return ""
    if view["all_loaded"]:
        return message_html("success", "Mọi container đã “Loaded on Board” (Bước 5) — có thể ghi ngày SHIPPED ON BOARD.")
    return message_html("warning", "B/L ghi RECEIVED FOR SHIPMENT — chưa được ghi ngày on-board.",
                        ["Chưa “Loaded on Board” ở Bước 5: " + ", ".join(view["not_loaded"])])


def status_html(view: dict | None) -> str:
    if not view:
        return ""
    label = BL.document_label(view)
    warnings = BL.checks(view)
    title = f"{BL.status_label(view['status'])} — {label['banner']}"
    kind = "success" if not warnings else ("error" if BL.step_status(view["shipment"]["shipment_id"]) == "Needs Correction"
                                           else "warning")
    if not view["exists"]:
        warnings = ["Chưa có B/L — nội dung đã được lấy sẵn từ SI. Bấm “💾 Lưu B/L nháp” để tạo."] + warnings
    return message_html(kind, title, warnings)


def cargo_frame(view) -> pd.DataFrame:
    rows = [[n, l.get("marks"), l.get("package_count"), l.get("package_type"), l.get("description"), l.get("hs_code"),
             l.get("gross_weight_kg"), l.get("volume_cbm")]
            for n, l in enumerate((view or {}).get("particulars", {}).get("cargo", []), start=1)]
    return pd.DataFrame(rows, columns=CARGO_HEADERS)


def cont_frame(view) -> pd.DataFrame:
    rows = [[c.get("container_number"), c.get("seal_number"), c.get("size_type"), c.get("package_count"),
             c.get("package_unit"), c.get("gross_weight_kg"), c.get("volume_cbm")]
            for c in (view or {}).get("particulars", {}).get("containers", [])]
    return pd.DataFrame(rows, columns=CONT_HEADERS)


def diff_html(view: dict | None) -> str:
    if not view:
        return ""
    diffs = BL.differences(view)
    if not diffs:
        return message_html("success", "B/L khớp với SI ở mọi mục so sánh.")
    rows = "".join(f"<tr><td>{n}</td><td><b>{e(d['label'])}</b></td><td class='bl' style='white-space:pre-line'>"
                   f"{e(d['bl'])}</td><td class='si' style='white-space:pre-line'>{e(d['si'])}</td></tr>"
                   for n, d in enumerate(diffs, start=1))
    return (message_html("warning", f"{len(diffs)} chỗ khác nhau — không tự sửa. Chọn từng mục bên dưới rồi bấm "
                                    "“Dùng giá trị SI”, hoặc sửa ở tab ✏️ Nội dung B/L.")
            + "<table class='bl-table'><tr><th>#</th><th>Mục</th><th>Trên B/L</th><th>Trên SI</th></tr>" + rows + "</table>")


def diff_choices(view) -> list:
    return [(f"{d['label']}: “{d['bl'][:40]}” → “{d['si'][:40]}”", d["key"]) for d in (BL.differences(view) if view else [])]


def history_html(view) -> str:
    if not view or not view["events"]:
        return notice_html("Chưa có thay đổi trạng thái.")
    docs = {d["id"]: d["file_name"] for d in view["documents"]}
    rows = "".join(f"<tr><td>{fmt_datetime(ev['recorded_at'][:16])}</td><td>{e(BL.status_label(ev['status']))}</td>"
                   f"<td>{e(ev['event_date'])}</td><td>{e(ev['confirmed_by'])}</td>"
                   f"<td>{'📎 ' + e(docs.get(ev['document_fk'])) if ev['document_fk'] else '—'}</td><td>{e(ev.get('note'))}</td></tr>"
                   for ev in reversed(view["events"]))
    return ("<table class='bl-table'><tr><th>Ghi nhận lúc</th><th>Trạng thái</th><th>Ngày</th><th>Người</th>"
            "<th>Chứng từ</th><th>Ghi chú</th></tr>" + rows + "</table>")


def documents_html(view) -> str:
    if not view or not view["documents"]:
        return notice_html("Chưa có chứng từ của hãng tàu. Cần cho Issued / Released / Amended.")
    return ("<table class='bl-table'><tr><th>ID</th><th>File</th><th>Mô tả</th><th>Người tải</th><th>Lúc</th></tr>"
            + "".join(f"<tr><td>{d['id']}</td><td>📎 {e(d['file_name'])}</td><td>{e(d.get('description'))}</td>"
                      f"<td>{e(d.get('uploaded_by'))}</td><td>{fmt_datetime(d['uploaded_at'][:16])}</td></tr>"
                      for d in view["documents"]) + "</table>")


def _rows(frame) -> list[list]:
    if frame is None:
        return []
    values = frame.values.tolist() if isinstance(frame, pd.DataFrame) else list(frame)
    return [r for r in values if not all(S.is_blank(v) for v in r)]


def parse_text(view: dict, values: dict, cargo_tab, cont_tab) -> tuple[dict, list[str]]:
    """The B/L text from the form (fields not on the form are kept from the stored B/L text)."""
    errors = []
    part = dict(view["particulars"])
    for k in ("shipper", "consignee", "notify", "vessel_name", "voyage_number", "port_of_loading", "port_of_discharge"):
        part[k] = S.clean_text(values.get(k)) or ""
    cargo = []
    for n, r in enumerate(_rows(cargo_tab), start=1):
        r = list(r) + [None] * 8
        cargo.append({"marks": S.clean_text(r[1]), "package_count": S.parse_number(r[2], f"Dòng hàng {n}: số kiện", errors, True),
                      "package_type": S.clean_text(r[3]), "description": S.clean_text(r[4]), "hs_code": S.clean_text(r[5]),
                      "gross_weight_kg": S.parse_number(r[6], f"Dòng hàng {n}: gross", errors),
                      "volume_cbm": S.parse_number(r[7], f"Dòng hàng {n}: CBM", errors)})
    conts = []
    for n, r in enumerate(_rows(cont_tab), start=1):
        r = list(r) + [None] * 7
        conts.append({"container_number": (S.clean_text(r[0]) or "").upper() or None, "seal_number": S.clean_text(r[1]),
                      "size_type": S.clean_text(r[2]),
                      "package_count": S.parse_number(r[3], f"Container {n}: số kiện", errors, True),
                      "package_unit": S.clean_text(r[4]),
                      "gross_weight_kg": S.parse_number(r[5], f"Container {n}: gross", errors),
                      "volume_cbm": S.parse_number(r[6], f"Container {n}: CBM", errors)})
    part["cargo"], part["containers"] = cargo, conts
    return part, errors


def build_bl_page():
    """Returns (inputs, outputs, refresh, edit-SI button, shipment dropdown)."""
    gr.HTML(page_title_html("Bước 6 · Bill of Lading (Draft)", "Vận đơn nháp — kế thừa từ SI, so sánh với SI"))
    gr.HTML(f"<style>{CSS}</style>")
    ship_dd = gr.Dropdown(label="Chọn lô hàng (Shipment)", choices=[])
    tracker = gr.HTML()
    status_box = gr.HTML()
    rec_in, text_in = {}, {}

    with gr.Tabs(selected="bl"):
        with gr.Tab("📄 B/L", id="bl"):
            inherited = gr.HTML()
            edit_si_btn = gr.Button("✏️ Sửa loại B/L / số bản gốc / cước ở Bước 4 (SI)", size="sm", elem_classes="fit-btn")
            with gr.Row():
                draft_ref = gr.Textbox(label="Draft ref. (tham chiếu nội bộ — không phải số B/L)", interactive=False)
                rec_in["carrier_bl_number"] = gr.Textbox(
                    label="Số B/L của hãng tàu (chỉ khi hãng tàu đã cấp)",
                    info="Chỉ nhập số THẬT do hãng tàu cấp. Để trống → PDF ghi “Draft ref.”.")
            with gr.Row():
                rec_in["place_of_issue"] = gr.Textbox(label="Nơi phát hành (Place of issue)")
                rec_in["date_of_issue"] = gr.DateTime(label="Ngày phát hành (Date of issue)", include_time=False,
                                                      type="string")
            onboard_box = gr.HTML()
            with gr.Row():
                rec_in["shipped_on_board_date"] = gr.DateTime(label="Ngày xếp hàng lên tàu (Shipped on board date)",
                                                              include_time=False, type="string")
                rec_in["on_board_notation"] = gr.Checkbox(label="In ghi chú SHIPPED ON BOARD trên B/L")
            rec_in["remarks"] = gr.Textbox(label="Ghi chú trên B/L (Remarks)", lines=2)
        with gr.Tab("✏️ Nội dung B/L", id="text"):
            gr.HTML(notice_html("Đây là <b>nội dung của B/L</b> (lấy từ SI khi tạo). Sửa ở đây khi B/L nháp của hãng tàu "
                                "ghi khác — tab ⚖️ sẽ liệt kê mọi chỗ khác SI. App <b>không tự sửa</b>."))
            with gr.Row():
                text_in["shipper"] = gr.Textbox(label="Shipper", lines=3)
                text_in["consignee"] = gr.Textbox(label="Consignee", lines=3)
                text_in["notify"] = gr.Textbox(label="Notify Party", lines=3)
            with gr.Row():
                text_in["vessel_name"] = gr.Textbox(label="Vessel")
                text_in["voyage_number"] = gr.Textbox(label="Voyage")
                text_in["port_of_loading"] = gr.Textbox(label="Port of Loading")
                text_in["port_of_discharge"] = gr.Textbox(label="Port of Discharge")
            gr.HTML(section_title_html("Hàng hóa trên B/L", "Cargo lines"))
            cargo_df = gr.Dataframe(value=pd.DataFrame(columns=CARGO_HEADERS), headers=CARGO_HEADERS, interactive=True,
                                    datatype=["number", "str", "number", "str", "str", "str", "number", "number"],
                                    static_columns=[0], wrap=True)
            gr.HTML(section_title_html("Container & seal trên B/L", "Containers"))
            cont_df = gr.Dataframe(value=pd.DataFrame(columns=CONT_HEADERS), headers=CONT_HEADERS, interactive=True,
                                   datatype=["str", "str", "str", "number", "str", "number", "number"], wrap=True)
            reset_btn = gr.Button("↺ Lấy lại TOÀN BỘ nội dung từ SI (ghi đè nội dung B/L)", size="sm")
        with gr.Tab("⚖️ So sánh với SI", id="compare"):
            diff_box = gr.HTML()
            with gr.Row():
                diff_dd = gr.Dropdown(label="Chọn một chỗ khác nhau", choices=[], scale=3)
                use_si_btn = gr.Button("⬅ Dùng giá trị SI cho mục này", scale=1)
            diff_msg = gr.HTML()
        with gr.Tab("🚦 Trạng thái", id="status"):
            gr.HTML(notice_html("<b>B/L Issued / Released / Amended</b> cần: số B/L thật của hãng tàu (tab 📄) <b>và</b> "
                                "chứng từ của hãng tàu đã tải lên. Trước đó mọi trang PDF ghi "
                                "<b>DRAFT BILL OF LADING — NOT NEGOTIABLE / INTERNAL PREVIEW</b>."))
            history = gr.HTML()
            gr.HTML(section_title_html("Chứng từ của hãng tàu", "Carrier documents"))
            documents = gr.HTML()
            with gr.Row():
                upload = gr.File(label="Tải lên B/L / xác nhận của hãng tàu (PDF, JPG, PNG)",
                                 file_types=list(BL.DOCUMENT_TYPES), type="filepath")
                with gr.Column():
                    up_desc = gr.Textbox(label="Mô tả")
                    up_by = gr.Textbox(label="Người tải lên")
                    upload_btn = gr.Button("📎 Lưu chứng từ")
            gr.HTML(section_title_html("Đổi trạng thái", "Change status"))
            with gr.Row():
                st_target = gr.Dropdown(label="Trạng thái mới", choices=STATUS_CHOICES, value="Draft Sent for Review")
                st_date = gr.DateTime(label="Ngày", include_time=False, type="string")
                st_by = gr.Textbox(label="Người xác nhận")
            with gr.Row():
                st_doc = gr.Dropdown(label="Chứng từ của hãng tàu (cho Issued / Released / Amended)", choices=[])
                st_note = gr.Textbox(label="Ghi chú")
            st_btn = gr.Button("🚦 Đổi trạng thái", variant="primary")
            st_msg = gr.HTML()
        with gr.Tab("👁 Xem trước & Xuất PDF", id="pdf"):
            with gr.Row():
                preview_btn = gr.Button("👁 Xem trước B/L")
                export_btn = gr.Button("📄 Xuất PDF B/L", variant="primary")
                download_btn = gr.DownloadButton("⬇ Tải B/L", visible=False)
            export_msg = gr.HTML()
            gallery = gr.Gallery(label="Bản xem trước (mỗi ảnh là một trang A4)", columns=1, height="auto",
                                 object_fit="contain")
    form_msg = gr.HTML()
    save_btn = gr.Button("💾 Lưu B/L nháp (tab 📄 + ✏️)", variant="primary")

    rec_keys, text_keys = list(rec_in), list(text_in)
    outputs = [tracker, status_box, inherited, draft_ref, onboard_box, *[rec_in[k] for k in rec_keys],
               *[text_in[k] for k in text_keys], cargo_df, cont_df, diff_box, diff_dd, history, documents, st_doc,
               download_btn]
    save_inputs = [ship_dd, *[rec_in[k] for k in rec_keys], *[text_in[k] for k in text_keys], cargo_df, cont_df]

    def values_for(view):
        if not view:
            return ([shipment_tracker_html(["Not Started"] * 6), "", inherited_html(None), "", ""]
                    + [None if k in BL.DATE_FIELDS else (False if k == "on_board_notation" else "") for k in rec_keys]
                    + [""] * len(text_keys) + [cargo_frame(None), cont_frame(None), "", gr.update(choices=[], value=None),
                                               "", "", gr.update(choices=[], value=None), gr.update(visible=False)])
        rec, part = view["record"] or {}, view["particulars"]
        recv = []
        for k in rec_keys:
            v = rec.get(k)
            recv.append(bool(v) if k == "on_board_notation" else (v or None) if k in BL.DATE_FIELDS else (v or ""))
        pdf = rec.get("last_pdf_path")
        return ([shipment_tracker_html(shipment_step_statuses(view["shipment"]["shipment_id"])), status_html(view),
                 inherited_html(view), rec.get("draft_reference") or f"BL-DRAFT-{view['shipment']['shipment_id']} (khi lưu)",
                 onboard_html(view), *recv, *[part.get(k) or "" for k in text_keys], cargo_frame(view), cont_frame(view),
                 diff_html(view), gr.update(choices=diff_choices(view), value=None), history_html(view),
                 documents_html(view),
                 gr.update(choices=[(f"#{d['id']} · {d['file_name']}", str(d["id"])) for d in view["documents"]],
                           value=None),
                 gr.update(value=pdf, visible=True, label=f"⬇ Tải ({Path(pdf).name})") if pdf and Path(pdf).exists()
                 else gr.update(visible=False)])

    def load(shipment_id):
        return values_for(BL.get_bl_view(shipment_id) if shipment_id else None)

    def refresh(shipment_id):
        choices = [(f"{r['shipment_id']} · {r.get('booking_number') or 'chưa có booking'} · "
                    f"{r.get('customer_name') or r.get('shipper_name') or ''}", r["shipment_id"])
                   for r in S.list_shipments()]
        ids = [c[1] for c in choices]
        if shipment_id not in ids:
            shipment_id = ids[0] if ids else None
        return [gr.update(choices=choices, value=shipment_id), *load(shipment_id)]

    skip = lambda: [gr.skip()] * len(outputs)

    def save(shipment_id, *values, reset=False):
        if not shipment_id:
            return skip() + [message_html("warning", "Hãy chọn lô hàng trước.")]
        view = BL.get_bl_view(shipment_id)
        recv = dict(zip(rec_keys, values[:len(rec_keys)]))
        textv = dict(zip(text_keys, values[len(rec_keys):len(rec_keys) + len(text_keys)]))
        cargo_tab, cont_tab = values[-2], values[-1]
        part, errors = (None, []) if (reset or not view["exists"]) else parse_text(view, textv, cargo_tab, cont_tab)
        if errors:
            return skip() + [message_html("error", "Chưa lưu được:", errors)]
        try:
            result = BL.save_bl(shipment_id, recv, part, reset_from_si=reset)
        except S.ShipmentError as ex:
            return skip() + [message_html("error", "Chưa lưu được:", ex.errors)]
        title = ("Đã lấy lại toàn bộ nội dung từ SI và lưu" if reset else "Đã lưu B/L nháp") + \
                f" — {BL.status_label(result.status)}"
        return load(shipment_id) + [message_html("warning" if result.warnings else "success",
                                                 title + (". Lưu ý:" if result.warnings else "."), result.warnings)]

    def use_si(shipment_id, key):
        if not shipment_id or not key:
            return skip() + [message_html("warning", "Chọn một chỗ khác nhau trước.")]
        try:
            label = BL.apply_si_value(shipment_id, key)
        except S.ShipmentError as ex:
            return skip() + [message_html("error", "Không thực hiện được:", ex.errors)]
        return load(shipment_id) + [message_html("success", f"Đã dùng giá trị SI cho “{label}” (chỉ mục này).")]

    def do_upload(shipment_id, path, desc, by):
        if not shipment_id or not path:
            return skip() + [message_html("warning", "Chọn lô hàng và file trước."), gr.skip()]
        try:
            did = BL.add_document(shipment_id, path, desc, by)
        except S.ShipmentError as ex:
            return skip() + [message_html("error", "Chưa lưu được file:", ex.errors), gr.skip()]
        return load(shipment_id) + [message_html("success", f"Đã lưu chứng từ #{did}."), None]

    def do_status(shipment_id, target, date, by, doc, note):
        if not shipment_id:
            return skip() + [message_html("warning", "Hãy chọn lô hàng trước.")]
        try:
            result = BL.change_status(shipment_id, target, date, by, note, int(doc) if doc else None)
        except S.ShipmentError as ex:
            return skip() + [message_html("error", "Không đổi được:", ex.errors)]
        if not result.done:
            return load(shipment_id) + [message_html("error", f"Chưa thể chuyển sang “{BL.status_label(target)}”:",
                                                     result.warnings)]
        return load(shipment_id) + [message_html("success", f"Đã chuyển sang “{BL.status_label(target)}”.", result.warnings)]

    def preview(shipment_id):
        if not shipment_id:
            return None, message_html("warning", "Hãy chọn lô hàng trước.")
        try:
            pages = render_pdf_pages(PB.build_bill_of_lading_pdf_bytes(shipment_id), scale=1.6)
        except S.ShipmentError as ex:
            return None, message_html("error", "Không tạo được bản xem trước.", ex.errors)
        return pages, message_html("info", f"Bản xem trước: {len(pages)} trang.")

    def export(shipment_id):
        if not shipment_id:
            return gr.skip(), message_html("warning", "Hãy chọn lô hàng trước.")
        try:
            path = PB.generate_bill_of_lading_pdf(shipment_id)
        except S.ShipmentError as ex:
            return gr.skip(), message_html("error", "Chưa xuất được PDF.", ex.errors)
        return (gr.update(value=str(path), visible=True, label=f"⬇ Tải ({path.name})"),
                message_html("success", f"Đã xuất PDF: {path.name}", [f"Lưu tại: {path}"]))

    ship_dd.change(lambda s: load(s) + ["", "", "", None, ""], ship_dd,
                   [*outputs, form_msg, diff_msg, st_msg, gallery, export_msg])
    save_btn.click(save, save_inputs, [*outputs, form_msg])
    reset_btn.click(lambda *v: save(*v, reset=True), save_inputs, [*outputs, form_msg])
    use_si_btn.click(use_si, [ship_dd, diff_dd], [*outputs, diff_msg])
    upload_btn.click(do_upload, [ship_dd, upload, up_desc, up_by], [*outputs, st_msg, upload])
    st_btn.click(do_status, [ship_dd, st_target, st_date, st_by, st_doc, st_note], [*outputs, st_msg])
    preview_btn.click(preview, ship_dd, [gallery, export_msg])
    export_btn.click(export, ship_dd, [download_btn, export_msg])

    return [ship_dd], [ship_dd, *outputs], refresh, edit_si_btn, ship_dd
