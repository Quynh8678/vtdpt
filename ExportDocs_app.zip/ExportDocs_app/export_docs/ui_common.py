"""Small HTML helpers shared by all pages."""

import html

from .shipments import SHIPMENT_STATUSES

NAVY = "#0B2545"
NAVY_LIGHT = "#13315C"
GREY_BG = "#F2F4F7"
GREEN, YELLOW, RED, GREY = "#2E8B57", "#D4A017", "#C0392B", "#CBD3DF"


def e(value) -> str:
    """Escape text for HTML; empty values become an em dash."""
    if value is None or value == "":
        return "—"
    return html.escape(str(value))


def page_title_html(title: str, subtitle: str = "") -> str:
    return f'<div class="page-title"><h2>{e(title)}</h2><p>{html.escape(subtitle)}</p></div>'


def section_title_html(title: str, subtitle: str = "") -> str:
    sub = f"<p>{html.escape(subtitle)}</p>" if subtitle else ""
    return f'<div class="section-title"><h3>{e(title)}</h3>{sub}</div>'


def notice_html(text_html: str) -> str:
    return f'<div class="notice">{text_html}</div>'


def coming_soon_html(phase: int) -> str:
    return notice_html(
        f"🚧 Chức năng này sẽ có ở <b>Giai đoạn {phase}</b>. "
        "Hiện tại bạn có thể dùng <b>Tổng quan</b>, <b>Quản lý lô hàng</b>, <b>Bước 1 · Booking</b> "
        "và <b>Bước 2 · EIR</b>."
    )


def message_html(kind: str, title: str, items: list[str] | None = None) -> str:
    """kind: success | warning | error | info"""
    icons = {"success": "✅", "warning": "⚠️", "error": "⛔", "info": "ℹ️"}
    lis = "".join(f"<li>{html.escape(i)}</li>" for i in (items or []))
    body = f"<ul>{lis}</ul>" if lis else ""
    return f'<div class="msg msg-{kind}"><b>{icons.get(kind, "")} {html.escape(title)}</b>{body}</div>'


def status_label(status: str) -> str:
    vi = SHIPMENT_STATUSES.get(status, status)
    return f"{vi} ({status})"


def status_pill(status: str) -> str:
    color = {"Not Started": GREY, "Draft": GREY, "In Progress": YELLOW, "On Hold": YELLOW,
             "Completed": GREEN, "Cancelled": RED}.get(status, GREY)
    return (f'<span class="pill" style="border-color:{color}">'
            f'<i class="dot" style="background:{color}"></i>{e(status_label(status))}</span>')


def sample_badge(ship: dict) -> str:
    """'SAMPLE / DEMO' or 'SAMPLE / TEST' badge; empty for real data."""
    from .shipments import sample_text
    text = sample_text(ship)
    return f'<span class="sample-badge">{e(text)}</span>' if text else ""


def progress_text(done: int, total: int = 6) -> str:
    return "▰" * done + "▱" * (total - done) + f"  {done}/{total}"


# ---- 6-step tracker with real statuses --------------------------------------
STEP_STATUS_COLOURS = {
    "Completed": GREEN,
    "In Progress": YELLOW,
    "Waiting for External Confirmation": YELLOW,
    "Needs Correction": RED,
    "Not Started": GREY,
}
STEP_STATUS_ICONS = {"Completed": "✓", "Needs Correction": "!"}


def shipment_tracker_html(statuses: list[str]) -> str:
    from .services import DOCUMENT_STEPS, STEP_STATUSES
    vi = dict(STEP_STATUSES)
    items = []
    for step, status in zip(DOCUMENT_STEPS, statuses):
        colour = STEP_STATUS_COLOURS.get(status, GREY)
        icon = STEP_STATUS_ICONS.get(status, str(step.number))
        items.append(
            f'<div class="step" style="border-top:4px solid {colour}">'
            f'<span class="num" style="background:{colour}">{icon}</span>'
            f'<div class="en">{e(step.number)}. {e(step.name_en)}</div><div class="vi">{e(step.name_vi)}</div>'
            f'<div class="st" style="color:{colour if status != "Not Started" else "#8A96A8"};font-weight:600">'
            f'{e(vi.get(status, status))}</div><div class="st">{e(status)}</div></div>')
    done = sum(s == "Completed" for s in statuses)
    return (f'<div class="steps">{"".join(items)}</div>'
            f'<div class="legend">Tiến độ: <b>{done}/6</b> bước hoàn thành</div>')


# ---- cut-off countdown and shipment header -----------------------------------
CUTOFF_WINDOW_HOURS = 72          # amber from 72 hours before a cut-off (same window as the dashboard)
AMBER = "#B7791F"


def countdown_text(hours: float) -> str:
    """42.5 → "còn 1 ngày 18 giờ"; -5 → "quá hạn 5 giờ"."""
    total = int(round(abs(hours)))
    days, rest = divmod(total, 24)
    text = (f"{days} ngày {rest} giờ" if days and rest else f"{days} ngày" if days else f"{rest} giờ") if total         else "dưới 1 giờ"
    return ("quá hạn " if hours < 0 else "còn ") + text


def cutoff_badges_html(ship: dict, now=None) -> str:
    """CY / SI / VGM cut-offs: green (> 72 h), amber (≤ 72 h), red (passed), with a countdown."""
    from datetime import datetime
    from .shipments import CUTOFF_LABELS, to_datetime
    now = now or datetime.now()
    badges = []
    for key, label in CUTOFF_LABELS.items():
        when = to_datetime(ship.get(key))
        if not when:
            badges.append(f'<span class="pill" style="border-color:{GREY};color:#8A96A8">{e(label)}: chưa có</span>')
            continue
        hours = (when - now).total_seconds() / 3600
        colour = RED if hours < 0 else AMBER if hours <= CUTOFF_WINDOW_HOURS else GREEN
        icon = "⛔" if hours < 0 else "⏰" if hours <= CUTOFF_WINDOW_HOURS else "🕒"
        badges.append(f'<span class="pill" style="border-color:{colour};color:{colour};font-weight:600" '
                      f'title="{e(ship.get(key))}">{icon} {e(label)} {e(ship.get(key))} · {e(countdown_text(hours))}</span>')
    return '<div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:6px">' + "".join(badges) + "</div>"


def shipment_summary_html(ship: dict) -> str:
    """Booking No. · Vessel / Voyage · POL → POD, then the cut-off badges."""
    vessel = " / ".join(x for x in (ship.get("vessel_name"), ship.get("voyage_number")) if x)
    route = " → ".join(x or "?" for x in (ship.get("port_of_loading"), ship.get("port_of_discharge")))         if (ship.get("port_of_loading") or ship.get("port_of_discharge")) else None
    parts = [f"<b>Booking No.</b> {e(ship.get('booking_number'))}", f"<b>Vessel / Voyage</b> {e(vessel or None)}",
             f"<b>POL → POD</b> {e(route)}"]
    return f'<p style="margin:6px 0 0">{" &nbsp;·&nbsp; ".join(parts)}</p>' + cutoff_badges_html(ship)
