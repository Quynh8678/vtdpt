"""Step 2 — Empty Container EIR page (REQUIREMENTS.md §5 Step 2).

Booking number, carrier, planned depot and pick-up date are shown read-only
(edited in Step 1). Container fields marked 🔗 are saved to the central
containers table. One EIR per container.
"""

from pathlib import Path

import gradio as gr
import pandas as pd

from . import eir as E
from . import pdf_generator as P
from . import shipments as S
from .formatting import fmt_date
from .ui_common import (
    e, message_html, notice_html, page_title_html, section_title_html, shipment_tracker_html,
)
from .workflow import shipment_step_statuses

NEW = "NEW"
STATUS_STYLE = {"Completed": "success", "Draft": "warning", "Not Started": "info"}
OVERVIEW_COLUMNS = ["#", "Container No.", "Size / ISO / Type", "EIR (tham chiếu)", "Số EIR của depot",
                    "Nhãn chứng từ", "Kiểm tra", "Trạng thái EIR"]
CONDITION_CHOICES = [("OK", "OK"), ("Hư hỏng (Damaged)", "DAMAGED"), ("Chưa kiểm tra (Not checked)", "NOT_CHECKED")]


def central_info_html(ship: dict | None) -> str:
    if not ship:
        return notice_html("Chọn một lô hàng để bắt đầu Bước 2.")
    cells = [("Booking No.", ship.get("booking_number")), ("Carrier", ship.get("carrier_name")),
             ("Depot lấy rỗng (kế hoạch)", ship.get("empty_pickup_depot")),
             ("Ngày lấy rỗng", fmt_date(ship.get("empty_pickup_date")) if ship.get("empty_pickup_date") else None)]
    items = "".join(f'<div class="kpi"><div class="label">🔗 {e(k)}</div>'
                    f'<div class="value" style="font-size:15px">{e(v)}</div></div>' for k, v in cells)
    return (f'<div class="kpi-grid">{items}</div>'
            '<div class="hint">🔗 Dữ liệu chung từ Bước 1 — chỉ xem ở đây. Bấm nút bên dưới để sửa tại nguồn.</div>')


def overview_table(overview: dict | None) -> pd.DataFrame:
    rows = []
    for i in (overview or {}).get("items", []):
        c, rec = i["container"], i["eir"]
        size = " ".join(x for x in (f"{c['container_size']}'" if c.get("container_size") else None,
                                    c.get("iso_type_code"), c.get("container_type")) if x)
        checked = (sum(1 for k, _, _ in E.CONDITION_AREAS if (rec.get(f"cond_{k}") or "NOT_CHECKED") != "NOT_CHECKED")
                   if rec else 0)
        label = E.document_label(overview["shipment"], c, rec)["badge"] if rec else "—"
        rows.append([i["no"], c.get("container_number") or "(chưa có số)", size or "—",
                     rec["internal_reference"] if rec else "—", c.get("eir_number") or "—", label,
                     f"{checked}/7" if rec else "—", f"{E.EIR_STATUSES[i['status']]} ({i['status']})"])
    return pd.DataFrame(rows, columns=OVERVIEW_COLUMNS)


def picker_choices(overview: dict | None) -> list:
    choices = []
    for i in (overview or {}).get("items", []):
        c = i["container"]
        choices.append((f"{i['no']}. {c.get('container_number') or '(chưa có số)'} · "
                        f"{E.EIR_STATUSES[i['status']]}", str(c["id"])))
    return choices + [("＋ Thêm container mới", NEW)]


def eir_status_html(overview: dict | None, container_id: int | None) -> str:
    if not overview:
        return ""
    if container_id is None:
        return message_html("info", "Container mới: nhập số container và thông tin EIR rồi bấm “Lưu EIR”. "
                                    "Container sẽ được thêm vào dữ liệu chung của lô hàng.")
    item = E.find_item(overview, container_id)
    if not item:
        return ""
    ship, c, rec = overview["shipment"], item["container"], item["eir"]
    kind = STATUS_STYLE[item["status"]]
    items = []
    if rec:
        label = E.document_label(ship, c, rec)
        items.append(f"Nhãn chứng từ: {label['badge']} — tham chiếu: {label['reference']}")
        missing = E.missing_for_completion(ship, c, rec)
        if missing:
            items.append("Cần để Hoàn thành: " + "; ".join(missing))
        advice = E.damage_warning(rec)
        if advice:
            items.append(f"⚠️ {advice}")
        if rec.get("last_pdf_at"):
            items.append(f"PDF xuất lần cuối: {rec['last_pdf_at']}")
    else:
        items.append("Chưa có EIR cho container này.")
    if c.get("container_number") and S.container_number_problem(c["container_number"]):
        items.append(f"⚠️ {c['container_number']}: {S.container_number_problem(c['container_number'])}")
    title = f"EIR {c.get('container_number') or '(chưa có số)'}: {E.EIR_STATUSES[item['status']]} ({item['status']})"
    return message_html(kind, title, items)


def build_eir_page():
    """Build the page. Returns (inputs, outputs, refresh function, edit-at-source button)."""
    cont_in, rec_in, cond_in, note_in = {}, {}, {}, {}

    gr.HTML(page_title_html("Bước 2 · Empty Container EIR",
                            "Phiếu EIR cấp container rỗng — một EIR cho mỗi container"))
    ship_dd = gr.Dropdown(label="Chọn lô hàng (Shipment)", choices=[])
    tracker = gr.HTML()
    central = gr.HTML(central_info_html(None))
    edit_source_btn = gr.Button("✏️ Sửa Booking No. / Carrier / Depot / ngày lấy rỗng ở Bước 1", size="sm",
                                elem_classes="fit-btn")
    gr.HTML(section_title_html("Container của lô hàng", "Containers and their EIR status"))
    overview_df = gr.Dataframe(value=pd.DataFrame(columns=OVERVIEW_COLUMNS), interactive=False, wrap=True)
    picker = gr.Dropdown(label="Chọn container để nhập / sửa EIR", choices=[])
    status_box = gr.HTML()

    with gr.Tabs(selected="form") as tabs:
        with gr.Tab("📝 Biểu mẫu EIR", id="form"):
            gr.HTML(notice_html(
                "🔗 = <b>dữ liệu chung</b> của container: lưu vào danh sách container của lô hàng, các bước 3–6 "
                "dùng chung. Lưu nháp luôn được. <b>Hoàn thành</b> cần: số container, ngày giờ EIR, depot và "
                "đủ 7 hạng mục đã kiểm tra; nếu có hạng mục <b>Hư hỏng</b> thì phải ghi <b>Mô tả hư hỏng</b>. "
                "App <b>không bao giờ</b> tự tạo số EIR của depot."))
            with gr.Accordion("A. Container (🔗 dữ liệu chung)", open=True):
                with gr.Row():
                    cont_in["container_number"] = gr.Textbox(label="🔗 Số container (Container No.) *",
                                                             placeholder="VD: MSKU1234565")
                    cont_in["container_size"] = gr.Dropdown(label="🔗 Size", choices=list(S.CONTAINER_SIZES),
                                                           allow_custom_value=True)
                    cont_in["iso_type_code"] = gr.Textbox(label="🔗 ISO Type", placeholder="VD: 45G1, 22G1")
                    cont_in["container_type"] = gr.Dropdown(label="🔗 Loại container (Type)",
                                                           choices=list(S.CONTAINER_TYPES), allow_custom_value=True)
            with gr.Accordion("B. Thông tin EIR (EIR information)", open=True):
                with gr.Row():
                    cont_in["eir_number"] = gr.Textbox(
                        label="🔗 Số EIR của depot (Depot EIR No.) — không bắt buộc",
                        info="Chỉ nhập khi có EIR thật từ depot → PDF ghi REFERENCE COPY. Để trống → INTERNAL EIR RECORD.")
                    rec_in["eir_datetime"] = gr.DateTime(label="Ngày giờ giao nhận (EIR date/time) *",
                                                         include_time=True, type="string")
                with gr.Row():
                    rec_in["depot_yard"] = gr.Textbox(label="Depot / bãi thực tế (Depot/Yard) *",
                                                      info="Mặc định là depot lấy rỗng ở Bước 1; sửa nếu thực tế khác.")
                    rec_in["handover_load_status"] = gr.Dropdown(label="Full/Empty khi giao",
                                                                 choices=list(E.HANDOVER_STATUSES), value="Empty")
                rec_in["handover_info"] = gr.Textbox(label="Thông tin giao nhận (Handover information)", lines=2)
            with gr.Accordion("C. Vận chuyển (Transport)", open=True):
                with gr.Row():
                    cont_in["truck_number"] = gr.Textbox(label="🔗 Số xe (Truck No.)")
                    cont_in["chassis_number"] = gr.Textbox(label="🔗 Số rơ-moóc (Chassis No.)")
                    rec_in["driver_info"] = gr.Textbox(label="Tài xế (Driver) — không bắt buộc",
                                                       placeholder="Họ tên, số CCCD/GPLX, điện thoại")
            with gr.Accordion("D. Tình trạng container khi giao (Condition at handover) *", open=True):
                all_ok_btn = gr.Button("✓ Đánh dấu tất cả 7 hạng mục là OK", size="sm", elem_classes="fit-btn")
                for key, en, vi in E.CONDITION_AREAS:
                    with gr.Row(equal_height=True):
                        cond_in[key] = gr.Radio(label=f"{en} — {vi}", choices=CONDITION_CHOICES,
                                                value="NOT_CHECKED", scale=3)
                        note_in[key] = gr.Textbox(label="Ghi chú", scale=2)
                rec_in["damage_remarks"] = gr.Textbox(
                    label="Mô tả hư hỏng / tình trạng (Damage / condition remarks)", lines=2,
                    info="Bắt buộc khi có hạng mục “Hư hỏng” — nếu không, EIR chỉ là Nháp.")
            form_msg = gr.HTML()
            with gr.Row():
                save_btn = gr.Button("💾 Lưu EIR", variant="primary", scale=2)
                delete_btn = gr.Button("🗑 Xóa EIR này", variant="stop", scale=1)
            with gr.Group(visible=False) as confirm_box:
                confirm_text = gr.HTML()
                with gr.Row():
                    confirm_yes = gr.Button("Xóa EIR", variant="stop")
                    confirm_no = gr.Button("Hủy, không xóa")

        with gr.Tab("👁 Xem trước & Xuất PDF", id="preview"):
            gr.HTML(notice_html("Xem trước dùng <b>dữ liệu đã lưu</b>. Mỗi container một trang A4. "
                                "PDF được lưu trong <code>pdfs/&lt;Shipment ID&gt;/</code>."))
            with gr.Row():
                preview_one_btn = gr.Button("👁 Xem trước EIR đang chọn")
                preview_all_btn = gr.Button("👁 Xem trước tất cả EIR")
            with gr.Row():
                export_one_btn = gr.Button("📄 Xuất PDF EIR đang chọn", variant="primary")
                export_all_btn = gr.Button("📄 Xuất PDF tất cả EIR (1 file)", variant="primary")
            with gr.Row():
                download_one = gr.DownloadButton("⬇ Tải EIR", visible=False)
                download_all = gr.DownloadButton("⬇ Tải tất cả EIR", visible=False)
            export_msg = gr.HTML()
            gallery = gr.Gallery(label="Bản xem trước (mỗi ảnh là một trang A4)", columns=1, height="auto",
                                 object_fit="contain")

    cont_keys = list(E.CONTAINER_FIELDS)
    rec_keys = ["eir_datetime", "depot_yard", "handover_load_status", "driver_info", "handover_info", "damage_remarks"]
    area_keys = [k for k, _, _ in E.CONDITION_AREAS]
    form_inputs = ([cont_in[k] for k in cont_keys] + [rec_in[k] for k in rec_keys]
                   + [cond_in[k] for k in area_keys] + [note_in[k] for k in area_keys])
    form_outputs = [status_box, *form_inputs, download_one]

    # ------------------------------------------------------------------ logic
    def form_values(overview, container_id):
        ship = overview["shipment"] if overview else {}
        item = E.find_item(overview, container_id) if overview and container_id is not None else None
        c = item["container"] if item else {}
        rec = (item or {}).get("eir") or {}
        values = [c.get(k) or ("" if k != "container_size" else None) for k in cont_keys]
        for k in rec_keys:
            v = rec.get(k)
            if k == "eir_datetime":
                v = f"{v}:00" if v else None
            elif k == "depot_yard":
                v = E.effective_depot(ship, rec) or ""
            elif k == "handover_load_status":
                v = v or "Empty"
            else:
                v = v or ""
            values.append(v)
        values += [rec.get(f"cond_{k}") or "NOT_CHECKED" for k in area_keys]
        values += [rec.get(f"note_{k}") or "" for k in area_keys]
        pdf = rec.get("last_pdf_path")
        single = pdf and Path(pdf).exists() and "_ALL_" not in Path(pdf).name
        download = (gr.update(value=pdf, visible=True, label=f"⬇ Tải EIR ({Path(pdf).name})")
                    if single else gr.update(value=None, visible=False))
        return [eir_status_html(overview, container_id), *values, download]

    def _cid(value):
        return None if value in (None, "", NEW) else int(value)

    def load_shipment(shipment_id, preferred=None):
        overview = E.get_shipment_eirs(shipment_id) if shipment_id else None
        choices = picker_choices(overview)
        ids = [v for _, v in choices]
        pick = preferred if preferred in ids else (ids[0] if ids else None)
        tracker_html = shipment_tracker_html(shipment_step_statuses(shipment_id) if overview else ["Not Started"] * 6)
        return ([tracker_html, central_info_html(overview["shipment"] if overview else None),
                 overview_table(overview), gr.update(choices=choices, value=pick)]
                + form_values(overview, _cid(pick)))

    head_outputs = [tracker, central, overview_df, picker]

    def on_ship(shipment_id):
        return load_shipment(shipment_id) + ["", None, "", gr.update(visible=False)]

    def on_pick(shipment_id, picked):
        overview = E.get_shipment_eirs(shipment_id) if shipment_id else None
        return form_values(overview, _cid(picked)) + [gr.update(visible=False)]

    def refresh(shipment_id):
        choices = [(f"{r['shipment_id']} · {r.get('booking_number') or 'chưa có booking'} · "
                    f"{r.get('customer_name') or r.get('shipper_name') or ''}", r["shipment_id"])
                   for r in S.list_shipments()]
        ids = [c[1] for c in choices]
        if shipment_id not in ids:
            shipment_id = ids[0] if ids else None
        return [gr.update(choices=choices, value=shipment_id), *load_shipment(shipment_id)]

    def do_save(shipment_id, picked, *values):
        if not shipment_id:
            return [gr.skip()] * (len(head_outputs) + len(form_outputs)) + [message_html("warning", "Hãy chọn lô hàng trước.")]
        n_c, n_r, n_a = len(cont_keys), len(rec_keys), len(area_keys)
        cont = dict(zip(cont_keys, values[:n_c]))
        rec = dict(zip(rec_keys, values[n_c:n_c + n_r]))
        rec.update({f"cond_{k}": v for k, v in zip(area_keys, values[n_c + n_r:n_c + n_r + n_a])})
        rec.update({f"note_{k}": v for k, v in zip(area_keys, values[n_c + n_r + n_a:])})
        try:
            result = E.save_eir(shipment_id, _cid(picked), cont, rec)
        except S.ShipmentError as ex:
            return [gr.skip()] * (len(head_outputs) + len(form_outputs)) + [
                message_html("error", "Chưa lưu được:", ex.errors)]
        verb = "Đã tạo" if result.created else "Đã lưu"
        title = f"{verb} EIR {result.internal_reference} — {E.EIR_STATUSES[result.status]} ({result.status})"
        msg = (message_html("warning", title + ". Lưu ý:", result.warnings) if result.warnings
               else message_html("success", title + "."))
        return load_shipment(shipment_id, str(result.container_id)) + [msg]

    def all_ok():
        return ["OK"] * len(area_keys)

    def ask_delete(shipment_id, picked):
        cid = _cid(picked)
        overview = E.get_shipment_eirs(shipment_id) if shipment_id else None
        item = E.find_item(overview, cid) if overview and cid is not None else None
        if not item or not item["eir"]:
            return gr.update(visible=False), "", message_html("warning", "Container này chưa có EIR để xóa.")
        name = item["container"].get("container_number") or item["eir"]["internal_reference"]
        return (gr.update(visible=True),
                message_html("error", f"Xóa EIR {item['eir']['internal_reference']} của container {name}?",
                             ["Container vẫn được giữ trong lô hàng; chỉ xóa phiếu EIR (ngày giờ, tình trạng, "
                              "tài xế…).", "Thao tác này không thể hoàn tác."]), "")

    def do_delete(shipment_id, picked):
        try:
            ref = E.delete_eir(shipment_id, _cid(picked))
        except S.ShipmentError as ex:
            return [gr.skip()] * (len(head_outputs) + len(form_outputs)) + [
                gr.update(visible=False), message_html("error", "Không xóa được.", ex.errors)]
        return load_shipment(shipment_id, picked) + [gr.update(visible=False),
                                                     message_html("success", f"Đã xóa EIR {ref}.")]

    def _preview(shipment_id, ids):
        if not shipment_id:
            return None, message_html("warning", "Hãy chọn lô hàng trước.")
        try:
            pages = P.render_pdf_pages(P.build_empty_eir_pdf_bytes(shipment_id, ids), scale=1.6)
        except S.ShipmentError as ex:
            return None, message_html("error", "Không tạo được bản xem trước.", ex.errors)
        return pages, message_html("info", f"Bản xem trước: {len(pages)} trang.")

    def preview_one(shipment_id, picked):
        cid = _cid(picked)
        if cid is None:
            return None, message_html("warning", "Hãy chọn một container đã lưu EIR.")
        return _preview(shipment_id, [cid])

    def preview_all(shipment_id):
        return _preview(shipment_id, None)

    def _export(shipment_id, ids):
        if not shipment_id:
            return gr.skip(), message_html("warning", "Hãy chọn lô hàng trước.")
        try:
            path = P.generate_empty_eir_pdf(shipment_id, ids)
        except S.ShipmentError as ex:
            return gr.skip(), message_html("error", "Chưa xuất được PDF.", ex.errors)
        return (gr.update(value=str(path), visible=True, label=f"⬇ Tải ({path.name})"),
                message_html("success", f"Đã xuất PDF: {path.name}", [f"Lưu tại: {path}"]))

    def export_one(shipment_id, picked):
        cid = _cid(picked)
        if cid is None:
            return gr.skip(), message_html("warning", "Hãy chọn một container đã lưu EIR.")
        return _export(shipment_id, [cid])

    def export_all(shipment_id):
        return _export(shipment_id, None)

    # ------------------------------------------------------------------ events
    ship_dd.change(on_ship, ship_dd, [*head_outputs, *form_outputs, form_msg, gallery, export_msg, confirm_box])
    picker.change(on_pick, [ship_dd, picker], [*form_outputs, confirm_box])
    save_btn.click(do_save, [ship_dd, picker, *form_inputs], [*head_outputs, *form_outputs, form_msg])
    all_ok_btn.click(all_ok, None, [cond_in[k] for k in area_keys])
    delete_btn.click(ask_delete, [ship_dd, picker], [confirm_box, confirm_text, form_msg])
    confirm_no.click(lambda: (gr.update(visible=False), message_html("info", "Đã hủy, không xóa gì.")),
                     None, [confirm_box, form_msg])
    confirm_yes.click(do_delete, [ship_dd, picker], [*head_outputs, *form_outputs, confirm_box, form_msg])
    preview_one_btn.click(preview_one, [ship_dd, picker], [gallery, export_msg])
    preview_all_btn.click(preview_all, ship_dd, [gallery, export_msg])
    export_one_btn.click(export_one, [ship_dd, picker], [download_one, export_msg]).then(
        lambda sid: load_shipment(sid)[:3] if sid else [gr.skip()] * 3, ship_dd, [tracker, central, overview_df])
    export_all_btn.click(export_all, ship_dd, [download_all, export_msg])

    return [ship_dd], [ship_dd, *head_outputs, *form_outputs], refresh, edit_source_btn, ship_dd
