"""Step 5 — Export Gate-in & Loading Registration business logic (REQUIREMENTS.md §5 Step 5, §6, §7).

A container-status-at-port record, one per container — not a standard form shared by all ports.

Central data (read-only here, warnings when missing): booking, carrier, vessel/voyage, POL/POD,
container number, size/type, seal (from the SI), cargo gross weight (SI cargo per container),
tare and VGM (Step 3).

Eight SEPARATE statuses, each changed only by its own event:
    Not Arrived, Gate-in Completed, Customs Pending, Customs Cleared,
    Export Registration Pending, Ready to Load, Loaded on Board, Hold/Rejected
One status NEVER changes because another one changed. Every event records its source
(uploaded file or manual entry), who confirmed it, when it happened and when it was recorded.

There is no real ePort connection: every record is an INTERNAL RECORD / REFERENCE COPY and the app
never creates port transaction, registration or EIR numbers — the user types them from the port's data.
"""

import re
import shutil
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from . import settings
from . import shipments as S
from .database import reading, transaction
from .tracking import tracked
from .formatting import fmt_datetime

STATUSES = (   # key, English, Vietnamese
    ("NOT_ARRIVED", "Not Arrived", "Chưa đến cảng"),
    ("GATE_IN_COMPLETED", "Gate-in Completed", "Đã hạ bãi (gate-in)"),
    ("CUSTOMS_PENDING", "Customs Pending", "Chờ thông quan"),
    ("CUSTOMS_CLEARED", "Customs Cleared", "Đã thông quan"),
    ("EXPORT_REG_PENDING", "Export Registration Pending", "Chờ đăng ký xuất tàu"),
    ("EXPORT_REGISTERED", "Export Registration Confirmed", "Đã đăng ký xuất tàu"),
    ("READY_TO_LOAD", "Ready to Load", "Sẵn sàng xếp tàu"),
    ("LOADED_ON_BOARD", "Loaded on Board", "Đã xếp lên tàu"),
    ("HOLD_REJECTED", "Hold / Rejected", "Bị giữ / từ chối"),
)
STATUS_NAMES = {k: en for k, en, _ in STATUSES}
STATUS_VI = {k: vi for k, _, vi in STATUSES}
ACTIONS = {"SET": "Xác nhận (confirmed)", "CLEAR": "Bỏ (no longer applies)"}
SOURCES = {"MANUAL": "Manual entry", "UPLOADED_FILE": "Uploaded file"}
CUSTOMS_LANES = {"GREEN": ("Green lane", "Luồng xanh"), "YELLOW": ("Yellow lane", "Luồng vàng"),
                 "RED": ("Red lane", "Luồng đỏ")}
SUPERVISION_STATUSES = ("Not yet under supervision", "Under customs supervision",
                        "Supervision confirmed (passed control area)")
EXPORT_REG_STATUSES = ("Not registered", "Registration submitted", "Registered", "Rejected")
LOADING_STATUSES = ("Not loaded", "Loading planned", "Loaded", "Short-shipped / rolled over")
CONDITIONS = ("Sound — no visible damage", "Damaged — see remarks")
EVIDENCE_TYPES = (".pdf", ".jpg", ".jpeg", ".png", ".xlsx")

TEXT_FIELDS = ("terminal_name", "terminal_area", "transaction_ref", "registration_no", "gatein_eir_no",
               "gatein_seal_number", "truck_number", "chassis_number", "yard_location", "yard_block", "yard_bay",
               "yard_row", "yard_tier", "container_condition", "customs_declaration_no", "customs_office",
               "customs_lane", "customs_supervision_status", "vessel_loading_status",
               "loading_confirmation_ref", "remarks")
DATETIME_FIELDS = ("gatein_datetime", "vehicle_arrival", "container_arrival", "actual_loading_datetime")
DATE_FIELDS = ("customs_declaration_date", "customs_clearance_date")
RECORD_FIELDS = TEXT_FIELDS + DATETIME_FIELDS + DATE_FIELDS
PORT_REFERENCE_FIELDS = ("transaction_ref", "registration_no", "gatein_eir_no", "loading_confirmation_ref")
AT_LEAST_READY = ("READY_TO_LOAD", "LOADED_ON_BOARD")


class GateInError(S.ShipmentError):
    pass


@dataclass
class GateInResult:
    container_id: int
    warnings: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------
def get_shipment_gateins(shipment_id: str) -> dict | None:
    """Central shipment + per container: gate-in record, status events, evidence, current statuses."""
    ship = S.get_shipment(shipment_id)
    if not ship:
        return None
    with reading() as conn:
        records = {r["container_fk"]: dict(r) for r in conn.execute(
            "SELECT * FROM gatein_records WHERE shipment_fk = ?", (ship["id"],))}
        events = [dict(r) for r in conn.execute(
            "SELECT * FROM gatein_status_events WHERE shipment_fk = ? ORDER BY id", (ship["id"],))]
        evidence = [dict(r) for r in conn.execute(
            "SELECT * FROM gatein_evidence WHERE shipment_fk = ? ORDER BY id", (ship["id"],))]
        alloc = {}
        for r in conn.execute("SELECT container_fk, SUM(gross_weight_kg) AS gross, COUNT(*) AS n FROM container_cargo "
                              "WHERE shipment_fk = ? GROUP BY container_fk", (ship["id"],)):
            alloc[r["container_fk"]] = r["gross"]
    items = []
    for n, c in enumerate(ship["containers"], start=1):
        own_events = [e for e in events if e["container_fk"] == c["id"]]
        latest = {}
        for e in own_events:                       # in recording order → the last one wins, per status
            latest[e["status_key"]] = e
        items.append({
            "no": n, "container": c, "record": records.get(c["id"]), "events": own_events,
            "evidence": [x for x in evidence if x["container_fk"] == c["id"]],
            "current": latest,                     # status_key → latest event (SET or CLEAR)
            "cargo_gross": alloc.get(c["id"]) if alloc.get(c["id"]) is not None else c.get("cargo_weight_kg"),
            "cargo_gross_source": "SI cargo per container" if c["id"] in alloc else "Shipment master data",
        })
    return {"shipment": ship, "items": items}


def find_item(overview: dict, container_id: int) -> dict | None:
    return next((i for i in overview["items"] if i["container"]["id"] == container_id), None)


def is_active(item: dict, key: str) -> bool:
    event = item["current"].get(key)
    return bool(event and event["action"] == "SET")


def active_statuses(item: dict) -> list[str]:
    return [k for k, _, _ in STATUSES if is_active(item, k)]


def has_evidence(item: dict, key: str) -> bool:
    event = item["current"].get(key)
    return bool(event and event["action"] == "SET" and event["source"] == "UPLOADED_FILE" and event["evidence_fk"])


def evidence_name(item: dict, evidence_id: int | None) -> str | None:
    return next((x["file_name"] for x in item["evidence"] if x["id"] == evidence_id), None)


def export_registration_text(item: dict) -> str:
    """Export registration as recorded in the status timeline (with date and who confirmed it).

    An older value typed in the former "registration status" field is shown, marked as not in the timeline;
    it is never turned into a confirmation automatically.
    """
    for key, label in (("EXPORT_REGISTERED", "Registered"), ("EXPORT_REG_PENDING", "Registration pending")):
        if is_active(item, key):
            ev = item["current"][key]
            return f"{label} — {fmt_datetime(ev['event_datetime'])} · {ev['confirmed_by']} ({SOURCES[ev['source']]})"
    legacy = (item.get("record") or {}).get("export_registration_status")
    if legacy and legacy != "Not registered":
        return f"Not in the timeline (earlier field: {legacy}) — record “Export Registration Confirmed”"
    return "Not registered"


def customs_number_problem(number: str | None) -> str | None:
    """Vietnamese customs declaration numbers have 12 digits."""
    if not number:
        return None
    if not re.fullmatch(r"\d{12}", number):
        return f"Số tờ khai “{number}” không đúng định dạng (tờ khai hải quan Việt Nam gồm 12 chữ số)"
    return None


# ---------------------------------------------------------------------------
# Checks — warnings only (drafts / partial records can always be saved)
# ---------------------------------------------------------------------------
def checks(ship: dict, item: dict) -> list[str]:
    c, rec = item["container"], item["record"] or {}
    name = c.get("container_number") or f"container #{item['no']}"
    out = []

    missing = [label for ok, label in (
        (ship.get("booking_number"), "Booking No."), (ship.get("carrier_name"), "Carrier"),
        (ship.get("vessel_name") and ship.get("voyage_number"), "Vessel / Voyage"),
        (ship.get("port_of_loading"), "POL"), (ship.get("port_of_discharge"), "POD"),
        (c.get("container_number"), "Container No."), (c.get("container_size") or c.get("iso_type_code"), "Size / type"),
        (c.get("seal_number"), "Seal (SI)"), (item["cargo_gross"] is not None, "Cargo gross weight"),
        (c.get("tare_weight_kg") is not None, "Tare"), (c.get("vgm_kg") is not None, "VGM (Bước 3)"),
    ) if not ok]
    if missing:
        out.append(f"{name}: thiếu dữ liệu chung — " + ", ".join(missing) + ".")

    gate_in = is_active(item, "GATE_IN_COMPLETED")
    if gate_in and c.get("vgm_kg") is None:
        out.append(f"{name}: đã gate-in nhưng CHƯA có VGM đã khai (Bước 3) — cảng có thể không cho xếp tàu.")
    if rec.get("gatein_seal_number") and c.get("seal_number") and \
            rec["gatein_seal_number"].strip().upper() != c["seal_number"].strip().upper():
        out.append(f"{name}: seal lúc gate-in ({rec['gatein_seal_number']}) KHÁC seal trên SI ({c['seal_number']}).")
    elif gate_in and not rec.get("gatein_seal_number"):
        out.append(f"{name}: đã gate-in nhưng chưa ghi số seal lúc gate-in.")
    cutoff = S.to_datetime(ship.get("cy_cutoff"))
    when = S.to_datetime(rec.get("gatein_datetime"))
    if cutoff and when and when > cutoff:
        out.append(f"{name}: gate-in lúc {fmt_datetime(rec['gatein_datetime'])} SAU CY cut-off "
                   f"({fmt_datetime(ship['cy_cutoff'])}) — cần hãng tàu chấp nhận hạ bãi trễ.")
    if is_active(item, "READY_TO_LOAD") and not is_active(item, "CUSTOMS_CLEARED"):
        out.append(f"{name}: “Ready to Load” nhưng CHƯA có “Customs Cleared”.")
    if c.get("container_number") and S.container_number_problem(c["container_number"]):
        out.append(f"{name}: {S.container_number_problem(c['container_number'])} (ISO 6346) — kiểm tra số trên "
                   "container trước khi hạ bãi.")
    if is_active(item, "LOADED_ON_BOARD") and not is_active(item, "READY_TO_LOAD"):
        out.append(f"{name}: “Loaded on Board” nhưng chưa có “Ready to Load”.")
    if is_active(item, "NOT_ARRIVED") and gate_in:
        out.append(f"{name}: vẫn đánh dấu “Not Arrived” trong khi đã “Gate-in Completed” — bỏ “Not Arrived” nếu đúng.")
    if is_active(item, "CUSTOMS_PENDING") and is_active(item, "CUSTOMS_CLEARED"):
        out.append(f"{name}: cùng lúc “Customs Pending” và “Customs Cleared” — bỏ trạng thái không còn đúng.")
    if is_active(item, "EXPORT_REG_PENDING") and is_active(item, "READY_TO_LOAD"):
        out.append(f"{name}: “Export Registration Pending” và “Ready to Load” cùng lúc — kiểm tra lại.")
    if is_active(item, "EXPORT_REG_PENDING") and is_active(item, "EXPORT_REGISTERED"):
        out.append(f"{name}: cùng lúc “Export Registration Pending” và “Confirmed” — bỏ “Pending” nếu đã đăng ký.")
    if is_active(item, "READY_TO_LOAD") and not is_active(item, "EXPORT_REGISTERED"):
        out.append(f"{name}: “Ready to Load” nhưng chưa ghi “Export Registration Confirmed” (ngày, nguồn, người xác nhận).")
    if is_active(item, "CUSTOMS_CLEARED") and not rec.get("customs_declaration_no"):
        out.append(f"{name}: “Customs Cleared” nhưng chưa có số tờ khai hải quan.")
    if is_active(item, "HOLD_REJECTED"):
        out.append(f"{name}: đang bị GIỮ / TỪ CHỐI (Hold/Rejected) — xem ghi chú và liên hệ cảng / hải quan.")
    problem = customs_number_problem(rec.get("customs_declaration_no"))
    if problem:
        out.append(f"{name}: {problem}.")
    for key in AT_LEAST_READY:
        if is_active(item, key) and not has_evidence(item, key):
            out.append(f"{name}: “{STATUS_NAMES[key]}” chỉ là nhập tay — chưa có file bằng chứng từ cảng.")
    return out


def document_label(ship: dict, item: dict) -> dict:
    rec = item["record"] or {}
    refs = [k for k in PORT_REFERENCE_FIELDS if rec.get(k)]
    note = ("No real ePort / terminal connection. "
            + ("Port references shown were typed in by the user from the terminal's data — this is a reference copy, "
               "not the terminal's document. " if refs else
               "No terminal reference number has been recorded — internal tracking record only. ")
            + "Statuses are recorded by the user with their source; the terminal's and customs' own records prevail.")
    return {"kind": "internal", "badge": "INTERNAL RECORD / REFERENCE COPY", "note": note,
            "sample": bool(ship["is_sample"]), "sample_text": S.sample_text(ship)}


def step_status(shipment_id: str) -> str:
    """Step 5: Completed only when EVERY container is at least Ready to Load, with an evidence file."""
    overview = get_shipment_gateins(shipment_id)
    if not overview or not overview["items"]:
        return "Not Started"
    items = overview["items"]
    if not any(i["record"] or i["events"] for i in items):
        return "Not Started"
    if any(is_active(i, "HOLD_REJECTED") for i in items):
        return "Needs Correction"
    ready = [any(is_active(i, k) for k in AT_LEAST_READY) for i in items]
    if all(ready):
        if all(any(has_evidence(i, k) for k in AT_LEAST_READY) for i in items):
            return "Completed"
        return "Waiting for External Confirmation"
    return "In Progress"


def count_records() -> int:
    with reading() as conn:
        return conn.execute("SELECT COUNT(*) FROM gatein_records").fetchone()[0]


# ---------------------------------------------------------------------------
# Save
# ---------------------------------------------------------------------------
def _owner(conn, shipment_id: str, container_id: int) -> int:
    fk = S.get_shipment_fk(conn, shipment_id)
    row = conn.execute("SELECT shipment_fk FROM containers WHERE id = ?", (container_id,)).fetchone()
    if not row or row[0] != fk:
        raise GateInError(["Container không thuộc lô hàng này."])
    return fk


def _ensure_record(conn, fk: int, container_id: int, stamp: str) -> None:
    conn.execute("INSERT OR IGNORE INTO gatein_records (shipment_fk, container_fk, created_at, updated_at) "
                 "VALUES (?, ?, ?, ?)", (fk, container_id, stamp, stamp))


@tracked("GATEIN")
def save_gatein(shipment_id: str, container_id: int, values: dict) -> GateInResult:
    """Save the gate-in facts of one container. Never changes any status."""
    errors = []
    rec = {k: S.clean_text(values.get(k)) for k in TEXT_FIELDS}
    rec.update({k: S.parse_when(values.get(k), True, k.replace("_", " ").capitalize(), errors) for k in DATETIME_FIELDS})
    rec.update({k: S.parse_when(values.get(k), False, k.replace("_", " ").capitalize(), errors) for k in DATE_FIELDS})
    if rec["customs_lane"] and rec["customs_lane"] not in CUSTOMS_LANES:
        errors.append("Luồng hải quan phải là Green / Yellow / Red.")
    for key in ("gatein_seal_number", "customs_declaration_no"):
        if rec[key]:
            rec[key] = re.sub(r"\s+", "", rec[key]).upper()
    if errors:
        raise GateInError(errors)
    stamp = S.now_text()
    with transaction() as conn:
        fk = _owner(conn, shipment_id, container_id)
        _ensure_record(conn, fk, container_id, stamp)
        conn.execute(f"UPDATE gatein_records SET {', '.join(f'{k} = ?' for k in RECORD_FIELDS)}, updated_at = ? "
                     f"WHERE container_fk = ?", [*(rec[k] for k in RECORD_FIELDS), stamp, container_id])
        conn.execute("UPDATE shipments SET updated_at = ? WHERE id = ?", (stamp, fk))
    return GateInResult(container_id, _warnings_for(shipment_id, container_id))


def _warnings_for(shipment_id: str, container_id: int) -> list[str]:
    overview = get_shipment_gateins(shipment_id)
    return checks(overview["shipment"], find_item(overview, container_id))


@tracked("GATEIN")
def add_evidence(shipment_id: str, container_id: int, source_path: str | Path, description: str | None = None,
                 uploaded_by: str | None = None) -> int:
    """Copy an uploaded file into the data folder and register it. Returns the evidence ID."""
    source = Path(source_path)
    if not source.exists():
        raise GateInError(["Không tìm thấy file tải lên."])
    if source.suffix.lower() not in EVIDENCE_TYPES:
        raise GateInError([f"Loại file {source.suffix or '(không có đuôi)'} không được nhận — dùng "
                           + ", ".join(EVIDENCE_TYPES) + "."])
    stamp = S.now_text()
    with transaction() as conn:
        fk = _owner(conn, shipment_id, container_id)
        folder = settings.UPLOAD_DIR / re.sub(r"[^A-Za-z0-9._-]+", "-", shipment_id) / "gatein" / str(container_id)
        folder.mkdir(parents=True, exist_ok=True)
        safe = re.sub(r"[^A-Za-z0-9._-]+", "-", source.name).strip("-") or f"evidence{source.suffix}"
        target = folder / f"{datetime.now():%Y%m%d-%H%M%S}_{safe}"
        shutil.copy2(source, target)
        cur = conn.execute("INSERT INTO gatein_evidence (shipment_fk, container_fk, file_path, file_name, description, "
                           "uploaded_by, uploaded_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                           (fk, container_id, str(target), source.name, S.clean_text(description),
                            S.clean_text(uploaded_by), stamp))
        _ensure_record(conn, fk, container_id, stamp)
        return cur.lastrowid


@tracked("GATEIN")
def record_status(shipment_id: str, container_id: int, status_key: str, action: str, event_datetime,
                  source: str, confirmed_by: str | None, note: str | None = None,
                  evidence_id: int | None = None) -> GateInResult:
    """Record ONE status change. Only this status changes — never any other."""
    errors = []
    if status_key not in STATUS_NAMES:
        errors.append("Trạng thái không hợp lệ.")
    if action not in ACTIONS:
        errors.append("Thao tác phải là SET hoặc CLEAR.")
    if source not in SOURCES:
        errors.append("Nguồn phải là “Uploaded file” hoặc “Manual entry”.")
    when = S.parse_when(event_datetime, True, "Thời điểm", errors)
    confirmed_by, note = S.clean_text(confirmed_by), S.clean_text(note)
    if not confirmed_by:
        errors.append("Phải ghi ai xác nhận (Confirmed by).")
    if action == "SET" and not when:
        errors.append("Phải ghi thời điểm xảy ra (date/time) theo nguồn.")
    if source == "MANUAL" and not note:
        errors.append("Nhập tay: ghi rõ thông tin lấy từ đâu (VD: màn hình ePort, email của cảng, điện thoại).")
    if source == "UPLOADED_FILE" and not evidence_id:
        errors.append("Nguồn “Uploaded file”: chọn file bằng chứng đã tải lên.")
    if errors:
        raise GateInError(errors)
    stamp = S.now_text()
    with transaction() as conn:
        fk = _owner(conn, shipment_id, container_id)
        if source == "UPLOADED_FILE":
            ok = conn.execute("SELECT 1 FROM gatein_evidence WHERE id = ? AND container_fk = ?",
                              (evidence_id, container_id)).fetchone()
            if not ok:
                raise GateInError(["File bằng chứng không thuộc container này."])
        _ensure_record(conn, fk, container_id, stamp)
        conn.execute("INSERT INTO gatein_status_events (shipment_fk, container_fk, status_key, action, event_datetime, "
                     "source, evidence_fk, confirmed_by, note, recorded_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                     (fk, container_id, status_key, action, when, source,
                      evidence_id if source == "UPLOADED_FILE" else None, confirmed_by, note, stamp))
        conn.execute("UPDATE shipments SET updated_at = ? WHERE id = ?", (stamp, fk))
    return GateInResult(container_id, _warnings_for(shipment_id, container_id))


def record_pdf_export(container_ids: list[int], path: str) -> None:
    with transaction() as conn:
        for cid in container_ids:
            conn.execute("UPDATE gatein_records SET last_pdf_path = ?, last_pdf_at = ? WHERE container_fk = ?",
                         (path, S.now_text()[:16], cid))
