"""Step 4 — Shipping Instruction page (REQUIREMENTS.md §5 Step 4): 7 tabs like a carrier eBusiness SI.

Everything that already exists is filled in from the central data (🔗, read-only here with a
button to edit it at the source). Editable here: the SI-only fields, seal numbers (central),
cargo per container (central) and the freight payer (central party).
The SI gross weight is the CARGO gross weight. The VGM is shown only in the VGM tab, read-only.
"""

from pathlib import Path

import gradio as gr
import pandas as pd

from . import pdf_si as PS
from . import shipments as S
from . import si as SI
from . import vgm as V
from .formatting import fmt_cbm, fmt_count, fmt_date, fmt_datetime, fmt_kg, fmt_packages, packages_total
from .pdf_generator import render_pdf_pages
from .ui_common import e, message_html, notice_html, page_title_html, section_title_html, shipment_tracker_html
from .workflow import shipment_step_statuses

SEAL_HEADERS = ["#", "Container No.", "Size / ISO / Type", "🔗 Seal No."]
ALLOC_HEADERS = ["Container No.", "Dòng hàng #", "Số kiện (Packages)", "Gross weight (kg)", "CBM"]
BL_CHOICES = [(f"{v}", k) for k, v in SI.BL_TYPES.items()]
PAYMENT_CHOICES = [("Prepaid — trả trước", "PREPAID"), ("Collect — trả sau", "COLLECT")]
STATUS_STYLE = {"Not Started": "info", "Draft": "warning", "Submitted": "success", "Amended": "success",
                "Draft B/L Received": "success", "Draft B/L Approved": "success"}


# ---------------------------------------------------------------------------
# HTML pieces
# ---------------------------------------------------------------------------
def _cards(cells: list[tuple[str, str | None]]) -> str:
    items = "".join(f'<div class="kpi"><div class="label">🔗 {e(k)}</div>'
                    f'<div class="value" style="font-size:14px;white-space:pre-line">{e(v)}</div></div>'
                    for k, v in cells)
    return f'<div class="kpi-grid">{items}</div>'


def _party_text(p: dict) -> str | None:
    if not p.get("party_name"):
        return None
    return "\n".join(x for x in (p.get("party_name"), p.get("address"), p.get("country")) if x)


def parties_html(view: dict | None) -> str:
    if not view:
        return ""
    ship = view["shipment"]
    cells = [(label, _party_text(SI.party(ship, role)) or "⚠️ CHƯA CÓ") for role, label in (
        ("SHIPPER", "Shipper *"), ("CONSIGNEE", "Consignee *"), ("NOTIFY_PARTY", "Notify Party *"),
        ("FORWARDER", "Forwarder"), ("FREIGHT_PAYER", "Freight payer"))]
    out = _cards(cells)
    consignee = SI.party(ship, "CONSIGNEE").get("party_name")
    if SI.is_to_order(consignee) and not SI.party(ship, "NOTIFY_PARTY").get("party_name"):
        out += message_html("error", f"Consignee “{consignee}” (B/L theo lệnh) → bắt buộc có Notify Party.")
    return out + '<div class="hint">🔗 Dữ liệu chung — sửa ở Quản lý lô hàng (nút bên dưới).</div>'


def routing_html(view: dict | None) -> str:
    if not view:
        return ""
    s = view["shipment"]
    vessel = " / ".join(x for x in (s.get("vessel_name"), s.get("voyage_number")) if x) or None
    return _cards([("Place of Receipt", s.get("place_of_receipt")), ("Vessel / Voyage", vessel),
                   ("Port of Loading", s.get("port_of_loading")), ("Transshipment", s.get("transshipment_port")),
                   ("Port of Discharge", s.get("port_of_discharge")), ("Place of Delivery", s.get("place_of_delivery")),
                   ("ETD", fmt_date(s.get("etd")) if s.get("etd") else None),
                   ("SI cut-off", fmt_datetime(s.get("si_cutoff")) if s.get("si_cutoff") else None)]) + \
        '<div class="hint">🔗 Dữ liệu chung từ Bước 1 — sửa ở Bước 1 (nút bên dưới).</div>'


def cargo_lines_html(view: dict | None) -> str:
    if not view:
        return ""
    rows = []
    for n, l in enumerate(view["shipment"]["cargo"], start=1):
        desc = l.get("cargo_description") or l.get("commodity") or ""
        short = desc if len(desc) <= 160 else desc[:160] + f"… ({len(desc):,} ký tự)"
        rows.append(f"<tr><td>{n}</td><td>{e(l.get('marks_and_numbers'))}</td>"
                    f"<td>{e(fmt_packages(l.get('package_count'), l.get('package_type')))}</td>"
                    f"<td style='white-space:pre-line'>{e(short)}</td><td>{e(l.get('hs_code'))}</td>"
                    f"<td style='text-align:right'>{fmt_kg(l.get('gross_weight_kg'))}</td>"
                    f"<td style='text-align:right'>{fmt_cbm(l.get('volume_cbm'))}</td></tr>")
    t = SI.totals(view)
    rows.append(f"<tr class='total'><td></td><td><b>TOTAL</b></td><td><b>{e(packages_total(view['shipment']['cargo']))}</b></td>"
                f"<td colspan='2'>gross = hàng + bao bì (không phải VGM)</td>"
                f"<td style='text-align:right'><b>{fmt_kg(t['cargo']['gross'])}</b></td>"
                f"<td style='text-align:right'><b>{fmt_cbm(t['cargo']['cbm'])}</b></td></tr>")
    return ("<table class='si-table'><tr><th>#</th><th>Marks &amp; Numbers</th><th>Packages</th>"
            "<th>Description of Goods</th><th>HS</th><th>Gross (kg)</th><th>CBM</th></tr>" + "".join(rows) + "</table>"
            '<div class="hint">🔗 Dòng hàng là dữ liệu chung — sửa ở Quản lý lô hàng → Hàng hóa.</div>')


def _container_label(c: dict, n: int) -> str:
    return c.get("container_number") or f"#{n}"


def seal_frame(view: dict | None) -> pd.DataFrame:
    rows = []
    for n, c in enumerate((view or {}).get("shipment", {}).get("containers", []), start=1):
        size = " ".join(x for x in (f"{c['container_size']}'" if c.get("container_size") else None,
                                    c.get("iso_type_code"), c.get("container_type")) if x)
        rows.append([n, _container_label(c, n), size, c.get("seal_number") or ""])
    return pd.DataFrame(rows, columns=SEAL_HEADERS)


def alloc_frame(view: dict | None) -> pd.DataFrame:
    if not view:
        return pd.DataFrame(columns=ALLOC_HEADERS)
    ship = view["shipment"]
    labels = {c["id"]: _container_label(c, n) for n, c in enumerate(ship["containers"], start=1)}
    line_no = {l["id"]: n for n, l in enumerate(ship["cargo"], start=1)}
    rows = [[labels.get(a["container_fk"]), line_no.get(a["cargo_fk"]), a.get("package_count"),
             a.get("gross_weight_kg"), a.get("volume_cbm")] for a in view["allocations"]]
    return pd.DataFrame(rows, columns=ALLOC_HEADERS)


def parse_allocations(view: dict, frame) -> tuple[list[dict], list[str]]:
    """Table rows → [{container_id, cargo_id, ...}]; unknown container / line → error message."""
    ship = view["shipment"]
    by_label = {_container_label(c, n).upper(): c["id"] for n, c in enumerate(ship["containers"], start=1)}
    lines = {n: l["id"] for n, l in enumerate(ship["cargo"], start=1)}
    values = frame.values.tolist() if isinstance(frame, pd.DataFrame) else list(frame or [])
    out, errors = [], []
    for n, row in enumerate(values, start=1):
        row = list(row) + [None] * 5
        if all(S.is_blank(v) for v in row[:5]):
            continue
        label = str(row[0] or "").strip().upper()
        try:
            line = int(float(row[1]))
        except (TypeError, ValueError):
            line = None
        if label not in by_label:
            errors.append(f"Phân bổ dòng {n}: không có container “{row[0]}” trong lô hàng.")
            continue
        if line not in lines:
            errors.append(f"Phân bổ dòng {n}: không có dòng hàng số “{row[1]}”.")
            continue
        out.append({"container_id": by_label[label], "cargo_id": lines[line], "package_count": row[2],
                    "gross_weight_kg": row[3], "volume_cbm": row[4]})
    return out, errors


def _lenient_view(view: dict, frame) -> dict:
    """The view with the allocations as typed (for live totals)."""
    def num(value, integer=False):
        errs = []
        number = S.parse_number(value, "", errs, integer)
        return None if errs else number

    rows, _ = parse_allocations(view, frame)
    allocs = [{"container_fk": r["container_id"], "cargo_fk": r["cargo_id"],
               "package_count": num(r["package_count"], True), "gross_weight_kg": num(r["gross_weight_kg"]),
               "volume_cbm": num(r["volume_cbm"])} for r in rows]
    return {**view, "allocations": allocs}


def alloc_totals_html(view: dict | None, frame=None) -> str:
    if not view:
        return ""
    v = _lenient_view(view, frame) if frame is not None else view
    _, errors = parse_allocations(view, frame) if frame is not None else ([], [])
    t = SI.totals(v)
    ship = v["shipment"]
    rows = "".join(
        f"<tr><td>{e(_container_label(c, n))}</td><td style='text-align:right'>{fmt_count(t['per_container'][c['id']]['packages'])}</td>"
        f"<td style='text-align:right'>{fmt_kg(t['per_container'][c['id']]['gross'])}</td>"
        f"<td style='text-align:right'>{fmt_cbm(t['per_container'][c['id']]['cbm'])}</td></tr>"
        for n, c in enumerate(ship["containers"], start=1))
    rows += (f"<tr class='total'><td><b>Đã phân bổ</b></td><td style='text-align:right'><b>{fmt_count(t['allocated']['packages'])}</b></td>"
             f"<td style='text-align:right'><b>{fmt_kg(t['allocated']['gross'])}</b></td>"
             f"<td style='text-align:right'><b>{fmt_cbm(t['allocated']['cbm'])}</b></td></tr>"
             f"<tr><td>Dòng hàng (cargo lines)</td><td style='text-align:right'>{fmt_count(t['cargo']['packages'])}</td>"
             f"<td style='text-align:right'>{fmt_kg(t['cargo']['gross'])}</td>"
             f"<td style='text-align:right'>{fmt_cbm(t['cargo']['cbm'])}</td></tr>")
    table = ("<table class='si-table'><tr><th>Container</th><th>Packages</th><th>Gross (kg)</th><th>CBM</th></tr>"
             + rows + "</table>")
    problems = errors + SI.allocation_problems(v)
    msg = (message_html("warning", "Chưa khớp:", problems) if problems
           else message_html("success", "Hàng theo container khớp với dòng hàng (kiện, gross, CBM)."))
    return table + msg


def vgm_html(view: dict | None) -> str:
    if not view:
        return ""
    ship = view["shipment"]
    rows, missing = [], []
    for n, c in enumerate(ship["containers"], start=1):
        rec = view["vgms"].get(c["id"])
        status = V.status_label(V.record_status(rec))
        vgm = SI.declared_vgm(view, c)
        if vgm is None:
            missing.append(_container_label(c, n))
        rows.append(f"<tr><td>{e(_container_label(c, n))}</td><td>{e(status)}</td>"
                    f"<td style='text-align:right'>{fmt_kg(vgm) + ' kg' if vgm is not None else '⚠️ chưa có VGM đã khai'}</td>"
                    f"<td>{e((rec or {}).get('vgm_reference'))}</td></tr>")
    out = ("<table class='si-table'><tr><th>Container</th><th>Trạng thái VGM (Bước 3)</th><th>VGM</th><th>VGM ref.</th></tr>"
           + "".join(rows) + "</table>")
    if missing:
        out += message_html("warning", "Chưa có VGM đã khai cho: " + ", ".join(missing),
                            ["SI không bao giờ tự điền VGM. Khai VGM ở Bước 3 (nút bên dưới)."])
    return out + notice_html("VGM chỉ để xem (từ Bước 3). <b>Gross weight trên SI là khối lượng hàng + bao bì, "
                             "không phải VGM.</b> Chỉ VGM đã khai (Declared trở lên) mới hiện ở đây.")


def review_html(view: dict | None) -> str:
    if not view:
        return notice_html("Chọn một lô hàng.")
    ship, si = view["shipment"], view["si"]
    blocking, warnings = SI.checks(view)
    label = SI.document_label(view)
    t = SI.totals(view)
    status = si.get("si_status") or "Not Started"
    summary = _cards([
        ("SI status", f"{SI.status_label(status)} — {SI.STATUS_LABELS[status][1]}"), ("Nhãn PDF", label["badge"]),
        ("Booking / SI ref.", f"{ship.get('booking_number') or '—'} / {si.get('si_reference') or '—'}"),
        ("B/L", f"{SI.BL_TYPES.get(si.get('bl_type'), '—')} · {si.get('originals_count') or 0} bản gốc · "
                f"{si.get('copies_count') or 0} bản sao"),
        ("Shipper → Consignee", f"{SI.party(ship, 'SHIPPER').get('party_name') or '—'}\n→ "
                                f"{SI.party(ship, 'CONSIGNEE').get('party_name') or '—'}"),
        ("Tuyến", f"{ship.get('port_of_loading') or '—'} → {ship.get('port_of_discharge') or '—'}\n"
                  f"{ship.get('vessel_name') or '—'} / {ship.get('voyage_number') or '—'}"),
        ("Hàng", f"{packages_total(ship['cargo'])} · {fmt_kg(t['cargo']['gross'])} kg · {fmt_cbm(t['cargo']['cbm'])} CBM"),
        ("Container", f"{len(ship['containers'])} cont · seal: "
                      f"{sum(1 for c in ship['containers'] if c.get('seal_number'))}/{len(ship['containers'])}"),
        ("Cước", f"{SI.FREIGHT_TERMS.get(si.get('freight_terms'), '—')} · move type {si.get('service_type') or '—'}"
                 + (f" · payable at {si['payable_at']}" if si.get("payable_at") else "")),
    ])
    if blocking:
        checks = message_html("error", f"Cần sửa trước khi gửi SI ({len(blocking)}):", blocking)
    else:
        checks = message_html("success", "Không có lỗi chặn — có thể đánh dấu đã gửi (Mark as submitted).")
    if warnings:
        checks += message_html("warning", f"Cảnh báo ({len(warnings)}):", warnings)
    return summary + checks


SI_CSS = """
.si-table{width:100%;border-collapse:collapse;font-size:13px;margin:4px 0 8px}
.si-table th{background:#0B2545;color:#fff;text-align:left;padding:5px 6px;font-weight:600}
.si-table td{border-bottom:1px solid #E1E7EF;padding:4px 6px;vertical-align:top}
.si-table tr.total td{border-top:2px solid #0B2545;background:#E9EEF5}
"""


# ---------------------------------------------------------------------------
# Page
# ---------------------------------------------------------------------------
def build_si_page():
    """Returns (inputs, outputs, refresh, edit-routing button, edit-parties button, VGM button, shipment dropdown)."""
    si_in = {}
    gr.HTML(page_title_html("Bước 4 · Shipping Instruction (SI)",
                            "Hướng dẫn lập vận đơn — 7 tab như hệ thống eBusiness của hãng tàu"))
    gr.HTML(f"<style>{SI_CSS}</style>")
    ship_dd = gr.Dropdown(label="Chọn lô hàng (Shipment)", choices=[])
    tracker = gr.HTML()
    status_box = gr.HTML()

    with gr.Tabs(selected="doc") as tabs:
        with gr.Tab("1. Document Information", id="doc"):
            with gr.Row():
                booking_no = gr.Textbox(label="🔗 Booking No. (từ Bước 1)", interactive=False)
                si_in["si_reference"] = gr.Textbox(label="SI reference", placeholder="Để trống → SI-<Shipment ID>")
            with gr.Row():
                si_in["bl_type"] = gr.Radio(label="Loại vận đơn (B/L type) *", choices=BL_CHOICES, value="ORIGINAL")
                si_in["transport_doc_type"] = gr.Dropdown(label="Loại chứng từ vận tải (Transport document type)",
                                                          choices=list(SI.TRANSPORT_DOC_TYPES), allow_custom_value=True)
            with gr.Row():
                si_in["originals_count"] = gr.Textbox(label="Số bản gốc (Originals) — Original B/L *", placeholder="VD: 3")
                si_in["copies_count"] = gr.Textbox(label="Số bản sao (Copies)", placeholder="VD: 3")
            with gr.Row():
                si_in["shipper_reference"] = gr.Textbox(label="Shipper's reference (VD: số PO)")
                si_in["export_reference"] = gr.Textbox(label="Export reference (VD: số invoice / tờ khai)")
            si_in["document_receiver"] = gr.Textbox(label="Người nhận chứng từ (Document receiver)",
                                                    placeholder="Ai nhận B/L gốc / bản sao")
        with gr.Tab("2. Parties", id="parties"):
            parties_box = gr.HTML()
            edit_parties_btn = gr.Button("✏️ Sửa Shipper / Consignee / Notify ở Quản lý lô hàng", size="sm",
                                         elem_classes="fit-btn")
            gr.HTML(section_title_html("Additional notify party", "Bên nhận thông báo thêm — chỉ có trên SI (không bắt buộc)"))
            with gr.Row():
                si_in["additional_notify_name"] = gr.Textbox(label="Tên (Name)")
                si_in["additional_notify_address"] = gr.Textbox(label="Địa chỉ (Address)")
        with gr.Tab("3. Routing", id="routing"):
            routing_box = gr.HTML()
            edit_routing_btn = gr.Button("✏️ Sửa tuyến / tàu / lịch ở Bước 1", size="sm", elem_classes="fit-btn")
            si_in["pre_carriage"] = gr.Textbox(label="Pre-carriage by (vận chuyển nội địa trước)",
                                               placeholder="VD: Truck / Barge")
        with gr.Tab("4. Cargo Details", id="cargo"):
            cargo_box = gr.HTML()
            gr.HTML(section_title_html("Container & seal", "Số seal là dữ liệu chung của container (🔗)"))
            seal_df = gr.Dataframe(value=pd.DataFrame(columns=SEAL_HEADERS), headers=SEAL_HEADERS,
                                   datatype=["number", "str", "str", "str"], interactive=True,
                                   static_columns=[0, 1, 2], wrap=True)
            gr.HTML(section_title_html("Hàng theo từng container (Cargo per container)",
                                       "Mỗi dòng: container + số dòng hàng + kiện / gross / CBM trong container đó"))
            gr.HTML(notice_html("Gõ <b>số container</b> (hoặc #1, #2 nếu chưa có số) và <b>số thứ tự dòng hàng</b>. "
                                "Tổng các container phải bằng dòng hàng. Gross = <b>hàng + bao bì</b>, không phải VGM."))
            alloc_df = gr.Dataframe(value=pd.DataFrame(columns=ALLOC_HEADERS), headers=ALLOC_HEADERS,
                                    datatype=["str", "number", "number", "number", "number"], interactive=True,
                                    wrap=True)
            with gr.Row():
                suggest_btn = gr.Button("💡 Gợi ý: dòng hàng 1 → container 1, dòng 2 → container 2…", size="sm")
                grid_btn = gr.Button("＋ Thêm dòng trống cho mọi container × dòng hàng", size="sm")
            alloc_totals = gr.HTML()
        with gr.Tab("5. Freight & Payment", id="freight"):
            with gr.Row():
                si_in["freight_terms"] = gr.Radio(label="Freight terms — Prepaid / Collect *", choices=PAYMENT_CHOICES,
                                                  value=None)
                si_in["service_type"] = gr.Dropdown(
                    label="Service type / Move type (VD CY/CY)", choices=list(SI.SERVICE_TYPES),
                    allow_custom_value=True,
                    info="CY/CY = port to port (merchant haulage). Có chặng Door = hãng tàu chở nội địa → Combined Transport B/L.")
            with gr.Row():
                si_in["payable_at"] = gr.Textbox(label="Payable at (bắt buộc khi Collect)")
                freight_payer = gr.Textbox(label="🔗 Bên thanh toán cước (Freight payer)",
                                           info="Dữ liệu chung (Các bên → Freight Payer).")
            si_in["freight_charges"] = gr.Textbox(label="Freight & charges (nếu có)", lines=2,
                                                  placeholder="VD: Ocean freight as arranged")
        with gr.Tab("6. VGM", id="vgm"):
            vgm_box = gr.HTML()
            open_vgm_btn = gr.Button("⚖️ Mở Bước 3 — khai VGM", size="sm", elem_classes="fit-btn")
        with gr.Tab("7. Review & Submit", id="review"):
            review_box = gr.HTML()
            si_in["remarks"] = gr.Textbox(label="Ghi chú trên SI (Remarks)", lines=2)
            form_msg = gr.HTML()
            save_btn = gr.Button("💾 Lưu nháp (Save draft)", variant="primary")
            with gr.Accordion("📤 Đánh dấu đã gửi SI (Mark as submitted)", open=False):
                gr.HTML(notice_html("Chỉ bấm khi bạn <b>đã thật sự gửi</b> SI cho hãng tàu. App không tự gửi."))
                with gr.Row():
                    si_in["submission_date"] = gr.DateTime(label="Ngày gửi (Submission date)", include_time=False,
                                                           type="string")
                    si_in["submission_channel"] = gr.Dropdown(label="Kênh gửi (Channel)", allow_custom_value=True,
                                                              choices=list(SI.SUBMISSION_CHANNELS))
                submit_btn = gr.Button("📤 Mark as submitted")
            with gr.Accordion("📝 Đánh dấu đã gửi bản sửa đổi (Mark as amended)", open=False):
                with gr.Row():
                    si_in["amendment_date"] = gr.DateTime(label="Ngày gửi bản sửa (Amendment date)",
                                                          include_time=False, type="string")
                    si_in["amendment_reason"] = gr.Textbox(label="Lý do sửa (Reason)")
                amend_btn = gr.Button("📝 Mark as amended")
            with gr.Accordion("📥 Draft B/L từ hãng tàu", open=False):
                with gr.Row():
                    si_in["draft_bl_received_date"] = gr.DateTime(label="Ngày nhận Draft B/L", include_time=False,
                                                                  type="string")
                    si_in["draft_bl_reference"] = gr.Textbox(label="Số tham chiếu Draft B/L (nếu có)")
                    si_in["draft_bl_approved_date"] = gr.DateTime(label="Ngày duyệt Draft B/L", include_time=False,
                                                                  type="string")
                with gr.Row():
                    bl_received_btn = gr.Button("📥 Draft B/L Received")
                    bl_approved_btn = gr.Button("✅ Draft B/L Approved")
            gr.HTML(section_title_html("PDF", "Xem trước dùng dữ liệu ĐÃ LƯU"))
            with gr.Row():
                preview_btn = gr.Button("👁 Xem trước SI")
                export_btn = gr.Button("📄 Xuất PDF SI", variant="primary")
                download_btn = gr.DownloadButton("⬇ Tải SI", visible=False)
            export_msg = gr.HTML()
            gallery = gr.Gallery(label="Bản xem trước (mỗi ảnh là một trang A4)", columns=1, height="auto",
                                 object_fit="contain")

    si_keys = list(SI.SI_FIELDS)
    si_inputs = [si_in[k] for k in si_keys]
    save_inputs = [ship_dd, *si_inputs, seal_df, alloc_df, freight_payer]
    view_outputs = [tracker, status_box, booking_no, parties_box, routing_box, cargo_box, seal_df, alloc_df,
                    alloc_totals, freight_payer, vgm_box, review_box, *si_inputs, download_btn]

    # ------------------------------------------------------------------ logic
    def status_html(view):
        if not view:
            return ""
        status = view["si"].get("si_status") or "Not Started"
        label = SI.document_label(view)
        blocking, warnings = SI.checks(view)
        kind = "error" if label["badge"] == "CHANGED SINCE SUBMISSION" else STATUS_STYLE.get(status, "info")
        items = [f"Nhãn PDF: {label['badge']}", f"{len(blocking)} lỗi cần sửa trước khi gửi · {len(warnings)} cảnh báo "
                 "— xem tab 7. Review & Submit"]
        if not view["exists"]:
            items.insert(0, "Chưa có SI — dữ liệu chung đã được điền sẵn. Kiểm tra rồi bấm “Lưu nháp”.")
        return message_html(kind, f"SI {view['si'].get('si_reference')}: {SI.status_label(status)}", items)

    def view_values(view):
        if not view:
            return [shipment_tracker_html(["Not Started"] * 6), "", "", "", "", "",
                    seal_frame(None), alloc_frame(None), "", "", "", review_html(None)] + \
                   [None] * len(si_keys) + [gr.update(visible=False)]
        si = view["si"]
        values = []
        for k in si_keys:
            v = si.get(k)
            if k in SI.INT_FIELDS:
                v = "" if v is None else str(v)
            elif k in SI.DATE_FIELDS or k in ("bl_type", "freight_terms", "transport_doc_type", "service_type",
                                              "submission_channel"):
                v = v or None
            else:
                v = v or ""
            values.append(v)
        pdf = si.get("last_pdf_path")
        download = (gr.update(value=pdf, visible=True, label=f"⬇ Tải SI ({Path(pdf).name})")
                    if pdf and Path(pdf).exists() else gr.update(value=None, visible=False))
        sid = view["shipment"]["shipment_id"]
        return [shipment_tracker_html(shipment_step_statuses(sid)), status_html(view),
                view["shipment"].get("booking_number") or "(chưa có — nhập ở Bước 1)", parties_html(view),
                routing_html(view), cargo_lines_html(view), seal_frame(view), alloc_frame(view),
                alloc_totals_html(view), SI.party(view["shipment"], "FREIGHT_PAYER").get("party_name") or "",
                vgm_html(view), review_html(view), *values, download]

    def load(shipment_id):
        return view_values(SI.get_si_view(shipment_id) if shipment_id else None)

    def refresh(shipment_id):
        choices = [(f"{r['shipment_id']} · {r.get('booking_number') or 'chưa có booking'} · "
                    f"{r.get('customer_name') or r.get('shipper_name') or ''}", r["shipment_id"])
                   for r in S.list_shipments()]
        ids = [c[1] for c in choices]
        if shipment_id not in ids:
            shipment_id = ids[0] if ids else None
        return [gr.update(choices=choices, value=shipment_id), *load(shipment_id)]

    def do_save(action, shipment_id, *values):
        n = len(si_keys)
        si_values = dict(zip(si_keys, values[:n]))
        seal_tab, alloc_tab, payer = values[n], values[n + 1], values[n + 2]
        skip = [gr.skip()] * len(view_outputs)
        if not shipment_id:
            return skip + [message_html("warning", "Hãy chọn lô hàng trước.")]
        view = SI.get_si_view(shipment_id)
        ship = view["shipment"]
        seals = {}
        seal_rows = seal_tab.values.tolist() if isinstance(seal_tab, pd.DataFrame) else list(seal_tab or [])
        for row, c in zip(seal_rows, ship["containers"]):
            seals[c["id"]] = row[3] if len(row) > 3 else None
        allocations, errors = parse_allocations(view, alloc_tab)
        if errors:
            return skip + [message_html("error", "Chưa lưu được:", errors)]
        try:
            result = SI.save_si(shipment_id, si_values, seals, allocations, payer, action)
        except S.ShipmentError as ex:
            return skip + [message_html("error", "Chưa lưu được:", ex.errors)]
        verb = {"draft": "Đã lưu nháp", "submit": "Đã đánh dấu ĐÃ GỬI", "amend": "Đã đánh dấu ĐÃ SỬA ĐỔI",
                "bl_received": "Đã ghi nhận Draft B/L", "bl_approved": "Đã ghi nhận duyệt Draft B/L"}[action]
        title = (f"{verb if result.action_done else 'Đã lưu dữ liệu'} — SI {result.si_reference}: "
                 f"{SI.status_label(result.status)}")
        kind = "success" if result.action_done and not result.warnings else ("warning" if result.action_done else "error")
        return load(shipment_id) + [message_html(kind, title + (". Lưu ý:" if result.warnings else "."), result.warnings)]

    def suggest(shipment_id):
        view = SI.get_si_view(shipment_id) if shipment_id else None
        if not view:
            return gr.skip(), ""
        ship = view["shipment"]
        rows = [[_container_label(c, n), n, l.get("package_count"), l.get("gross_weight_kg"), l.get("volume_cbm")]
                for n, (c, l) in enumerate(zip(ship["containers"], ship["cargo"]), start=1)]
        frame = pd.DataFrame(rows, columns=ALLOC_HEADERS)
        return frame, alloc_totals_html(view, frame)     # e.g. "container X has no cargo" when counts differ

    def full_grid(shipment_id):
        view = SI.get_si_view(shipment_id) if shipment_id else None
        if not view:
            return gr.skip()
        ship = view["shipment"]
        rows = [[_container_label(c, i), n, None, None, None]
                for i, c in enumerate(ship["containers"], start=1) for n, _ in enumerate(ship["cargo"], start=1)]
        return pd.DataFrame(rows, columns=ALLOC_HEADERS)

    def live_totals(shipment_id, frame):
        view = SI.get_si_view(shipment_id) if shipment_id else None
        return alloc_totals_html(view, frame) if view else ""

    def preview(shipment_id):
        if not shipment_id:
            return None, message_html("warning", "Hãy chọn lô hàng trước.")
        try:
            pages = render_pdf_pages(PS.build_shipping_instruction_pdf_bytes(shipment_id), scale=1.6)
        except S.ShipmentError as ex:
            return None, message_html("error", "Không tạo được bản xem trước.", ex.errors)
        return pages, message_html("info", f"Bản xem trước: {len(pages)} trang.")

    def export(shipment_id):
        if not shipment_id:
            return gr.skip(), message_html("warning", "Hãy chọn lô hàng trước.")
        try:
            path = PS.generate_shipping_instruction_pdf(shipment_id)
        except S.ShipmentError as ex:
            return gr.skip(), message_html("error", "Chưa xuất được PDF.", ex.errors)
        return (gr.update(value=str(path), visible=True, label=f"⬇ Tải ({path.name})"),
                message_html("success", f"Đã xuất PDF: {path.name}", [f"Lưu tại: {path}"]))

    # ------------------------------------------------------------------ events
    ship_dd.change(lambda s: load(s) + ["", None, ""], ship_dd, [*view_outputs, form_msg, gallery, export_msg])
    for btn, action in ((save_btn, "draft"), (submit_btn, "submit"), (amend_btn, "amend"),
                        (bl_received_btn, "bl_received"), (bl_approved_btn, "bl_approved")):
        btn.click(lambda *v, a=action: do_save(a, *v), save_inputs, [*view_outputs, form_msg])
    suggest_btn.click(suggest, ship_dd, [alloc_df, alloc_totals])
    grid_btn.click(full_grid, ship_dd, alloc_df)
    alloc_df.change(live_totals, [ship_dd, alloc_df], alloc_totals, show_progress="hidden")
    preview_btn.click(preview, ship_dd, [gallery, export_msg])
    export_btn.click(export, ship_dd, [download_btn, export_msg])

    return [ship_dd], [ship_dd, *view_outputs], refresh, edit_routing_btn, edit_parties_btn, open_vgm_btn, ship_dd
