"""One formatting standard for every document (all six PDFs) and the screens.

    Weights  : kilograms, no decimals, thousands separator   → 18,500
               (metric tons when chosen for a VGM: 3 decimals → 23.035)
    Volume   : CBM, 3 decimals                                → 60.500
    Counts   : thousands separator                            → 1,540
    Packages : total with unit; mixed or missing types → PKGS → 1,540 CARTONS / 1,540 PKGS
    Dates    : DD MON YYYY (unambiguous internationally)      → 27 NOV 2026
    Date-time: DD MON YYYY HH:MM                              → 25 NOV 2026 12:00
"""

from datetime import datetime
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

DASH = "—"
MIXED_PACKAGE_UNIT = "PKGS"


def _decimal(value) -> Decimal | None:
    if value is None or (isinstance(value, str) and not value.strip()):
        return None
    try:
        number = Decimal(str(value))
    except InvalidOperation:
        return None
    return None if number.is_nan() else number


def fmt_kg(value) -> str:
    """Weight in kg: 18500.4 → '18,500' (rounded half up, no decimals)."""
    number = _decimal(value)
    if number is None:
        return DASH
    return f"{number.quantize(Decimal('1'), ROUND_HALF_UP):,}"


def fmt_tonnes(value_kg) -> str:
    """Weight given in kg, shown in metric tons with 3 decimals: 23035 → '23.035'."""
    number = _decimal(value_kg)
    if number is None:
        return DASH
    return f"{(number / 1000).quantize(Decimal('0.001'), ROUND_HALF_UP):,}"


def fmt_cbm(value) -> str:
    """Volume in CBM: 60.5 → '60.500'."""
    number = _decimal(value)
    if number is None:
        return DASH
    return f"{number.quantize(Decimal('0.001'), ROUND_HALF_UP):,}"


def fmt_count(value) -> str:
    number = _decimal(value)
    if number is None:
        return DASH
    return f"{number.quantize(Decimal('1'), ROUND_HALF_UP):,}"


def package_unit(package_type) -> str:
    return (package_type or "").strip().upper()


def fmt_packages(count, package_type) -> str:
    """One line: '780 CARTONS' (unit PKGS when the type is not recorded)."""
    if count in (None, ""):
        return DASH
    return f"{fmt_count(count)} {package_unit(package_type) or MIXED_PACKAGE_UNIT}"


def packages_total(lines: list[dict]) -> str:
    """Total over cargo lines: '1,540 CARTONS' if every line uses the same unit, else '1,540 PKGS'."""
    counted = [line for line in lines if line.get("package_count") not in (None, "")]
    if not counted:
        return DASH
    total = sum(int(line["package_count"]) for line in counted)
    units = {package_unit(line.get("package_type")) for line in counted}
    unit = units.pop() if len(units) == 1 and "" not in units else MIXED_PACKAGE_UNIT
    return f"{total:,} {unit}"


def fmt_date(value) -> str:
    """'2026-11-27' → '27 NOV 2026'."""
    if not value:
        return DASH
    try:
        return datetime.strptime(str(value)[:10], "%Y-%m-%d").strftime("%d %b %Y").upper()
    except ValueError:
        return str(value)


def fmt_datetime(value) -> str:
    """'2026-11-25 12:00' → '25 NOV 2026 12:00' (a date without time stays a date)."""
    if not value:
        return DASH
    text = str(value)
    try:
        return datetime.strptime(text[:16], "%Y-%m-%d %H:%M").strftime("%d %b %Y %H:%M").upper()
    except ValueError:
        return fmt_date(text)
