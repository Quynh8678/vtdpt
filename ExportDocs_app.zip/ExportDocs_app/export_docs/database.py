"""SQLite database: connection and table definitions.

Field names follow one convention everywhere (snake_case, DCSA-inspired):
weights are always in kilograms (*_kg), volume in cubic metres (*_cbm),
dates as ISO text "YYYY-MM-DD", date-times as "YYYY-MM-DD HH:MM".

Tables created so far (REQUIREMENTS.md §13): shipments, shipment_parties,
shipment_cargo, containers, container_cargo, bookings, eir_records, vgm_records, si_records,
gatein_records, gatein_evidence, gatein_status_events, bl_records, bl_documents, bl_status_events,
for Phase 5: document_versions, change_log, doc_locks, doc_overrides, sync_conflicts,
and for Phase 6: uploaded_documents, library_files, reference_items.
"""

import sqlite3
from contextlib import contextmanager

from . import drive_sync, settings

SCHEMA = """
CREATE TABLE IF NOT EXISTS shipments (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_id             TEXT NOT NULL UNIQUE,        -- public ID, e.g. SHP-2026-0001
    status                  TEXT NOT NULL DEFAULT 'Draft',
    is_sample               INTEGER NOT NULL DEFAULT 0,  -- 1 = sample data, never real
    sample_label            TEXT,                        -- 'SAMPLE / DEMO' or 'SAMPLE / TEST'
    created_at              TEXT NOT NULL,
    updated_at              TEXT NOT NULL,

    -- A. General
    transport_mode          TEXT,
    export_type             TEXT,
    person_in_charge        TEXT,
    customer_name           TEXT,
    contract_reference      TEXT,
    notes                   TEXT,

    -- D. Transport
    carrier_name            TEXT,
    booking_number          TEXT,
    vessel_name             TEXT,
    voyage_number           TEXT,
    place_of_receipt        TEXT,
    port_of_loading         TEXT,
    port_of_discharge       TEXT,
    transshipment_port      TEXT,
    place_of_delivery       TEXT,
    etd                     TEXT,
    eta                     TEXT,
    cy_cutoff               TEXT,
    si_cutoff               TEXT,
    vgm_cutoff              TEXT,
    empty_pickup_depot      TEXT,
    empty_pickup_date       TEXT,
    container_return_depot  TEXT
);

-- B. Parties: one row per role per shipment
CREATE TABLE IF NOT EXISTS shipment_parties (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_fk     INTEGER NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
    party_role      TEXT NOT NULL,   -- SHIPPER, CONSIGNEE, NOTIFY_PARTY, BOOKING_PARTY, FORWARDER, FREIGHT_PAYER
    party_name      TEXT,
    address         TEXT,
    country         TEXT,
    tax_id          TEXT,
    email           TEXT,
    phone           TEXT,
    UNIQUE (shipment_fk, party_role)
);

-- C. Cargo: many lines per shipment
CREATE TABLE IF NOT EXISTS shipment_cargo (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_fk         INTEGER NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
    line_number         INTEGER NOT NULL,
    commodity           TEXT,
    cargo_description   TEXT,          -- English description of goods
    hs_code             TEXT,
    quantity            REAL,
    quantity_unit       TEXT,
    package_count       INTEGER,
    package_type        TEXT,
    gross_weight_kg     REAL,
    net_weight_kg       REAL,
    volume_cbm          REAL,
    marks_and_numbers   TEXT,
    storage_conditions  TEXT,
    dangerous_goods_info TEXT
);

-- E. Containers: many per shipment, each its own record
CREATE TABLE IF NOT EXISTS containers (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_fk         INTEGER NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
    container_number    TEXT,          -- may be empty until the container is assigned
    container_size      TEXT,          -- 20 / 40 / 45
    iso_type_code       TEXT,          -- e.g. 22G1, 45G1
    container_type      TEXT,          -- Dry, High Cube, Reefer, Open Top, Flat Rack, Tank
    load_status         TEXT,          -- Full / Empty
    tare_weight_kg      REAL,
    cargo_weight_kg     REAL,
    gross_weight_kg     REAL,
    seal_number         TEXT,
    vgm_kg              REAL,          -- filled by Step 3 (VGM Declaration)
    truck_number        TEXT,
    chassis_number      TEXT,
    eir_number          TEXT,          -- filled by Step 2 (EIR)
    notes               TEXT
);

-- Step 1: Booking Confirmation — ONLY the booking-specific fields.
-- Booking number, carrier, routing, vessel/voyage, dates and cut-offs live in
-- `shipments` (one central copy) and are read from there (REQUIREMENTS.md §6).
CREATE TABLE IF NOT EXISTS bookings (
    id                          INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_fk                 INTEGER NOT NULL UNIQUE REFERENCES shipments(id) ON DELETE CASCADE,
    booking_status              TEXT NOT NULL DEFAULT 'Booking Request',
    booking_date                TEXT,
    confirmation_date           TEXT,
    customer_reference          TEXT,
    commodity                   TEXT,
    special_cargo_requirements  TEXT,
    carrier_instructions        TEXT,
    remarks                     TEXT,
    -- evidence of the carrier's confirmation (never assumed)
    confirmation_source         TEXT NOT NULL DEFAULT 'NONE',
    confirmation_reference      TEXT,
    confirmed_by                TEXT,
    doc_version                 INTEGER NOT NULL DEFAULT 1,
    last_pdf_path               TEXT,
    last_pdf_at                 TEXT,
    created_at                  TEXT NOT NULL,
    updated_at                  TEXT NOT NULL
);

-- Step 2: Empty Container EIR — one record per container, EIR-only facts.
-- Container number, size/ISO/type, truck, chassis and the depot's EIR number
-- live in `containers` (central); booking no., carrier, planned depot in `shipments`.
CREATE TABLE IF NOT EXISTS eir_records (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_fk             INTEGER NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
    container_fk            INTEGER NOT NULL UNIQUE REFERENCES containers(id) ON DELETE CASCADE,
    internal_reference      TEXT NOT NULL UNIQUE,   -- EIR-INT-<ShipmentID>-<n>; never a depot number
    eir_datetime            TEXT,                   -- handover date/time
    depot_yard              TEXT,                   -- actual depot; NULL = same as planned pick-up depot
    handover_load_status    TEXT NOT NULL DEFAULT 'Empty',
    driver_info             TEXT,
    handover_info           TEXT,
    damage_remarks          TEXT,
    cond_floor              TEXT NOT NULL DEFAULT 'NOT_CHECKED',
    cond_roof               TEXT NOT NULL DEFAULT 'NOT_CHECKED',
    cond_left_side          TEXT NOT NULL DEFAULT 'NOT_CHECKED',
    cond_right_side         TEXT NOT NULL DEFAULT 'NOT_CHECKED',
    cond_front_wall         TEXT NOT NULL DEFAULT 'NOT_CHECKED',
    cond_door               TEXT NOT NULL DEFAULT 'NOT_CHECKED',
    cond_door_seals         TEXT NOT NULL DEFAULT 'NOT_CHECKED',
    note_floor              TEXT,
    note_roof               TEXT,
    note_left_side          TEXT,
    note_right_side         TEXT,
    note_front_wall         TEXT,
    note_door               TEXT,
    note_door_seals         TEXT,
    doc_version             INTEGER NOT NULL DEFAULT 1,
    last_pdf_path           TEXT,
    last_pdf_at             TEXT,
    created_at              TEXT NOT NULL,
    updated_at              TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_eir_shipment ON eir_records(shipment_fk);

-- Step 3: VGM Declaration — one record per container, VGM-only facts.
-- Container number, tare, max gross (CSC) live in `containers`; booking no., vessel/voyage,
-- shipper in `shipments` / `shipment_parties`. The declared VGM is copied to containers.vgm_kg.
CREATE TABLE IF NOT EXISTS vgm_records (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_fk             INTEGER NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
    container_fk            INTEGER NOT NULL UNIQUE REFERENCES containers(id) ON DELETE CASCADE,
    vgm_reference           TEXT NOT NULL,          -- the shipper's own reference (VGM-<ShipmentID>-<n> by default)
    vgm_status              TEXT NOT NULL DEFAULT 'Draft',   -- Draft / Declared / Submitted / Acknowledged / Amended
    responsible_party       TEXT,                   -- shipper responsible for the VGM
    weighing_method         TEXT,                   -- METHOD_1 / METHOD_2
    cargo_basis             TEXT NOT NULL DEFAULT 'GROSS',   -- GROSS = cargo weight includes packaging; NET = goods only
    cargo_weight_kg         REAL,
    packaging_weight_kg     REAL,
    pallet_weight_kg        REAL,
    dunnage_weight_kg       REAL,
    securing_weight_kg      REAL,
    weighed_vgm_kg          REAL,                   -- Method 1: result of weighing the packed container
    vgm_kg                  REAL,                   -- final VGM (Method 1 weighed / Method 2 calculated)
    tare_used_kg            REAL,                   -- tare used when the VGM was saved (detects later changes)
    declared_booking_number TEXT,                   -- booking number when saved (detects later changes)
    vgm_unit                TEXT NOT NULL DEFAULT 'KGM',     -- KGM (kg) / TNE (metric tons) — display unit
    weighing_datetime       TEXT,
    weighing_location       TEXT,
    weighing_provider       TEXT,                   -- weighing equipment / service provider
    signatory_name          TEXT,
    signatory_position      TEXT,
    declaration_date        TEXT,
    submission_date         TEXT,
    submission_channel      TEXT,
    ack_reference           TEXT,                   -- carrier/terminal acknowledgement ref, typed by the user
    remarks                 TEXT,
    doc_version             INTEGER NOT NULL DEFAULT 1,
    last_pdf_path           TEXT,
    last_pdf_at             TEXT,
    created_at              TEXT NOT NULL,
    updated_at              TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_vgm_shipment ON vgm_records(shipment_fk);

-- Cargo per container (central: used by the SI in Step 4 and the B/L in Step 6).
-- One row = part of one cargo line packed in one container.
CREATE TABLE IF NOT EXISTS container_cargo (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_fk         INTEGER NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
    container_fk        INTEGER NOT NULL REFERENCES containers(id) ON DELETE CASCADE,
    cargo_fk            INTEGER NOT NULL REFERENCES shipment_cargo(id) ON DELETE CASCADE,
    package_count       INTEGER,
    gross_weight_kg     REAL,          -- CARGO gross weight (goods + packaging) — never the VGM
    volume_cbm          REAL,
    UNIQUE (container_fk, cargo_fk)
);
CREATE INDEX IF NOT EXISTS idx_container_cargo_shipment ON container_cargo(shipment_fk);

-- Step 5: Export Gate-in & Loading Registration — one record per container (port facts only).
-- Booking, vessel, routing, container, seal (SI), cargo gross, tare and VGM are read from the central data.
-- Nothing here comes from a real ePort connection: every record is an INTERNAL RECORD / REFERENCE COPY,
-- and port reference numbers are only ever typed in by the user.
CREATE TABLE IF NOT EXISTS gatein_records (
    id                          INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_fk                 INTEGER NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
    container_fk                INTEGER NOT NULL UNIQUE REFERENCES containers(id) ON DELETE CASCADE,
    terminal_name               TEXT,
    terminal_area               TEXT,
    transaction_ref             TEXT,       -- terminal transaction reference (typed by the user)
    registration_no             TEXT,       -- export registration number (typed by the user)
    gatein_eir_no               TEXT,       -- terminal's gate-in (full-in) EIR number (typed by the user)
    gatein_datetime             TEXT,
    gatein_seal_number          TEXT,       -- seal seen at gate-in (compared with the SI seal)
    truck_number                TEXT,
    chassis_number              TEXT,
    vehicle_arrival             TEXT,
    container_arrival           TEXT,
    yard_location               TEXT,
    yard_block                  TEXT,
    yard_bay                    TEXT,
    yard_row                    TEXT,
    yard_tier                   TEXT,
    container_condition         TEXT,
    customs_declaration_no      TEXT,       -- Vietnamese export declaration: 12 digits
    customs_declaration_date    TEXT,
    customs_office              TEXT,
    customs_lane                TEXT,       -- GREEN / YELLOW / RED
    customs_clearance_date      TEXT,
    customs_supervision_status  TEXT,
    export_registration_status  TEXT,       -- former field; now a status in the timeline
    vessel_loading_status       TEXT,
    loading_confirmation_ref    TEXT,
    actual_loading_datetime     TEXT,
    remarks                     TEXT,
    doc_version                 INTEGER NOT NULL DEFAULT 1,
    last_pdf_path               TEXT,
    last_pdf_at                 TEXT,
    created_at                  TEXT NOT NULL,
    updated_at                  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_gatein_shipment ON gatein_records(shipment_fk);

-- Uploaded evidence (port confirmation files, photos) for Step 5
CREATE TABLE IF NOT EXISTS gatein_evidence (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_fk     INTEGER NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
    container_fk    INTEGER NOT NULL REFERENCES containers(id) ON DELETE CASCADE,
    file_path       TEXT NOT NULL,
    file_name       TEXT NOT NULL,
    description     TEXT,
    uploaded_by     TEXT,
    uploaded_at     TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_gatein_evidence_container ON gatein_evidence(container_fk);

-- Step 5 status log: each of the 9 statuses changes ONLY through its own event (never automatically).
-- Every event records its source, the evidence file (if any), who confirmed it and when.
CREATE TABLE IF NOT EXISTS gatein_status_events (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_fk     INTEGER NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
    container_fk    INTEGER NOT NULL REFERENCES containers(id) ON DELETE CASCADE,
    status_key      TEXT NOT NULL,      -- NOT_ARRIVED, GATE_IN_COMPLETED, CUSTOMS_PENDING, …
    action          TEXT NOT NULL,      -- SET (confirmed) / CLEAR (no longer applies)
    event_datetime  TEXT,               -- when it happened (as reported by the source)
    source          TEXT NOT NULL,      -- MANUAL / UPLOADED_FILE
    evidence_fk     INTEGER REFERENCES gatein_evidence(id) ON DELETE SET NULL,
    confirmed_by    TEXT NOT NULL,
    note            TEXT,
    recorded_at     TEXT NOT NULL       -- when it was entered in this app
);
CREATE INDEX IF NOT EXISTS idx_gatein_events_container ON gatein_status_events(container_fk);

-- Step 6: Bill of Lading (draft) — one per shipment, B/L-only fields.
-- `particulars` is the B/L's OWN copy of what it says (parties, routing, cargo lines, containers, seals),
-- taken from the SI when the B/L is created. It is compared with the SI; differences are only
-- resolved by the user ("use SI value") — never automatically.
-- Freight, B/L type, originals, booking and carrier are inherited live from the SI / central data.
CREATE TABLE IF NOT EXISTS bl_records (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_fk             INTEGER NOT NULL UNIQUE REFERENCES shipments(id) ON DELETE CASCADE,
    bl_status               TEXT NOT NULL DEFAULT 'Draft',
    draft_reference         TEXT NOT NULL,      -- internal "Draft ref." — never an official B/L number
    carrier_bl_number       TEXT,               -- only the carrier's real number, typed by the user
    place_of_issue          TEXT,
    date_of_issue           TEXT,
    shipped_on_board_date   TEXT,               -- only when every container is Loaded on Board (Step 5)
    on_board_notation       INTEGER NOT NULL DEFAULT 0,
    remarks                 TEXT,
    particulars             TEXT NOT NULL,      -- JSON
    doc_version             INTEGER NOT NULL DEFAULT 1,
    last_pdf_path           TEXT,
    last_pdf_at             TEXT,
    created_at              TEXT NOT NULL,
    updated_at              TEXT NOT NULL
);

-- Carrier documents uploaded for the B/L (required before "Issued" / "Released" / "Amended")
CREATE TABLE IF NOT EXISTS bl_documents (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_fk     INTEGER NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
    file_path       TEXT NOT NULL,
    file_name       TEXT NOT NULL,
    description     TEXT,
    uploaded_by     TEXT,
    uploaded_at     TEXT NOT NULL
);

-- B/L status history: every status change with date, who confirmed it and the document used
CREATE TABLE IF NOT EXISTS bl_status_events (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_fk     INTEGER NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
    status          TEXT NOT NULL,
    event_date      TEXT,
    confirmed_by    TEXT NOT NULL,
    note            TEXT,
    document_fk     INTEGER REFERENCES bl_documents(id) ON DELETE SET NULL,
    recorded_at     TEXT NOT NULL
);

-- Step 4: Shipping Instruction — one per shipment, SI-only fields.
-- Parties, routing, vessel/voyage, cargo lines, containers, seals and VGM are read
-- from the central tables (REQUIREMENTS.md §6).
CREATE TABLE IF NOT EXISTS si_records (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_fk             INTEGER NOT NULL UNIQUE REFERENCES shipments(id) ON DELETE CASCADE,
    si_status               TEXT NOT NULL DEFAULT 'Draft',
    si_reference            TEXT NOT NULL,
    bl_type                 TEXT,          -- ORIGINAL / SEA_WAYBILL / TELEX
    originals_count         INTEGER,
    copies_count            INTEGER,
    transport_doc_type      TEXT,
    shipper_reference       TEXT,
    export_reference        TEXT,
    document_receiver       TEXT,
    additional_notify_name  TEXT,
    additional_notify_address TEXT,
    pre_carriage            TEXT,
    service_type            TEXT,          -- service type / move type, e.g. CY/CY
    freight_terms           TEXT,          -- PREPAID / COLLECT
    payable_at              TEXT,
    freight_charges         TEXT,
    remarks                 TEXT,
    submission_date         TEXT,
    submission_channel      TEXT,
    amendment_date          TEXT,
    amendment_reason        TEXT,
    draft_bl_received_date  TEXT,
    draft_bl_reference      TEXT,
    draft_bl_approved_date  TEXT,
    booking_basis           TEXT,          -- JSON: booking data the SI was based on (detects later changes)
    submitted_hash          TEXT,          -- fingerprint of the SI content when submitted / amended
    doc_version             INTEGER NOT NULL DEFAULT 1,
    last_pdf_path           TEXT,
    last_pdf_at             TEXT,
    created_at              TEXT NOT NULL,
    updated_at              TEXT NOT NULL
);

-- Phase 5 — versions of every document (one row per version; old versions are never changed).
-- snapshot = JSON {"own": the document's own fields (used to restore), "flat": everything it showed}
CREATE TABLE IF NOT EXISTS document_versions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_fk     INTEGER NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
    doc_type        TEXT NOT NULL,      -- BOOKING / EIR / VGM / SI / GATEIN / BL
    container_fk    INTEGER,            -- EIR / VGM / GATEIN: one document per container
    version         INTEGER NOT NULL,
    kind            TEXT NOT NULL,      -- Baseline / Created / Edited / Status / Synced / Amended / Restored
    status          TEXT,
    snapshot        TEXT NOT NULL,
    reason          TEXT,
    created_by      TEXT NOT NULL,
    created_at      TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_versions_doc ON document_versions(shipment_fk, doc_type, container_fk);

-- Phase 5 — change log / activity log: one row per changed field. Kept after a shipment is deleted.
CREATE TABLE IF NOT EXISTS change_log (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_fk     INTEGER,
    shipment_id     TEXT NOT NULL,
    doc_type        TEXT NOT NULL,      -- SHIPMENT (master data) or a document type
    container_fk    INTEGER,
    doc_label       TEXT,               -- e.g. "VGM — TEMU1000016"
    doc_version     INTEGER,
    field_key       TEXT NOT NULL,
    field_label     TEXT NOT NULL,
    old_value       TEXT,
    new_value       TEXT,
    action          TEXT NOT NULL,      -- CREATE / EDIT / SYNC / AMEND / RESTORE / APPLY / KEEP / REPLACE / STATUS / DELETE
    via_doc         TEXT,               -- the form the change was made in
    reason          TEXT,
    user_name       TEXT NOT NULL,
    changed_at      TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_change_log_shipment ON change_log(shipment_id, changed_at);

-- Phase 5 — content fingerprint when a document was confirmed / issued by an outside party
-- (Booking confirmed by the carrier, B/L issued). Changed content later = needs re-confirmation.
CREATE TABLE IF NOT EXISTS doc_locks (
    shipment_fk     INTEGER NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
    doc_type        TEXT NOT NULL,
    content_hash    TEXT NOT NULL,
    version         INTEGER,
    locked_at       TEXT NOT NULL,
    PRIMARY KEY (shipment_fk, doc_type)
);

-- Phase 5 — a document keeps its OWN value for an inherited field (e.g. the SI keeps the consignee
-- that was submitted to the carrier) instead of following the central data.
CREATE TABLE IF NOT EXISTS doc_overrides (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_fk     INTEGER NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
    doc_type        TEXT NOT NULL,
    field_key       TEXT NOT NULL,      -- e.g. party:CONSIGNEE, vessel_name
    value           TEXT,               -- JSON
    source          TEXT NOT NULL,      -- EXTERNAL (already sent / confirmed) / MANUAL
    note            TEXT,
    created_by      TEXT NOT NULL,
    created_at      TEXT NOT NULL,
    UNIQUE (shipment_fk, doc_type, field_key)
);

-- Phase 5 — source data changed but a document must not be overwritten silently: the user
-- chooses "keep" (document keeps its value) or "replace" (document takes the new value).
CREATE TABLE IF NOT EXISTS sync_conflicts (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_fk     INTEGER NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
    doc_type        TEXT NOT NULL,
    field_key       TEXT NOT NULL,
    field_label     TEXT NOT NULL,
    doc_value       TEXT,
    new_value       TEXT,
    cause           TEXT NOT NULL,      -- LOCKED (submitted / confirmed / issued) / MANUAL (edited in the document) / NOTICE
    detail          TEXT,
    status          TEXT NOT NULL DEFAULT 'PENDING',   -- PENDING / KEPT / REPLACED / DISMISSED / RESOLVED
    created_by      TEXT NOT NULL,
    created_at      TEXT NOT NULL,
    resolved_by     TEXT,
    resolved_at     TEXT,
    resolution_note TEXT
);
CREATE INDEX IF NOT EXISTS idx_conflicts_shipment ON sync_conflicts(shipment_fk, status);

-- Phase 6 — files uploaded by the user (helper only: never official / confirmed automatically).
-- manual_fields = values the user typed from the file (JSON); extraction_source NONE / MANUAL / OCR.
-- evidence_table / evidence_id = where the file was registered as evidence (gatein_evidence / bl_documents).
CREATE TABLE IF NOT EXISTS uploaded_documents (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_fk         INTEGER NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
    container_fk        INTEGER REFERENCES containers(id) ON DELETE SET NULL,
    step                INTEGER,               -- 1-6, or NULL (commercial documents)
    category            TEXT NOT NULL,         -- BOOKING_CONFIRMATION, EIR, WEIGHING_TICKET, PORT_CONFIRMATION, …
    file_path           TEXT NOT NULL,
    file_name           TEXT NOT NULL,
    file_size           INTEGER,
    description         TEXT,
    uploaded_by         TEXT NOT NULL,
    uploaded_at         TEXT NOT NULL,
    manual_fields       TEXT,
    extraction_source   TEXT NOT NULL DEFAULT 'NONE',
    extracted_by        TEXT,
    extracted_at        TEXT,
    evidence_table      TEXT,
    evidence_id         INTEGER
);
CREATE INDEX IF NOT EXISTS idx_uploads_shipment ON uploaded_documents(shipment_fk);

-- Phase 6 — every PDF the app generated and every export (combined PDF / ZIP / JSON), for the Document Library.
CREATE TABLE IF NOT EXISTS library_files (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_fk     INTEGER REFERENCES shipments(id) ON DELETE CASCADE,
    shipment_id     TEXT NOT NULL,
    source          TEXT NOT NULL,      -- GENERATED / EXPORT
    doc_type        TEXT NOT NULL,      -- BOOKING / EIR / VGM / SI / GATEIN / BL / COMBINED / ZIP / JSON
    title           TEXT NOT NULL,
    version         TEXT,
    status          TEXT,
    file_path       TEXT NOT NULL,
    file_name       TEXT NOT NULL,
    details         TEXT,               -- JSON (documents included, warnings …)
    created_by      TEXT NOT NULL,
    created_at      TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_library_shipment ON library_files(shipment_id);

-- Phase 6 — lists the forms can pick from (Settings): carriers, ports, terminals, depots.
CREATE TABLE IF NOT EXISTS reference_items (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    kind        TEXT NOT NULL,          -- CARRIER / PORT / TERMINAL / DEPOT
    name        TEXT NOT NULL,
    code        TEXT,
    notes       TEXT,
    active      INTEGER NOT NULL DEFAULT 1,
    created_at  TEXT NOT NULL,
    UNIQUE (kind, name)
);

-- Small key/value store for app bookkeeping (e.g. "sample data already created")
CREATE TABLE IF NOT EXISTS app_meta (
    key     TEXT PRIMARY KEY,
    value   TEXT
);

CREATE INDEX IF NOT EXISTS idx_parties_shipment   ON shipment_parties(shipment_fk);
CREATE INDEX IF NOT EXISTS idx_cargo_shipment     ON shipment_cargo(shipment_fk);
CREATE INDEX IF NOT EXISTS idx_containers_shipment ON containers(shipment_fk);
CREATE INDEX IF NOT EXISTS idx_containers_number  ON containers(container_number);
"""


def get_connection() -> sqlite3.Connection:
    """Open a connection to the app database (rows behave like dicts)."""
    settings.ensure_data_folders()
    conn = sqlite3.connect(settings.DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@contextmanager
def reading():
    """Connection for reading; always closed afterwards."""
    conn = get_connection()
    try:
        yield conn
    finally:
        conn.close()


@contextmanager
def transaction():
    """Connection for writing: everything inside is saved together, or nothing is."""
    conn = get_connection()
    try:
        conn.execute("BEGIN IMMEDIATE")
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
    drive_sync.after_commit()          # Colab: copy the saved database back to Google Drive (no-op locally)


def get_meta(key: str) -> str | None:
    with reading() as conn:
        row = conn.execute("SELECT value FROM app_meta WHERE key = ?", (key,)).fetchone()
    return row["value"] if row else None


def set_meta(key: str, value: str) -> None:
    with transaction() as conn:
        conn.execute(
            "INSERT INTO app_meta (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, value),
        )


# Columns added after a table was first created: (table, column, definition).
# init_database() adds them to existing databases, so no data is lost on upgrade.
_ADDED_COLUMNS = (
    ("shipments", "sample_label", "TEXT"),
    ("containers", "max_gross_kg", "REAL"),      # Max gross mass from the CSC safety approval plate
    ("vgm_records", "method2_certification_ref", "TEXT"),   # optional: shipper's Method 2 certification / approval
)


# Columns renamed after a table was first created, applied IN ORDER: (table, old, new).
# Only renamed when the old name exists and the new one does not.
_RENAMED_COLUMNS = (
    ("si_records", "freight_terms", "service_type"),    # held CY/CY → it is the service / move type
    ("si_records", "payment_terms", "freight_terms"),   # Prepaid / Collect = the freight terms
)


def init_database() -> None:
    """Create the database file and all tables if they are missing; upgrade old databases."""
    conn = get_connection()
    try:
        conn.execute("PRAGMA journal_mode = WAL")
        for table, old, new in _RENAMED_COLUMNS:          # before CREATE … IF NOT EXISTS, on old tables only
            existing = {row["name"] for row in conn.execute(f"PRAGMA table_info({table})")}
            if old in existing and new not in existing:
                conn.execute(f"ALTER TABLE {table} RENAME COLUMN {old} TO {new}")
        conn.executescript(SCHEMA)
        for table, column, definition in _ADDED_COLUMNS:
            existing = {row["name"] for row in conn.execute(f"PRAGMA table_info({table})")}
            if column not in existing:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")
        conn.commit()
    finally:
        conn.close()
