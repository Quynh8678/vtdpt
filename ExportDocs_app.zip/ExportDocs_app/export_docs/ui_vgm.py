"""Step 3 — VGM Declaration page (REQUIREMENTS.md §5 Step 3).

Booking number, vessel/voyage, shipper and VGM cut-off are shown read-only (edited in
Step 1). Container number comes from the central containers; tare and max gross mass
(CSC plate) are central fields that can be edited here (🔗). One VGM per container.
Method 2 shows every component, the formula and the result live while typing.
"""

import html
from pathlib import Path

import gradio as gr
import pandas as pd

from . import pdf_vgm as PV
from . import shipments as S
from . import vgm as V
from .formatting import fmt_datetime, fmt_kg, fmt_tonnes
from .pdf_generator import render_pdf_pages
from .ui_common import e, message_html, notice_html, page_title_html, section_title_html, shipment_tracker_html
from .workflow import shipment_step_statuses

STATUS_STYLE = {"Not Entered": "info", "Draft": "warning", "Declared": "success", "Submitted": "success",
                "Acknowledged": "success", "Amended": "warning"}
OVERVIEW_COLUMNS = ["#", "Container No.", "Size / Type", "Tare (kg)", "Max gross CSC (kg)", "Phương pháp",
                    "VGM (kg)", "VGM ref.", "Trạng thái VGM"]
METHOD_CHOICES = [("Method 1 — cân cả container đã đóng hàng", "METHOD_1"),
                  ("Method 2 — tính: cộng từng thành phần + tare", "METHOD_2")]
BASIS_CHOICES = [("Khối lượng hàng ĐÃ GỒM bao bì (gross) — Cargo weight already includes packaging", "GROSS"),
                 ("Khối lượng hàng chỉ là hàng tịnh (net) — Cargo weight is net goods only", "NET")]
UNIT_CHOICES = [("kg", "KGM"), ("metric tons (tấn)", "TNE")]
STATUS_CHOICES = [(f"{V.status_label(s)} — {V.STATUS_LABELS[s][1]}", s) for s in V.STATUSES]
BASIS_HELP = ("<b>Tránh tính bao bì hai lần:</b> nếu số “Cargo weight” là <b>gross</b> (đã gồm thùng carton, bao…) "
              "thì bao bì đã nằm trong đó → ô Bao bì bị khóa = 0. Chỉ chọn <b>net</b> khi Cargo weight là khối lượng "
              "hàng tịnh; khi đó nhập khối lượng bao bì riêng.")


def _num_text(value) -> str:
    if value is None:
        return ""
    return str(int(value)) if float(value).is_integer() else str(value)


def _lenient(value):
    """Number while typing (no error messages): None if blank / not a number."""
    errors = []
    number = S.parse_number(value, "", errors)
    return None if errors else number


def central_info_html(ship: dict | None) -> str:
    if not ship:
        return notice_html("Chọn một lô hàng để bắt đầu Bước 3.")
    vessel = " / ".join(x for x in (ship.get("vessel_name"), ship.get("voyage_number")) if x) or None
    cells = [("Booking No.", ship.get("booking_number")), ("Vessel / Voyage", vessel),
             ("Shipper", V.shipper_name(ship)),
             ("VGM cut-off", fmt_datetime(ship.get("vgm_cutoff")) if ship.get("vgm_cutoff") else None)]
    items = "".join(f'<div class="kpi"><div class="label">🔗 {e(k)}</div>'
                    f'<div class="value" style="font-size:15px">{e(v)}</div></div>' for k, v in cells)
    return (f'<div class="kpi-grid">{items}</div>'
            '<div class="hint">🔗 Dữ liệu chung từ Bước 1 — chỉ xem ở đây. Bấm nút bên dưới để sửa tại nguồn.</div>')


def overview_table(overview: dict | None) -> pd.DataFrame:
    rows = []
    for i in (overview or {}).get("items", []):
        c, rec = i["container"], i["vgm"] or {}
        size = " ".join(x for x in (f"{c['container_size']}'" if c.get("container_size") else None,
                                    c.get("container_type")) if x)
        method = {"METHOD_1": "Method 1", "METHOD_2": "Method 2"}.get(rec.get("weighing_method"), "—")
        rows.append([i["no"], c.get("container_number") or "(chưa có số)", size or "—", fmt_kg(c.get("tare_weight_kg")),
                     fmt_kg(c.get("max_gross_kg")), method, fmt_kg(rec.get("vgm_kg")), rec.get("vgm_reference") or "—",
                     f"{V.status_label(i['status'])} ({V.STATUS_LABELS[i['status']][1]})"])
    return pd.DataFrame(rows, columns=OVERVIEW_COLUMNS)


def picker_choices(overview: dict | None) -> list:
    return [(f"{i['no']}. {i['container'].get('container_number') or '(chưa có số)'} · {V.status_label(i['status'])}",
             str(i["container"]["id"])) for i in (overview or {}).get("items", [])]


def vgm_status_html(overview: dict | None, container_id: int | None) -> str:
    if not overview or container_id is None:
        return ""
    item = V.find_item(overview, container_id)
    if not item:
        return ""
    ship, c, rec = overview["shipment"], item["container"], item["vgm"]
    items = []
    if rec:
        label = V.document_label(ship, c, rec)
        items.append(f"Nhãn chứng từ: {label['badge']} — VGM ref.: {rec['vgm_reference']}")
        blocking, soft = V.checks(ship, c, rec)
        if blocking:
            items.append("Cần để khai (Declared): " + " ".join(blocking))
        items += [f"⚠️ {w}" for w in soft]
        if rec.get("last_pdf_at"):
            items.append(f"PDF xuất lần cuối: {rec['last_pdf_at']}")
        kind = "error" if label["badge"] == "NEEDS CORRECTION" else STATUS_STYLE[item["status"]]
    else:
        items.append("Chưa có VGM cho container này. Nhập thông tin rồi bấm “Lưu VGM”.")
        if not c.get("container_number"):
            items.append("⚠️ Container chưa có số — nhập số ở Bước 2 hoặc Quản lý lô hàng trước khi khai VGM.")
        kind = "info"
    title = f"VGM {c.get('container_number') or '(chưa có số)'}: {V.status_label(item['status'])}"
    return message_html(kind, title, items)


def calculation_html(method, basis, cargo, packaging, pallet, dunnage, securing, weighed, tare, max_gross, unit) -> str:
    """Live box: components, formula, result and the main checks."""
    values = {"cargo_weight_kg": _lenient(cargo), "packaging_weight_kg": _lenient(packaging),
              "pallet_weight_kg": _lenient(pallet), "dunnage_weight_kg": _lenient(dunnage),
              "securing_weight_kg": _lenient(securing), "weighed_vgm_kg": _lenient(weighed)}
    tare_v, max_v = _lenient(tare), _lenient(max_gross)
    result = V.compute_vgm(method, basis, values, tare_v)
    if method == "METHOD_2":
        rows = "".join(
            f"<tr><td>{e(r['en'])} <span class='hint'>· {e(r['vi'])}</span></td>"
            f"<td class='hint'>{e(r['note'])}</td><td style='text-align:right'>"
            f"{fmt_kg(r['kg']) if r['kg'] is not None else ('?' if r['key'] in ('cargo_weight_kg', 'tare_weight_kg') else '0')}"
            f"</td></tr>" for r in V.breakdown(basis, values, tare_v))
        body = (f"<div><b>Công thức:</b> {e(V.FORMULA)}</div>"
                f"<table class='calc'>{rows}<tr class='total'><td colspan='2'><b>VGM</b> = "
                f"{e(V.formula_with_numbers(basis, values, tare_v))}</td>"
                f"<td style='text-align:right'><b>{fmt_kg(result)}</b></td></tr></table>")
    elif method == "METHOD_1":
        body = ("<div>Method 1: VGM = số cân được của <b>cả container đã đóng hàng và niêm phong</b>. "
                "Cargo weight và tare chỉ để kiểm tra, không dùng để tính.</div>")
    else:
        return notice_html("Chọn phương pháp (Method 1 hoặc Method 2) để xem VGM.")
    checks = []
    if result is not None:
        if tare_v is not None and result <= tare_v:
            checks.append("VGM phải lớn hơn tare.")
        if values["cargo_weight_kg"] is not None and result <= values["cargo_weight_kg"]:
            checks.append("VGM phải lớn hơn Cargo weight — Cargo weight KHÔNG phải là VGM.")
        if max_v and result > max_v:
            checks.append(f"Vượt Max gross (CSC) {fmt_kg(max_v)} kg thêm {fmt_kg(result - max_v)} kg.")
    shown = (f"{fmt_tonnes(result)} t" if unit == "TNE" else f"{fmt_kg(result)} kg") if result is not None else "—"
    second = (f"= {fmt_kg(result)} kg" if unit == "TNE" else f"= {fmt_tonnes(result)} t") if result is not None else \
        "chưa đủ số liệu để xác định VGM"
    colour = "#9C2F23" if checks or result is None else "#0B2545"
    warn = "".join(f"<li>{e(c)}</li>" for c in checks)
    return (f"<div class='vgm-calc' style='border:2px solid {colour};border-radius:10px;padding:12px 14px'>"
            f"{body}<div style='margin-top:8px;font-size:13px;color:#5B6B82'>VERIFIED GROSS MASS (VGM)</div>"
            f"<div style='font-size:28px;font-weight:700;color:{colour}'>{html.escape(shown)}</div>"
            f"<div class='hint'>{html.escape(second)}</div>"
            + (f"<ul style='color:#9C2F23;margin:6px 0 0 18px'>{warn}</ul>" if warn else "") + "</div>")


CALC_CSS = """
.vgm-calc table.calc{width:100%;border-collapse:collapse;margin-top:6px;font-size:13px}
.vgm-calc table.calc td{border-bottom:1px solid #E1E7EF;padding:4px 6px}
.vgm-calc table.calc tr.total td{border-top:2px solid #0B2545;background:#E9EEF5}
"""


def build_vgm_page():
    """Build the page. Returns (inputs, outputs, refresh function, edit-at-source button, shipment dropdown)."""
    num, txt_in = {}, {}

    gr.HTML(page_title_html("Bước 3 · VGM Declaration",
                            "Phiếu khai báo khối lượng toàn bộ container (SOLAS) — một VGM cho mỗi container"))
    gr.HTML(f"<style>{CALC_CSS}</style>")
    ship_dd = gr.Dropdown(label="Chọn lô hàng (Shipment)", choices=[])
    tracker = gr.HTML()
    central = gr.HTML(central_info_html(None))
    edit_source_btn = gr.Button("✏️ Sửa Booking No. / Vessel / Shipper / VGM cut-off ở Bước 1", size="sm",
                                elem_classes="fit-btn")
    gr.HTML(section_title_html("Container của lô hàng", "Containers and their VGM status"))
    overview_df = gr.Dataframe(value=pd.DataFrame(columns=OVERVIEW_COLUMNS), interactive=False, wrap=True)
    picker = gr.Dropdown(label="Chọn container để khai VGM", choices=[])
    status_box = gr.HTML()

    with gr.Tabs(selected="form"):
        with gr.Tab("📝 Biểu mẫu VGM", id="form"):
            gr.HTML(notice_html(
                "🔗 = <b>dữ liệu chung</b>. <b>Không bao giờ dùng Cargo Weight làm VGM.</b> Lưu nháp luôn được. "
                "Để <b>Declared</b> cần: container có số, phương pháp, bên chịu trách nhiệm, người ký, ngày khai, "
                "VGM lớn hơn tare và cargo, không vượt Max gross (CSC). "
                "<b>Acknowledged</b> chỉ khi bạn nhập số xác nhận thật của hãng tàu / cảng."))
            with gr.Accordion("A. Container (🔗 dữ liệu chung)", open=True):
                with gr.Row():
                    container_no = gr.Textbox(label="🔗 Số container (Container No.)", interactive=False)
                    num["tare_weight_kg"] = gr.Textbox(
                        label="🔗 Tare (kg)", info="Lấy từ dữ liệu container. Sửa ở đây sẽ cập nhật dữ liệu chung (có cảnh báo).")
                    num["max_gross_kg"] = gr.Textbox(
                        label="🔗 Max gross mass — biển CSC (kg) — không bắt buộc",
                        info="Khối lượng tối đa trên biển CSC ở cửa container (VD 30,480 / 32,500).")
            with gr.Accordion("B. Thông tin VGM", open=True):
                with gr.Row():
                    txt_in["vgm_reference"] = gr.Textbox(label="Số tham chiếu VGM (VGM reference)",
                                                         placeholder="Để trống → VGM-<Shipment ID>-<n>")
                    txt_in["responsible_party"] = gr.Textbox(label="Bên chịu trách nhiệm (Responsible party / Shipper) *")
                with gr.Row():
                    txt_in["weighing_method"] = gr.Radio(label="Phương pháp xác định VGM (Weighing method) *",
                                                         choices=METHOD_CHOICES, value=None, scale=3)
                    txt_in["vgm_unit"] = gr.Radio(label="Đơn vị (Unit)", choices=UNIT_CHOICES, value="KGM", scale=1)
            with gr.Accordion("C. Khối lượng (Weights, kg)", open=True):
                txt_in["cargo_basis"] = gr.Radio(label="Cargo weight là gross hay net? *", choices=BASIS_CHOICES,
                                                 value="GROSS")
                gr.HTML(notice_html(BASIS_HELP))
                with gr.Row():
                    num["cargo_weight_kg"] = gr.Textbox(label="Cargo weight — hàng hóa (kg)")
                    num["packaging_weight_kg"] = gr.Textbox(label="Packaging — bao bì (kg)", value="0",
                                                            interactive=False)
                with gr.Group(visible=False) as m2_group:
                    with gr.Row():
                        num["pallet_weight_kg"] = gr.Textbox(label="Pallets (kg)")
                        num["dunnage_weight_kg"] = gr.Textbox(label="Dunnage — chèn lót (kg)")
                        num["securing_weight_kg"] = gr.Textbox(label="Securing — chằng buộc (kg)")
                    txt_in["method2_certification_ref"] = gr.Textbox(
                        label="Số chứng nhận / phê duyệt Method 2 (Method 2 certification / approval ref.) — "
                              "không bắt buộc",
                        info="Chỉ nhập khi cơ quan có thẩm quyền đã cấp cho shipper (một số nước yêu cầu). "
                             "Không tự tạo số.")
                with gr.Group(visible=False) as m1_group:
                    with gr.Row():
                        num["weighed_vgm_kg"] = gr.Textbox(label="VGM cân được — cả container (kg) *")
                        txt_in["weighing_datetime"] = gr.DateTime(label="Ngày giờ cân (Weighing date/time)",
                                                                  include_time=True, type="string")
                    with gr.Row():
                        txt_in["weighing_location"] = gr.Textbox(label="Nơi cân (Weighing location) *")
                        txt_in["weighing_provider"] = gr.Textbox(
                            label="Thiết bị cân / đơn vị cân (Equipment / service provider) *")
                calc_box = gr.HTML(calculation_html(None, "GROSS", *[None] * 9))
            with gr.Accordion("D. Khai báo & gửi (Declaration & submission)", open=True):
                with gr.Row():
                    txt_in["signatory_name"] = gr.Textbox(label="Người ký có thẩm quyền (Authorized signatory) *")
                    txt_in["signatory_position"] = gr.Textbox(label="Chức vụ (Position)")
                    txt_in["declaration_date"] = gr.DateTime(label="Ngày khai (Declaration date) *",
                                                             include_time=False, type="string")
                with gr.Row():
                    txt_in["submission_date"] = gr.DateTime(label="Ngày gửi (Submission date)",
                                                            include_time=False, type="string")
                    txt_in["submission_channel"] = gr.Dropdown(label="Kênh gửi (Submission channel)",
                                                               choices=list(V.SUBMISSION_CHANNELS),
                                                               allow_custom_value=True)
                    txt_in["ack_reference"] = gr.Textbox(
                        label="Số xác nhận của hãng tàu / cảng (Acknowledgement ref.)",
                        info="Chỉ nhập khi đã nhận phản hồi thật. Không có số này → không thể là Acknowledged.")
                txt_in["remarks"] = gr.Textbox(label="Ghi chú (Remarks)", lines=2)
                status_in = gr.Radio(label="Trạng thái muốn lưu (app sẽ hạ xuống nếu dữ liệu chưa đủ)",
                                     choices=STATUS_CHOICES, value="Draft")
            form_msg = gr.HTML()
            with gr.Row():
                save_btn = gr.Button("💾 Lưu VGM", variant="primary", scale=2)
                delete_btn = gr.Button("🗑 Xóa VGM này", variant="stop", scale=1)
            with gr.Group(visible=False) as confirm_box:
                confirm_text = gr.HTML()
                with gr.Row():
                    confirm_yes = gr.Button("Xóa VGM", variant="stop")
                    confirm_no = gr.Button("Hủy, không xóa")

        with gr.Tab("👁 Xem trước & Xuất PDF", id="preview"):
            gr.HTML(notice_html("Xem trước dùng <b>dữ liệu đã lưu</b>. Mỗi container một trang A4. "
                                "PDF được lưu trong <code>pdfs/&lt;Shipment ID&gt;/</code>."))
            with gr.Row():
                preview_one_btn = gr.Button("👁 Xem trước VGM đang chọn")
                preview_all_btn = gr.Button("👁 Xem trước tất cả VGM")
            with gr.Row():
                export_one_btn = gr.Button("📄 Xuất PDF VGM đang chọn", variant="primary")
                export_all_btn = gr.Button("📄 Xuất PDF tất cả VGM (1 file)", variant="primary")
            with gr.Row():
                download_one = gr.DownloadButton("⬇ Tải VGM", visible=False)
                download_all = gr.DownloadButton("⬇ Tải tất cả VGM", visible=False)
            export_msg = gr.HTML()
            gallery = gr.Gallery(label="Bản xem trước (mỗi ảnh là một trang A4)", columns=1, height="auto",
                                 object_fit="contain")

    num_keys = list(num)
    txt_keys = list(txt_in)
    form_inputs = [num[k] for k in num_keys] + [txt_in[k] for k in txt_keys] + [status_in]
    calc_inputs = [txt_in["weighing_method"], txt_in["cargo_basis"], num["cargo_weight_kg"],
                   num["packaging_weight_kg"], num["pallet_weight_kg"], num["dunnage_weight_kg"],
                   num["securing_weight_kg"], num["weighed_vgm_kg"], num["tare_weight_kg"], num["max_gross_kg"],
                   txt_in["vgm_unit"]]
    form_outputs = [status_box, container_no, *form_inputs, m1_group, m2_group, calc_box, download_one]

    # ------------------------------------------------------------------ logic
    def form_values(overview, container_id):
        ship = overview["shipment"] if overview else {}
        item = V.find_item(overview, container_id) if overview and container_id is not None else None
        c = item["container"] if item else {}
        rec = (item or {}).get("vgm") or {}
        defaults = {"responsible_party": V.shipper_name(ship) if ship else None, "cargo_basis": "GROSS",
                    "vgm_unit": "KGM", "cargo_weight_kg": c.get("cargo_weight_kg")}
        get = lambda k: rec.get(k) if rec else defaults.get(k)
        nums = []
        for k in num_keys:
            nums.append(_num_text(c.get(k) if k in V.CONTAINER_FIELDS else get(k)))
        basis = get("cargo_basis") or "GROSS"
        if basis == "GROSS":
            nums[num_keys.index("packaging_weight_kg")] = gr.update(value="0", interactive=False)
        else:
            nums[num_keys.index("packaging_weight_kg")] = gr.update(
                value=_num_text(rec.get("packaging_weight_kg")), interactive=True)
        texts = []
        for k in txt_keys:
            v = get(k)
            if k == "weighing_datetime":
                v = f"{v}:00" if v else None
            elif k in ("declaration_date", "submission_date"):
                v = v or None
            elif k in ("weighing_method", "submission_channel"):
                v = v or None
            elif k == "cargo_basis":
                v = basis
            elif k == "vgm_unit":
                v = v or "KGM"
            else:
                v = v or ""
            texts.append(v)
        method = get("weighing_method")
        calc = calculation_html(method, basis, *[c.get(k) if k in V.CONTAINER_FIELDS else get(k) for k in (
            "cargo_weight_kg", "packaging_weight_kg", "pallet_weight_kg", "dunnage_weight_kg", "securing_weight_kg",
            "weighed_vgm_kg", "tare_weight_kg", "max_gross_kg")], get("vgm_unit") or "KGM")
        pdf = rec.get("last_pdf_path")
        single = pdf and Path(pdf).exists() and "_ALL_" not in Path(pdf).name
        download = (gr.update(value=pdf, visible=True, label=f"⬇ Tải VGM ({Path(pdf).name})")
                    if single else gr.update(value=None, visible=False))
        return ([vgm_status_html(overview, container_id), c.get("container_number") or "(chưa có số)",
                 *nums, *texts, rec.get("vgm_status") or "Draft",
                 gr.update(visible=method == "METHOD_1"), gr.update(visible=method == "METHOD_2"), calc, download])

    def _cid(value):
        return None if value in (None, "") else int(value)

    def load_shipment(shipment_id, preferred=None):
        overview = V.get_shipment_vgms(shipment_id) if shipment_id else None
        choices = picker_choices(overview)
        ids = [v for _, v in choices]
        pick = preferred if preferred in ids else (ids[0] if ids else None)
        tracker_html = shipment_tracker_html(shipment_step_statuses(shipment_id) if overview else ["Not Started"] * 6)
        return ([tracker_html, central_info_html(overview["shipment"] if overview else None),
                 overview_table(overview), gr.update(choices=choices, value=pick)]
                + form_values(overview, _cid(pick)))

    head_outputs = [tracker, central, overview_df, picker]

    def on_ship(shipment_id):
        return load_shipment(shipment_id) + ["", None, "", gr.update(visible=False)]

    def on_pick(shipment_id, picked):
        overview = V.get_shipment_vgms(shipment_id) if shipment_id else None
        return form_values(overview, _cid(picked)) + [gr.update(visible=False)]

    def refresh(shipment_id):
        choices = [(f"{r['shipment_id']} · {r.get('booking_number') or 'chưa có booking'} · "
                    f"{r.get('customer_name') or r.get('shipper_name') or ''}", r["shipment_id"])
                   for r in S.list_shipments()]
        ids = [c[1] for c in choices]
        if shipment_id not in ids:
            shipment_id = ids[0] if ids else None
        return [gr.update(choices=choices, value=shipment_id), *load_shipment(shipment_id)]

    def on_method(method):
        return gr.update(visible=method == "METHOD_1"), gr.update(visible=method == "METHOD_2")

    def on_basis(basis):
        return gr.update(value="0", interactive=False) if basis == "GROSS" else gr.update(interactive=True)

    skip_all = lambda extra: [gr.skip()] * (len(head_outputs) + len(form_outputs)) + extra

    def do_save(shipment_id, picked, *values):
        cid = _cid(picked)
        if not shipment_id or cid is None:
            return skip_all([message_html("warning", "Hãy chọn lô hàng và container trước.")])
        n_num, n_txt = len(num_keys), len(txt_keys)
        numbers = dict(zip(num_keys, values[:n_num]))
        texts = dict(zip(txt_keys, values[n_num:n_num + n_txt]))
        requested = values[n_num + n_txt]
        cont = {k: numbers.pop(k) for k in V.CONTAINER_FIELDS}
        try:
            result = V.save_vgm(shipment_id, cid, cont, {**numbers, **texts}, requested)
        except S.ShipmentError as ex:
            return skip_all([message_html("error", "Chưa lưu được:", ex.errors)])
        verb = "Đã tạo" if result.created else "Đã lưu"
        title = f"{verb} VGM {result.vgm_reference} — {V.status_label(result.status)} · VGM {fmt_kg(result.vgm_kg)} kg"
        msg = (message_html("warning", title + ". Lưu ý:", result.warnings) if result.warnings
               else message_html("success", title + "."))
        return load_shipment(shipment_id, str(cid)) + [msg]

    def ask_delete(shipment_id, picked):
        cid = _cid(picked)
        overview = V.get_shipment_vgms(shipment_id) if shipment_id else None
        item = V.find_item(overview, cid) if overview and cid is not None else None
        if not item or not item["vgm"]:
            return gr.update(visible=False), "", message_html("warning", "Container này chưa có VGM để xóa.")
        name = item["container"].get("container_number") or item["vgm"]["vgm_reference"]
        return (gr.update(visible=True),
                message_html("error", f"Xóa VGM {item['vgm']['vgm_reference']} của container {name}?",
                             ["Container vẫn được giữ; VGM trong dữ liệu chung của container cũng bị xóa.",
                              "Thao tác này không thể hoàn tác."]), "")

    def do_delete(shipment_id, picked):
        try:
            ref = V.delete_vgm(shipment_id, _cid(picked))
        except S.ShipmentError as ex:
            return skip_all([gr.update(visible=False), message_html("error", "Không xóa được.", ex.errors)])
        return load_shipment(shipment_id, picked) + [gr.update(visible=False),
                                                     message_html("success", f"Đã xóa VGM {ref}.")]

    def _preview(shipment_id, ids):
        if not shipment_id:
            return None, message_html("warning", "Hãy chọn lô hàng trước.")
        try:
            pages = render_pdf_pages(PV.build_vgm_declaration_pdf_bytes(shipment_id, ids), scale=1.6)
        except S.ShipmentError as ex:
            return None, message_html("error", "Không tạo được bản xem trước.", ex.errors)
        return pages, message_html("info", f"Bản xem trước: {len(pages)} trang.")

    def _export(shipment_id, ids):
        if not shipment_id:
            return gr.skip(), message_html("warning", "Hãy chọn lô hàng trước.")
        try:
            path = PV.generate_vgm_declaration_pdf(shipment_id, ids)
        except S.ShipmentError as ex:
            return gr.skip(), message_html("error", "Chưa xuất được PDF.", ex.errors)
        return (gr.update(value=str(path), visible=True, label=f"⬇ Tải ({path.name})"),
                message_html("success", f"Đã xuất PDF: {path.name}", [f"Lưu tại: {path}"]))

    def _one(fn, shipment_id, picked):
        cid = _cid(picked)
        if cid is None:
            return gr.skip() if fn is _export else None, message_html("warning", "Hãy chọn một container đã lưu VGM.")
        return fn(shipment_id, [cid])

    # ------------------------------------------------------------------ events
    ship_dd.change(on_ship, ship_dd, [*head_outputs, *form_outputs, form_msg, gallery, export_msg, confirm_box])
    picker.change(on_pick, [ship_dd, picker], [*form_outputs, confirm_box])
    txt_in["weighing_method"].change(on_method, txt_in["weighing_method"], [m1_group, m2_group])
    txt_in["cargo_basis"].change(on_basis, txt_in["cargo_basis"], num["packaging_weight_kg"])
    for comp in calc_inputs:
        comp.change(calculation_html, calc_inputs, calc_box, show_progress="hidden")
    save_btn.click(do_save, [ship_dd, picker, *form_inputs], [*head_outputs, *form_outputs, form_msg])
    delete_btn.click(ask_delete, [ship_dd, picker], [confirm_box, confirm_text, form_msg])
    confirm_no.click(lambda: (gr.update(visible=False), message_html("info", "Đã hủy, không xóa gì.")),
                     None, [confirm_box, form_msg])
    confirm_yes.click(do_delete, [ship_dd, picker], [*head_outputs, *form_outputs, confirm_box, form_msg])
    preview_one_btn.click(lambda s, p: _one(_preview, s, p), [ship_dd, picker], [gallery, export_msg])
    preview_all_btn.click(lambda s: _preview(s, None), ship_dd, [gallery, export_msg])
    export_one_btn.click(lambda s, p: _one(_export, s, p), [ship_dd, picker], [download_one, export_msg]).then(
        lambda sid: load_shipment(sid)[:3] if sid else [gr.skip()] * 3, ship_dd, [tracker, central, overview_df])
    export_all_btn.click(lambda s: _export(s, None), ship_dd, [download_all, export_msg])

    return [ship_dd], [ship_dd, *head_outputs, *form_outputs], refresh, edit_source_btn, ship_dd
