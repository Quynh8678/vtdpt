"""Document Library ("Thư viện chứng từ") + upload area (REQUIREMENTS.md §3, §10)."""

import gradio as gr
import pandas as pd

from . import library as L
from . import shipments as S
from . import uploads as U
from .ui_common import message_html, notice_html, page_title_html, section_title_html

ALL = "ALL"
LIB_COLUMNS = ["Mã", "Lô hàng", "Nguồn", "Loại chứng từ", "Container", "Phiên bản", "Trạng thái", "Ngày", "Người",
               "Tên file"]
ENTRY_COLUMNS = ["Trường", "Giá trị trong file (nhập tay)", "Giá trị trong hệ thống", "Khác nhau?"]


def library_frame(files: list[dict]) -> pd.DataFrame:
    rows = [[f["key"], f["shipment_id"], L.SOURCES.get(f["source"], f["source"]), f["title"], f["container"] or "",
             f["version"] or "", f["status"] or "", (f["date"] or "")[:16], f["by"],
             f["file_name"] + ("" if f["exists"] else " (file không còn)")] for f in files]
    return pd.DataFrame(rows, columns=LIB_COLUMNS)


def _shipments():
    return [(f"{r['shipment_id']} · {r.get('customer_name') or r.get('shipper_name') or ''}", r["shipment_id"])
            for r in S.list_shipments()]


def entry_frame(rows: list[dict]) -> pd.DataFrame:
    return pd.DataFrame([[r["label"], r["file_value"] or "", "" if r["app_value"] is None else str(r["app_value"]),
                          "⚠️ KHÁC" if r["differs"] else ("" if not r["file_value"] else "khớp")] for r in rows],
                        columns=ENTRY_COLUMNS)


def build_library_page():
    gr.HTML(page_title_html("Thư viện chứng từ", "Document Library — PDF đã tạo, bộ xuất và file tải lên"))
    with gr.Tabs():
        # ------------------------------------------------------------ library
        with gr.Tab("📚 Thư viện"):
            with gr.Row():
                f_ship = gr.Dropdown(label="Lô hàng", choices=[("Tất cả lô hàng", ALL)], value=ALL, scale=2)
                f_source = gr.Dropdown(label="Nguồn", value=ALL, scale=1,
                                       choices=[("Tất cả", ALL)] + [(v, k) for k, v in L.SOURCES.items()])
                f_btn = gr.Button("🔍 Lọc", scale=1)
            lib_info = gr.HTML()
            lib_table = gr.Dataframe(value=pd.DataFrame(columns=LIB_COLUMNS), interactive=False, wrap=True)
            pick = gr.Dropdown(label="Chọn file để xem trước / tải về", choices=[])
            with gr.Row():
                pick_preview = gr.Gallery(label="Xem trước", columns=2, height=520, scale=3)
                with gr.Column(scale=2):
                    pick_html = gr.HTML()
                    pick_file = gr.File(label="Tải về", interactive=False)

        # ------------------------------------------------------------ upload
        with gr.Tab("⬆️ Tải lên & nhập dữ liệu"):
            gr.HTML(notice_html(
                "Tải lên PDF / JPG / PNG / XLSX (Booking của hãng tàu, EIR, phiếu cân, xác nhận của cảng, tờ khai, "
                "invoice, packing list, B/L của hãng tàu…), chọn loại và gắn với lô hàng / container / bước. "
                "<b>File tải lên KHÔNG bao giờ tự trở thành xác nhận chính thức</b> và không tự đổi trạng thái. "
                "Có thể dùng làm <b>bằng chứng</b>: xác nhận của cảng (Bước 5, chọn container) và B/L của hãng tàu "
                "(Bước 6) — sau đó vẫn ghi trạng thái ở Bước 5 / Bước 6 và chọn file này."))
            with gr.Row():
                up_ship = gr.Dropdown(label="Lô hàng", choices=[], scale=2)
                up_cat = gr.Dropdown(label="Loại chứng từ", scale=2,
                                     choices=[(f"{v[0]} ({v[1]})", k) for k, v in U.CATEGORIES.items()])
                up_step = gr.Dropdown(label="Bước", scale=1, choices=[("— Không gắn bước", 0)]
                                      + [(v, k) for k, v in U.STEPS.items()], value=0)
                up_cont = gr.Dropdown(label="Container (nếu có)", choices=[], scale=1)
            with gr.Row():
                up_file = gr.File(label="File (PDF / JPG / PNG / XLSX, tối đa 20 MB)", type="filepath",
                                  file_types=list(U.ALLOWED), scale=2)
                with gr.Column(scale=2):
                    up_desc = gr.Textbox(label="Mô tả (không bắt buộc)", placeholder="VD: email xác nhận của cảng ngày 23/11")
                    up_evidence = gr.Checkbox(label="Dùng làm bằng chứng (Bước 5 gate-in / Bước 6 B/L của hãng tàu)")
                    up_btn = gr.Button("⬆️ Tải lên", variant="primary")
            up_msg = gr.HTML()

            gr.HTML(section_title_html("Nhập dữ liệu từ file", "Manual entry next to the file — OCR can plug in here later"))
            with gr.Row():
                entry_pick = gr.Dropdown(label="File đã tải lên", choices=[], scale=3)
                evidence_btn = gr.Button("📎 Dùng file này làm bằng chứng", scale=1)
            with gr.Row():
                entry_preview = gr.Gallery(label="File gốc", columns=1, height=560, scale=3)
                with gr.Column(scale=3):
                    entry_note = gr.HTML()
                    entry_table = gr.Dataframe(value=pd.DataFrame(columns=ENTRY_COLUMNS), headers=ENTRY_COLUMNS,
                                               interactive=True, static_columns=[0, 2, 3], wrap=True)
                    entry_btn = gr.Button("💾 Lưu dữ liệu nhập tay (chỉ so sánh, không tự áp dụng)", variant="primary")
                    entry_msg = gr.HTML()

    # ------------------------------------------------------------ library logic
    def load_library(ship_id, source):
        files = L.list_files(None if ship_id in (None, ALL) else ship_id, None if source in (None, ALL) else source)
        choices = [(f"{f['key']} · {f['shipment_id']} · {f['title']} · {f['file_name']}", f["key"]) for f in files]
        info = f"<p class='hint'>{len(files)} file · mọi file nằm trong thư mục dữ liệu.</p>"
        return info, library_frame(files), gr.update(choices=choices, value=choices[0][1] if choices else None)

    def show_file(key):
        if not key:
            return [], "", None
        f = L.get_file(key)
        if not f:
            return [], message_html("error", "Không tìm thấy file."), None
        images, html_text = L.preview(f["path"])
        meta = (f"<div class='notice'><b>{f['title']}</b><br>{f['file_name']}<br>Nguồn: {L.SOURCES.get(f['source'])}"
                f"<br>Phiên bản: {f['version'] or '—'} · Trạng thái: {f['status'] or '—'}<br>Ngày: {(f['date'] or '')[:16]} · "
                f"{f['by']}</div>")
        return images, meta + (html_text or ""), f["path"] if f["exists"] else None

    f_btn.click(load_library, [f_ship, f_source], [lib_info, lib_table, pick])
    f_ship.input(load_library, [f_ship, f_source], [lib_info, lib_table, pick])
    f_source.input(load_library, [f_ship, f_source], [lib_info, lib_table, pick])
    pick.change(show_file, pick, [pick_preview, pick_html, pick_file])

    # ------------------------------------------------------------ upload logic
    def containers_of(ship_id):
        ship = S.get_shipment(ship_id) if ship_id else None
        choices = [("— Không gắn container", 0)] + [
            (c.get("container_number") or f"Container #{n} (chưa có số)", c["id"])
            for n, c in enumerate((ship or {}).get("containers", []), start=1)]
        return gr.update(choices=choices, value=0)

    def uploads_of(ship_id, selected=None):
        ups = U.list_uploads(ship_id) if ship_id else []
        choices = [(f"#{u['id']} · {U.CATEGORIES[u['category']][0]} · {u['file_name']}"
                    + (f" · {u['container_number']}" if u["container_number"] else ""), u["id"]) for u in ups]
        ids = [c[1] for c in choices]
        return gr.update(choices=choices, value=selected if selected in ids else (ids[0] if ids else None))

    def on_ship(ship_id):
        return containers_of(ship_id), uploads_of(ship_id)

    def on_category(cat):
        step = U.CATEGORIES.get(cat, (None, None, None))[2]
        return gr.update(value=step or 0), gr.update(value=step in (5, 6))

    def do_upload(ship_id, cat, step, cont, path, desc, evidence):
        if not ship_id:
            return message_html("warning", "Chọn lô hàng."), gr.skip()
        try:
            result = U.upload(ship_id, path, cat, int(step or 0) or None, int(cont or 0) or None, desc, bool(evidence))
        except S.ShipmentError as ex:
            return message_html("error", "Chưa tải lên được.", ex.errors), gr.skip()
        items = [f"Lưu tại thư mục dữ liệu: {result['path']}",
                 "Không có trạng thái nào tự thay đổi; file không phải xác nhận chính thức."]
        if result["evidence"]:
            items.insert(0, result["evidence"])
        return message_html("success", f"Đã tải lên (#{result['id']}). Nhập dữ liệu đọc được ở phần bên dưới.", items), \
            uploads_of(ship_id, result["id"])

    def show_entry(upload_id):
        if not upload_id:
            return [], "", pd.DataFrame(columns=ENTRY_COLUMNS)
        up = U.get_upload(int(upload_id))
        images, html_text = L.preview(up["file_path"])
        ocr = U.extract_fields(up["file_path"], up["category"])
        note = message_html("info", ocr.get("message") or f"OCR ({ocr.get('engine')}): giá trị gợi ý — kiểm tra trước khi lưu.")
        if up["extraction_source"] == "MANUAL":
            note += f"<p class='hint'>Đã nhập tay bởi {up['extracted_by']} lúc {(up['extracted_at'] or '')[:16]}.</p>"
        if up["evidence_table"]:
            note += "<p class='hint'>📎 File này đã là bằng chứng "\
                    f"({'Bước 5 · gate-in' if up['evidence_table'] == 'gatein_evidence' else 'Bước 6 · B/L'}).</p>"
        typed = up["manual_fields"] or ocr.get("fields") or {}
        return images, note + (html_text or ""), entry_frame(U.comparison(int(upload_id), typed))

    def save_entry(upload_id, frame):
        if not upload_id:
            return gr.skip(), message_html("warning", "Chọn một file đã tải lên.")
        up = U.get_upload(int(upload_id))
        labels = {label: key for key, label in U.FIELDS.get(up["category"], [])}
        values = {}
        for _, row in frame.iterrows():
            key = labels.get(row.iloc[0])
            if key:
                values[key] = row.iloc[1]
        rows = U.save_manual_fields(int(upload_id), values)
        diffs = [r["label"] for r in rows if r["differs"]]
        msg = (message_html("warning", "Đã lưu. Khác với dữ liệu trong hệ thống (không tự sửa — kiểm tra rồi sửa ở "
                                       "nguồn nếu file đúng):", diffs) if diffs
               else message_html("success", "Đã lưu dữ liệu nhập tay. Không có khác biệt với dữ liệu trong hệ thống."))
        return entry_frame(rows), msg

    def make_evidence(upload_id):
        if not upload_id:
            return message_html("warning", "Chọn một file đã tải lên.")
        try:
            return message_html("success", U.link_as_evidence(int(upload_id)))
        except S.ShipmentError as ex:
            return message_html("error", "Chưa dùng làm bằng chứng được.", ex.errors)

    up_ship.input(on_ship, up_ship, [up_cont, entry_pick])
    up_cat.input(on_category, up_cat, [up_step, up_evidence])
    up_btn.click(do_upload, [up_ship, up_cat, up_step, up_cont, up_file, up_desc, up_evidence], [up_msg, entry_pick])
    entry_pick.change(show_entry, entry_pick, [entry_preview, entry_note, entry_table])
    entry_btn.click(save_entry, [entry_pick, entry_table], [entry_table, entry_msg])
    evidence_btn.click(make_evidence, entry_pick, entry_msg).then(show_entry, entry_pick,
                                                                  [entry_preview, entry_note, entry_table])

    def refresh():
        ships = _shipments()
        first = ships[0][1] if ships else None
        info, frame, pick_update = load_library(ALL, ALL)
        return [gr.update(choices=[("Tất cả lô hàng", ALL)] + ships, value=ALL), info, frame, pick_update,
                gr.update(choices=ships, value=first), containers_of(first), uploads_of(first)]

    return [f_ship, lib_info, lib_table, pick, up_ship, up_cont, entry_pick], refresh
