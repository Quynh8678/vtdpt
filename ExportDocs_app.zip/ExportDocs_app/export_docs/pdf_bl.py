"""Step 6 — Bill of Lading PDF: generate_bill_of_lading_pdf() (REQUIREMENTS.md §5 Step 6, §11).

Classic B/L layout, printed from the B/L's OWN particulars (not re-read from the SI):

    shipper / consignee / notify boxes (left) | title, B/L No. or Draft ref., booking, references,
                                                 carrier name box (no logo) (right)
    routing grid: pre-carriage, place of receipt, vessel/voyage, POL, POD, place of delivery
    particulars: Container/Seal & Marks | No. & Kind of Packages | Description of Goods | Gross | CBM
        "SHIPPER'S LOAD, STOW, COUNT AND SEAL" · "SAID TO CONTAIN" · total packages in words
        → runs onto RIDER pages with the header repeated
    freight block | originals, place/date of issue, RECEIVED FOR SHIPMENT or SHIPPED ON BOARD
    remarks, empty carrier signature box ("As Carrier" blank), neutral terms line, status note

Every page carries DRAFT BILL OF LADING — NOT NEGOTIABLE / INTERNAL PREVIEW until the B/L is
issued with the carrier's number and document. No carrier logo, signature, stamp or real terms.
"""

import io
from datetime import datetime
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import Flowable, KeepTogether, SimpleDocTemplate, Spacer, Table, TableStyle

from . import APP_NAME, bl as BL, settings
from . import si as SI
from .formatting import DASH, fmt_cbm, fmt_count, fmt_date, fmt_kg, fmt_packages, packages_total
from .pdf_generator import (
    FONT, FONT_BOLD, GAP, GRID, MARGIN_BOTTOM, MARGIN_TOP, MARGIN_X, MUTED, NAVY, NAVY_SOFT, PAGE_H, PAGE_W,
    TABLE_FONT, W, ZEBRA, Paragraph, _block, _numbered_canvas, _plain_grid, _styles, field, field_grid, note_box,
    printable, register_fonts, safe_filename_part, side_by_side, txt,
)
from .pdf_si import split_text
from .shipments import sample_text

RED = colors.HexColor("#9C2F23")
BANNER_H = 6 * mm


def doc_name(label: dict) -> str:
    return "Sea Waybill" if label["title"] == "SEA WAYBILL" else "Bill of Lading"


def _html(text) -> str:
    return escape(printable(str(text or ""))).replace("\n", "<br/>")


def _party_box(st, title: str, text: str, width: float) -> Table:
    body = _html(text) if text else "<font color='#9C2F23'><b>NOT RECORDED</b></font>"
    lines = body.split("<br/>", 1)
    body = f"<b>{lines[0]}</b>" + (f"<br/>{lines[1]}" if len(lines) > 1 else "")
    t = Table([[Paragraph(escape(title.upper()), st["label"])], [Paragraph(body, st["value"])]], colWidths=[width])
    t.setStyle(TableStyle(TABLE_FONT + [
        ("BOX", (0, 0), (-1, -1), 0.8, NAVY), ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 2.5), ("BOTTOMPADDING", (0, -1), (-1, -1), 5),
    ]))
    return t


def _header_right(st, view: dict, label: dict, width: float) -> list:
    si, ship = view["si"], view["shipment"]
    bl_type = si.get("bl_type")
    negotiable = ("NEGOTIABLE" if bl_type == "ORIGINAL" and not label["draft"] else "NON-NEGOTIABLE")
    if label["draft"]:
        negotiable = "NOT NEGOTIABLE — DRAFT"
    title = ParagraphStyle("bt", parent=st["title"], fontSize=17, leading=20, alignment=TA_CENTER)
    sub = ParagraphStyle("bs", parent=st["badge_sub"], alignment=TA_CENTER, textColor=RED if label["draft"] else NAVY)
    title_box = Table([[Paragraph(escape(label["title"]), title)],
                       [Paragraph(f"<b>{escape(negotiable)}</b>", sub)],
                       [Paragraph(escape(si.get("transport_doc_type") or ""), ParagraphStyle(
                           "bd", parent=st["subnote"], alignment=TA_CENTER))]], colWidths=[width])
    title_box.setStyle(TableStyle(TABLE_FONT + [("BOX", (0, 0), (-1, -1), 1.2, NAVY), ("BACKGROUND", (0, 0), (-1, -1), NAVY_SOFT),
                                                ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, -1), (-1, -1), 4)]))
    no_label, no_value = BL.bl_number_text(view)
    refs = Table([[Paragraph(escape(no_label.upper()), st["label"]), Paragraph("BOOKING NO.", st["label"])],
                  [Paragraph(f"<b>{_html(no_value)}</b>", ParagraphStyle(
                      "blno", parent=st["value_big"], fontSize=11 if len(no_value) <= 18 else 9.2, leading=13)),
                   Paragraph(f"<b>{_html(ship.get('booking_number') or DASH)}</b>", st["value_b"])],
                  [Paragraph("SHIPPER'S REFERENCE", st["label"]), Paragraph("EXPORT REFERENCE", st["label"])],
                  [Paragraph(txt(si.get("shipper_reference")), st["value"]),
                   Paragraph(txt(si.get("export_reference")), st["value"])]],
                 colWidths=[width * 0.6, width * 0.4])
    refs.setStyle(TableStyle(TABLE_FONT + [("BOX", (0, 0), (-1, -1), 0.8, NAVY), ("INNERGRID", (0, 1), (-1, 1), 0, colors.white),
                                           ("LINEBELOW", (0, 1), (-1, 1), 0.4, GRID), ("LINEAFTER", (0, 0), (0, -1), 0.4, GRID),
                                           ("LEFTPADDING", (0, 0), (-1, -1), 5), ("TOPPADDING", (0, 0), (-1, -1), 2),
                                           ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5)]))
    carrier = Table([[Paragraph("CARRIER", st["label"])],
                     [Paragraph(f"<b>{_html(ship.get('carrier_name') or 'CARRIER NOT RECORDED')}</b>",
                                ParagraphStyle("cn", parent=st["value_big"], fontSize=12.5, leading=15))],
                     [Paragraph("Carrier name only — no carrier logo, stamp or signature is reproduced.", st["subnote"])]],
                    colWidths=[width])
    carrier.setStyle(TableStyle(TABLE_FONT + [("BOX", (0, 0), (-1, -1), 0.8, NAVY), ("LEFTPADDING", (0, 0), (-1, -1), 5),
                                              ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, -1), (-1, -1), 4)]))
    return [title_box, Spacer(1, 2 * mm), refs, Spacer(1, 2 * mm), carrier]


def _routing(st, part: dict) -> Table:
    vessel = " / ".join(x for x in (part.get("vessel_name"), part.get("voyage_number")) if x)
    via = f"<br/><font size='6.6' color='#5B6B82'>Via {_html(part['transshipment_port'])}</font>" \
        if part.get("transshipment_port") else ""
    cells = [[("Pre-carriage by", txt(part.get("pre_carriage"))), ("Place of Receipt", txt(part.get("place_of_receipt"))),
              ("Ocean Vessel / Voy. No.", f"<b>{txt(vessel or None)}</b>{via}")],
             [("Port of Loading", f"<b>{txt(part.get('port_of_loading'))}</b>"),
              ("Port of Discharge", f"<b>{txt(part.get('port_of_discharge'))}</b>"),
              ("Place of Delivery", txt(part.get("place_of_delivery")))]]
    t = Table([[field(st, *c) for c in row] for row in cells], colWidths=[W / 3] * 3)
    t.setStyle(TableStyle(TABLE_FONT + [("BOX", (0, 0), (-1, -1), 0.8, NAVY), ("INNERGRID", (0, 0), (-1, -1), 0.4, GRID),
                                        ("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 5),
                                        ("TOPPADDING", (0, 0), (-1, -1), 2.2), ("BOTTOMPADDING", (0, 0), (-1, -1), 3.2)]))
    return t


def total_packages_words(part: dict) -> str:
    total = packages_total(part["cargo"])
    if total == DASH:
        return DASH
    count, unit = total.split(" ", 1)
    n = int(count.replace(",", ""))
    return f"{BL.number_to_words(n)} ({fmt_count(n)}) {unit} ONLY"


def _particulars(st, view: dict) -> Table:
    part = view["particulars"]
    widths = [W * w for w in (0.21, 0.15, 0.38, 0.13, 0.13)]
    head = [Paragraph(h, st["th_r" if r else "th"]) for h, r in (
        ("CONTAINER / SEAL NO.<br/>MARKS &amp; NUMBERS", False), ("NO. &amp; KIND OF PACKAGES", False),
        ("DESCRIPTION OF GOODS", False), ("GROSS WEIGHT (KG)", True), ("MEASUREMENT (CBM)", True))]
    rows, style = [head], []
    containers = part["containers"]
    eq = {}
    for c in containers:
        eq[c.get("size_type") or "SIZE TBA"] = eq.get(c.get("size_type") or "SIZE TBA", 0) + 1
    eq_text = ", ".join(f"{n} x {k}" for k, n in eq.items())
    rows.append([Paragraph("", st["cell"]),
                 Paragraph(f"<b>{BL.number_to_words(len(containers))} ({len(containers)}) CONTAINER(S)</b>", st["cell"]),
                 Paragraph(f"<b>SHIPPER'S LOAD, STOW, COUNT AND SEAL</b><br/>{escape(eq_text)}<br/><b>SAID TO CONTAIN:</b>",
                           st["cell"]), Paragraph("", st["cell"]), Paragraph("", st["cell"])])
    style.append(("BACKGROUND", (0, 1), (-1, 1), ZEBRA))
    for line in part["cargo"]:
        d_parts = split_text(line.get("description")) or [""]
        m_parts = split_text(line.get("marks"), 160) or [""]
        first = len(rows)
        for i in range(max(len(d_parts), len(m_parts))):
            d = _html(d_parts[i]) if i < len(d_parts) else ""
            if i == 0 and line.get("hs_code"):
                d = f"<font size='6.8' color='#5B6B82'>HS Code: {escape(line['hs_code'])}</font><br/>{d}"
            rows.append([Paragraph(_html(m_parts[i]) if i < len(m_parts) else "", st["cell"]),
                         Paragraph(f"<b>{fmt_packages(line.get('package_count'), line.get('package_type'))}</b>"
                                   if i == 0 else "", st["cell"]),
                         Paragraph(d, st["cell"]),
                         Paragraph(fmt_kg(line.get("gross_weight_kg")) if i == 0 else "", st["cell_r"]),
                         Paragraph(fmt_cbm(line.get("volume_cbm")) if i == 0 else "", st["cell_r"])])
        style.append(("LINEABOVE", (0, first), (-1, first), 0.6, GRID))
        if len(rows) - first > 1:
            style += [("BOTTOMPADDING", (0, first), (-1, len(rows) - 2), 0),
                      ("TOPPADDING", (0, first + 1), (-1, len(rows) - 1), 0)]
    sub = len(rows)
    rows.append([Paragraph("<b>CONTAINER NO. / SEAL NO.</b>", st["cell"]), Paragraph("<b>PACKAGES</b>", st["cell"]),
                 Paragraph("<b>SIZE / TYPE</b>", st["cell"]), Paragraph("<b>GROSS (KG)</b>", st["cell_r"]),
                 Paragraph("<b>CBM</b>", st["cell_r"])])
    style += [("BACKGROUND", (0, sub), (-1, sub), NAVY_SOFT), ("LINEABOVE", (0, sub), (-1, sub), 0.8, NAVY)]
    for c in containers:
        rows.append([Paragraph(f"{txt(c.get('container_number'))} / {txt(c.get('seal_number'))}", st["cell"]),
                     Paragraph(f"{fmt_count(c.get('package_count'))} {escape(c.get('package_unit') or '')}"
                               if c.get("package_count") is not None else DASH, st["cell"]),
                     Paragraph(txt(c.get("size_type") or None), st["cell"]),
                     Paragraph(fmt_kg(c.get("gross_weight_kg")), st["cell_r"]),
                     Paragraph(fmt_cbm(c.get("volume_cbm")), st["cell_r"])])
    gross = sum(l.get("gross_weight_kg") or 0 for l in part["cargo"])
    cbm = sum(l.get("volume_cbm") or 0 for l in part["cargo"])
    rows.append([Paragraph("<b>TOTAL</b>", st["cell_b"]),
                 Paragraph(f"<b>{escape(packages_total(part['cargo']))}</b>", st["cell"]),
                 Paragraph(f"<b>TOTAL NUMBER OF PACKAGES (IN WORDS):</b><br/>SAY {escape(total_packages_words(part))}",
                           st["cell"]),
                 Paragraph(f"<b>{fmt_kg(gross)}</b>", st["cell_r"]), Paragraph(f"<b>{fmt_cbm(cbm)}</b>", st["cell_r"])])
    t = Table(rows, colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle(TABLE_FONT + [
        ("BACKGROUND", (0, 0), (-1, 0), NAVY), ("BOX", (0, 0), (-1, -1), 0.9, NAVY),
        ("LINEAFTER", (0, 0), (-2, -1), 0.4, GRID), ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.6),
        ("BACKGROUND", (0, -1), (-1, -1), NAVY_SOFT), ("LINEABOVE", (0, -1), (-1, -1), 0.9, NAVY),
    ] + style))
    return t


def originals_text(si: dict) -> str:
    bl_type, n = si.get("bl_type"), si.get("originals_count")
    if bl_type == "SEA_WAYBILL":
        return "NONE — SEA WAYBILL (NON-NEGOTIABLE, NO ORIGINALS)"
    if bl_type == "TELEX":
        return (f"{BL.count_in_words(n)} — SURRENDERED AT ORIGIN (TELEX RELEASE)" if n
                else "SURRENDERED AT ORIGIN (TELEX RELEASE)")
    return BL.count_in_words(n) if n else "NOT STATED"


class _PageMarker(Flowable):
    """Invisible: remembers the page it lands on (used to see whether the particulars ran over)."""

    def __init__(self, store: dict, key: str):
        super().__init__()
        self.store, self.key = store, key

    def wrap(self, avail_w, avail_h):
        return 0, 0

    def draw(self):
        self.store[self.key] = self.canv.getPageNumber()


def _story(st, view: dict, compact: bool = False, marks: dict | None = None) -> list:
    """compact=True: tighter spacing so the whole B/L stays on page 1 when the particulars fit there."""
    si, part, rec = view["si"], view["particulars"], view["record"] or {}
    label = BL.document_label(view)
    marks = {} if marks is None else marks
    gap = (1.3 if compact else 2.6) * mm
    left_w, right_w = W * 0.56, W * 0.44 - GAP
    half = (W - GAP) / 2
    parties = [_party_box(st, "Shipper", part.get("shipper"), left_w), Spacer(1, 1.8 * mm),
               _party_box(st, "Consignee (or order)", part.get("consignee"), left_w), Spacer(1, 1.8 * mm),
               _party_box(st, "Notify Party", part.get("notify"), left_w)]
    if part.get("also_notify"):
        parties += [Spacer(1, 1.8 * mm), _party_box(st, "Also Notify", part["also_notify"], left_w)]
    top = Table([[parties, "", _header_right(st, view, label, right_w)]], colWidths=[left_w, GAP, right_w])
    top.setStyle(TableStyle(TABLE_FONT + [("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0),
                                          ("RIGHTPADDING", (0, 0), (-1, -1), 0), ("TOPPADDING", (0, 0), (-1, -1), 0),
                                          ("BOTTOMPADDING", (0, 0), (-1, -1), 0)]))
    story = [top, Spacer(1, gap), _routing(st, part), Spacer(1, gap),
             Paragraph(f"PARTICULARS FURNISHED BY THE SHIPPER &nbsp;<font name='{FONT}' size='7' color='#5B6B82'>"
                       "Chi tiết do người gửi hàng khai — continued on rider page(s) if needed</font>", st["subhead"]),
             Spacer(1, 1.5), _particulars(st, view), _PageMarker(marks, "particulars_end"), Spacer(1, gap)]

    payment = SI.FREIGHT_TERMS.get(si.get("freight_terms"))
    freight = _block(st, "Freight & Charges", "Cước", [_plain_grid(st, [
        [("Freight", f"<b>{txt(payment.upper() if payment else None)}</b>", "value_big"),
         ("Payable at", txt(si.get("payable_at")))],
        [("Service type / Move type", txt(si.get("service_type"))), ("Freight & charges", txt(si.get("freight_charges")))],
    ], [half * 0.5, half * 0.5])], half)
    shipped = bool(rec.get("on_board_notation") and rec.get("shipped_on_board_date") and view["all_loaded"])
    if shipped:
        vessel = " / ".join(x for x in (part.get("vessel_name"), part.get("voyage_number")) if x)
        board = (f"<font color='#1E6B45'><b>SHIPPED ON BOARD</b></font><br/>{fmt_date(rec['shipped_on_board_date'])} · "
                 f"{_html(vessel)} · {_html(part.get('port_of_loading'))}")
    else:
        board = ("<b>RECEIVED FOR SHIPMENT</b><br/><font size='6.8' color='#5B6B82'>Not yet shipped on board — "
                 "no on-board date (not every container is Loaded on Board in Step 5).</font>")
    issue = _block(st, "Issuance", "Phát hành", [_plain_grid(st, [
        [("Number of original B/Ls", f"<b>{escape(originals_text(si))}</b>")],
        [("Place and date of issue", f"{txt(rec.get('place_of_issue'))} · Date: "
                                     f"{fmt_date(rec['date_of_issue']) if rec.get('date_of_issue') else DASH}")],
        [("On board", board)],
    ], [half])], half)
    story += [KeepTogether([side_by_side([freight], [issue])]), Spacer(1, gap)]

    remarks = []
    if si.get("bl_type") == "TELEX":
        remarks.append("TELEX RELEASE: original bills of lading surrendered at origin; cargo to be released at "
                       "destination without presentation of an original.")
    if si.get("bl_type") == "SEA_WAYBILL":
        remarks.append("SEA WAYBILL: non-negotiable; cargo released to the named consignee on proof of identity.")
    if rec.get("remarks"):
        remarks.append(rec["remarks"])
    if remarks:
        story += [field_grid(st, [[("Remarks", "<br/>".join(_html(r) for r in remarks))]], [W]), Spacer(1, gap)]

    sign = Table([[[Paragraph("SIGNED FOR THE CARRIER", st["label"]), Spacer(1, (7 if compact else 10) * mm),
                    Table([[Paragraph("BY:", st["label"]), Paragraph("AS CARRIER", st["label"])]],
                          colWidths=[half * 0.45, half * 0.45],
                          style=TableStyle(TABLE_FONT + [("LINEABOVE", (0, 0), (-1, -1), 0.6, MUTED),
                                                         ("LEFTPADDING", (0, 0), (-1, -1), 0)]))]]],
                 colWidths=[half])
    sign.setStyle(TableStyle(TABLE_FONT + [("BOX", (0, 0), (-1, -1), 0.8, NAVY), ("LEFTPADDING", (0, 0), (-1, -1), 6),
                                           ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
    terms = Table([[[Paragraph("TERMS", st["label"]), Spacer(1, 1.5), Paragraph(escape(BL.NEUTRAL_TERMS), st["note"]),
                     Spacer(1, 2), Paragraph("Weights and measurements as declared by the shipper.", st["subnote"])]]],
                  colWidths=[half])
    terms.setStyle(TableStyle(TABLE_FONT + [("BOX", (0, 0), (-1, -1), 0.8, NAVY), ("LEFTPADDING", (0, 0), (-1, -1), 6),
                                            ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
    honesty = (f"{APP_NAME} never invents B/L numbers, carrier signatures, stamps or "
               "authentication codes. The carrier signature box is left blank on purpose.")
    heading = f"DOCUMENT STATUS: {BL.status_label(view['status']).upper()}"
    status = (note_box(st, label["kind"], heading, f"{label['note']} {honesty}") if compact
              else note_box(st, label["kind"], heading, label["note"], fine=honesty))
    story += [KeepTogether([side_by_side([terms], [sign])]), Spacer(1, (1.3 if compact else 2.2) * mm), status,
              _PageMarker(marks, "end")]
    return story


def _decorator(view: dict, label: dict, rider: bool = True):
    """rider=True: the particulars ran over, so later pages are RIDER PAGES. Otherwise (only the
    closing blocks did not fit) later pages are called CONTINUATION."""
    no_label, no_value = BL.bl_number_text(view)
    later = "RIDER PAGE" if rider else "CONTINUATION PAGE"
    watermark = "SAMPLE" if view["shipment"]["is_sample"] else ("DRAFT" if label["draft"] else "COPY")

    def on_page(canv, doc):
        canv.saveState()
        canv.setFont(FONT_BOLD, 64)
        canv.setFillColor(NAVY)
        canv.setFillAlpha(0.06)
        canv.translate(PAGE_W / 2, PAGE_H / 2)
        canv.rotate(35)
        canv.drawCentredString(0, -20, watermark)
        canv.rotate(-35)
        canv.translate(-PAGE_W / 2, -PAGE_H / 2)
        canv.setFillAlpha(1)
        # status banner on EVERY page
        y = PAGE_H - MARGIN_TOP + 1.5 * mm
        fill = colors.HexColor("#FDECEA") if label["draft"] else NAVY_SOFT
        canv.setFillColor(fill)
        canv.setStrokeColor(RED if label["draft"] else NAVY)
        canv.rect(MARGIN_X, y, W, BANNER_H - 1 * mm, fill=1, stroke=1)
        canv.setFillColor(RED if label["draft"] else NAVY)
        canv.setFont(FONT_BOLD, 8.6)
        text = label["banner"] + (f"   ·   {label['sample_text']} DATA" if label["sample"] else "")
        canv.drawCentredString(PAGE_W / 2, y + 1.6 * mm, text)
        if doc.page > 1:
            canv.setFont(FONT_BOLD, 8)
            canv.setFillColor(NAVY)
            canv.drawString(MARGIN_X, y - 4.2 * mm, f"{later} {doc.page - 1}")
            canv.setFont(FONT, 7)
            canv.setFillColor(MUTED)
            canv.drawRightString(PAGE_W - MARGIN_X, y - 4.2 * mm,
                                 printable(f"Attached to and forming part of {doc_name(label)} — {no_label} "
                                           f"{no_value} · Booking {view['shipment'].get('booking_number') or DASH}"))
        canv.restoreState()
    return on_page


def bl_pdf_filename(view: dict) -> str:
    ship = view["shipment"]
    return (f"{safe_filename_part(ship['shipment_id'], 'SHIPMENT')}_"
            f"{safe_filename_part(ship.get('booking_number'), 'NO-BOOKING')}_Bill_of_Lading_"
            f"{'Draft' if BL.document_label(view)['draft'] else 'Copy'}_v{(view['record'] or {}).get('doc_version') or 1}.pdf")


def _view(shipment_id: str) -> dict:
    view = BL.get_bl_view(shipment_id)
    if not view:
        raise BL.BLError([f"Không tìm thấy lô hàng {shipment_id}."])
    if not view["exists"]:
        raise BL.BLError(["Chưa có B/L. Hãy bấm “Lưu B/L nháp” trước khi xuất PDF."])
    return view


def _render(view: dict, target) -> None:
    register_fonts()
    st = _styles()
    label = BL.document_label(view)
    ship = view["shipment"]
    no_label, no_value = BL.bl_number_text(view)
    footer = [
        f"Shipment ID: {ship['shipment_id']}   ·   Booking No.: {ship.get('booking_number') or DASH}   ·   "
        f"{no_label} {no_value}",
        f"{doc_name(label)} · Document version: v{(view['record'] or {}).get('doc_version') or 1}"
        f" · {BL.status_label(view['status'])}"
        + (f" · {sample_text(ship)} DATA" if ship["is_sample"] else "")
        + f" · Exported: {datetime.now().strftime('%d %b %Y %H:%M').upper()}",
    ]
    def build(out, compact: bool, rider: bool) -> dict:
        marks: dict = {}
        doc = SimpleDocTemplate(
            out, pagesize=A4, leftMargin=MARGIN_X, rightMargin=MARGIN_X, topMargin=MARGIN_TOP + 6.5 * mm,
            bottomMargin=MARGIN_BOTTOM, title=f"{doc_name(label)} — {ship['shipment_id']}", author=APP_NAME,
            subject=f"{doc_name(label)} · {ship['shipment_id']} · {BL.status_label(view['status'])}",
            creator=APP_NAME, initialFontName=FONT, initialFontSize=8)
        decorate = _decorator(view, label, rider)
        doc.build(_story(st, view, compact, marks), onFirstPage=decorate, onLaterPages=decorate,
                  canvasmaker=_numbered_canvas(footer))
        return marks

    # Trial run in memory: rider pages only when the PARTICULARS table itself runs over page 1.
    # If the particulars fit but the closing blocks do not, use the compact layout (one page).
    marks = build(io.BytesIO(), False, True)
    rider = marks.get("particulars_end", 1) > 1
    compact = not rider and marks.get("end", 1) > 1
    build(target, compact, rider)


def build_bill_of_lading_pdf_bytes(shipment_id: str) -> bytes:
    buffer = io.BytesIO()
    _render(_view(shipment_id), buffer)
    return buffer.getvalue()


def generate_bill_of_lading_pdf(shipment_id: str, output_path: str | Path | None = None) -> Path:
    """Create the (draft) Bill of Lading PDF and save it in the data folder.

    File: <data>/pdfs/<ShipmentID>/<ShipmentID>_<BookingNo>_Bill_of_Lading_<Draft|Copy>_v<N>.pdf
    """
    view = _view(shipment_id)
    if output_path is None:
        folder = settings.PDF_DIR / safe_filename_part(shipment_id, "SHIPMENT")
        folder.mkdir(parents=True, exist_ok=True)
        output_path = folder / bl_pdf_filename(view)
    output_path = Path(output_path)
    _render(view, str(output_path))
    BL.record_pdf_export(shipment_id, str(output_path))
    from .library import register_generated      # Document Library keeps every version
    register_generated(shipment_id, "BL", output_path)
    return output_path
