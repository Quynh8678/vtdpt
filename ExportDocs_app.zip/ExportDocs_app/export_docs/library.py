"""Phase 6 — Document Library: every generated PDF, every export and every uploaded file, per shipment
(REQUIREMENTS.md §3 "Document Library", §12 "Save every exported PDF version").

Generated PDFs are registered by the generate_*_pdf() functions (register_generated); exports by
exporter.py; uploads live in uploaded_documents (uploads.py). Evidence files uploaded directly in Step 5 /
Step 6 (gatein_evidence, bl_documents) are listed too.
"""

import json
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree

from . import shipments as S
from .database import reading, transaction

SOURCES = {"GENERATED": "PDF do hệ thống tạo", "EXPORT": "Bộ xuất (PDF gộp / ZIP / JSON)", "UPLOAD": "File tải lên"}
DOC_TITLES = {
    "BOOKING": "1. Booking Confirmation", "EIR": "2. Empty Container EIR", "VGM": "3. VGM Declaration",
    "SI": "4. Shipping Instruction", "GATEIN": "5. Export Gate-in & Loading Registration", "BL": "6. Bill of Lading",
    "COMBINED": "Bộ chứng từ gộp (PDF)", "ZIP": "Bộ chứng từ ZIP", "JSON": "Dữ liệu lô hàng (JSON)",
}
PREVIEW_PAGES = 4


def document_status(shipment_id: str, doc_type: str) -> str:
    """The document's status right now (stored with every generated file)."""
    from . import bl, bookings, eir, gatein, si, vgm
    if doc_type == "BOOKING":
        view = bookings.get_booking_view(shipment_id)
        return view["booking"]["booking_status"] if view and view["exists"] else "Not Started"
    if doc_type == "EIR":
        return eir.step_status(shipment_id)
    if doc_type == "VGM":
        items = (vgm.get_shipment_vgms(shipment_id) or {"items": []})["items"]
        found = sorted({i["vgm"]["vgm_status"] for i in items if i["vgm"]})
        return ", ".join(found) or "Not Started"
    if doc_type == "SI":
        view = si.get_si_view(shipment_id)
        return si.status_label(view["si"]["si_status"]) if view and view["exists"] else "Not Started"
    if doc_type == "GATEIN":
        return gatein.step_status(shipment_id)
    if doc_type == "BL":
        view = bl.get_bl_view(shipment_id)
        return bl.status_label(view["status"]) if view else "Not Started"
    return ""


def version_of(file_name: str) -> str | None:
    m = re.search(r"_v(\d+)(?:\.\w+)?$", Path(file_name).stem + Path(file_name).suffix)
    return f"v{m.group(1)}" if m else None


def register(shipment_id: str, source: str, doc_type: str, path: str | Path, status: str | None = None,
             title: str | None = None, details: dict | None = None) -> int:
    from .history import current_user
    path = Path(path)
    with transaction() as conn:
        row = conn.execute("SELECT id FROM shipments WHERE shipment_id = ?", (shipment_id,)).fetchone()
        cur = conn.execute(
            "INSERT INTO library_files (shipment_fk, shipment_id, source, doc_type, title, version, status, file_path, "
            "file_name, details, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (row[0] if row else None, shipment_id, source, doc_type, title or DOC_TITLES.get(doc_type, doc_type),
             version_of(path.name), status, str(path), path.name,
             json.dumps(details, ensure_ascii=False) if details else None, current_user(), S.now_text()))
        return cur.lastrowid


def register_generated(shipment_id: str, doc_type: str, path: str | Path) -> int:
    """Called by every generate_*_pdf(): keeps every generated version in the library."""
    part = Path(path).stem
    title = DOC_TITLES[doc_type]
    m = re.search(r"_(ALL|[A-Z]{4}\d{7})_v\d+$", part)
    if m:
        title += " — " + ("tất cả container" if m.group(1) == "ALL" else m.group(1))
    return register(shipment_id, "GENERATED", doc_type, path, document_status(shipment_id, doc_type), title)


def list_files(shipment_id: str | None = None, source: str | None = None) -> list[dict]:
    """All files, newest first: {id, key, source, shipment_id, doc_type, title, version, status, date, by, path, …}."""
    from .uploads import CATEGORIES
    out = []
    with reading() as conn:
        where, params = [], []
        if shipment_id:
            where.append("shipment_id = ?")
            params.append(shipment_id)
        for r in conn.execute("SELECT * FROM library_files" + (" WHERE " + " AND ".join(where) if where else ""), params):
            out.append({"key": f"L{r['id']}", "source": r["source"], "shipment_id": r["shipment_id"],
                        "doc_type": r["doc_type"], "title": r["title"], "version": r["version"], "status": r["status"],
                        "date": r["created_at"], "by": r["created_by"], "path": r["file_path"],
                        "file_name": r["file_name"], "container": None, "step": None})
        ship_sql = " AND s.shipment_id = ?" if shipment_id else ""
        up_ids = set()
        for r in conn.execute(
                "SELECT u.*, s.shipment_id, c.container_number FROM uploaded_documents u JOIN shipments s ON s.id = "
                "u.shipment_fk LEFT JOIN containers c ON c.id = u.container_fk WHERE 1 = 1" + ship_sql, params):
            up_ids.add((r["evidence_table"], r["evidence_id"]))
            evidence = " · dùng làm bằng chứng" if r["evidence_table"] else ""
            out.append({"key": f"U{r['id']}", "source": "UPLOAD", "shipment_id": r["shipment_id"],
                        "doc_type": r["category"], "title": CATEGORIES.get(r["category"], (r["category"],))[0],
                        "version": None,
                        "status": ("Đã nhập tay dữ liệu từ file" if r["extraction_source"] == "MANUAL"
                                   else "Chưa nhập dữ liệu") + evidence + " — không phải xác nhận chính thức",
                        "date": r["uploaded_at"], "by": r["uploaded_by"], "path": r["file_path"],
                        "file_name": r["file_name"], "container": r["container_number"], "step": r["step"]})
        for table, step, label in (("gatein_evidence", 5, "Bằng chứng Gate-in (tải ở Bước 5)"),
                                   ("bl_documents", 6, "Chứng từ hãng tàu cho B/L (tải ở Bước 6)")):
            cont = ", c.container_number" if table == "gatein_evidence" else ", NULL AS container_number"
            join = " LEFT JOIN containers c ON c.id = e.container_fk" if table == "gatein_evidence" else ""
            for r in conn.execute(f"SELECT e.*, s.shipment_id{cont} FROM {table} e JOIN shipments s ON s.id = "
                                  f"e.shipment_fk{join} WHERE 1 = 1" + ship_sql, params):
                if (table, r["id"]) in up_ids:
                    continue
                out.append({"key": f"{'G' if step == 5 else 'B'}{r['id']}", "source": "UPLOAD",
                            "shipment_id": r["shipment_id"], "doc_type": "EVIDENCE", "title": label,
                            "version": None, "status": "Bằng chứng do người dùng tải lên", "date": r["uploaded_at"],
                            "by": r["uploaded_by"] or "—", "path": r["file_path"], "file_name": r["file_name"],
                            "container": r["container_number"], "step": step})
    out += _unregistered_pdfs(shipment_id, {f["path"] for f in out})
    if source:
        out = [f for f in out if f["source"] == source]
    for f in out:
        f["exists"] = Path(f["path"]).exists()
    return sorted(out, key=lambda f: f["date"] or "", reverse=True)


# file-name part → document type, for PDFs in pdfs/ that were generated before the library existed
FILE_DOC_TYPES = (("Booking_Confirmation", "BOOKING"), ("Empty_Container_EIR", "EIR"), ("VGM_Declaration", "VGM"),
                  ("Shipping_Instruction", "SI"), ("Export_Gate-in", "GATEIN"), ("Bill_of_Lading", "BL"))


def _unregistered_pdfs(shipment_id: str | None, known: set[str]) -> list[dict]:
    """Step PDFs in <data>/pdfs/<ShipmentID>/ that are not in library_files (e.g. made before Phase 6)."""
    from datetime import datetime
    from . import settings
    known = {str(Path(k).resolve()).lower() for k in known}
    folders = [settings.PDF_DIR / shipment_id] if shipment_id else         [f for f in settings.PDF_DIR.iterdir() if f.is_dir()] if settings.PDF_DIR.exists() else []
    out = []
    for folder in folders:
        for f in sorted(folder.glob("*.pdf")) if folder.exists() else []:
            if str(f.resolve()).lower() in known:
                continue
            doc_type = next((d for part, d in FILE_DOC_TYPES if f"_{part}" in f.name), None)
            if not doc_type:
                continue
            title = DOC_TITLES[doc_type]
            m = re.search(r"_(ALL|[A-Z]{4}\d{7})_v\d+\.pdf$", f.name)
            if m:
                title += " — " + ("tất cả container" if m.group(1) == "ALL" else m.group(1))
            out.append({"key": "F" + f.relative_to(settings.PDF_DIR).as_posix(), "source": "GENERATED",
                        "shipment_id": folder.name, "doc_type": doc_type, "title": title,
                        "version": version_of(f.name),
                        "status": "Tạo trước khi có thư viện — trạng thái lúc tạo không được ghi",
                        "date": datetime.fromtimestamp(f.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
                        "by": "—", "path": str(f), "file_name": f.name, "container": None, "step": None})
    return out


def get_file(key: str, shipment_id: str | None = None) -> dict | None:
    return next((f for f in list_files(shipment_id) if f["key"] == key), None)


# ---------------------------------------------------------------------------
# Preview
# ---------------------------------------------------------------------------
def preview(path: str | Path) -> tuple[list, str | None]:
    """(images, html) for a file: PDF pages / an image as images; an XLSX sheet as an HTML table."""
    path = Path(path)
    if not path.exists():
        return [], "<p class='hint'>File không còn trong thư mục dữ liệu.</p>"
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        from .pdf_generator import render_pdf_pages
        images = render_pdf_pages(path.read_bytes(), 1.2)
        note = None if len(images) <= PREVIEW_PAGES else \
            f"<p class='hint'>Xem trước {PREVIEW_PAGES}/{len(images)} trang — tải về để xem đủ.</p>"
        return images[:PREVIEW_PAGES], note
    if suffix in (".png", ".jpg", ".jpeg"):
        from PIL import Image
        with Image.open(path) as img:
            return [img.copy()], None
    if suffix == ".xlsx":
        return [], xlsx_table_html(path)
    if suffix == ".json":
        return [], "<pre style='max-height:420px;overflow:auto;font-size:12px'>" + \
            _escape(path.read_text(encoding="utf-8")[:6000]) + "</pre>"
    if suffix == ".zip":
        with zipfile.ZipFile(path) as z:
            names = "".join(f"<li>{_escape(n)}</li>" for n in z.namelist())
        return [], f"<p><b>Nội dung ZIP:</b></p><ul>{names}</ul>"
    return [], "<p class='hint'>Không xem trước được loại file này — hãy tải về.</p>"


def _escape(text: str) -> str:
    import html
    return html.escape(text)


def xlsx_table_html(path: Path, max_rows: int = 25, max_cols: int = 12) -> str:
    """First sheet of an .xlsx as a small table (read with the standard library — no extra package)."""
    ns = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
    try:
        with zipfile.ZipFile(path) as z:
            shared = []
            if "xl/sharedStrings.xml" in z.namelist():
                root = ElementTree.fromstring(z.read("xl/sharedStrings.xml"))
                shared = ["".join(t.text or "" for t in si.iter(f"{{{ns['m']}}}t")) for si in root.findall("m:si", ns)]
            sheets = sorted(n for n in z.namelist() if re.fullmatch(r"xl/worksheets/sheet\d+\.xml", n))
            root = ElementTree.fromstring(z.read(sheets[0]))
    except (KeyError, IndexError, zipfile.BadZipFile, ElementTree.ParseError):
        return "<p class='hint'>Không đọc được file Excel này — hãy tải về để mở.</p>"
    rows = []
    for row in root.iter(f"{{{ns['m']}}}row"):
        cells = []
        for c in row.findall("m:c", ns)[:max_cols]:
            v = c.find("m:v", ns)
            text = v.text if v is not None else "".join(t.text or "" for t in c.iter(f"{{{ns['m']}}}t"))
            if c.get("t") == "s" and text is not None and text.isdigit() and int(text) < len(shared):
                text = shared[int(text)]
            cells.append(f"<td>{_escape(text or '')}</td>")
        rows.append(f"<tr>{''.join(cells)}</tr>")
        if len(rows) >= max_rows:
            break
    return ('<p class="hint">Trang tính đầu tiên (tối đa 25 dòng) — chỉ để xem, hệ thống không tự đọc số liệu.</p>'
            f'<div class="table-wrap"><table class="grid">{"".join(rows)}</table></div>')
