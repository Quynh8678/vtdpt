"""@tracked: puts every save function under version control and the change log (REQUIREMENTS.md §6, §8).

    @tracked("SI")
    def save_si(shipment_id, ...): ...

The wrapper takes a snapshot of the whole shipment before and after the save, then
history.after_change() applies the sync rules, writes the change log (time, user, document, field,
old value, new value, reason) and a new version for every document whose content changed.

Every tracked function also accepts `reason="..."` (stored in the change log). Nested calls
(a tracked function calling another one) are recorded once, by the outer call.
This module imports nothing heavy, so every business module can use it.
"""

import functools
import threading
from contextlib import contextmanager

_state = threading.local()


def tracked(doc_type: str):
    """doc_type: the form the change is made in (SHIPMENT, BOOKING, EIR, VGM, SI, GATEIN, BL)."""
    def decorate(fn):
        @functools.wraps(fn)
        def wrapper(shipment_id, *args, reason: str | None = None, **kwargs):
            if getattr(_state, "depth", 0):
                return fn(shipment_id, *args, **kwargs)
            from . import history          # imported here: history imports the business modules
            _state.depth = 1
            try:
                before = history.capture(shipment_id) if shipment_id else None
                result = fn(shipment_id, *args, **kwargs)
                sid = shipment_id or getattr(result, "shipment_id", None)
                report = history.after_change(sid, doc_type, before, reason or getattr(_state, "reason", None))
            finally:
                _state.depth = 0
            if report and hasattr(result, "warnings"):
                result.warnings.extend(report)
            return result
        return wrapper
    return decorate


@contextmanager
def action(name: str, reason: str | None = None):
    """Label the changes made inside (RESTORE, APPLY, KEEP, REPLACE …) and give them a reason."""
    old = getattr(_state, "action", None), getattr(_state, "reason", None)
    _state.action, _state.reason = name, reason
    try:
        yield
    finally:
        _state.action, _state.reason = old


def current_action() -> str | None:
    return getattr(_state, "action", None)


@contextmanager
def acting_as(user: str):
    """Record changes under another name (e.g. the demo data created by the system)."""
    old = getattr(_state, "user", None)
    _state.user = user
    try:
        yield
    finally:
        _state.user = old


def acting_user() -> str | None:
    return getattr(_state, "user", None)
