"""Step 3 — VGM Declaration PDF: generate_vgm_declaration_pdf() (REQUIREMENTS.md §5 Step 3, §11).

Its own layout, modelled on a shipper's SOLAS VGM declaration:

    navy header "VERIFIED GROSS MASS DECLARATION (SOLAS Chapter VI, Regulation 2)"
    status strip (DRAFT until declared; acknowledged only with the user's reference)
    references → shipment/voyage block | container block
    large highlighted VGM figure with unit and method
    Method 2 breakdown table with the formula  — or —  Method 1 weighing details
    declaration statement → authorized signatory (signature left EMPTY) | submission & acknowledgement
    remarks → document status note

One page per container; several containers can go in one PDF. Shared fonts, colours,
footer ("Page X of Y") and number formats come from pdf_generator / formatting.
"""

import io
from datetime import datetime
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (
    KeepInFrame, KeepTogether, PageBreak, SimpleDocTemplate, Spacer, Table, TableStyle,
)

from . import APP_NAME, settings, vgm
from .formatting import DASH, fmt_date, fmt_datetime, fmt_kg, fmt_tonnes
from .pdf_generator import (
    FONT, FONT_BOLD, GAP, GRID, KIND_COLOURS, MARGIN_BOTTOM, MARGIN_TOP, MARGIN_X, MUTED, NAVY, NAVY_SOFT,
    TABLE_FONT, W, _block, _container_number_block, _numbered_canvas, _page_decorator, _plain_grid, _styles,
    data_table, field_grid, note_box, register_fonts, safe_filename_part, side_by_side, txt, Paragraph,
)
from .shipments import sample_text

RED = colors.HexColor("#9C2F23")
RED_BG = colors.HexColor("#FDECEA")
GREEN = colors.HexColor("#1E6B45")


def vgm_figure(kg, unit: str) -> tuple[str, str]:
    """('23,035 KG', '= 23.035 metric tons') or ('23.035 METRIC TONS', '= 23,035 kg')."""
    if kg is None:
        return "NOT DETERMINED", "VGM cannot be determined from the data entered yet"
    if unit == "TNE":
        return f"{fmt_tonnes(kg)} METRIC TONS", f"= {fmt_kg(kg)} kg"
    return f"{fmt_kg(kg)} KG", f"= {fmt_tonnes(kg)} metric tons"


def _band(st, method: str | None) -> Table:
    white = ParagraphStyle("vb_t", parent=st["title"], textColor=colors.white, fontSize=14.5, leading=17.5)
    white_sub = ParagraphStyle("vb_s", parent=st["subtitle"], textColor=colors.HexColor("#C9D4E5"))
    big = ParagraphStyle("vb_m", parent=st["value_big"], textColor=NAVY, alignment=TA_CENTER, fontSize=15, leading=17)
    small = ParagraphStyle("vb_m2", parent=st["badge_sub"], textColor=NAVY, alignment=TA_CENTER)
    method_text = {"METHOD_1": "METHOD 1 · WEIGHED", "METHOD_2": "METHOD 2 · CALCULATED"}.get(method, "METHOD NOT SELECTED")
    box = Table([[Paragraph("VGM", big)], [Paragraph(method_text, small)]], colWidths=[40 * mm])
    box.setStyle(TableStyle(TABLE_FONT + [
        ("BACKGROUND", (0, 0), (-1, -1), colors.white),
        ("TOPPADDING", (0, 0), (0, 0), 3), ("BOTTOMPADDING", (0, -1), (-1, -1), 3.5),
    ]))
    band = Table([[[Paragraph("VERIFIED GROSS MASS DECLARATION", white),
                    Paragraph("(SOLAS Chapter VI, Regulation 2)", ParagraphStyle(
                        "vb_r", parent=white_sub, fontName=FONT_BOLD, textColor=colors.white, fontSize=9)),
                    Paragraph(f"Phiếu khai báo khối lượng toàn bộ container (VGM) &nbsp;·&nbsp; "
                              f"<font name='{FONT_BOLD}' size='7'>STEP 3 OF 6</font>", white_sub)], box]],
                 colWidths=[W - 44 * mm, 44 * mm])
    band.setStyle(TableStyle(TABLE_FONT + [
        ("BACKGROUND", (0, 0), (-1, -1), NAVY), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (1, 0), (1, 0), "RIGHT"),
        ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 5.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 6.5),
    ]))
    return band


def _status_strip(st, label: dict, status: str, index: int, total: int) -> Table:
    fg, bg = KIND_COLOURS[label["kind"]]
    strip = Table([[Paragraph(escape(label["badge"]), ParagraphStyle("vs", parent=st["note_b"], textColor=fg)),
                    Paragraph(f"Status: <b>{escape(vgm.status_label(status))}</b> &nbsp;·&nbsp; VGM {index} of {total}"
                              + (f" &nbsp;·&nbsp; <b>{escape(label['sample_text'])} DATA</b>" if label["sample"] else ""),
                              ParagraphStyle("vs_r", parent=st["note"], alignment=TA_RIGHT))]],
                  colWidths=[W * 0.52, W * 0.48])
    strip.setStyle(TableStyle(TABLE_FONT + [
        ("BACKGROUND", (0, 0), (-1, -1), bg), ("LINEBELOW", (0, 0), (-1, -1), 1.2, fg),
        ("LEFTPADDING", (0, 0), (-1, -1), 6), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    return strip


def _vgm_box(st, rec: dict, container: dict, label: dict) -> Table:
    """The large highlighted VGM figure."""
    kg, unit = rec.get("vgm_kg"), rec.get("vgm_unit") or "KGM"
    over = bool(kg and container.get("max_gross_kg") and kg > container["max_gross_kg"])
    figure, second = vgm_figure(kg, unit)
    colour = RED if over or kg is None else NAVY
    border = RED if over else (KIND_COLOURS["draft"][0] if label["kind"] == "draft" else NAVY)
    big = ParagraphStyle("vgm_big", parent=st["value_big"], fontSize=24 if kg is not None else 16, leading=28,
                         textColor=colour)
    left = [Paragraph("VERIFIED GROSS MASS (VGM) · KHỐI LƯỢNG TOÀN BỘ ĐÃ XÁC MINH", st["label"]), Spacer(1, 2),
            Paragraph(escape(figure), big), Paragraph(escape(second), st["subnote"])]
    method = rec.get("weighing_method")
    method_en = vgm.METHODS[method][0] if method in vgm.METHODS else "Not selected"
    right = [Paragraph("METHOD", st["label"]), Paragraph(escape(method_en), st["value_b"]), Spacer(1, 3)]
    if method == "METHOD_1":
        right += [Paragraph("WEIGHED ON", st["label"]), Paragraph(fmt_datetime(rec.get("weighing_datetime")), st["value"])]
    elif method == "METHOD_2":
        right += [Paragraph("CARGO WEIGHT BASIS", st["label"]),
                  Paragraph(escape(vgm.CARGO_BASES[rec.get("cargo_basis") or "GROSS"][0]), st["value"])]
    max_gross = container.get("max_gross_kg")
    right += [Spacer(1, 3), Paragraph("MAX GROSS MASS (CSC PLATE)", st["label"]),
              Paragraph(f"{fmt_kg(max_gross)} kg" if max_gross else "Not recorded", st["value"])]
    if over:
        right.append(Paragraph(f"<b>EXCEEDS MAX GROSS BY {fmt_kg(kg - max_gross)} KG</b>",
                               ParagraphStyle("over", parent=st["value"], textColor=RED)))
    t = Table([[left, right]], colWidths=[W * 0.58, W * 0.42])
    t.setStyle(TableStyle(TABLE_FONT + [
        ("BACKGROUND", (0, 0), (0, 0), RED_BG if over else NAVY_SOFT),
        ("BOX", (0, 0), (-1, -1), 2, border), ("LINEAFTER", (0, 0), (0, 0), 0.6, GRID),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 8), ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    return t


def _method_section(st, rec: dict, container: dict) -> list:
    method = rec.get("weighing_method")
    tare = rec.get("tare_used_kg") if rec.get("tare_used_kg") is not None else container.get("tare_weight_kg")
    if method == "METHOD_2":
        basis = rec.get("cargo_basis") or "GROSS"
        rows = vgm.breakdown(basis, rec, tare)
        body = [[str(n), f"<b>{escape(r['en'])}</b> <font size='6.5' color='#5B6B82'>· {escape(r['vi'])}</font>",
                 escape(r["note"]) or DASH, fmt_kg(r["kg"]) if r["kg"] is not None else
                 ("0" if r["key"] not in ("cargo_weight_kg", "tare_weight_kg") else DASH)]
                for n, r in enumerate(rows, start=1)]
        total = ["", "<b>VERIFIED GROSS MASS (VGM)</b>",
                 f"= {escape(vgm.formula_with_numbers(basis, rec, tare))}", fmt_kg(rec.get("vgm_kg"))]
        table = data_table(st, [("#", "l"), ("Component · Thành phần", "l"), ("Basis / note", "l"),
                                ("Weight (kg)", "r")], body, [W * w for w in (0.06, 0.34, 0.42, 0.18)], total)
        formula = Paragraph(f"<b>Formula:</b> {escape(vgm.FORMULA)}", st["note"])
        cert = rec.get("method2_certification_ref")
        cert_line = Paragraph(
            f"<b>Method 2 certification / approval ref.:</b> {txt(cert)} <font size='6.6' color='#5B6B82'>"
            "(entered by the user from the shipper's certificate)</font>" if cert else
            "<b>Method 2 certification / approval ref.:</b> not recorded <font size='6.6' color='#5B6B82'>(only "
            "where the competent authority certifies shippers for Method 2)</font>", st["note"])
        return [KeepTogether([
            Paragraph(f"METHOD 2 — CALCULATION &nbsp;<font name='{FONT}' size='7' color='#5B6B82'>"
                      "Phương pháp 2 — cộng khối lượng tất cả thành phần và tare</font>", st["subhead"]),
            Spacer(1, 1.5), formula, Spacer(1, 2), table, Spacer(1, 2), cert_line])]
    if method == "METHOD_1":
        grid = _plain_grid(st, [
            [("Weighing date / time", fmt_datetime(rec.get("weighing_datetime")), "value_b"),
             ("Weighed gross mass (kg)", fmt_kg(rec.get("weighed_vgm_kg")), "value_b")],
            [("Weighing location", txt(rec.get("weighing_location"))),
             ("Weighing equipment / service provider", txt(rec.get("weighing_provider")))],
        ], [W * 0.5, W * 0.5])
        ref = Paragraph(
            f"The packed and sealed container was weighed as a whole. For reference only (not used to determine "
            f"the VGM): cargo weight {fmt_kg(rec.get('cargo_weight_kg'))} kg, container tare {fmt_kg(tare)} kg.",
            st["subnote"])
        return [_block(st, "Method 1 — Weighing details", "Phương pháp 1 — thông tin cân",
                       [grid, Table([[ref]], colWidths=[W], style=TableStyle(TABLE_FONT + [
                           ("LEFTPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))], W)]
    return [Paragraph("<b>Method not selected.</b> Choose Method 1 (weighing) or Method 2 (calculation) "
                      "before declaring.", ParagraphStyle("nm", parent=st["note"], textColor=RED))]


def _signatory_block(st, rec: dict, width: float) -> Table:
    grid = _plain_grid(st, [
        [("Name of authorized signatory", txt(rec.get("signatory_name")), "value_b"),
         ("Position", txt(rec.get("signatory_position")))],
        [("On behalf of (responsible party)", txt(rec.get("responsible_party"))),
         ("Declaration date", fmt_date(rec.get("declaration_date")), "value_b")],
    ], [width * 0.55, width * 0.45])
    sign = Table([[[Paragraph("SIGNATURE / CHỮ KÝ", st["label"]), Spacer(1, 11 * mm)]]], colWidths=[width])
    sign.setStyle(TableStyle(TABLE_FONT + [
        ("LINEABOVE", (0, 0), (-1, -1), 0.4, GRID),
        ("LEFTPADDING", (0, 0), (-1, -1), 5), ("TOPPADDING", (0, 0), (-1, -1), 2.5),
    ]))
    return _block(st, "Authorized signatory", "Người ký có thẩm quyền", [grid, sign], width)


def _submission_block(st, rec: dict, width: float) -> Table:
    ack = rec.get("ack_reference") if rec.get("vgm_status") == "Acknowledged" else None
    ack_html = (f"<font color='#1E6B45'><b>{txt(ack)}</b></font><br/><font size='6.5' color='#5B6B82'>"
                "entered by the user from the carrier/terminal response</font>") if ack else \
        "<font color='#9C2F23'>Not acknowledged — no carrier/terminal acknowledgement reference recorded</font>"
    grid = _plain_grid(st, [
        [("Submission date", fmt_date(rec.get("submission_date")), "value_b")],
        [("Submission channel", txt(rec.get("submission_channel")))],
        [("Carrier / terminal acknowledgement ref.", ack_html)],
    ], [width])
    return _block(st, "Submission & acknowledgement", "Gửi & xác nhận", [grid], width)


def _vgm_page(st, ship: dict, item: dict, index: int, total: int) -> list:
    c, rec = item["container"], item["vgm"]
    label = vgm.document_label(ship, c, rec)
    half = (W - GAP) / 2
    story = [_band(st, rec.get("weighing_method")),
             _status_strip(st, label, rec["vgm_status"], index, total), Spacer(1, 2.4 * mm)]

    story += [field_grid(st, [[
        ("VGM Reference (shipper)", txt(rec.get("vgm_reference")), "value_big"),
        ("Booking No.", txt(ship.get("booking_number")), "value_b"),
        ("Declaration Date", fmt_date(rec.get("declaration_date")), "value_b"),
        ("Carrier", txt(ship.get("carrier_name"))),
        ("Shipment ID", txt(ship["shipment_id"])),
    ]], [W * w for w in (0.27, 0.17, 0.17, 0.22, 0.17)], shade=True), Spacer(1, 2.4 * mm)]

    vessel = " / ".join(x for x in (ship.get("vessel_name"), ship.get("voyage_number")) if x)
    shipment = _block(st, "Shipment / Voyage", "Lô hàng / chuyến tàu", [
        _plain_grid(st, [[("Shipper / Responsible party", txt(rec.get("responsible_party")), "value_b")]], [half]),
        _plain_grid(st, [
            [("Vessel / Voyage", txt(vessel), "value_b"), ("VGM cut-off", fmt_datetime(ship.get("vgm_cutoff")), "value_b")],
            [("Port of Loading", txt(ship.get("port_of_loading"))),
             ("Port of Discharge", txt(ship.get("port_of_discharge")))],
        ], [half * 0.5, half * 0.5])], half)
    size = f"{c['container_size']}'" if c.get("container_size") else None
    container = _block(st, "Container", "Container", [
        Spacer(1, 2), Table([[_container_number_block(st, c.get("container_number"))]], colWidths=[half],
                            style=TableStyle(TABLE_FONT + [("LEFTPADDING", (0, 0), (-1, -1), 4)])),
        _plain_grid(st, [
            [("Size", txt(size), "value_b"), ("ISO Type", txt(c.get("iso_type_code")), "value_b"),
             ("Type", txt(c.get("container_type")))],
            [("Seal No.", txt(c.get("seal_number")), "value_b"), ("Tare (kg)", fmt_kg(c.get("tare_weight_kg")), "value_b"),
             ("Max gross — CSC (kg)", fmt_kg(c.get("max_gross_kg")))],
        ], [half * 0.30, half * 0.30, half * 0.40]),
    ], half)
    story += [side_by_side([shipment], [container]), Spacer(1, 2.4 * mm)]

    story += [_vgm_box(st, rec, c, label), Spacer(1, 2.4 * mm)]
    story += _method_section(st, rec, c) + [Spacer(1, 2.4 * mm)]

    blocking = vgm.checks(ship, c, rec)[0]
    if blocking:
        story += [Table([[[Paragraph("NOT READY TO DECLARE · CHƯA ĐỦ ĐIỀU KIỆN KHAI", ParagraphStyle(
            "nr", parent=st["note_b"], textColor=RED))] + [Paragraph("– " + escape(b), st["note"]) for b in blocking]]],
            colWidths=[W], style=TableStyle(TABLE_FONT + [
                ("BACKGROUND", (0, 0), (-1, -1), RED_BG), ("BOX", (0, 0), (-1, -1), 0.9, RED),
                ("LEFTPADDING", (0, 0), (-1, -1), 6.5), ("TOPPADDING", (0, 0), (-1, -1), 3.5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4.5)])), Spacer(1, 2.4 * mm)]

    method = rec.get("weighing_method")
    method_name = vgm.METHODS[method][0].split(" — ")[0] if method in vgm.METHODS else "[method not selected]"
    statement = (
        f"I, the undersigned, on behalf of the shipper named above, declare that the verified gross mass of the "
        f"packed container stated above has been obtained in accordance with SOLAS Chapter VI, Regulation 2, "
        f"using {method_name}, and that it is accurate to the best of my knowledge. The shipper remains responsible "
        f"for the verified gross mass.")
    statement_vi = ("Tôi, người ký tên dưới đây, thay mặt người gửi hàng, xác nhận khối lượng toàn bộ đã xác minh "
                    "(VGM) của container nêu trên được xác định theo Quy định 2, Chương VI, Công ước SOLAS.")
    decl = Table([[[Paragraph("DECLARATION · LỜI CAM KẾT", st["subhead"]), Spacer(1, 1.5),
                    Paragraph(escape(statement), st["note"]), Paragraph(escape(statement_vi), st["subnote"])]]],
                 colWidths=[W])
    decl.setStyle(TableStyle(TABLE_FONT + [
        ("BOX", (0, 0), (-1, -1), 0.8, NAVY), ("LEFTPADDING", (0, 0), (-1, -1), 6.5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6.5), ("TOPPADDING", (0, 0), (-1, -1), 3.5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4.5),
    ]))
    story += [KeepTogether([decl, Spacer(1, 2.5 * mm),
                            side_by_side([_signatory_block(st, rec, half)], [_submission_block(st, rec, half)])]),
              Spacer(1, 2.4 * mm)]

    if rec.get("remarks"):
        story += [field_grid(st, [[("Remarks · Ghi chú", txt(rec.get("remarks")))]], [W]), Spacer(1, 2.4 * mm)]

    story.append(note_box(st, label["kind"], f"DOCUMENT STATUS: {label['badge']}", label["note"],
                          fine=f"The signature area is left blank on purpose — {APP_NAME} never reproduces "
                               "signatures, stamps or carrier/terminal confirmations. Weights in kilograms."))
    return story


def vgm_pdf_filename(ship: dict, items: list[dict], all_vgms: bool) -> str:
    if all_vgms:
        part = "ALL"
    else:
        part = safe_filename_part(items[0]["container"].get("container_number") or items[0]["vgm"]["vgm_reference"],
                                  "VGM")
    version = max((i["vgm"].get("doc_version") or 1) for i in items)
    return (f"{safe_filename_part(ship['shipment_id'], 'SHIPMENT')}_"
            f"{safe_filename_part(ship.get('booking_number'), 'NO-BOOKING')}_VGM_Declaration_{part}_v{version}.pdf")


def _vgm_items(shipment_id: str, container_ids: list[int] | None) -> tuple[dict, list[dict]]:
    overview = vgm.get_shipment_vgms(shipment_id)
    if not overview:
        raise vgm.VGMError([f"Không tìm thấy lô hàng {shipment_id}."])
    items = [i for i in overview["items"] if i["vgm"]]
    if container_ids is not None:
        items = [i for i in items if i["container"]["id"] in container_ids]
    if not items:
        raise vgm.VGMError(["Chưa có VGM nào được lưu. Hãy bấm “Lưu VGM” trước khi xuất PDF."])
    return overview["shipment"], items


def _flatten(flowables: list) -> list:
    """Unwrap KeepTogether groups (not needed inside a one-page KeepInFrame, which cannot draw them)."""
    out = []
    for f in flowables:
        out += _flatten(f._content) if isinstance(f, KeepTogether) else [f]
    return out


def _render_vgm_pdf(ship: dict, items: list[dict], target) -> None:
    register_fonts()
    st = _styles()
    exported_at = datetime.now()
    statuses = {i["vgm"]["vgm_status"] for i in items}
    watermark = "SAMPLE" if ship["is_sample"] else ("DRAFT" if statuses == {"Draft"} else None)
    version = f"v{max((i['vgm'].get('doc_version') or 1) for i in items)}"
    footer = [
        f"Shipment ID: {ship['shipment_id']}   ·   Booking No.: {ship.get('booking_number') or DASH}   ·   "
        f"Document version: {version}",
        f"VGM Declaration   ·   {len(items)} container{'s' if len(items) > 1 else ''}"
        + (f"   ·   {sample_text(ship)} DATA" if ship["is_sample"] else "")
        + f"   ·   Exported: {exported_at.strftime('%d %b %Y %H:%M').upper()}",
    ]
    doc = SimpleDocTemplate(
        target, pagesize=A4, leftMargin=MARGIN_X, rightMargin=MARGIN_X,
        topMargin=MARGIN_TOP, bottomMargin=MARGIN_BOTTOM,
        title=f"VGM Declaration — {ship['shipment_id']}", author=APP_NAME,
        subject=f"Verified Gross Mass Declaration · {ship['shipment_id']} · {version}", creator=APP_NAME,
        initialFontName=FONT, initialFontSize=8)
    story = []
    for n, item in enumerate(items, start=1):
        if n > 1:
            story.append(PageBreak())
        # Always ONE page per container: very long names/remarks shrink the page slightly instead of
        # pushing the status note onto a second page.
        story.append(KeepInFrame(W, doc.height - 12, _flatten(_vgm_page(st, ship, item, n, len(items))),
                                 mode="shrink"))
    decorate = _page_decorator(watermark, None)
    doc.build(story, onFirstPage=decorate, onLaterPages=decorate, canvasmaker=_numbered_canvas(footer))


def build_vgm_declaration_pdf_bytes(shipment_id: str, container_ids: list[int] | None = None) -> bytes:
    """VGM PDF in memory (preview): one page per container that has a VGM record."""
    ship, items = _vgm_items(shipment_id, container_ids)
    buffer = io.BytesIO()
    _render_vgm_pdf(ship, items, buffer)
    return buffer.getvalue()


def generate_vgm_declaration_pdf(shipment_id: str, container_ids: list[int] | None = None,
                                 output_path: str | Path | None = None) -> Path:
    """Create the VGM Declaration PDF and save it in the data folder.

    container_ids=None → every saved VGM of the shipment in one PDF (one page per container).
    File: <data>/pdfs/<ShipmentID>/<ShipmentID>_<BookingNo>_VGM_Declaration_<ContainerNo|ALL>_v<N>.pdf
    """
    ship, items = _vgm_items(shipment_id, container_ids)
    if output_path is None:
        folder = settings.PDF_DIR / safe_filename_part(shipment_id, "SHIPMENT")
        folder.mkdir(parents=True, exist_ok=True)
        output_path = folder / vgm_pdf_filename(ship, items, all_vgms=container_ids is None)
    output_path = Path(output_path)
    _render_vgm_pdf(ship, items, str(output_path))
    vgm.record_pdf_export([i["container"]["id"] for i in items], str(output_path))
    from .library import register_generated      # Document Library keeps every version
    register_generated(shipment_id, "VGM", output_path)
    return output_path
