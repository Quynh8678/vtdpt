"""EXPORT DOCS MANAGEMENT — export container documentation system."""

from pathlib import Path

APP_NAME = "EXPORT DOCS MANAGEMENT"


def _read_version() -> str:
    """The app version is written in the VERSION file next to app.py (also inside the Colab ZIP)."""
    try:
        return (Path(__file__).resolve().parent.parent / "VERSION").read_text(encoding="utf-8").strip() or "unknown"
    except OSError:
        return "unknown"


__version__ = _read_version()
