"""Shipment Management page (REQUIREMENTS.md §3 and §4).

List + search + filter, view details, create, edit, copy, delete with confirmation.
The form is split into five groups: General, Parties, Cargo, Transport, Containers.
"""

import math

import gradio as gr
import pandas as pd

from . import shipments as S
from .formatting import fmt_cbm, fmt_kg, fmt_packages
from .ui_common import (
    e, message_html, notice_html, page_title_html, sample_badge, section_title_html,
    shipment_summary_html, shipment_tracker_html, status_label, status_pill,
)
from . import reference
from .ui_validation import build_conflict_panel
from .workflow import shipment_step_statuses

# ---------------------------------------------------------------------------
# Labels (Vietnamese UI, English shipping terms). * = needed to complete documents
# ---------------------------------------------------------------------------
FIELD_LABELS = {
    "status": "Trạng thái lô hàng (Status)",
    "transport_mode": "Phương thức vận chuyển (Transport mode)",
    "export_type": "Loại hình xuất khẩu (Export type)",
    "person_in_charge": "Người phụ trách (Person in charge)",
    "customer_name": "Khách hàng (Customer) *",
    "contract_reference": "Số hợp đồng / tham chiếu (Contract / Reference)",
    "notes": "Ghi chú (Notes)",
    "carrier_name": "Hãng tàu (Carrier) *",
    "booking_number": "Số booking (Booking Number)",
    "vessel_name": "Tên tàu (Vessel)",
    "voyage_number": "Số chuyến (Voyage)",
    "place_of_receipt": "Nơi nhận hàng (Place of Receipt)",
    "port_of_loading": "Cảng xếp hàng (POL) *",
    "port_of_discharge": "Cảng dỡ hàng (POD) *",
    "transshipment_port": "Cảng chuyển tải (Transshipment port)",
    "place_of_delivery": "Nơi giao hàng (Place of Delivery)",
    "etd": "ETD — Ngày tàu chạy dự kiến",
    "eta": "ETA — Ngày tàu đến dự kiến",
    "cy_cutoff": "CY cut-off — Hạn hạ container có hàng",
    "si_cutoff": "SI cut-off — Hạn nộp Shipping Instruction",
    "vgm_cutoff": "VGM cut-off — Hạn khai VGM",
    "empty_pickup_depot": "Depot lấy container rỗng (Empty pick-up depot)",
    "empty_pickup_date": "Ngày lấy container rỗng (Pick-up date)",
    "container_return_depot": "Nơi hạ container có hàng (Return depot / terminal)",
}
PARTY_FIELD_LABELS = {
    "party_name": "Tên công ty (Name)",
    "address": "Địa chỉ (Address)",
    "country": "Quốc gia (Country)",
    "tax_id": "Mã số thuế (Tax ID)",
    "email": "Email",
    "phone": "Điện thoại (Phone)",
}
REQUIRED_PARTIES = ("SHIPPER", "CONSIGNEE")

LIST_COLUMNS = ["Shipment ID", "Trạng thái", "Khách hàng (Customer)", "Booking No.", "Shipper",
                "Consignee", "POL", "POD", "Vessel/Voyage", "ETD", "Số cont", "Cập nhật lúc"]

CARGO_HEADERS = ["ID"] + [c.header for c in S.CARGO_COLUMNS]
CONTAINER_HEADERS = ["ID"] + [c.header for c in S.CONTAINER_COLUMNS]


def _types(columns):
    return ["number"] + ["number" if c.kind in ("number", "integer") else "str" for c in columns]


CARGO_TYPES = _types(S.CARGO_COLUMNS)
CONTAINER_TYPES = _types(S.CONTAINER_COLUMNS)
CONTAINER_STATIC = [0] + [i + 1 for i, c in enumerate(S.CONTAINER_COLUMNS) if c.locked]

PARTY_KEYS = [(role, f) for role, *_ in S.PARTY_ROLES for f in S.PARTY_FIELDS]


# ---------------------------------------------------------------------------
# Table <-> rows conversion
# ---------------------------------------------------------------------------
def _cell(value, kind):
    if value is None:
        return None if kind != "text" else ""
    return value


def rows_to_frame(rows, columns, headers) -> pd.DataFrame:
    data = [[r.get("id")] + [_cell(r.get(c.key), c.kind) for c in columns] for r in rows]
    return pd.DataFrame(data, columns=headers)


def frame_to_rows(frame, columns) -> list[dict]:
    if frame is None:
        return []
    values = frame.values.tolist() if isinstance(frame, pd.DataFrame) else list(frame)
    rows = []
    for raw in values:
        raw = list(raw) + [None] * (len(columns) + 1 - len(raw))
        row = {"id": raw[0]}
        row.update({c.key: raw[i + 1] for i, c in enumerate(columns)})
        rows.append(row)
    return rows


def _to_frame(frame, headers) -> pd.DataFrame:
    if isinstance(frame, pd.DataFrame):
        out = frame.copy()
        out.columns = headers[: len(out.columns)]
        return out
    return pd.DataFrame(frame or [], columns=headers)


def add_row(frame, headers):
    df = _to_frame(frame, headers)
    return pd.concat([df, pd.DataFrame([[None] * len(headers)], columns=headers)], ignore_index=True)


def remove_row(frame, row_number, headers):
    df = _to_frame(frame, headers)
    text = str(row_number or "").strip()
    if not text.isdigit() or not (1 <= int(text) <= len(df)):
        return gr.skip(), message_html("warning", f"Hãy nhập số thứ tự dòng từ 1 đến {len(df)} "
                                       f"(bảng hiện có {len(df)} dòng).")
    df = df.drop(index=df.index[int(text) - 1]).reset_index(drop=True)
    return df, message_html("info", f"Đã bỏ dòng {text} khỏi bảng. "
                            "Bấm “Lưu lô hàng” để lưu thay đổi.")


def _num(value):
    try:
        number = float(value)
        return 0.0 if math.isnan(number) else number
    except (TypeError, ValueError):
        return 0.0


def cargo_totals_html(frame) -> str:
    rows = [r for r in frame_to_rows(frame, S.CARGO_COLUMNS)
            if any(not S.is_blank(v) for k, v in r.items() if k != "id")]
    pk = sum(_num(r["package_count"]) for r in rows)
    gw = sum(_num(r["gross_weight_kg"]) for r in rows)
    nw = sum(_num(r["net_weight_kg"]) for r in rows)
    cbm = sum(_num(r["volume_cbm"]) for r in rows)
    return (f'<div class="totals">Tổng: <b>{len(rows)}</b> dòng hàng · <b>{pk:,.0f}</b> kiện · '
            f'Gross <b>{gw:,.2f}</b> kg · Net <b>{nw:,.2f}</b> kg · <b>{cbm:,.3f}</b> CBM</div>')


def container_totals_html(frame) -> str:
    rows = [r for r in frame_to_rows(frame, S.CONTAINER_COLUMNS)
            if any(not S.is_blank(v) for k, v in r.items() if k != "id")]
    sizes = {}
    for r in rows:
        size = S.clean_text(r["container_size"]) or "?"
        sizes[size] = sizes.get(size, 0) + 1
    mix = ", ".join(f"{n} × {size}'" for size, n in sorted(sizes.items())) or "—"
    cargo = sum(_num(r["cargo_weight_kg"]) for r in rows)
    gross = sum(_num(r["gross_weight_kg"]) for r in rows)
    return (f'<div class="totals">Tổng: <b>{len(rows)}</b> container ({e(mix)}) · '
            f'Cargo <b>{cargo:,.0f}</b> kg · Gross <b>{gross:,.0f}</b> kg</div>')


# ---------------------------------------------------------------------------
# HTML views
# ---------------------------------------------------------------------------
def form_title_html(ship: dict | None) -> str:
    if not ship:
        return ('<div class="form-head"><h3>📝 Lô hàng mới</h3>'
                '<p>Shipment ID sẽ được tạo tự động khi bạn bấm “Lưu lô hàng”.</p></div>')
    sample = sample_badge(ship)
    return (f'<div class="form-head"><h3>✏️ {e(ship["shipment_id"])} {sample}</h3>'
            f'<p>{status_pill(ship["status"])} &nbsp; Tạo lúc {e(ship["created_at"][:16])} · '
            f'Cập nhật lúc {e(ship["updated_at"][:16])}</p>{shipment_summary_html(ship)}</div>')


def _kv_table(pairs) -> str:
    rows = "".join(f"<tr><th>{e(k)}</th><td>{e(v)}</td></tr>" for k, v in pairs)
    return f'<table class="kv">{rows}</table>'


def _grid_table(headers, rows) -> str:
    head = "".join(f"<th>{e(h)}</th>" for h in headers)
    body = "".join("<tr>" + "".join(f"<td>{e(v)}</td>" for v in r) + "</tr>" for r in rows)
    if not rows:
        body = f'<tr><td colspan="{len(headers)}" class="empty">Chưa có dữ liệu</td></tr>'
    return f'<div class="table-wrap"><table class="grid"><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>'


def details_html(ship: dict | None) -> str:
    if not ship:
        return notice_html("Chọn một lô hàng trong bảng (bấm vào dòng) để xem chi tiết.")
    L = FIELD_LABELS
    general = _kv_table([(L[k].rstrip(" *"), status_label(ship[k]) if k == "status" else ship[k])
                         for k in S.GENERAL_FIELDS])
    transport = _kv_table([(L[k].rstrip(" *"), ship[k]) for k in S.TRANSPORT_FIELDS])
    party_blocks = []
    for role, en, vi, _ in S.PARTY_ROLES:
        p = ship["parties"].get(role) or {}
        lines = [p.get("party_name"), p.get("address"), p.get("country"),
                 f"Tax ID: {p['tax_id']}" if p.get("tax_id") else None,
                 p.get("email"), p.get("phone")]
        text = "<br>".join(e(x) for x in lines if x) or '<span class="empty">Chưa nhập</span>'
        party_blocks.append(f'<div class="party"><div class="role">{e(en)} · {e(vi)}</div>{text}</div>')
    cargo = _grid_table(
        ["#", "Commodity", "Description of Goods", "HS", "Packages", "Gross (kg)", "Net (kg)", "CBM"],
        [[c["line_number"], c["commodity"], c["cargo_description"], c["hs_code"],
          fmt_packages(c["package_count"], c["package_type"]),
          fmt_kg(c["gross_weight_kg"]), fmt_kg(c["net_weight_kg"]), fmt_cbm(c["volume_cbm"])]
         for c in ship["cargo"]])
    conts = _grid_table(
        ["Container No.", "Size/Type", "Full/Empty", "Seal No.", "Tare (kg)", "Cargo (kg)",
         "Gross (kg)", "VGM (kg)", "Truck / Chassis", "EIR No."],
        [[c["container_number"] or "(chưa có số)",
          " ".join(x for x in (c["container_size"], c["iso_type_code"], c["container_type"]) if x),
          c["load_status"], c["seal_number"], fmt_kg(c["tare_weight_kg"]), fmt_kg(c["cargo_weight_kg"]),
          fmt_kg(c["gross_weight_kg"]), fmt_kg(c["vgm_kg"]),
          " / ".join(x for x in (c["truck_number"], c["chassis_number"]) if x), c["eir_number"]]
         for c in ship["containers"]])
    sample = sample_badge(ship)
    return f"""
    <div class="details">
      <div class="form-head"><h3>🔎 {e(ship['shipment_id'])} {sample}</h3>
        <p>{status_pill(ship['status'])} &nbsp; Tạo lúc {e(ship['created_at'][:16])} · Cập nhật lúc {e(ship['updated_at'][:16])}</p>
        {shipment_summary_html(ship)}</div>
      {section_title_html('Tiến độ 6 bước chứng từ', '6-step document progress')}
      {shipment_tracker_html(shipment_step_statuses(ship['shipment_id']))}
      <div class="two-col"><div>{section_title_html('Thông tin chung', 'General')}{general}</div>
        <div>{section_title_html('Vận chuyển', 'Transport')}{transport}</div></div>
      {section_title_html('Các bên liên quan', 'Parties')}<div class="parties">{''.join(party_blocks)}</div>
      {section_title_html(f'Hàng hóa — {len(ship["cargo"])} dòng', 'Cargo lines')}{cargo}
      {section_title_html(f'Container — {len(ship["containers"])} chiếc', 'Containers')}{conts}
    </div>"""


def list_table(rows: list[dict]) -> pd.DataFrame:
    data = []
    for r in rows:
        vessel = " / ".join(x for x in (r.get("vessel_name"), r.get("voyage_number")) if x)
        data.append([
            r["shipment_id"], status_label(r["status"]) + (f" · {S.sample_text(r)}" if r["is_sample"] else ""),
            r.get("customer_name") or "", r.get("booking_number") or "", r.get("shipper_name") or "",
            r.get("consignee_name") or "", r.get("port_of_loading") or "", r.get("port_of_discharge") or "",
            vessel, r.get("etd") or "", r["container_count"], (r["updated_at"] or "")[:16],
        ])
    return pd.DataFrame(data, columns=LIST_COLUMNS)


# ---------------------------------------------------------------------------
# Page
# ---------------------------------------------------------------------------
def _field(key: str):
    """A text field, or — for carriers, ports and depots — a pick list from Settings that still accepts typing."""
    if key in reference.FIELD_KINDS:
        return gr.Dropdown(label=FIELD_LABELS[key], choices=reference.choices(reference.FIELD_KINDS[key]),
                           value=None, allow_custom_value=True, info="Chọn từ danh mục (Cài đặt) hoặc gõ mới")
    return gr.Textbox(label=FIELD_LABELS[key])


def build_shipments_page():
    """Build the page. Returns (list inputs, list outputs, refresh function)."""
    current_id = gr.State(None)       # Shipment ID loaded in the form (None = new)
    header_inputs, party_inputs = {}, {}

    gr.HTML(page_title_html("Quản lý lô hàng", "Shipment Management — dữ liệu gốc của từng lô hàng"))
    new_btn = gr.Button("＋ Tạo lô hàng mới", variant="primary", elem_classes="fit-btn")

    with gr.Tabs(selected="list") as tabs:
        # ------------------------------------------------------------ list tab
        with gr.Tab("📋 Danh sách lô hàng", id="list"):
            with gr.Row():
                search = gr.Textbox(label="Tìm kiếm", scale=3,
                                    placeholder="Shipment ID, Booking, Khách hàng, Shipper, Consignee, "
                                                "Container, Seal, Tàu…")
                status_filter = gr.Dropdown(
                    label="Lọc theo trạng thái", scale=1, value="ALL",
                    choices=[("Tất cả", "ALL")] + [(status_label(s), s) for s in S.SHIPMENT_STATUSES])
                etd_from = gr.DateTime(label="ETD từ ngày", include_time=False, type="string", scale=1)
                etd_to = gr.DateTime(label="ETD đến ngày", include_time=False, type="string", scale=1)
            table = gr.Dataframe(value=pd.DataFrame(columns=LIST_COLUMNS), interactive=False,
                                 wrap=True, max_height=420)
            gr.HTML('<div class="hint">👆 Bấm vào một dòng để chọn lô hàng, rồi dùng các nút bên dưới.</div>')
            with gr.Row(equal_height=True):
                picked = gr.Dropdown(label="Lô hàng đang chọn", choices=[], scale=2)
                view_btn = gr.Button("🔎 Xem chi tiết", scale=1)
                edit_btn = gr.Button("✏️ Sửa", scale=1)
                copy_btn = gr.Button("⧉ Sao chép", scale=1)
                delete_btn = gr.Button("🗑 Xóa", variant="stop", scale=1)
            with gr.Group(visible=False) as confirm_box:
                confirm_text = gr.HTML()
                with gr.Row():
                    confirm_yes = gr.Button("Xóa vĩnh viễn", variant="stop")
                    confirm_no = gr.Button("Hủy, không xóa")
            list_msg = gr.HTML()
            details = gr.HTML(details_html(None))

        # ------------------------------------------------------------ form tab
        with gr.Tab("📝 Biểu mẫu lô hàng", id="form"):
            form_title = gr.HTML(form_title_html(None))
            gr.HTML(notice_html(
                "<b>*</b> = cần có để hoàn thành bộ chứng từ, nhưng bạn vẫn có thể <b>lưu nháp</b> khi còn thiếu. "
                "Để lưu được, chỉ cần có <b>Khách hàng</b> hoặc <b>tên Shipper</b>."))
            with gr.Tabs():
                with gr.Tab("1. Thông tin chung"):
                    with gr.Row():
                        header_inputs["status"] = gr.Dropdown(
                            label=FIELD_LABELS["status"], value="Not Started",
                            choices=[(status_label(s), s) for s in S.EDITABLE_STATUSES]
                            + [(status_label("Completed") + " — do hệ thống đặt", "Completed")],
                            info="“Hoàn thành” do hệ thống tự đặt khi đủ 6 chứng từ hợp lệ.")
                        header_inputs["transport_mode"] = gr.Dropdown(
                            label=FIELD_LABELS["transport_mode"], choices=list(S.TRANSPORT_MODES),
                            value=S.TRANSPORT_MODES[0], allow_custom_value=True)
                        header_inputs["export_type"] = gr.Dropdown(
                            label=FIELD_LABELS["export_type"], choices=list(S.EXPORT_TYPES),
                            value=None, allow_custom_value=True)
                    with gr.Row():
                        header_inputs["customer_name"] = gr.Textbox(label=FIELD_LABELS["customer_name"])
                        header_inputs["person_in_charge"] = gr.Textbox(label=FIELD_LABELS["person_in_charge"])
                        header_inputs["contract_reference"] = gr.Textbox(label=FIELD_LABELS["contract_reference"])
                    header_inputs["notes"] = gr.Textbox(label=FIELD_LABELS["notes"], lines=3)

                with gr.Tab("2. Các bên liên quan"):
                    for role, en, vi, show_tax in S.PARTY_ROLES:
                        with gr.Accordion(f"{en} — {vi}", open=role in ("SHIPPER", "CONSIGNEE", "NOTIFY_PARTY")):
                            with gr.Row():
                                name_label = PARTY_FIELD_LABELS["party_name"] + (" *" if role in REQUIRED_PARTIES else "")
                                party_inputs[(role, "party_name")] = gr.Textbox(label=name_label, scale=2)
                                party_inputs[(role, "country")] = gr.Textbox(label=PARTY_FIELD_LABELS["country"])
                                party_inputs[(role, "tax_id")] = gr.Textbox(
                                    label=PARTY_FIELD_LABELS["tax_id"], visible=show_tax)
                            party_inputs[(role, "address")] = gr.Textbox(
                                label=PARTY_FIELD_LABELS["address"], lines=2)
                            with gr.Row():
                                party_inputs[(role, "email")] = gr.Textbox(label=PARTY_FIELD_LABELS["email"])
                                party_inputs[(role, "phone")] = gr.Textbox(label=PARTY_FIELD_LABELS["phone"])

                with gr.Tab("3. Hàng hóa (Cargo)"):
                    gr.HTML(notice_html(
                        "Mỗi dòng là một mặt hàng. Bấm vào ô để sửa. Trọng lượng tính bằng <b>kg</b>, "
                        "thể tích bằng <b>CBM</b>, số thập phân dùng dấu chấm (ví dụ 18500.5). "
                        "Cột <b>ID</b> do hệ thống tạo — để trống với dòng mới."))
                    cargo_df = gr.Dataframe(
                        value=pd.DataFrame(columns=CARGO_HEADERS), headers=CARGO_HEADERS,
                        datatype=CARGO_TYPES, interactive=True, static_columns=[0], wrap=True,
                        column_widths=["60px"] + ["170px"] * len(S.CARGO_COLUMNS))
                    cargo_totals = gr.HTML(cargo_totals_html(None))
                    with gr.Row(equal_height=True):
                        cargo_add = gr.Button("＋ Thêm dòng hàng", scale=1)
                        cargo_del_no = gr.Textbox(label="Số thứ tự dòng cần bỏ", placeholder="VD: 2", scale=1)
                        cargo_del = gr.Button("− Bỏ dòng này", scale=1)

                with gr.Tab("4. Vận chuyển (Transport)"):
                    gr.HTML(section_title_html("Hãng tàu & Booking", "Carrier & booking"))
                    with gr.Row():
                        for key in ("carrier_name", "booking_number", "vessel_name", "voyage_number"):
                            header_inputs[key] = _field(key)
                    gr.HTML(section_title_html("Tuyến đường", "Routing"))
                    with gr.Row():
                        for key in ("place_of_receipt", "port_of_loading", "transshipment_port"):
                            header_inputs[key] = _field(key)
                    with gr.Row():
                        for key in ("port_of_discharge", "place_of_delivery"):
                            header_inputs[key] = _field(key)
                    gr.HTML(section_title_html("Lịch tàu & hạn chót", "Schedule & cut-off"))
                    with gr.Row():
                        for key in ("etd", "eta"):
                            header_inputs[key] = gr.DateTime(label=FIELD_LABELS[key], include_time=False,
                                                             type="string")
                    with gr.Row():
                        for key in ("cy_cutoff", "si_cutoff", "vgm_cutoff"):
                            header_inputs[key] = gr.DateTime(label=FIELD_LABELS[key], include_time=True,
                                                             type="string")
                    gr.HTML(section_title_html("Container rỗng", "Empty container pick-up & return"))
                    with gr.Row():
                        header_inputs["empty_pickup_depot"] = _field("empty_pickup_depot")
                        header_inputs["empty_pickup_date"] = gr.DateTime(
                            label=FIELD_LABELS["empty_pickup_date"], include_time=False, type="string")
                        header_inputs["container_return_depot"] = _field("container_return_depot")

                with gr.Tab("5. Container"):
                    gr.HTML(notice_html(
                        "Mỗi dòng là một container. Có thể để trống <b>Container No.</b> nếu chưa được cấp. "
                        "Size: <b>20 / 40 / 45</b>. Full/Empty: <b>Full</b> hoặc <b>Empty</b>. "
                        f"Loại: {', '.join(S.CONTAINER_TYPES)}. "
                        "Số container được kiểm tra theo chuẩn ISO 6346. "
                        "Cột <b>VGM</b> và <b>EIR No.</b> chỉ xem — sẽ được điền ở Bước 3 và Bước 2. "
                        "<b>Gross Weight</b> ở đây là Tare + Cargo, <b>không phải VGM</b>."))
                    cont_df = gr.Dataframe(
                        value=pd.DataFrame(columns=CONTAINER_HEADERS), headers=CONTAINER_HEADERS,
                        datatype=CONTAINER_TYPES, interactive=True, static_columns=CONTAINER_STATIC,
                        wrap=True, column_widths=["60px"] + ["150px"] * len(S.CONTAINER_COLUMNS))
                    cont_totals = gr.HTML(container_totals_html(None))
                    with gr.Row(equal_height=True):
                        cont_add = gr.Button("＋ Thêm container", scale=1)
                        cont_del_no = gr.Textbox(label="Số thứ tự dòng cần bỏ", placeholder="VD: 2", scale=1)
                        cont_del = gr.Button("− Bỏ dòng này", scale=1)

            test_cb = gr.Checkbox(label="Đánh dấu là lô hàng THỬ (SAMPLE / TEST — mã TEST-…) — chỉ áp dụng khi tạo lô mới",
                                  value=False, info="Dùng để thử app mà không lẫn với lô hàng thật.")
            save_reason = gr.Textbox(label="Lý do thay đổi (ghi vào Lịch sử chứng từ — không bắt buộc)",
                                     placeholder="VD: Khách hàng đổi consignee theo email ngày 20/11")
            form_msg = gr.HTML()
            with gr.Row():
                save_btn = gr.Button("💾 Lưu lô hàng", variant="primary", scale=2)
                back_btn = gr.Button("← Quay lại danh sách", scale=1)
            conflict_outputs, conflict_refresh, _ = build_conflict_panel(current_id)

    header_list = [header_inputs[k] for k in S.HEADER_FIELDS]
    party_list = [party_inputs[k] for k in PARTY_KEYS]
    form_outputs = [current_id, form_title, *header_list, *party_list,
                    cargo_df, cargo_totals, cont_df, cont_totals]

    # ------------------------------------------------------------------ logic
    def fill_form(ship: dict | None) -> list:
        ship = ship or {}
        values = []
        for key in S.HEADER_FIELDS:
            v = ship.get(key)
            if key == "status":
                v = v or "Not Started"
            elif key == "transport_mode" and not ship:
                v = S.TRANSPORT_MODES[0]
            elif key in S.DATETIME_FIELDS and v:
                v = f"{v}:00"
            value = v if v is not None else ("" if key not in S.DATE_FIELDS + S.DATETIME_FIELDS else None)
            if key in reference.FIELD_KINDS:      # pick list from Settings + the value already saved
                value = gr.update(value=v or None, choices=reference.choices(reference.FIELD_KINDS[key], v))
            values.append(value)
        parties = ship.get("parties", {})
        party_values = [(parties.get(role) or {}).get(f) or "" for role, f in PARTY_KEYS]
        cargo = rows_to_frame(ship.get("cargo", []), S.CARGO_COLUMNS, CARGO_HEADERS)
        conts = rows_to_frame(ship.get("containers", []), S.CONTAINER_COLUMNS, CONTAINER_HEADERS)
        return [ship.get("shipment_id"), form_title_html(ship or None), *values, *party_values,
                cargo, cargo_totals_html(cargo), conts, container_totals_html(conts)]

    def refresh_list(term, status, chosen, etd_from=None, etd_to=None):
        rows = S.list_shipments(term, None if status == "ALL" else status, etd_from=(etd_from or "")[:10] or None,
                                etd_to=(etd_to or "")[:10] or None)
        all_ids = [r["shipment_id"] for r in S.list_shipments()]
        choices = [(f"{r['shipment_id']} · {r.get('customer_name') or r.get('shipper_name') or ''}",
                    r["shipment_id"]) for r in rows]
        if chosen and chosen in all_ids and chosen not in [c[1] for c in choices]:
            choices.append((chosen, chosen))      # keep the selection even if filtered out
        value = chosen if chosen in all_ids else None
        return list_table(rows), gr.update(choices=choices, value=value)

    def show_details(chosen):
        return details_html(S.get_shipment(chosen) if chosen else None), gr.update(visible=False)

    def on_row_select(frame, evt: gr.SelectData):
        """Clicking ANY cell of a row selects that shipment (row values, or the row number as a fallback)."""
        row = list(evt.row_value or [])
        if not row and evt.index is not None and frame is not None and len(frame):
            index = evt.index[0] if isinstance(evt.index, (list, tuple)) else evt.index
            if isinstance(index, int) and 0 <= index < len(frame):
                row = list(frame.iloc[index])
        shipment_id = str(row[0]).strip() if row else ""
        return shipment_id or gr.skip()

    def need_pick(chosen):
        return message_html("warning", "Hãy chọn một lô hàng trước (bấm vào dòng trong bảng).") if not chosen else None

    def start_new():
        return [*fill_form(None), message_html("info", "Nhập thông tin lô hàng mới rồi bấm “Lưu lô hàng”."),
                gr.Tabs(selected="form")]

    def start_edit(chosen):
        warn = need_pick(chosen)
        if warn:
            return [gr.skip()] * len(form_outputs) + ["", gr.skip(), warn]
        ship = S.get_shipment(chosen)
        if not ship:
            return [gr.skip()] * len(form_outputs) + ["", gr.skip(),
                                                     message_html("error", f"Không tìm thấy {chosen}.")]
        return [*fill_form(ship), "", gr.Tabs(selected="form"), ""]

    def do_copy(chosen):
        warn = need_pick(chosen)
        if warn:
            return [gr.skip()] * len(form_outputs) + ["", gr.skip(), warn]
        try:
            result = S.copy_shipment(chosen)
        except S.ShipmentError as ex:
            return [gr.skip()] * len(form_outputs) + ["", gr.skip(),
                                                     message_html("error", "Không sao chép được.", ex.errors)]
        msg = message_html(
            "success", f"Đã tạo {result.shipment_id} (bản sao của {chosen}).",
            ["Đã sao chép: thông tin chung, các bên, hàng hóa, tuyến đường, hãng tàu, depot và kích cỡ container.",
             "Hãy nhập cho lô mới: Booking Number, tàu/chuyến, ETD/ETA, cut-off, số container và seal."])
        return [*fill_form(S.get_shipment(result.shipment_id)), msg, gr.Tabs(selected="form"), ""]

    def ask_delete(chosen):
        warn = need_pick(chosen)
        if warn:
            return gr.update(visible=False), "", warn
        ship = S.get_shipment(chosen)
        if not ship:
            return gr.update(visible=False), "", message_html("error", f"Không tìm thấy {chosen}.")
        text = message_html(
            "error", f"Bạn có chắc muốn xóa lô hàng {chosen}?",
            [f"Sẽ xóa cùng lúc: các bên liên quan, {len(ship['cargo'])} dòng hàng và "
             f"{len(ship['containers'])} container.", "Thao tác này không thể hoàn tác."])
        return gr.update(visible=True), text, ""

    def do_delete(chosen, loaded):
        try:
            S.delete_shipment(chosen)
        except S.ShipmentError as ex:
            return [gr.update(visible=False), message_html("error", "Không xóa được.", ex.errors),
                    details_html(None), gr.skip()] + [gr.skip()] * len(form_outputs)
        form = fill_form(None) if loaded == chosen else [gr.skip()] * len(form_outputs)
        return [gr.update(visible=False), message_html("success", f"Đã xóa lô hàng {chosen}."),
                details_html(None), None] + form

    def do_save(loaded, reason, is_test, *values):
        n_h, n_p = len(header_list), len(party_list)
        header = dict(zip(S.HEADER_FIELDS, values[:n_h]))
        parties = {}
        for (role, f), v in zip(PARTY_KEYS, values[n_h:n_h + n_p]):
            parties.setdefault(role, {})[f] = v
        cargo_frame, cont_frame = values[n_h + n_p], values[n_h + n_p + 1]
        try:
            test = bool(is_test) and not loaded         # a TEST shipment: TEST-… ID, marked SAMPLE / TEST
            result = S.save_shipment(loaded, header, parties,
                                     frame_to_rows(cargo_frame, S.CARGO_COLUMNS),
                                     frame_to_rows(cont_frame, S.CONTAINER_COLUMNS), is_sample=test,
                                     sample_label=S.SAMPLE_TEST if test else None,
                                     id_prefix=S.TEST_ID_PREFIX if test else S.ID_PREFIX, reason=reason)
        except S.ShipmentError as ex:
            return [gr.skip()] * len(form_outputs) + [
                message_html("error", "Chưa lưu — vui lòng sửa các lỗi sau:", ex.errors)]
        verb = "Đã tạo" if result.created else "Đã lưu"
        if result.warnings:
            msg = message_html("warning", f"{verb} {result.shipment_id}. Lưu ý các điểm sau "
                               "(vẫn lưu được, nên kiểm tra lại):", result.warnings)
        else:
            msg = message_html("success", f"{verb} {result.shipment_id}. Dữ liệu hợp lệ.")
        return [*fill_form(S.get_shipment(result.shipment_id)), msg]

    # ------------------------------------------------------------------ events
    list_inputs = [search, status_filter, picked, etd_from, etd_to]
    list_outputs = [table, picked]

    search.change(refresh_list, list_inputs, list_outputs)
    status_filter.change(refresh_list, list_inputs, list_outputs)
    etd_from.change(refresh_list, list_inputs, list_outputs)
    etd_to.change(refresh_list, list_inputs, list_outputs)
    table.select(on_row_select, table, picked)
    picked.change(show_details, picked, [details, confirm_box])
    view_btn.click(lambda c: (show_details(c)[0], need_pick(c) or ""), picked, [details, list_msg])

    new_btn.click(start_new, None, [*form_outputs, form_msg, tabs])
    edit_btn.click(start_edit, picked, [*form_outputs, form_msg, tabs, list_msg])
    # After copy/save, refresh the list and select the shipment now open in the form
    select_saved = [search, status_filter, current_id, etd_from, etd_to]
    copy_btn.click(do_copy, picked, [*form_outputs, form_msg, tabs, list_msg]).then(
        refresh_list, select_saved, list_outputs)
    delete_btn.click(ask_delete, picked, [confirm_box, confirm_text, list_msg])
    confirm_no.click(lambda: (gr.update(visible=False), message_html("info", "Đã hủy, không xóa gì.")),
                     None, [confirm_box, list_msg])
    confirm_yes.click(do_delete, [picked, current_id],
                      [confirm_box, list_msg, details, picked, *form_outputs]).then(
        refresh_list, list_inputs, list_outputs)
    back_btn.click(lambda: gr.Tabs(selected="list"), None, tabs).then(refresh_list, list_inputs, list_outputs)

    save_btn.click(do_save, [current_id, save_reason, test_cb, *header_list, *party_list, cargo_df, cont_df],
                   [*form_outputs, form_msg]).then(refresh_list, select_saved, list_outputs).then(
        conflict_refresh, current_id, conflict_outputs)
    current_id.change(conflict_refresh, current_id, conflict_outputs)

    cargo_add.click(lambda f: add_row(f, CARGO_HEADERS), cargo_df, cargo_df)
    cargo_del.click(lambda f, n: remove_row(f, n, CARGO_HEADERS), [cargo_df, cargo_del_no], [cargo_df, form_msg])
    cargo_df.change(cargo_totals_html, cargo_df, cargo_totals)
    cont_add.click(lambda f: add_row(f, CONTAINER_HEADERS), cont_df, cont_df)
    cont_del.click(lambda f, n: remove_row(f, n, CONTAINER_HEADERS), [cont_df, cont_del_no], [cont_df, form_msg])
    cont_df.change(container_totals_html, cont_df, cont_totals)

    return list_inputs, list_outputs, refresh_list
