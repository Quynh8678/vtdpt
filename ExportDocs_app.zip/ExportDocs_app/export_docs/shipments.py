"""Shipment Master Data — business logic (REQUIREMENTS.md §4).

Everything about shipments goes through this file: create, update, list,
search, copy, delete, checks and deadline alerts. The interface (ui_*.py)
never writes SQL itself.

Rules applied here:
- Saving a draft is always allowed; problems are shown as warnings.
  Only real data errors block saving (e.g. negative weight, same container twice).
- The status "Completed" is never set by hand. From Phase 5 the workflow engine
  sets it when all six documents are validated (REQUIREMENTS.md §7).
- VGM and EIR number on a container are filled by Step 3 / Step 2, not here.
"""

import json
import math
import re
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta

from .database import reading, transaction
from .tracking import tracked

# ---------------------------------------------------------------------------
# Business definitions
# ---------------------------------------------------------------------------
SHIPMENT_STATUSES = {            # value (stored) -> Vietnamese label
    "Not Started": "Chưa bắt đầu",     # new shipment, Step 1 not saved yet
    "Draft": "Nháp",
    "In Progress": "Đang xử lý",
    "On Hold": "Tạm giữ",
    "Completed": "Hoàn thành",
    "Cancelled": "Đã hủy",
}
EDITABLE_STATUSES = ("Not Started", "Draft", "In Progress", "On Hold", "Cancelled")
ACTIVE_STATUSES = ("Not Started", "Draft", "In Progress", "On Hold")

TRANSPORT_MODES = ("Sea — FCL (nguyên container)", "Sea — LCL (hàng lẻ)")
EXPORT_TYPES = (
    "Xuất kinh doanh (Commercial export)",
    "Xuất gia công (Processing export)",
    "Xuất sản xuất xuất khẩu (Export production)",
    "Xuất tạm (Temporary export)",
    "Khác (Other)",
)

# (role, English name, Vietnamese name, show tax ID field)
PARTY_ROLES = (
    ("SHIPPER", "Shipper", "Người gửi hàng", True),
    ("CONSIGNEE", "Consignee", "Người nhận hàng", False),
    ("NOTIFY_PARTY", "Notify Party", "Bên nhận thông báo", False),
    ("BOOKING_PARTY", "Booking Party", "Bên đặt chỗ", True),
    ("FORWARDER", "Forwarder", "Đại lý giao nhận (tùy chọn)", True),
    ("FREIGHT_PAYER", "Freight Payer", "Bên thanh toán cước (tùy chọn)", True),
)
PARTY_FIELDS = ("party_name", "address", "country", "tax_id", "email", "phone")

GENERAL_FIELDS = (
    "status", "transport_mode", "export_type", "person_in_charge",
    "customer_name", "contract_reference", "notes",
)
TRANSPORT_FIELDS = (
    "carrier_name", "booking_number", "vessel_name", "voyage_number",
    "place_of_receipt", "port_of_loading", "port_of_discharge", "transshipment_port",
    "place_of_delivery", "etd", "eta", "cy_cutoff", "si_cutoff", "vgm_cutoff",
    "empty_pickup_depot", "empty_pickup_date", "container_return_depot",
)
HEADER_FIELDS = GENERAL_FIELDS + TRANSPORT_FIELDS
DATE_FIELDS = ("etd", "eta", "empty_pickup_date")
DATETIME_FIELDS = ("cy_cutoff", "si_cutoff", "vgm_cutoff")
CUTOFF_LABELS = {"cy_cutoff": "CY cut-off", "si_cutoff": "SI cut-off", "vgm_cutoff": "VGM cut-off"}


@dataclass(frozen=True)
class Column:
    key: str
    header: str
    kind: str = "text"     # text | number | integer
    locked: bool = False   # filled by a later step, not editable here


# Table columns, in display order. "id" is the internal row ID (read-only).
CARGO_COLUMNS = (
    Column("commodity", "Tên hàng (Commodity)"),
    Column("cargo_description", "Mô tả hàng — EN (Description of Goods)"),
    Column("hs_code", "HS Code"),
    Column("quantity", "Số lượng (Quantity)", "number"),
    Column("quantity_unit", "Đơn vị (Unit)"),
    Column("package_count", "Số kiện (Packages)", "integer"),
    Column("package_type", "Loại kiện (Package type)"),
    Column("gross_weight_kg", "Gross Weight (kg)", "number"),
    Column("net_weight_kg", "Net Weight (kg)", "number"),
    Column("volume_cbm", "Measurement (CBM)", "number"),
    Column("marks_and_numbers", "Marks & Numbers"),
    Column("storage_conditions", "Điều kiện bảo quản"),
    Column("dangerous_goods_info", "Hàng nguy hiểm / đặc biệt"),
)
CONTAINER_COLUMNS = (
    Column("container_number", "Container No."),
    Column("container_size", "Size (20/40/45)"),
    Column("iso_type_code", "ISO Type"),
    Column("container_type", "Loại cont (Type)"),
    Column("load_status", "Full/Empty"),
    Column("tare_weight_kg", "Tare (kg)", "number"),
    Column("cargo_weight_kg", "Cargo Weight (kg)", "number"),
    Column("gross_weight_kg", "Gross Weight (kg)", "number"),
    Column("max_gross_kg", "Max Gross — CSC plate (kg)", "number"),
    Column("seal_number", "Seal No."),
    Column("truck_number", "Số xe (Truck No.)"),
    Column("chassis_number", "Số rơ-moóc (Chassis No.)"),
    Column("notes", "Ghi chú"),
    Column("vgm_kg", "VGM (kg) — Bước 3", "number", locked=True),
    Column("eir_number", "EIR No. — Bước 2", locked=True),
)
CONTAINER_SIZES = ("20", "40", "45")
CONTAINER_TYPES = ("Dry", "High Cube", "Reefer", "Open Top", "Flat Rack", "Tank")


class ShipmentError(Exception):
    """Data errors that block saving. `errors` is a list of Vietnamese messages."""

    def __init__(self, errors: list[str]):
        super().__init__("; ".join(errors))
        self.errors = errors


@dataclass
class SaveResult:
    shipment_id: str
    created: bool
    warnings: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------
def now_text() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def is_blank(value) -> bool:
    if value is None:
        return True
    if isinstance(value, float) and math.isnan(value):
        return True
    return isinstance(value, str) and value.strip() == ""


def clean_text(value) -> str | None:
    if is_blank(value):
        return None
    text = str(value).strip()
    # numbers typed into text cells come back as 123.0 — keep them tidy
    if isinstance(value, float) and value.is_integer():
        text = str(int(value))
    return text


def parse_number(value, label: str, errors: list[str], integer: bool = False):
    if is_blank(value):
        return None
    if isinstance(value, (int, float)):
        number = float(value)
    else:
        text = str(value).strip().replace(" ", "")
        if re.fullmatch(r"\d{1,3}(,\d{3})+(\.\d+)?", text):   # 1,234.5 → thousands separator
            text = text.replace(",", "")
        try:
            number = float(text)
        except ValueError:
            errors.append(f"{label}: “{value}” không phải là số (dùng dấu chấm cho số thập phân).")
            return None
    if number < 0:
        errors.append(f"{label}: không được là số âm.")
        return None
    if integer:
        if not number.is_integer():
            errors.append(f"{label}: phải là số nguyên.")
            return None
        return int(number)
    return round(number, 3)


_DATE_INPUT_FORMATS = ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M:%S",
                       "%Y-%m-%dT%H:%M", "%Y-%m-%d", "%d/%m/%Y %H:%M", "%d/%m/%Y")


def parse_when(value, with_time: bool, label: str, errors: list[str]) -> str | None:
    """Accept a date/date-time from the date picker or typed text; store ISO text."""
    if is_blank(value):
        return None
    if isinstance(value, (int, float)):
        parsed = datetime.fromtimestamp(value)
    elif isinstance(value, datetime):
        parsed = value
    else:
        text = str(value).strip()
        parsed = None
        for fmt in _DATE_INPUT_FORMATS:
            try:
                parsed = datetime.strptime(text, fmt)
                break
            except ValueError:
                continue
        if parsed is None:
            errors.append(f"{label}: “{value}” không đúng định dạng ngày (YYYY-MM-DD).")
            return None
    return parsed.strftime("%Y-%m-%d %H:%M" if with_time else "%Y-%m-%d")


def to_datetime(text: str | None) -> datetime | None:
    if not text:
        return None
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            pass
    return None


# ---- Container number (ISO 6346) -------------------------------------------
def _iso6346_letter_values() -> dict[str, int]:
    values, n = {}, 10
    for letter in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
        if n % 11 == 0:      # 11, 22, 33 are skipped by the standard
            n += 1
        values[letter] = n
        n += 1
    return values


_LETTER_VALUES = _iso6346_letter_values()


def iso6346_check_digit(first_ten: str) -> int:
    """Check digit for the first 10 characters (4 letters + 6 digits)."""
    total = 0
    for i, ch in enumerate(first_ten):
        value = _LETTER_VALUES[ch] if ch.isalpha() else int(ch)
        total += value * (2 ** i)
    return total % 11 % 10


def normalize_container_number(value) -> str | None:
    text = clean_text(value)
    if not text:
        return None
    return re.sub(r"[\s\-./]", "", text).upper()


def container_number_problem(number: str) -> str | None:
    """None if the number is a valid ISO 6346 container number, else a message."""
    if not re.fullmatch(r"[A-Z]{3}[UJZ]\d{7}", number):
        return "không đúng định dạng ISO 6346 (4 chữ cái, chữ thứ 4 là U/J/Z, + 7 chữ số)"
    if iso6346_check_digit(number[:10]) != int(number[10]):
        expected = iso6346_check_digit(number[:10])
        return f"số kiểm tra (check digit) sai — chữ số cuối phải là {expected}"
    return None


# ---------------------------------------------------------------------------
# Validation of a whole shipment before saving
# ---------------------------------------------------------------------------
def _normalize_rows(rows, columns, kind_label, errors):
    """Turn raw table rows into clean dicts; drop completely empty rows."""
    cleaned = []
    for index, raw in enumerate(rows or [], start=1):
        row_id = raw.get("id")
        row_id = None if is_blank(row_id) else int(float(row_id))
        values = {}
        for col in columns:
            if col.locked:
                continue
            label = f"{kind_label} dòng {index} — {col.header}"
            raw_value = raw.get(col.key)
            if col.kind == "number":
                values[col.key] = parse_number(raw_value, label, errors)
            elif col.kind == "integer":
                values[col.key] = parse_number(raw_value, label, errors, integer=True)
            else:
                values[col.key] = clean_text(raw_value)
        if all(v is None for v in values.values()):
            continue   # empty row → ignored (or removed if it existed)
        values["id"] = row_id
        values["_row"] = index
        cleaned.append(values)
    return cleaned


def clean_header_values(values: dict, keys, errors: list[str]) -> dict:
    """Clean the given shipment-level fields (text, dates, date-times)."""
    clean = {}
    for key in keys:
        value = values.get(key)
        if key in DATE_FIELDS:
            clean[key] = parse_when(value, False, key.upper(), errors)
        elif key in DATETIME_FIELDS:
            clean[key] = parse_when(value, True, CUTOFF_LABELS[key], errors)
        else:
            clean[key] = clean_text(value)
    return clean


def schedule_warnings(header: dict) -> list[str]:
    """ETA before ETD, or a cut-off after ETD."""
    warnings = []
    etd, eta = to_datetime(header.get("etd")), to_datetime(header.get("eta"))
    if etd and eta and eta < etd:
        warnings.append("ETA đang sớm hơn ETD — kiểm tra lại ngày.")
    if etd:
        for key, label in CUTOFF_LABELS.items():
            cutoff = to_datetime(header.get(key))
            if cutoff and cutoff.date() > etd.date():
                warnings.append(f"{label} ({header[key]}) đang sau ngày ETD ({header['etd']}).")
    return warnings


def booking_number_duplicates(conn, booking_number: str | None, fk: int) -> list[str]:
    """Warn when the same booking number is used by another (not cancelled) shipment."""
    if not booking_number:
        return []
    others = conn.execute(
        "SELECT shipment_id FROM shipments WHERE booking_number = ? AND id != ? AND status != 'Cancelled'",
        (booking_number, fk)).fetchall()
    if not others:
        return []
    ids = ", ".join(r["shipment_id"] for r in others)
    return [f"Booking Number {booking_number} đã được dùng ở lô hàng: {ids}."]


def _validate(header, parties, cargo, containers, errors, warnings):
    # --- general ---
    status = header.get("status") or "Not Started"
    if status not in EDITABLE_STATUSES:
        errors.append(f"Trạng thái “{status}” không hợp lệ. "
                      "Trạng thái Hoàn thành chỉ được hệ thống đặt khi đủ 6 chứng từ.")
    shipper_name = (parties.get("SHIPPER") or {}).get("party_name")
    if not header.get("customer_name") and not shipper_name:
        errors.append("Cần nhập ít nhất Khách hàng (Customer) hoặc tên Shipper.")

    # --- missing key data (warnings only: drafts can still be saved) ---
    for role, label in (("SHIPPER", "Shipper"), ("CONSIGNEE", "Consignee")):
        if not (parties.get(role) or {}).get("party_name"):
            warnings.append(f"Chưa có tên {label}.")
    for key, label in (("carrier_name", "Carrier"), ("port_of_loading", "POL"),
                       ("port_of_discharge", "POD")):
        if not header.get(key):
            warnings.append(f"Chưa có {label}.")
    if not cargo:
        warnings.append("Chưa có dòng hàng hóa nào (Cargo).")
    if not containers:
        warnings.append("Chưa có container nào.")

    # --- dates ---
    warnings.extend(schedule_warnings(header))

    # --- cargo lines ---
    for line in cargo:
        gw, nw = line.get("gross_weight_kg"), line.get("net_weight_kg")
        if gw is not None and nw is not None and nw > gw:
            warnings.append(f"Cargo dòng {line['_row']}: Net Weight lớn hơn Gross Weight.")
        if not line.get("cargo_description"):
            warnings.append(f"Cargo dòng {line['_row']}: chưa có mô tả hàng tiếng Anh.")

    # --- containers ---
    seen = {}
    for c in containers:
        row = c["_row"]
        number = normalize_container_number(c.get("container_number"))
        c["container_number"] = number
        if number:
            if number in seen:
                errors.append(f"Container {number} bị nhập 2 lần (dòng {seen[number]} và {row}).")
            seen[number] = row
            problem = container_number_problem(number)
            if problem:
                warnings.append(f"Container dòng {row} ({number}): {problem}.")
        size = clean_text(c.get("container_size"))
        if size:
            size = re.sub(r"(?i)\s*(ft|feet|'|’)$", "", size)
            if size not in CONTAINER_SIZES:
                errors.append(f"Container dòng {row}: Size phải là 20, 40 hoặc 45.")
            c["container_size"] = size
        status_text = (c.get("load_status") or "").strip().lower()
        if status_text:
            if status_text in ("full", "f", "đầy", "hàng"):
                c["load_status"] = "Full"
            elif status_text in ("empty", "e", "rỗng"):
                c["load_status"] = "Empty"
            else:
                errors.append(f"Container dòng {row}: Full/Empty phải là “Full” hoặc “Empty”.")
        if c.get("iso_type_code"):
            c["iso_type_code"] = c["iso_type_code"].upper()
        tare, cargo_w, gross = c.get("tare_weight_kg"), c.get("cargo_weight_kg"), c.get("gross_weight_kg")
        if gross is not None and cargo_w is not None and gross < cargo_w:
            warnings.append(f"Container dòng {row}: Gross Weight nhỏ hơn Cargo Weight.")
        if None not in (tare, cargo_w, gross) and abs(tare + cargo_w - gross) > 1:
            warnings.append(
                f"Container dòng {row}: Gross Weight ({gross:,.0f}) ≠ Tare + Cargo "
                f"({tare + cargo_w:,.0f}). Lưu ý: đây chưa phải VGM.")


# ---------------------------------------------------------------------------
# Create / update
# ---------------------------------------------------------------------------
def get_shipment_fk(conn, shipment_id: str) -> int:
    row = conn.execute("SELECT id FROM shipments WHERE shipment_id = ?", (shipment_id,)).fetchone()
    if not row:
        raise ShipmentError([f"Không tìm thấy lô hàng {shipment_id} (có thể đã bị xóa)."])
    return row["id"]


SAMPLE_DEMO = "SAMPLE / DEMO"
SAMPLE_TEST = "SAMPLE / TEST"
ID_PREFIX = "SHP"          # real and demo shipments
TEST_ID_PREFIX = "TEST"    # automated test shipments → TEST-2026-0001 (never collides with SHP-…)


def sample_text(ship: dict) -> str | None:
    """'SAMPLE / DEMO', 'SAMPLE / TEST', or None for real data."""
    if not ship.get("is_sample"):
        return None
    return ship.get("sample_label") or SAMPLE_DEMO


def _next_shipment_id(conn, id_prefix: str = ID_PREFIX) -> str:
    prefix = f"{id_prefix}-{date.today().year}-"
    row = conn.execute(
        "SELECT shipment_id FROM shipments WHERE shipment_id LIKE ? "
        "ORDER BY shipment_id DESC LIMIT 1", (prefix + "%",)).fetchone()
    last = int(row["shipment_id"].rsplit("-", 1)[1]) if row else 0
    return f"{prefix}{last + 1:04d}"


@tracked("SHIPMENT")
def save_shipment(shipment_id: str | None, header: dict, parties: dict,
                  cargo_rows: list[dict], container_rows: list[dict],
                  is_sample: bool = False, sample_label: str | None = None,
                  id_prefix: str = ID_PREFIX) -> SaveResult:
    """Create (shipment_id=None) or update a shipment with all its parts.

    is_sample / sample_label / id_prefix only apply when creating.
    Raises ShipmentError if the data has errors that must be fixed first.
    """
    if not re.fullmatch(r"[A-Z]{2,6}", id_prefix):
        raise ShipmentError([f"ID prefix “{id_prefix}” không hợp lệ."])
    if is_sample and not sample_label:
        sample_label = SAMPLE_DEMO
    errors, warnings = [], []

    clean = clean_header_values(header, HEADER_FIELDS, errors)
    clean["status"] = clean["status"] or "Not Started"
    if clean["status"] == "Completed":
        # "Completed" is set only by the workflow engine; it is checked again right after saving
        clean["status"] = "In Progress"
    clean_parties = {
        role: {f: clean_text((parties.get(role) or {}).get(f)) for f in PARTY_FIELDS}
        for role, *_ in PARTY_ROLES
    }
    cargo = _normalize_rows(cargo_rows, CARGO_COLUMNS, "Cargo", errors)
    containers = _normalize_rows(container_rows, CONTAINER_COLUMNS, "Container", errors)
    _validate(clean, clean_parties, cargo, containers, errors, warnings)
    if errors:
        raise ShipmentError(errors)

    with transaction() as conn:
        created = shipment_id is None
        stamp = now_text()
        if created:
            shipment_id = _next_shipment_id(conn, id_prefix)
            cols = ["shipment_id", "is_sample", "sample_label", "created_at", "updated_at", *HEADER_FIELDS]
            vals = [shipment_id, int(is_sample), sample_label if is_sample else None, stamp, stamp,
                    *(clean[k] for k in HEADER_FIELDS)]
            cur = conn.execute(
                f"INSERT INTO shipments ({', '.join(cols)}) VALUES ({', '.join('?' * len(cols))})", vals)
            fk = cur.lastrowid
        else:
            row = conn.execute("SELECT id FROM shipments WHERE shipment_id = ?", (shipment_id,)).fetchone()
            if not row:
                raise ShipmentError([f"Không tìm thấy lô hàng {shipment_id} (có thể đã bị xóa)."])
            fk = row["id"]
            sets = ", ".join(f"{k} = ?" for k in HEADER_FIELDS)
            conn.execute(f"UPDATE shipments SET {sets}, updated_at = ? WHERE id = ?",
                         [*(clean[k] for k in HEADER_FIELDS), stamp, fk])

        # parties: one row per role
        for role, values in clean_parties.items():
            conn.execute(
                f"INSERT INTO shipment_parties (shipment_fk, party_role, {', '.join(PARTY_FIELDS)}) "
                f"VALUES (?, ?, {', '.join('?' * len(PARTY_FIELDS))}) "
                f"ON CONFLICT(shipment_fk, party_role) DO UPDATE SET "
                + ", ".join(f"{f} = excluded.{f}" for f in PARTY_FIELDS),
                [fk, role, *(values[f] for f in PARTY_FIELDS)])

        # cargo lines and containers keep their row IDs (later documents link to them)
        cargo_keys = [c.key for c in CARGO_COLUMNS]
        for n, line in enumerate(cargo, start=1):
            line["line_number"] = n
        _sync_rows(conn, "shipment_cargo", fk, cargo, cargo_keys + ["line_number"])
        editable_container_keys = [c.key for c in CONTAINER_COLUMNS if not c.locked]
        _sync_rows(conn, "containers", fk, containers, editable_container_keys)

        # duplicate checks against other shipments (warnings)
        for c in containers:
            if c.get("container_number"):
                others = conn.execute(
                    "SELECT DISTINCT s.shipment_id FROM containers c JOIN shipments s ON s.id = c.shipment_fk "
                    "WHERE c.container_number = ? AND s.id != ? AND s.status IN (" + ",".join("?" * len(ACTIVE_STATUSES)) + ")",
                    (c["container_number"], fk, *ACTIVE_STATUSES)).fetchall()
                if others:
                    ids = ", ".join(r["shipment_id"] for r in others)
                    warnings.append(f"Container {c['container_number']} cũng có trong lô hàng đang xử lý: {ids}.")
        warnings.extend(booking_number_duplicates(conn, clean.get("booking_number"), fk))

    return SaveResult(shipment_id=shipment_id, created=created, warnings=warnings)


def _sync_rows(conn, table: str, fk: int, rows: list[dict], keys: list[str]) -> None:
    """Update existing rows (by id), insert new ones, delete rows the user removed."""
    existing = {r["id"] for r in conn.execute(f"SELECT id FROM {table} WHERE shipment_fk = ?", (fk,))}
    kept = set()
    for row in rows:
        values = [row.get(k) for k in keys]
        if row.get("id") in existing:
            conn.execute(f"UPDATE {table} SET {', '.join(f'{k} = ?' for k in keys)} WHERE id = ?",
                         [*values, row["id"]])
            kept.add(row["id"])
        else:
            conn.execute(f"INSERT INTO {table} (shipment_fk, {', '.join(keys)}) "
                         f"VALUES (?, {', '.join('?' * len(keys))})", [fk, *values])
    removed = existing - kept
    if table == "containers" and removed:
        # A container with an EIR (Step 2) must not disappear silently with its document.
        marks = ",".join("?" * len(removed))
        with_eir = conn.execute(
            f"SELECT COALESCE(c.container_number, e.internal_reference) FROM eir_records e "
            f"JOIN containers c ON c.id = e.container_fk WHERE e.container_fk IN ({marks})",
            list(removed)).fetchall()
        if with_eir:
            names = ", ".join(r[0] for r in with_eir)
            raise ShipmentError([f"Không thể bỏ container đã có EIR (Bước 2): {names}. "
                                 "Giữ lại dòng container này, hoặc xóa EIR ở Bước 2 trước."])
        with_vgm = conn.execute(
            f"SELECT COALESCE(c.container_number, v.vgm_reference) FROM vgm_records v "
            f"JOIN containers c ON c.id = v.container_fk WHERE v.container_fk IN ({marks})",
            list(removed)).fetchall()
        if with_vgm:
            names = ", ".join(r[0] for r in with_vgm)
            raise ShipmentError([f"Không thể bỏ container đã có VGM (Bước 3): {names}. "
                                 "Giữ lại dòng container này, hoặc xóa VGM ở Bước 3 trước."])
        with_gatein = conn.execute(
            f"SELECT DISTINCT COALESCE(c.container_number, '#' || c.id) FROM containers c WHERE c.id IN ({marks}) AND "
            f"(EXISTS (SELECT 1 FROM gatein_records g WHERE g.container_fk = c.id) OR "
            f"EXISTS (SELECT 1 FROM gatein_status_events s WHERE s.container_fk = c.id))",
            list(removed)).fetchall()
        if with_gatein:
            names = ", ".join(r[0] for r in with_gatein)
            raise ShipmentError([f"Không thể bỏ container đã có dữ liệu cảng (Bước 5): {names}. "
                                 "Dữ liệu gate-in / trạng thái phải được giữ lại."])
    for row_id in removed:
        conn.execute(f"DELETE FROM {table} WHERE id = ?", (row_id,))


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------
def get_shipment(shipment_id: str, for_doc: str | None = None) -> dict | None:
    """Full shipment: header fields + parties + cargo lines + containers.

    for_doc="SI": the values as that document shows them — where the document keeps its own value
    (e.g. the consignee already submitted to the carrier, see sync.py) that value is used.
    data["overrides"] lists those fields.
    """
    with reading() as conn:
        row = conn.execute("SELECT * FROM shipments WHERE shipment_id = ?", (shipment_id,)).fetchone()
        if not row:
            return None
        data = dict(row)
        fk = row["id"]
        data["parties"] = {r["party_role"]: dict(r) for r in conn.execute(
            "SELECT * FROM shipment_parties WHERE shipment_fk = ?", (fk,))}
        data["cargo"] = [dict(r) for r in conn.execute(
            "SELECT * FROM shipment_cargo WHERE shipment_fk = ? ORDER BY line_number, id", (fk,))]
        data["containers"] = [dict(r) for r in conn.execute(
            "SELECT * FROM containers WHERE shipment_fk = ? ORDER BY id", (fk,))]
        data["overrides"] = {}
        if for_doc:
            for r in conn.execute("SELECT field_key, value, note FROM doc_overrides WHERE shipment_fk = ? AND doc_type = ?",
                                  (fk, for_doc)):
                value = json.loads(r["value"])
                data["overrides"][r["field_key"]] = {"value": value, "note": r["note"],
                                                     "central": None}
                if r["field_key"].startswith("party:"):
                    role = r["field_key"][6:]
                    data["overrides"][r["field_key"]]["central"] = dict(data["parties"].get(role) or {})
                    data["parties"][role] = {**(data["parties"].get(role) or {}), **(value or {}), "party_role": role}
                else:
                    data["overrides"][r["field_key"]]["central"] = data.get(r["field_key"])
                    data[r["field_key"]] = value
    return data


# ---------------------------------------------------------------------------
# Small central updates (Validation Center "apply this value", sync choices) — logged like every save
# ---------------------------------------------------------------------------
def write_central(shipment_id: str, values: dict) -> None:
    """values: shipment header fields and/or "party:ROLE" → {party fields}. Not logged — use update_central()."""
    header = {k: v for k, v in values.items() if k in HEADER_FIELDS}
    errors = []
    clean = clean_header_values(header, header.keys(), errors)
    if errors:
        raise ShipmentError(errors)
    with transaction() as conn:
        fk = get_shipment_fk(conn, shipment_id)
        if clean:
            conn.execute(f"UPDATE shipments SET {', '.join(f'{k} = ?' for k in clean)}, updated_at = ? WHERE id = ?",
                         [*clean.values(), now_text(), fk])
        for key, value in values.items():
            if key.startswith("party:"):
                role = key[6:]
                p = {f: clean_text((value or {}).get(f)) for f in PARTY_FIELDS}
                conn.execute(f"INSERT INTO shipment_parties (shipment_fk, party_role, {', '.join(PARTY_FIELDS)}) "
                             f"VALUES (?, ?, {', '.join('?' * len(PARTY_FIELDS))}) ON CONFLICT(shipment_fk, party_role) "
                             "DO UPDATE SET " + ", ".join(f"{f} = excluded.{f}" for f in PARTY_FIELDS),
                             [fk, role, *(p[f] for f in PARTY_FIELDS)])


@tracked("SHIPMENT")
def update_central(shipment_id: str, values: dict) -> None:
    write_central(shipment_id, values)


@tracked("SHIPMENT")
def update_rows(shipment_id: str, containers: dict | None = None, cargo: dict | None = None) -> None:
    """containers / cargo: {row id: {column: value}} — e.g. cargo weights chosen in the Validation Center."""
    allowed_c = {c.key for c in CONTAINER_COLUMNS if not c.locked}
    allowed_l = {c.key for c in CARGO_COLUMNS}
    with transaction() as conn:
        fk = get_shipment_fk(conn, shipment_id)
        for table, rows, allowed in (("containers", containers, allowed_c), ("shipment_cargo", cargo, allowed_l)):
            for row_id, values in (rows or {}).items():
                bad = set(values) - allowed
                if bad:
                    raise ShipmentError([f"Không sửa được cột: {', '.join(sorted(bad))}."])
                cur = conn.execute(f"UPDATE {table} SET {', '.join(f'{k} = ?' for k in values)} "
                                   f"WHERE id = ? AND shipment_fk = ?", [*values.values(), row_id, fk])
                if cur.rowcount != 1:
                    raise ShipmentError(["Dòng dữ liệu không thuộc lô hàng này."])
        conn.execute("UPDATE shipments SET updated_at = ? WHERE id = ?", (now_text(), fk))


_LIST_SQL = """
SELECT s.shipment_id, s.status, s.is_sample, s.sample_label, s.customer_name, s.booking_number,
       s.port_of_loading, s.port_of_discharge, s.vessel_name, s.voyage_number, s.etd,
       s.cy_cutoff, s.si_cutoff, s.vgm_cutoff, s.updated_at,
       sh.party_name AS shipper_name, cn.party_name AS consignee_name,
       (SELECT COUNT(*) FROM containers c WHERE c.shipment_fk = s.id) AS container_count
FROM shipments s
LEFT JOIN shipment_parties sh ON sh.shipment_fk = s.id AND sh.party_role = 'SHIPPER'
LEFT JOIN shipment_parties cn ON cn.shipment_fk = s.id AND cn.party_role = 'CONSIGNEE'
"""


def list_shipments(search: str = "", status: str | None = None, limit: int | None = None,
                   etd_from: str | None = None, etd_to: str | None = None) -> list[dict]:
    """Shipments, newest change first.

    `search` looks in Shipment ID, booking, customer, parties, vessel / voyage, ports, container and seal
    numbers; `status` and an ETD range (YYYY-MM-DD, both ends included) filter the list.
    """
    where, params = [], []
    if status and status in SHIPMENT_STATUSES:
        where.append("s.status = ?")
        params.append(status)
    if etd_from:
        where.append("s.etd >= ?")
        params.append(etd_from[:10])
    if etd_to:
        where.append("s.etd <= ?")
        params.append(etd_to[:10])
    term = (search or "").strip()
    if term:
        like = f"%{term}%"
        where.append(
            "(s.shipment_id LIKE ? OR s.booking_number LIKE ? OR s.customer_name LIKE ? "
            "OR s.vessel_name LIKE ? OR s.voyage_number LIKE ? OR s.port_of_loading LIKE ? "
            "OR s.port_of_discharge LIKE ? "
            "OR EXISTS (SELECT 1 FROM shipment_parties p WHERE p.shipment_fk = s.id AND p.party_name LIKE ?) "
            "OR EXISTS (SELECT 1 FROM containers c WHERE c.shipment_fk = s.id "
            "           AND (c.container_number LIKE ? OR c.seal_number LIKE ?)))")
        params += [like] * 10
    sql = _LIST_SQL + (" WHERE " + " AND ".join(where) if where else "") + " ORDER BY s.updated_at DESC, s.id DESC"
    if limit:
        sql += f" LIMIT {int(limit)}"
    with reading() as conn:
        return [dict(r) for r in conn.execute(sql, params)]


# ---------------------------------------------------------------------------
# The shipment the user opened last (pages default to it)
# ---------------------------------------------------------------------------
DEMO_SHIPMENT_ID = "SHP-2026-0001"


def remember_opened(shipment_id: str | None) -> None:
    if shipment_id:
        from .database import set_meta
        set_meta("last_opened_shipment", shipment_id)


def default_shipment(ids: list[str]) -> str | None:
    """The most recently opened shipment, else the demo SHP-2026-0001, else the first one."""
    from .database import get_meta
    last = get_meta("last_opened_shipment")
    for candidate in (last, DEMO_SHIPMENT_ID):
        if candidate in ids:
            return candidate
    return ids[0] if ids else None


# ---------------------------------------------------------------------------
# Copy / delete
# ---------------------------------------------------------------------------
# Fields that belong to one specific sailing and must not be copied
_NOT_COPIED = ("booking_number", "vessel_name", "voyage_number", "etd", "eta",
               "cy_cutoff", "si_cutoff", "vgm_cutoff", "empty_pickup_date")


def copy_shipment(shipment_id: str) -> SaveResult:
    """Duplicate a shipment as a new Draft.

    Copied: general info, parties, cargo lines, routing, carrier, depots, and the
    container plan (size/type only). Not copied: booking number, vessel/voyage,
    dates, cut-offs, and container numbers/seals/weights (they are unique to one sailing).
    """
    source = get_shipment(shipment_id)
    if not source:
        raise ShipmentError([f"Không tìm thấy lô hàng {shipment_id}."])
    header = {k: source.get(k) for k in HEADER_FIELDS}
    for key in _NOT_COPIED:
        header[key] = None
    header["status"] = "Not Started"
    note = f"Sao chép từ {shipment_id}."
    header["notes"] = f"{note}\n{source['notes']}" if source.get("notes") else note
    cargo = [{k: line.get(k) for k in (c.key for c in CARGO_COLUMNS)} for line in source["cargo"]]
    containers = [{k: c.get(k) for k in ("container_size", "iso_type_code", "container_type")}
                  for c in source["containers"]]
    return save_shipment(None, header, source["parties"], cargo, containers,
                         is_sample=bool(source["is_sample"]), sample_label=source.get("sample_label"),
                         id_prefix=shipment_id.split("-", 1)[0], reason=note)


def delete_shipment(shipment_id: str) -> None:
    with transaction() as conn:
        cur = conn.execute("DELETE FROM shipments WHERE shipment_id = ?", (shipment_id,))
        if cur.rowcount == 0:
            raise ShipmentError([f"Không tìm thấy lô hàng {shipment_id}."])
    from .history import log_event          # the activity log keeps the deletion (REQUIREMENTS.md §8)
    log_event(shipment_id, "SHIPMENT", "Lô hàng", shipment_id, None, "DELETE",
              "Đã xóa lô hàng và toàn bộ chứng từ của lô hàng")


# ---------------------------------------------------------------------------
# Deadline alerts (used by the dashboard, see workflow.py)
# ---------------------------------------------------------------------------
DEADLINE_WINDOW_HOURS = 72


def deadline_alerts(rows: list[dict], now: datetime | None = None) -> list[dict]:
    """Cut-offs that are overdue or due within 72 hours, for active shipments
    whose vessel has not left yet."""
    now = now or datetime.now()
    alerts = []
    for r in rows:
        if r["status"] not in ACTIVE_STATUSES:
            continue
        etd = to_datetime(r.get("etd"))
        if etd and etd.date() < now.date():
            continue
        for key, label in CUTOFF_LABELS.items():
            cutoff = to_datetime(r.get(key))
            if cutoff and cutoff <= now + timedelta(hours=DEADLINE_WINDOW_HOURS):
                alerts.append({
                    "shipment_id": r["shipment_id"], "booking_number": r.get("booking_number"),
                    "label": label, "cutoff": r[key], "overdue": cutoff < now,
                    "hours_left": (cutoff - now).total_seconds() / 3600,
                })
    return sorted(alerts, key=lambda a: a["hours_left"])
