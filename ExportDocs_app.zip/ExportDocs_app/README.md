# EXPORT DOCS MANAGEMENT

**Phiên bản / Version:** xem file [VERSION](VERSION) (hiện tại / currently **1.0.1**)

🇻🇳 [Tiếng Việt](#tiếng-việt) · 🇬🇧 [English](#english)

---

## Tiếng Việt

### Ứng dụng này là gì?

**EXPORT DOCS MANAGEMENT** là hệ thống quản lý bộ chứng từ xuất khẩu container, chạy trên trình duyệt. Mỗi lô hàng
được nhập **một lần** (dữ liệu gốc), rồi dùng cho cả 6 bước chứng từ:

1. Booking Confirmation (xác nhận đặt chỗ)
2. Empty Container EIR (phiếu giao nhận container rỗng)
3. VGM Declaration (khai báo khối lượng toàn bộ container)
4. Shipping Instruction — SI (hướng dẫn làm vận đơn)
5. Export Gate-in & Loading Registration (hạ bãi và đăng ký xuất tàu)
6. Bill of Lading — B/L (vận đơn)

Ngoài ra còn có:
- kiểm tra chéo dữ liệu giữa các chứng từ (Trung tâm kiểm tra)
- lịch sử và phiên bản của mọi chứng từ
- xuất PDF (từng chứng từ, gộp một file, ZIP, JSON)
- thư viện chứng từ, tải file lên
- sao lưu và khôi phục

PDF có phông chữ tiếng Việt (Noto Sans, kèm sẵn).

Ứng dụng **không tự tạo** số booking, số EIR của depot, số B/L, chữ ký hay con dấu. Những số đó phải lấy từ chứng từ
thật của hãng tàu, cảng hoặc depot. Dữ liệu mẫu luôn được ghi rõ **SAMPLE / DEMO**.

### Chạy trên máy tính (Windows)

**Cần:** Python **3.12** (đã kiểm tra với 3.12; dùng được 3.11–3.13), tải tại <https://www.python.org/downloads/>.
Khi cài, đánh dấu ô *“Add python.exe to PATH”*.

**Giải nén vào một thư mục có đường dẫn ngắn**, ví dụ `C:\ExportDocs`. Windows giới hạn độ dài đường dẫn file
(260 ký tự), nên cài thư viện trong một thư mục quá sâu có thể báo lỗi *“No such file or directory”*.

Mở **PowerShell** trong thư mục đã giải nén (thư mục có file `app.py`), rồi chạy:

```powershell
# 1. Tạo môi trường ảo (chỉ làm một lần)
py -3.12 -m venv .venv

# 2. Cài thư viện (chỉ làm một lần, khoảng 1–3 phút)
.venv\Scripts\python.exe -m pip install -r requirements.txt

# 3. Chạy ứng dụng (mỗi lần dùng)
.venv\Scripts\python.exe app.py
```

Sau đó mở trình duyệt tại **http://127.0.0.1:7860**. Dừng ứng dụng: bấm `Ctrl+C` trong cửa sổ PowerShell.

- Lần chạy đầu tiên, ứng dụng tự tạo cơ sở dữ liệu và một lô hàng mẫu **SHP-2026-0001** (SAMPLE / DEMO).
  Muốn bắt đầu không có lô hàng mẫu: chạy `$env:EXPORT_DOCS_LOAD_DEMO = "0"` trước bước 3.
- macOS / Linux: dùng `python3.12 -m venv .venv`, `.venv/bin/python -m pip install -r requirements.txt` và
  `.venv/bin/python app.py`.
- Ứng dụng không có đăng nhập. Trên máy tính, ứng dụng chỉ mở được từ chính máy này (`127.0.0.1`).

### Chạy trên Google Colab

Không cần cài gì vào máy, dữ liệu lưu trong Google Drive. Làm theo hướng dẫn **[COLAB_GUIDE.md](COLAB_GUIDE.md)**
và notebook **[ExportDocs_Colab.ipynb](ExportDocs_Colab.ipynb)**. Trên Colab, ứng dụng mở qua một **link công khai**
và **không có đăng nhập**: ai có link đều mở được, nên đừng gửi link cho người ngoài.

File `ExportDocs_app.zip` mà hướng dẫn nhắc tới được tạo từ mã nguồn này bằng lệnh:

```powershell
.venv\Scripts\python.exe tools\build_colab.py      # → thư mục dist\
```

### Dữ liệu được lưu ở đâu?

Toàn bộ dữ liệu nằm trong **một thư mục dữ liệu**:

| Chạy ở đâu | Thư mục dữ liệu |
|---|---|
| Máy tính | thư mục `data\` bên cạnh `app.py` (tự tạo) |
| Google Colab | `My Drive/ExportDocs_data` trên Google Drive |

Bên trong thư mục dữ liệu:

| Thư mục | Nội dung |
|---|---|
| `database/` | cơ sở dữ liệu SQLite (lô hàng, chứng từ, lịch sử) |
| `pdfs/` | các PDF đã tạo, mỗi lô hàng một thư mục |
| `uploads/` | file tải lên (xác nhận của cảng, hãng tàu …) |
| `exports/` | file xuất (PDF gộp, ZIP, JSON) |
| `backups/` | bản sao lưu (Cài đặt → Sao lưu & khôi phục) |

- **Đổi thư mục dữ liệu:** đặt biến môi trường `EXPORT_DOCS_DATA_DIR` trước khi chạy, ví dụ
  `$env:EXPORT_DOCS_DATA_DIR = "D:\ExportDocs_data"`.
- **Đổi cổng:** `EXPORT_DOCS_PORT`, ví dụ `7861`.
- **Sao lưu:** vào **Cài đặt → 💾 Tạo bản sao lưu ngay**. Bản sao lưu là một file ZIP gồm cơ sở dữ liệu và mọi file.
  Nên sao lưu thường xuyên và giữ một bản ở nơi khác.

### Nội dung gói mã nguồn

| File / thư mục | Nội dung |
|---|---|
| `app.py` | khởi động ứng dụng |
| `export_docs/` | mã ứng dụng; `export_docs/assets/fonts/` chứa phông Noto Sans và giấy phép `OFL.txt` (SIL Open Font License) |
| `requirements.txt` | thư viện Python, phiên bản cố định |
| `VERSION` | số phiên bản |
| `COLAB_GUIDE.md`, `ExportDocs_Colab.ipynb`, `tools/build_colab.py` | bản Google Colab |
| `REQUIREMENTS.md` | đặc tả yêu cầu |
| `DEVELOPER.md` | ghi chú kỹ thuật (tiếng Anh): cấu trúc mã, các bảng dữ liệu, cách chạy kiểm thử |
| `tests/`, `TEST_REPORT.md` | kiểm thử tự động (chỉ tạo lô hàng THỬ mã `TEST-…` trong thư mục tạm) và báo cáo kiểm thử |

---

## English

### What is this app?

**EXPORT DOCS MANAGEMENT** is a browser-based system for managing export container documents. Each shipment is
entered **once** (master data) and reused across all 6 document steps:

1. Booking Confirmation
2. Empty Container EIR
3. VGM Declaration
4. Shipping Instruction (SI)
5. Export Gate-in & Loading Registration
6. Bill of Lading (B/L)

It also includes:
- cross-document checks (Validation Center)
- history and versions of every document
- PDF export (single documents, one combined PDF, ZIP, JSON)
- a document library and file uploads
- backup and restore

PDFs use an embedded Vietnamese-capable font (Noto Sans, included).

The app **never invents** booking numbers, depot EIR numbers, B/L numbers, signatures or stamps. Those must come
from the carrier's, port's or depot's real documents. Sample data is always marked **SAMPLE / DEMO**.

### Run it locally (Windows)

**Requires:** Python **3.12** (tested with 3.12; 3.11–3.13 work), from <https://www.python.org/downloads/>.
Tick *“Add python.exe to PATH”* when installing.

**Unzip into a folder with a short path**, for example `C:\ExportDocs`. Windows limits file paths to 260
characters, so installing the libraries in a deeply nested folder can fail with *“No such file or directory”*.

Open **PowerShell** in the unzipped folder (the folder that contains `app.py`) and run:

```powershell
# 1. Create a virtual environment (once)
py -3.12 -m venv .venv

# 2. Install the libraries (once, about 1–3 minutes)
.venv\Scripts\python.exe -m pip install -r requirements.txt

# 3. Start the app (every time)
.venv\Scripts\python.exe app.py
```

Then open **http://127.0.0.1:7860** in your browser. Stop the app with `Ctrl+C` in the PowerShell window.

- On the first start the app creates the database and one sample shipment **SHP-2026-0001** (SAMPLE / DEMO).
  To start without it, run `$env:EXPORT_DOCS_LOAD_DEMO = "0"` before step 3.
- macOS / Linux: use `python3.12 -m venv .venv`, `.venv/bin/python -m pip install -r requirements.txt` and
  `.venv/bin/python app.py`.
- The app has no login. On a computer it only answers on that same computer (`127.0.0.1`).

### Run it on Google Colab

Nothing to install, and the data is kept in Google Drive. Follow **[COLAB_GUIDE.md](COLAB_GUIDE.md)** (Vietnamese)
and the notebook **[ExportDocs_Colab.ipynb](ExportDocs_Colab.ipynb)**. On Colab the app opens through a **public link**
and has **no login**: anyone with the link can open it, so don't share the link with outsiders.

The `ExportDocs_app.zip` that the guide mentions is built from this source code with:

```powershell
.venv\Scripts\python.exe tools\build_colab.py      # → dist\ folder
```

### Where is the data stored?

All data lives in **one data folder**:

| Running on | Data folder |
|---|---|
| Your computer | `data\` next to `app.py` (created automatically) |
| Google Colab | `My Drive/ExportDocs_data` on Google Drive |

Inside the data folder:

| Folder | Contents |
|---|---|
| `database/` | SQLite database (shipments, documents, history) |
| `pdfs/` | generated PDFs, one folder per shipment |
| `uploads/` | uploaded files (port / carrier confirmations …) |
| `exports/` | exports (combined PDF, ZIP, JSON) |
| `backups/` | backups (Settings → Backup & restore) |

- **Use another data folder:** set the environment variable `EXPORT_DOCS_DATA_DIR` before starting, for example
  `$env:EXPORT_DOCS_DATA_DIR = "D:\ExportDocs_data"`.
- **Use another port:** set `EXPORT_DOCS_PORT`, for example `7861`.
- **Back up:** go to **Settings → 💾 Tạo bản sao lưu ngay**. A backup is one ZIP file with the database and every
  file. Back up regularly and keep a copy somewhere else.

### What is in this source package

| File / folder | Contents |
|---|---|
| `app.py` | starts the app |
| `export_docs/` | the app code; `export_docs/assets/fonts/` holds the Noto Sans fonts and their licence `OFL.txt` (SIL Open Font License) |
| `requirements.txt` | Python libraries, pinned versions |
| `VERSION` | version number |
| `COLAB_GUIDE.md`, `ExportDocs_Colab.ipynb`, `tools/build_colab.py` | the Google Colab version |
| `REQUIREMENTS.md` | requirements specification |
| `DEVELOPER.md` | technical notes: code structure, database tables, how to run the tests |
| `tests/`, `TEST_REPORT.md` | automated tests (they only create `TEST-…` shipments in a temporary folder) and the test report |
