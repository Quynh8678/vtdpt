# Hướng dẫn chạy EXPORT DOCS MANAGEMENT trên Google Colab

Ứng dụng chạy trên **Google Colab** (máy chủ miễn phí của Google) và mở được bằng trình duyệt trên máy tính hoặc
điện thoại. **Dữ liệu được lưu trong Google Drive của bạn**, nên không mất khi Colab dừng.

Bạn cần: một tài khoản Google (Gmail) và trình duyệt Chrome / Edge / Firefox. Không cần cài gì vào máy.

---

## Bước 1 — Chuẩn bị (chỉ làm một lần)

Bạn nhận được 3 file: `ExportDocs_app.zip`, `ExportDocs_Colab.ipynb` và hướng dẫn này.

1. Mở **Google Drive**: <https://drive.google.com> (đăng nhập tài khoản Google của bạn).
2. Trong **Drive của tôi (My Drive)**, bấm **+ Mới → Thư mục mới**, đặt tên đúng là **`ExportDocs_app`** → **Tạo**.
3. Mở thư mục `ExportDocs_app` vừa tạo, kéo thả 2 file **`ExportDocs_app.zip`** và **`ExportDocs_Colab.ipynb`**
   vào đó (hoặc bấm **+ Mới → Tải tệp lên**).
   - **Không giải nén** file ZIP. Notebook tự giải nén mỗi lần chạy.
   - Tên thư mục và tên file phải đúng như trên (chữ hoa / thường không quan trọng với file ZIP, nhưng nên giữ nguyên).

Thư mục dữ liệu **`ExportDocs_data`** sẽ được tạo tự động trong Drive ở lần chạy đầu tiên. Bạn không cần tạo.

Kết quả trên Drive:

```
Drive của tôi/
├── ExportDocs_app/          ← mã ứng dụng (bạn tải lên)
│   ├── ExportDocs_app.zip
│   └── ExportDocs_Colab.ipynb
└── ExportDocs_data/         ← DỮ LIỆU (tự tạo): lô hàng, PDF, file tải lên, bản sao lưu
```

## Bước 2 — Mở notebook

1. Trên Google Drive, mở thư mục `ExportDocs_app` và **bấm đúp** vào `ExportDocs_Colab.ipynb`.
2. Chọn **Mở bằng → Google Colaboratory**.
   - Nếu không thấy *Google Colaboratory*: bấm **Kết nối thêm ứng dụng**, tìm “Colaboratory”, bấm **Cài đặt**,
     rồi làm lại bước 2.
3. Notebook mở ra với các ô đánh số **1️⃣ → 6️⃣**.

## Bước 3 — Chạy các ô theo thứ tự

Bấm nút **▶** bên trái từng ô. **Chờ ô chạy xong** (thấy dấu ✅ ở cuối kết quả) rồi mới chạy ô tiếp theo.

| Ô | Việc ô làm | Bạn cần làm gì |
|---|------------|----------------|
| 1️⃣ Cài thư viện | Cài các thư viện ứng dụng cần, đúng phiên bản đã kiểm tra (1–2 phút) | Lần đầu Colab có thể hỏi *“Notebook này không phải do Google tạo”* → bấm **Vẫn chạy (Run anyway)**. Chữ đỏ *dependency conflicts* là **bình thường**. Nếu ô báo **cần khởi động lại**: menu **Runtime → Restart session**, rồi chạy lại từ ô 1. |
| 2️⃣ Kết nối Google Drive | Kết nối Drive, tạo thư mục `ExportDocs_data` | Chọn tài khoản Google của bạn → **Cho phép (Allow)** ở mọi câu hỏi quyền truy cập. |
| 3️⃣ Lấy mã ứng dụng | Giải nén `ExportDocs_app.zip` (có sẵn phông chữ tiếng Việt) và in **“Phiên bản ứng dụng: …”** | Không cần làm gì. |
| 4️⃣ Mở dữ liệu | Khóa dữ liệu cho phiên này, chép cơ sở dữ liệu từ Drive, tạo / nâng cấp bảng, in số lô hàng | Không cần làm gì (xem phần **Khóa dữ liệu** nếu có cảnh báo ⛔). |
| 5️⃣ Lô hàng MẪU (tùy chọn) | Mặc định **TẮT** | Muốn có lô hàng mẫu SHP-2026-0001 (**SAMPLE / DEMO**, dữ liệu giả để tập dùng): đánh dấu ô **TAI_DU_LIEU_MAU** rồi chạy. Không cần thì bỏ qua. |
| 6️⃣ Mở ứng dụng | In ra **đường link công khai** | Bấm vào link (xem Bước 4). |

Cách nhanh: menu **Runtime → Run all** (chạy tất cả). Vẫn phải bấm **Cho phép** khi ô 2 hỏi quyền Drive.

## Bước 4 — Mở ứng dụng

Khi ô 6 chạy xong phần khởi động, bạn sẽ thấy:

```
========================================================================
✅ ỨNG DỤNG ĐANG CHẠY. Mở đường link này (bấm vào, hoặc sao chép):

    https://xxxxxxxxxxxxxxxx.gradio.live
========================================================================
👉 Mở EXPORT DOCS MANAGEMENT
```

- Bấm vào link → ứng dụng mở trong thẻ mới của trình duyệt. Có thể gửi link sang điện thoại của chính bạn để mở.
- Ô 6 **vẫn hiện biểu tượng đang chạy** (vòng tròn quay): đó là bình thường. Ứng dụng chạy chừng nào ô còn chạy.
- **Ứng dụng không có đăng nhập: ai có link đều mở được ứng dụng và dữ liệu.** Đừng gửi link cho người ngoài.
  Khi không dùng nữa, bấm **■** ở ô 6 để tắt link.
- Đầu trang ứng dụng ghi **“Phiên bản …”**, giống số phiên bản ô 3 in ra.
- Lần đầu: vào **Cài đặt** và nhập **Người dùng hiện tại** (tên của bạn), để lịch sử ghi đúng người sửa.

## Khi Colab dừng — điều cần biết

- **Link chỉ hoạt động khi notebook đang chạy.** Đóng Colab, bấm ■, hoặc Colab ngắt kết nối thì link ngừng hoạt động.
- **Link hết hạn sau một thời gian.** Mỗi lần chạy ô 6 sẽ có một link **mới**; link cũ không dùng lại được.
- **Colab tự ngắt các phiên không hoạt động.** Bản miễn phí ngắt khi notebook không có thao tác một thời gian
  (thường khoảng 90 phút), và một phiên không chạy quá khoảng 12 giờ. Google có thể thay đổi các con số này.
  Mẹo: để thẻ Colab mở trong lúc làm việc.
- **Nếu link không vào được nữa:**
  1. Quay lại thẻ Colab.
  2. Nếu ô 6 vẫn đang chạy: bấm **■** ở ô 6, rồi bấm **▶** chạy lại ô 6 → có link mới.
  3. Nếu Colab báo đã ngắt kết nối (*Disconnected* / *Runtime disconnected*): bấm **Kết nối lại (Reconnect)**,
     rồi chạy lại các ô **1 → 6**.
- **Dữ liệu vẫn an toàn trên Drive.** Ứng dụng chép cơ sở dữ liệu lên Drive khoảng 1 giây sau **mỗi lần lưu**.
  File PDF và file tải lên được ghi thẳng vào Drive. Lần chạy sau, ô 4 in ra đúng số lô hàng như trước.
  Chỉ một thao tác lưu đúng vào giây Colab bị ngắt mới có thể bị mất.
- **Dừng đúng cách** khi làm xong: bấm **■** ở ô 6. Ô sẽ in *“✅ Đã dừng. Dữ liệu đã được chép lên Drive …”*.

## Khóa dữ liệu (chỉ một phiên Colab một lúc)

Khi ứng dụng chạy, thư mục `ExportDocs_data` có file **`ExportDocs_DANG_MO.lock`**. File này ngăn một phiên Colab
khác (thẻ khác, máy khác, người khác dùng chung Drive) mở **cùng dữ liệu** một lúc, để không ghi đè lên nhau.

Nếu dữ liệu đang mở ở nơi khác, ô 4 báo:

```
⛔  DỮ LIỆU ĐANG ĐƯỢC MỞ Ở MỘT PHIÊN COLAB KHÁC
```

Cách xử lý:

1. Ở phiên Colab kia: bấm **■** ở ô 6, hoặc menu **Runtime → Disconnect and delete runtime**. Rồi chạy lại ô 4 ở đây.
2. Nếu phiên kia đã bị ngắt kết nối: khóa **tự hết hạn sau 15 phút** không hoạt động. Chờ rồi chạy lại ô 4.
3. Chỉ khi **chắc chắn** không còn phiên nào khác: ở ô 4 đánh dấu **MO_KHOA_CU** rồi chạy lại ô 4.
   (Nếu hai phiên cùng chạy, phiên đến sau sẽ ghi đè thay đổi của phiên trước.)

Khởi động lại trên **cùng** máy Colab (*Runtime → Restart session*) không bị chặn: ô 4 tự nhận lại khóa của chính bạn.

## Sao lưu và khôi phục

**Sao lưu** (nên làm mỗi tuần và trước khi cập nhật phiên bản):

1. Trong ứng dụng: **Cài đặt → Sao lưu & khôi phục → 💾 Tạo bản sao lưu ngay**.
2. File `ExportDocs_backup_<ngày-giờ>.zip` được lưu trong `ExportDocs_data/backups/` trên Drive. File gồm cơ sở
   dữ liệu, PDF, file tải lên và file xuất.
3. Bấm vào file vừa tạo để **tải về máy tính**. Nên giữ một bản ngoài Google Drive (phòng khi xóa nhầm trên Drive).

**Khôi phục** (Cài đặt → Sao lưu & khôi phục):

1. Chọn file sao lưu `.zip` (từ máy tính).
2. Chọn nơi khôi phục:
   - **Thư mục MỚI** (an toàn): dữ liệu được khôi phục vào thư mục mới, mặc định
     `MyDrive/ExportDocs_data_restored`. Dữ liệu hiện tại không đổi. Muốn mở dữ liệu đó: bấm ■ ở ô 6,
     **Runtime → Restart session**, ở ô 2 đổi **THU_MUC_DU_LIEU** thành thư mục mới, rồi chạy lại ô 1 → 6.
   - **THAY dữ liệu hiện tại**: đánh dấu ô xác nhận. Ứng dụng **tự sao lưu dữ liệu hiện tại trước**
     (vào `backups/`), rồi thay bằng bản sao lưu. Bấm sang trang khác (VD: Tổng quan) để xem dữ liệu đã khôi phục.
3. Bấm **♻️ Khôi phục**.

Cách khác: khi ứng dụng **đã dừng** (đã bấm ■), bạn có thể chép / tải về cả thư mục `ExportDocs_data` trên Drive.
Đó cũng là một bản sao lưu đầy đủ.

## Cập nhật phiên bản mới

1. **Tạo bản sao lưu** (xem trên), rồi bấm **■** ở ô 6.
2. Trên Drive, mở `ExportDocs_app`, tải file `ExportDocs_app.zip` mới lên. Nếu Drive hỏi, chọn **Thay thế tệp hiện có**.
   Nếu notebook mới cũng được gửi kèm, thay luôn `ExportDocs_Colab.ipynb`.
3. Trong Colab: **Runtime → Restart session**, rồi chạy lại ô **1 → 6**. Ô 3 in **“Phiên bản ứng dụng: …”** của bản mới.
   Có nhiều file ZIP trong thư mục thì ô 3 tự dùng bản có phiên bản mới nhất.

Dữ liệu trong `ExportDocs_data` giữ nguyên. Bản mới tự nâng cấp bảng mà không xóa dữ liệu.

## Lỗi thường gặp

| Thông báo | Cách xử lý |
|-----------|------------|
| ⛔ Không tìm thấy file ExportDocs_app.zip | Kiểm tra file ZIP nằm trong **Drive của tôi → ExportDocs_app** (đúng tên thư mục), rồi chạy lại ô 3. |
| ⚠️ Colab cần KHỞI ĐỘNG LẠI một lần | **Runtime → Restart session**, rồi chạy lại từ ô 1. |
| ⛔ Hãy chạy ô 2 và ô 3 trước / ô 4 trước | Chạy các ô theo đúng thứ tự từ ô 1. |
| ⛔ DỮ LIỆU ĐANG ĐƯỢC MỞ Ở MỘT PHIÊN COLAB KHÁC | Xem phần **Khóa dữ liệu**. |
| ⛔ Chưa tạo được link công khai | Mạng của Gradio đang bận: chờ 1–2 phút rồi chạy lại ô 6. |
| Link mở ra báo lỗi / không tải được | Ô 6 còn chạy không? Nếu không: chạy lại ô 6 (hoặc ô 1 → 6 nếu Colab đã ngắt). |
| ⚠️ Chưa chép được lên Drive | Drive tạm thời lỗi; ứng dụng tự thử lại sau lần lưu tiếp theo. Nếu báo mãi: tạo bản sao lưu và tải về máy. |

## Lưu ý về dữ liệu

- Ứng dụng **không tự tạo** số booking, số EIR của depot, số B/L, chữ ký hay con dấu. Những số đó phải lấy từ
  chứng từ thật của hãng tàu / cảng / depot.
- Lô hàng mẫu (SHP-2026-0001) và lô hàng thử (mã TEST-…) luôn được ghi rõ **SAMPLE / DEMO** hoặc **SAMPLE / TEST**.
- Dữ liệu chỉ nằm trong Google Drive của bạn và trong máy Colab đang chạy.
